package adapters_test

import (
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/yhonda-ohishi/etc_meisai/src/adapters"
	"github.com/yhonda-ohishi/etc_meisai/src/models"
)

// Helper functions
func stringPtr(s string) *string {
	return &s
}

func int32Ptr(i int32) *int32 {
	return &i
}

func TestToCompat(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name     string
		meisai   *models.ETCMeisai
		wantNil  bool
		validate func(*testing.T, *adapters.ETCMeisaiCompat)
	}{
		{
			name:    "nil input",
			meisai:  nil,
			wantNil: true,
		},
		{
			name: "basic conversion",
			meisai: &models.ETCMeisai{
				ID:        123,
				UseDate:   time.Date(2024, 1, 15, 0, 0, 0, 0, time.UTC),
				UseTime:   "10:30:00",
				EntryIC:   "Tokyo IC",
				ExitIC:    "Osaka IC",
				Amount:    2500,
				CarNumber: "品川500あ1234",
				ETCNumber: "1234567890123456",
				Hash:      "abc123hash",
				CreatedAt: time.Date(2024, 1, 15, 10, 30, 0, 0, time.UTC),
				UpdatedAt: time.Date(2024, 1, 15, 10, 30, 0, 0, time.UTC),
			},
			validate: func(t *testing.T, got *adapters.ETCMeisaiCompat) {
				assert.Equal(t, int64(123), got.ID)
				assert.Equal(t, time.Date(2024, 1, 15, 0, 0, 0, 0, time.UTC), got.UseDate)
				assert.Equal(t, "10:30:00", got.UseTime)
				assert.Equal(t, "Tokyo IC", got.EntryIC)
				assert.Equal(t, "Osaka IC", got.ExitIC)
				assert.Equal(t, int32(2500), got.Amount)
				assert.Equal(t, "品川500あ1234", got.CarNumber)
				assert.Equal(t, "1234567890123456", got.ETCNumber)
				assert.Equal(t, "abc123hash", got.Hash)

				// Check legacy alias fields
				assert.NotNil(t, got.ICEntry)
				assert.Equal(t, "Tokyo IC", *got.ICEntry)
				assert.NotNil(t, got.ICExit)
				assert.Equal(t, "Osaka IC", *got.ICExit)
				assert.NotNil(t, got.TollAmount)
				assert.Equal(t, int32(2500), *got.TollAmount)
				assert.NotNil(t, got.UsageDate)
				assert.Equal(t, "2024-01-15", *got.UsageDate)
				assert.NotNil(t, got.UsageTime)
				assert.Equal(t, "10:30:00", *got.UsageTime)
				assert.NotNil(t, got.ETCCardNum)
				assert.Equal(t, "1234567890123456", *got.ETCCardNum)
				assert.NotNil(t, got.VehicleNum)
				assert.Equal(t, "品川500あ1234", *got.VehicleNum)
			},
		},
		{
			name: "zero amount conversion",
			meisai: &models.ETCMeisai{
				ID:        456,
				UseDate:   time.Date(2024, 2, 20, 0, 0, 0, 0, time.UTC),
				UseTime:   "14:45:30",
				EntryIC:   "Nagoya IC",
				ExitIC:    "Kyoto IC",
				Amount:    0,
				CarNumber: "名古屋300た5678",
				ETCNumber: "9876543210987654",
				Hash:      "xyz789hash",
			},
			validate: func(t *testing.T, got *adapters.ETCMeisaiCompat) {
				assert.Equal(t, int64(456), got.ID)
				assert.Equal(t, int32(0), got.Amount)
				assert.NotNil(t, got.TollAmount)
				assert.Equal(t, int32(0), *got.TollAmount)
				assert.NotNil(t, got.TotalAmount)
				assert.Equal(t, int32(0), *got.TotalAmount)
			},
		},
	}

	adapter := adapters.NewETCMeisaiCompatAdapter()
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := adapter.ToCompat(tt.meisai)
			if tt.wantNil {
				assert.Nil(t, got)
			} else {
				assert.NotNil(t, got)
				if tt.validate != nil {
					tt.validate(t, got)
				}
			}
		})
	}
}

func TestFromCompat(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name     string
		compat   *adapters.ETCMeisaiCompat
		wantNil  bool
		validate func(*testing.T, *models.ETCMeisai)
	}{
		{
			name:    "nil input",
			compat:  nil,
			wantNil: true,
		},
		{
			name: "basic conversion from core fields",
			compat: &adapters.ETCMeisaiCompat{
				ID:        456,
				UseDate:   time.Date(2024, 2, 20, 0, 0, 0, 0, time.UTC),
				UseTime:   "14:45:30",
				EntryIC:   "Nagoya IC",
				ExitIC:    "Kyoto IC",
				Amount:    1800,
				CarNumber: "名古屋300た5678",
				ETCNumber: "9876543210987654",
				Hash:      "xyz789hash",
				CreatedAt: time.Date(2024, 2, 20, 14, 45, 30, 0, time.UTC),
				UpdatedAt: time.Date(2024, 2, 20, 14, 45, 30, 0, time.UTC),
			},
			validate: func(t *testing.T, got *models.ETCMeisai) {
				assert.Equal(t, int64(456), got.ID)
				assert.Equal(t, time.Date(2024, 2, 20, 0, 0, 0, 0, time.UTC), got.UseDate)
				assert.Equal(t, "14:45:30", got.UseTime)
				assert.Equal(t, "Nagoya IC", got.EntryIC)
				assert.Equal(t, "Kyoto IC", got.ExitIC)
				assert.Equal(t, int32(1800), got.Amount)
				assert.Equal(t, "名古屋300た5678", got.CarNumber)
				assert.Equal(t, "9876543210987654", got.ETCNumber)
				assert.Equal(t, "xyz789hash", got.Hash)
			},
		},
		{
			name: "conversion from legacy fields only",
			compat: &adapters.ETCMeisaiCompat{
				ID:          789,
				ICEntry:     stringPtr("Legacy Entry"),
				ICExit:      stringPtr("Legacy Exit"),
				UsageDate:   stringPtr("2024-03-15"),
				UsageTime:   stringPtr("09:15:00"),
				ETCCardNum:  stringPtr("1111222233334444"),
				VehicleNum:  stringPtr("大阪400な9999"),
				TollAmount:  int32Ptr(3200),
				Hash:        "legacy_hash",
				CreatedAt:   time.Date(2024, 3, 15, 9, 15, 0, 0, time.UTC),
				UpdatedAt:   time.Date(2024, 3, 15, 9, 15, 0, 0, time.UTC),
			},
			validate: func(t *testing.T, got *models.ETCMeisai) {
				assert.Equal(t, int64(789), got.ID)
				assert.Equal(t, "Legacy Entry", got.EntryIC)
				assert.Equal(t, "Legacy Exit", got.ExitIC)
				assert.Equal(t, time.Date(2024, 3, 15, 0, 0, 0, 0, time.UTC), got.UseDate)
				assert.Equal(t, "09:15:00", got.UseTime)
				assert.Equal(t, "1111222233334444", got.ETCNumber)
				assert.Equal(t, "大阪400な9999", got.CarNumber)
				assert.Equal(t, int32(3200), got.Amount)
				assert.Equal(t, "legacy_hash", got.Hash)
			},
		},
		{
			name: "mixed core and legacy fields (legacy overrides)",
			compat: &adapters.ETCMeisaiCompat{
				ID:         999,
				UseDate:    time.Date(2024, 4, 10, 0, 0, 0, 0, time.UTC),
				UseTime:    "11:22:33",
				EntryIC:    "Core Entry",
				ExitIC:     "Core Exit",
				Amount:     4500,
				CarNumber:  "京都500む1111",
				ETCNumber:  "5555666677778888",
				// Legacy fields that should be ignored
				ICEntry:    stringPtr("Should be ignored"),
				ICExit:     stringPtr("Should be ignored"),
				UsageDate:  stringPtr("2023-01-01"),
				UsageTime:  stringPtr("00:00:00"),
				ETCCardNum: stringPtr("0000000000000000"),
				VehicleNum: stringPtr("ignored"),
				TollAmount: int32Ptr(9999),
				Hash:       "mixed_hash",
			},
			validate: func(t *testing.T, got *models.ETCMeisai) {
				assert.Equal(t, int64(999), got.ID)
				// Legacy fields override core fields in current implementation
				assert.Equal(t, "Should be ignored", got.EntryIC)
				assert.Equal(t, "Should be ignored", got.ExitIC)
				assert.Equal(t, time.Date(2023, 1, 1, 0, 0, 0, 0, time.UTC), got.UseDate)
				assert.Equal(t, "00:00:00", got.UseTime)
				assert.Equal(t, "0000000000000000", got.ETCNumber)
				assert.Equal(t, "ignored", got.CarNumber)
				assert.Equal(t, int32(9999), got.Amount)
			},
		},
	}

	adapter := adapters.NewETCMeisaiCompatAdapter()
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := adapter.FromCompat(tt.compat)
			if tt.wantNil {
				assert.Nil(t, got)
			} else {
				assert.NotNil(t, got)
				if tt.validate != nil {
					tt.validate(t, got)
				}
			}
		})
	}
}

func TestToCompatList(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   []*models.ETCMeisai
		wantLen int
	}{
		{
			name:    "nil input",
			input:   nil,
			wantLen: 0,
		},
		{
			name:    "empty slice",
			input:   []*models.ETCMeisai{},
			wantLen: 0,
		},
		{
			name: "multiple items",
			input: []*models.ETCMeisai{
				{
					ID:        1,
					UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
					UseTime:   "08:00:00",
					EntryIC:   "Entry1",
					ExitIC:    "Exit1",
					Amount:    1000,
					CarNumber: "Car1",
					ETCNumber: "ETC1",
					Hash:      "hash1",
				},
				{
					ID:        2,
					UseDate:   time.Date(2024, 1, 2, 0, 0, 0, 0, time.UTC),
					UseTime:   "09:00:00",
					EntryIC:   "Entry2",
					ExitIC:    "Exit2",
					Amount:    2000,
					CarNumber: "Car2",
					ETCNumber: "ETC2",
					Hash:      "hash2",
				},
			},
			wantLen: 2,
		},
	}

	adapter := adapters.NewETCMeisaiCompatAdapter()
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := adapter.ToCompatList(tt.input)
			if tt.input == nil {
				assert.Nil(t, got)
			} else {
				assert.Len(t, got, tt.wantLen)
				for i, item := range tt.input {
					assert.Equal(t, item.ID, got[i].ID)
					assert.Equal(t, item.EntryIC, got[i].EntryIC)
					assert.Equal(t, item.ETCNumber, got[i].ETCNumber)
				}
			}
		})
	}
}

func TestFromCompatList(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   []*adapters.ETCMeisaiCompat
		wantLen int
	}{
		{
			name:    "nil input",
			input:   nil,
			wantLen: 0,
		},
		{
			name:    "empty slice",
			input:   []*adapters.ETCMeisaiCompat{},
			wantLen: 0,
		},
		{
			name: "multiple items",
			input: []*adapters.ETCMeisaiCompat{
				{
					ID:        1,
					UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
					UseTime:   "08:00:00",
					EntryIC:   "Entry1",
					ExitIC:    "Exit1",
					Amount:    1000,
					CarNumber: "Car1",
					ETCNumber: "ETC1",
					Hash:      "hash1",
				},
				{
					ID:        2,
					UseDate:   time.Date(2024, 1, 2, 0, 0, 0, 0, time.UTC),
					UseTime:   "09:00:00",
					EntryIC:   "Entry2",
					ExitIC:    "Exit2",
					Amount:    2000,
					CarNumber: "Car2",
					ETCNumber: "ETC2",
					Hash:      "hash2",
				},
			},
			wantLen: 2,
		},
	}

	adapter := adapters.NewETCMeisaiCompatAdapter()
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := adapter.FromCompatList(tt.input)
			if tt.input == nil {
				assert.Nil(t, got)
			} else {
				assert.Len(t, got, tt.wantLen)
				for i, item := range tt.input {
					assert.Equal(t, item.ID, got[i].ID)
					assert.Equal(t, item.EntryIC, got[i].EntryIC)
					assert.Equal(t, item.ETCNumber, got[i].ETCNumber)
				}
			}
		})
	}
}

func TestConvertToStandardFormat(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name     string
		compat   *adapters.ETCMeisaiCompat
		wantNil  bool
		validate func(*testing.T, *adapters.ETCMeisaiCompat)
	}{
		{
			name:    "nil input",
			compat:  nil,
			wantNil: true,
		},
		{
			name: "normalize from legacy fields",
			compat: &adapters.ETCMeisaiCompat{
				ID:         123,
				ICEntry:    stringPtr("Legacy Entry IC"),
				ICExit:     stringPtr("Legacy Exit IC"),
				UsageDate:  stringPtr("2024-05-20"),
				UsageTime:  stringPtr("15:30:45"),
				VehicleNum: stringPtr("福岡300ら7890"),
				ETCCardNum: stringPtr("4444333322221111"),
				TollAmount: int32Ptr(2800),
			},
			validate: func(t *testing.T, got *adapters.ETCMeisaiCompat) {
				assert.Equal(t, "Legacy Entry IC", got.EntryIC)
				assert.Equal(t, "Legacy Exit IC", got.ExitIC)
				assert.Equal(t, time.Date(2024, 5, 20, 0, 0, 0, 0, time.UTC), got.UseDate)
				assert.Equal(t, "15:30:45", got.UseTime)
				assert.Equal(t, "福岡300ら7890", got.CarNumber)
				assert.Equal(t, "4444333322221111", got.ETCNumber)
				assert.Equal(t, int32(2800), got.Amount)
			},
		},
		{
			name: "already normalized",
			compat: &adapters.ETCMeisaiCompat{
				ID:        456,
				EntryIC:   "Already Normal Entry",
				ExitIC:    "Already Normal Exit",
				UseDate:   time.Date(2024, 6, 15, 0, 0, 0, 0, time.UTC),
				UseTime:   "12:00:00",
				CarNumber: "標準500せ1234",
				ETCNumber: "9999888877776666",
				Amount:    3500,
			},
			validate: func(t *testing.T, got *adapters.ETCMeisaiCompat) {
				assert.Equal(t, "Already Normal Entry", got.EntryIC)
				assert.Equal(t, "Already Normal Exit", got.ExitIC)
				assert.Equal(t, time.Date(2024, 6, 15, 0, 0, 0, 0, time.UTC), got.UseDate)
				assert.Equal(t, "12:00:00", got.UseTime)
				assert.Equal(t, "標準500せ1234", got.CarNumber)
				assert.Equal(t, "9999888877776666", got.ETCNumber)
				assert.Equal(t, int32(3500), got.Amount)
			},
		},
	}

	adapter := adapters.NewETCMeisaiCompatAdapter()
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := adapter.ConvertToStandardFormat(tt.compat)
			if tt.wantNil {
				assert.Nil(t, got)
			} else {
				assert.NotNil(t, got)
				if tt.validate != nil {
					tt.validate(t, got)
				}
			}
		})
	}
}

func TestGetActualMethods(t *testing.T) {
	t.Parallel()

	t.Run("GetActualAmount", func(t *testing.T) {
		tests := []struct {
			name   string
			compat *adapters.ETCMeisaiCompat
			want   int32
		}{
			{
				name:   "from Amount field",
				compat: &adapters.ETCMeisaiCompat{Amount: 1000},
				want:   1000,
			},
			{
				name:   "from TollAmount field",
				compat: &adapters.ETCMeisaiCompat{TollAmount: int32Ptr(2000)},
				want:   2000,
			},
			{
				name:   "from TotalAmount field",
				compat: &adapters.ETCMeisaiCompat{TotalAmount: int32Ptr(3000)},
				want:   3000,
			},
			{
				name:   "Amount takes precedence",
				compat: &adapters.ETCMeisaiCompat{Amount: 1000, TollAmount: int32Ptr(2000)},
				want:   1000,
			},
			{
				name:   "zero when all empty",
				compat: &adapters.ETCMeisaiCompat{},
				want:   0,
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				got := tt.compat.GetActualAmount()
				assert.Equal(t, tt.want, got)
			})
		}
	})

	t.Run("GetActualETCNumber", func(t *testing.T) {
		tests := []struct {
			name   string
			compat *adapters.ETCMeisaiCompat
			want   string
		}{
			{
				name:   "from ETCNumber field",
				compat: &adapters.ETCMeisaiCompat{ETCNumber: "1111"},
				want:   "1111",
			},
			{
				name:   "from ETCCardNum field",
				compat: &adapters.ETCMeisaiCompat{ETCCardNum: stringPtr("2222")},
				want:   "2222",
			},
			{
				name:   "from ETCCardNumber field",
				compat: &adapters.ETCMeisaiCompat{ETCCardNumber: stringPtr("3333")},
				want:   "3333",
			},
			{
				name:   "ETCNumber takes precedence",
				compat: &adapters.ETCMeisaiCompat{ETCNumber: "1111", ETCCardNum: stringPtr("2222")},
				want:   "1111",
			},
			{
				name:   "empty when all empty",
				compat: &adapters.ETCMeisaiCompat{},
				want:   "",
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				got := tt.compat.GetActualETCNumber()
				assert.Equal(t, tt.want, got)
			})
		}
	})

	t.Run("GetActualVehicleNumber", func(t *testing.T) {
		tests := []struct {
			name   string
			compat *adapters.ETCMeisaiCompat
			want   string
		}{
			{
				name:   "from CarNumber field",
				compat: &adapters.ETCMeisaiCompat{CarNumber: "Car1"},
				want:   "Car1",
			},
			{
				name:   "from VehicleNum field",
				compat: &adapters.ETCMeisaiCompat{VehicleNum: stringPtr("Vehicle2")},
				want:   "Vehicle2",
			},
			{
				name:   "from VehicleNumber field",
				compat: &adapters.ETCMeisaiCompat{VehicleNumber: stringPtr("Vehicle3")},
				want:   "Vehicle3",
			},
			{
				name:   "CarNumber takes precedence",
				compat: &adapters.ETCMeisaiCompat{CarNumber: "Car1", VehicleNum: stringPtr("Vehicle2")},
				want:   "Car1",
			},
			{
				name:   "empty when all empty",
				compat: &adapters.ETCMeisaiCompat{},
				want:   "",
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				got := tt.compat.GetActualVehicleNumber()
				assert.Equal(t, tt.want, got)
			})
		}
	})

	t.Run("GetActualEntryIC", func(t *testing.T) {
		tests := []struct {
			name   string
			compat *adapters.ETCMeisaiCompat
			want   string
		}{
			{
				name:   "from EntryIC field",
				compat: &adapters.ETCMeisaiCompat{EntryIC: "Entry1"},
				want:   "Entry1",
			},
			{
				name:   "from ICEntry field",
				compat: &adapters.ETCMeisaiCompat{ICEntry: stringPtr("Entry2")},
				want:   "Entry2",
			},
			{
				name:   "EntryIC takes precedence",
				compat: &adapters.ETCMeisaiCompat{EntryIC: "Entry1", ICEntry: stringPtr("Entry2")},
				want:   "Entry1",
			},
			{
				name:   "empty when all empty",
				compat: &adapters.ETCMeisaiCompat{},
				want:   "",
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				got := tt.compat.GetActualEntryIC()
				assert.Equal(t, tt.want, got)
			})
		}
	})

	t.Run("GetActualExitIC", func(t *testing.T) {
		tests := []struct {
			name   string
			compat *adapters.ETCMeisaiCompat
			want   string
		}{
			{
				name:   "from ExitIC field",
				compat: &adapters.ETCMeisaiCompat{ExitIC: "Exit1"},
				want:   "Exit1",
			},
			{
				name:   "from ICExit field",
				compat: &adapters.ETCMeisaiCompat{ICExit: stringPtr("Exit2")},
				want:   "Exit2",
			},
			{
				name:   "ExitIC takes precedence",
				compat: &adapters.ETCMeisaiCompat{ExitIC: "Exit1", ICExit: stringPtr("Exit2")},
				want:   "Exit1",
			},
			{
				name:   "empty when all empty",
				compat: &adapters.ETCMeisaiCompat{},
				want:   "",
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				got := tt.compat.GetActualExitIC()
				assert.Equal(t, tt.want, got)
			})
		}
	})
}

func TestRoundtripConversion(t *testing.T) {
	t.Parallel()

	adapter := adapters.NewETCMeisaiCompatAdapter()

	original := &models.ETCMeisai{
		ID:        999,
		UseDate:   time.Date(2024, 7, 30, 0, 0, 0, 0, time.UTC),
		UseTime:   "16:45:00",
		EntryIC:   "Sendai IC",
		ExitIC:    "Fukushima IC",
		Amount:    5500,
		CarNumber: "仙台700そ9876",
		ETCNumber: "1234123412341234",
		Hash:      "roundtrip_hash",
		CreatedAt: time.Date(2024, 7, 30, 16, 45, 0, 0, time.UTC),
		UpdatedAt: time.Date(2024, 7, 30, 16, 45, 0, 0, time.UTC),
	}

	// Convert to compat
	compat := adapter.ToCompat(original)
	assert.NotNil(t, compat)

	// Convert back to ETCMeisai
	restored := adapter.FromCompat(compat)
	assert.NotNil(t, restored)

	// Verify all fields match
	assert.Equal(t, original.ID, restored.ID)
	assert.Equal(t, original.UseDate, restored.UseDate)
	assert.Equal(t, original.UseTime, restored.UseTime)
	assert.Equal(t, original.EntryIC, restored.EntryIC)
	assert.Equal(t, original.ExitIC, restored.ExitIC)
	assert.Equal(t, original.Amount, restored.Amount)
	assert.Equal(t, original.CarNumber, restored.CarNumber)
	assert.Equal(t, original.ETCNumber, restored.ETCNumber)
	assert.Equal(t, original.Hash, restored.Hash)
	assert.Equal(t, original.CreatedAt, restored.CreatedAt)
	assert.Equal(t, original.UpdatedAt, restored.UpdatedAt)
}