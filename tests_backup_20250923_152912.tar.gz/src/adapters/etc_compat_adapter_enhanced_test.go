package adapters_test

import (
	"fmt"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"github.com/yhonda-ohishi/etc_meisai/src/adapters"
)

// T007-A: Comprehensive error handling tests for ETCCompatAdapter.ConvertToProto() with nil inputs
func TestETCCompatAdapter_ConvertToProto_ErrorHandling(t *testing.T) {
	t.Parallel()

	adapter := adapters.NewETCMeisaiCompatAdapter()

	t.Run("nil input returns error", func(t *testing.T) {
		proto, err := adapter.ConvertToProto(nil)
		assert.Error(t, err)
		assert.Nil(t, proto)
		assert.Contains(t, err.Error(), "compat cannot be nil")
	})

	t.Run("empty compat record", func(t *testing.T) {
		compat := &adapters.ETCMeisaiCompat{}
		proto, err := adapter.ConvertToProto(compat)
		assert.NoError(t, err)
		assert.NotNil(t, proto)

		// Verify zero values are handled correctly
		assert.Equal(t, int64(0), proto.Id)
		assert.Equal(t, "", proto.Hash)
		assert.Equal(t, "0001-01-01", proto.Date) // Zero time formatted
		assert.Equal(t, "", proto.Time)
		assert.Equal(t, "", proto.EntranceIc)
		assert.Equal(t, "", proto.ExitIc)
		assert.Equal(t, int32(0), proto.TollAmount)
		assert.Equal(t, "", proto.CarNumber)
		assert.Equal(t, "", proto.EtcCardNumber)
	})

	t.Run("compat record with invalid date", func(t *testing.T) {
		compat := &adapters.ETCMeisaiCompat{
			ID:      123,
			Hash:    "test_hash",
			UseDate: time.Time{}, // Zero time
		}
		proto, err := adapter.ConvertToProto(compat)
		assert.NoError(t, err)
		assert.NotNil(t, proto)
		assert.Equal(t, "0001-01-01", proto.Date)
	})

	t.Run("compat record with nil pointers in legacy fields", func(t *testing.T) {
		compat := &adapters.ETCMeisaiCompat{
			ID:           456,
			Hash:         "test_hash",
			UseDate:      time.Date(2024, 1, 15, 0, 0, 0, 0, time.UTC),
			UseTime:      "10:30:00",
			ICEntry:      nil, // Nil pointer
			ICExit:       nil, // Nil pointer
			ETCCardNum:   nil, // Nil pointer
			VehicleNum:   nil, // Nil pointer
			TollAmount:   nil, // Nil pointer
		}
		proto, err := adapter.ConvertToProto(compat)
		assert.NoError(t, err)
		assert.NotNil(t, proto)
		assert.Equal(t, int64(456), proto.Id)
		assert.Equal(t, "2024-01-15", proto.Date)
	})
}

func TestETCCompatAdapter_ConvertToProtoList_ErrorHandling(t *testing.T) {
	t.Parallel()

	adapter := adapters.NewETCMeisaiCompatAdapter()

	t.Run("nil input returns nil", func(t *testing.T) {
		protoList, err := adapter.ConvertToProtoList(nil)
		assert.NoError(t, err)
		assert.Nil(t, protoList)
	})

	t.Run("empty slice returns empty slice", func(t *testing.T) {
		protoList, err := adapter.ConvertToProtoList([]*adapters.ETCMeisaiCompat{})
		assert.NoError(t, err)
		assert.NotNil(t, protoList)
		assert.Len(t, protoList, 0)
	})

	t.Run("slice with nil element returns error", func(t *testing.T) {
		compatList := []*adapters.ETCMeisaiCompat{
			{ID: 1, Hash: "hash1"},
			nil, // Nil element
			{ID: 3, Hash: "hash3"},
		}
		protoList, err := adapter.ConvertToProtoList(compatList)
		assert.Error(t, err)
		assert.Nil(t, protoList)
		assert.Contains(t, err.Error(), "compat at index 1 cannot be nil")
	})

	t.Run("valid slice with multiple elements", func(t *testing.T) {
		compatList := []*adapters.ETCMeisaiCompat{
			{
				ID:        1,
				UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
				UseTime:   "08:00:00",
				EntryIC:   "Entry1",
				ExitIC:    "Exit1",
				Amount:    1000,
				CarNumber: "Car1",
				ETCNumber: "ETC1",
				Hash:      "hash1",
			},
			{
				ID:        2,
				UseDate:   time.Date(2024, 1, 2, 0, 0, 0, 0, time.UTC),
				UseTime:   "09:00:00",
				EntryIC:   "Entry2",
				ExitIC:    "Exit2",
				Amount:    2000,
				CarNumber: "Car2",
				ETCNumber: "ETC2",
				Hash:      "hash2",
			},
		}
		protoList, err := adapter.ConvertToProtoList(compatList)
		assert.NoError(t, err)
		assert.NotNil(t, protoList)
		assert.Len(t, protoList, 2)

		assert.Equal(t, int64(1), protoList[0].Id)
		assert.Equal(t, "2024-01-01", protoList[0].Date)
		assert.Equal(t, int64(2), protoList[1].Id)
		assert.Equal(t, "2024-01-02", protoList[1].Date)
	})
}

// T007-B: Field mapping validation testing with mismatched data types
func TestETCCompatAdapter_FieldMappingValidation(t *testing.T) {
	t.Parallel()

	adapter := adapters.NewETCMeisaiCompatAdapter()

	t.Run("string to int32 conversion for amount fields", func(t *testing.T) {
		// Test different amount field precedence
		tests := []struct {
			name     string
			compat   *adapters.ETCMeisaiCompat
			expected int32
		}{
			{
				name:     "Amount field takes precedence",
				compat:   &adapters.ETCMeisaiCompat{Amount: 1000, TollAmount: int32Ptr(2000), TotalAmount: int32Ptr(3000)},
				expected: 1000,
			},
			{
				name:     "TollAmount when Amount is zero",
				compat:   &adapters.ETCMeisaiCompat{Amount: 0, TollAmount: int32Ptr(2000), TotalAmount: int32Ptr(3000)},
				expected: 2000,
			},
			{
				name:     "TotalAmount when others are zero",
				compat:   &adapters.ETCMeisaiCompat{Amount: 0, TollAmount: int32Ptr(0), TotalAmount: int32Ptr(3000)},
				expected: 3000,
			},
			{
				name:     "Zero when all are zero or nil",
				compat:   &adapters.ETCMeisaiCompat{Amount: 0, TollAmount: nil, TotalAmount: nil},
				expected: 0,
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				proto, err := adapter.ConvertToProto(tt.compat)
				assert.NoError(t, err)
				assert.Equal(t, tt.expected, proto.TollAmount)
			})
		}
	})

	t.Run("string field mapping for ETC number", func(t *testing.T) {
		tests := []struct {
			name     string
			compat   *adapters.ETCMeisaiCompat
			expected string
		}{
			{
				name:     "ETCNumber field takes precedence",
				compat:   &adapters.ETCMeisaiCompat{ETCNumber: "1111", ETCCardNum: stringPtr("2222"), ETCCardNumber: stringPtr("3333")},
				expected: "1111",
			},
			{
				name:     "ETCCardNum when ETCNumber is empty",
				compat:   &adapters.ETCMeisaiCompat{ETCNumber: "", ETCCardNum: stringPtr("2222"), ETCCardNumber: stringPtr("3333")},
				expected: "2222",
			},
			{
				name:     "ETCCardNumber fallback",
				compat:   &adapters.ETCMeisaiCompat{ETCNumber: "", ETCCardNum: stringPtr(""), ETCCardNumber: stringPtr("3333")},
				expected: "3333",
			},
			{
				name:     "Empty when all are empty",
				compat:   &adapters.ETCMeisaiCompat{ETCNumber: "", ETCCardNum: stringPtr(""), ETCCardNumber: stringPtr("")},
				expected: "",
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				proto, err := adapter.ConvertToProto(tt.compat)
				assert.NoError(t, err)
				assert.Equal(t, tt.expected, proto.EtcCardNumber)
			})
		}
	})

	t.Run("time field validation and formatting", func(t *testing.T) {
		compat := &adapters.ETCMeisaiCompat{
			ID:      123,
			UseDate: time.Date(2024, 12, 25, 15, 30, 45, 0, time.UTC),
			UseTime: "14:30:45",
		}
		proto, err := adapter.ConvertToProto(compat)
		assert.NoError(t, err)
		assert.Equal(t, "2024-12-25", proto.Date)
		assert.Equal(t, "14:30:45", proto.Time)
	})

	t.Run("legacy field override behavior", func(t *testing.T) {
		compat := &adapters.ETCMeisaiCompat{
			ID:         456,
			EntryIC:    "Core Entry",
			ExitIC:     "Core Exit",
			Amount:     1000,
			CarNumber:  "Core Car",
			ETCNumber:  "Core ETC",
			// Legacy fields should override core fields in normalized format
			ICEntry:    stringPtr("Legacy Entry"),
			ICExit:     stringPtr("Legacy Exit"),
			TollAmount: int32Ptr(2000),
			VehicleNum: stringPtr("Legacy Car"),
			ETCCardNum: stringPtr("Legacy ETC"),
		}
		proto, err := adapter.ConvertToProto(compat)
		assert.NoError(t, err)

		// The ConvertToStandardFormat normalizes to use the "Get*" methods which prioritize core fields
		assert.Equal(t, "Core Entry", proto.EntranceIc)
		assert.Equal(t, "Core Exit", proto.ExitIc)
		assert.Equal(t, int32(1000), proto.TollAmount)
		assert.Equal(t, "Core Car", proto.CarNumber)
		assert.Equal(t, "Core ETC", proto.EtcCardNumber)
	})
}

// T007-C: Backward compatibility testing with legacy data formats
func TestETCCompatAdapter_BackwardCompatibility(t *testing.T) {
	t.Parallel()

	adapter := adapters.NewETCMeisaiCompatAdapter()

	t.Run("legacy date format handling", func(t *testing.T) {
		tests := []struct {
			name        string
			compat      *adapters.ETCMeisaiCompat
			expectedDate string
		}{
			{
				name: "UsageDate string format",
				compat: &adapters.ETCMeisaiCompat{
					ID:        123,
					UsageDate: stringPtr("2024-06-15"),
				},
				expectedDate: "2024-06-15",
			},
			{
				name: "Date string format",
				compat: &adapters.ETCMeisaiCompat{
					ID:   456,
					Date: stringPtr("2024-07-20"),
				},
				expectedDate: "2024-07-20",
			},
			{
				name: "Core UseDate takes precedence",
				compat: &adapters.ETCMeisaiCompat{
					ID:        789,
					UseDate:   time.Date(2024, 8, 25, 0, 0, 0, 0, time.UTC),
					UsageDate: stringPtr("2024-06-15"),
					Date:      stringPtr("2024-07-20"),
				},
				expectedDate: "2024-08-25",
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				proto, err := adapter.ConvertToProto(tt.compat)
				assert.NoError(t, err)
				assert.Equal(t, tt.expectedDate, proto.Date)
			})
		}
	})

	t.Run("legacy time format handling", func(t *testing.T) {
		tests := []struct {
			name         string
			compat       *adapters.ETCMeisaiCompat
			expectedTime string
		}{
			{
				name: "UsageTime string format",
				compat: &adapters.ETCMeisaiCompat{
					ID:        123,
					UsageTime: stringPtr("15:30:45"),
				},
				expectedTime: "15:30:45",
			},
			{
				name: "Time string format",
				compat: &adapters.ETCMeisaiCompat{
					ID:   456,
					Time: stringPtr("16:45:30"),
				},
				expectedTime: "16:45:30",
			},
			{
				name: "Core UseTime takes precedence",
				compat: &adapters.ETCMeisaiCompat{
					ID:        789,
					UseTime:   "17:30:00",
					UsageTime: stringPtr("15:30:45"),
					Time:      stringPtr("16:45:30"),
				},
				expectedTime: "17:30:00",
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				proto, err := adapter.ConvertToProto(tt.compat)
				assert.NoError(t, err)
				assert.Equal(t, tt.expectedTime, proto.Time)
			})
		}
	})

	t.Run("multiple legacy field variations", func(t *testing.T) {
		compat := &adapters.ETCMeisaiCompat{
			ID: 999,
			// Multiple vehicle number fields
			VehicleNum:    stringPtr("Vehicle1"),
			VehicleNumber: stringPtr("Vehicle2"),
			VehicleNo:     stringPtr("Vehicle3"),
			// Multiple ETC number fields
			ETCNum:        stringPtr("ETC1"),
			CardNo:        stringPtr("ETC2"),
			CardNumber:    stringPtr("ETC3"),
		}

		proto, err := adapter.ConvertToProto(compat)
		assert.NoError(t, err)

		// Should use first non-empty field in precedence order
		assert.Equal(t, "Vehicle1", proto.CarNumber)
		assert.Equal(t, "ETC1", proto.EtcCardNumber)
	})

	t.Run("roundtrip compatibility with legacy data", func(t *testing.T) {
		// Create a record using only legacy fields
		originalCompat := &adapters.ETCMeisaiCompat{
			ID:         123,
			ICEntry:    stringPtr("Legacy Entry IC"),
			ICExit:     stringPtr("Legacy Exit IC"),
			UsageDate:  stringPtr("2024-05-15"),
			UsageTime:  stringPtr("13:45:30"),
			VehicleNum: stringPtr("京都500む1234"),
			ETCCardNum: stringPtr("1234567890123456"),
			TollAmount: int32Ptr(2800),
			Hash:       "legacy_hash",
			CreatedAt:  time.Date(2024, 5, 15, 13, 45, 30, 0, time.UTC),
			UpdatedAt:  time.Date(2024, 5, 15, 13, 45, 30, 0, time.UTC),
		}

		// Convert to proto
		proto, err := adapter.ConvertToProto(originalCompat)
		assert.NoError(t, err)
		assert.NotNil(t, proto)

		// Verify converted values
		assert.Equal(t, int64(123), proto.Id)
		assert.Equal(t, "Legacy Entry IC", proto.EntranceIc)
		assert.Equal(t, "Legacy Exit IC", proto.ExitIc)
		assert.Equal(t, "2024-05-15", proto.Date)
		assert.Equal(t, "13:45:30", proto.Time)
		assert.Equal(t, "京都500む1234", proto.CarNumber)
		assert.Equal(t, "1234567890123456", proto.EtcCardNumber)
		assert.Equal(t, int32(2800), proto.TollAmount)
		assert.Equal(t, "legacy_hash", proto.Hash)
		assert.NotNil(t, proto.CreatedAt)
		assert.NotNil(t, proto.UpdatedAt)
	})
}

// T007-D: Performance testing for large batch conversions (10k+ records)
func TestETCCompatAdapter_PerformanceTesting(t *testing.T) {
	t.Parallel()

	adapter := adapters.NewETCMeisaiCompatAdapter()

	t.Run("performance test with 10k records", func(t *testing.T) {
		if testing.Short() {
			t.Skip("Skipping performance test in short mode")
		}

		// Generate 10,000 test records
		const recordCount = 10000
		compatList := make([]*adapters.ETCMeisaiCompat, recordCount)

		for i := 0; i < recordCount; i++ {
			compatList[i] = &adapters.ETCMeisaiCompat{
				ID:        int64(i + 1),
				UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC).AddDate(0, 0, i%365),
				UseTime:   fmt.Sprintf("%02d:%02d:%02d", (i%24), (i%60), (i%60)),
				EntryIC:   fmt.Sprintf("Entry%d", i%100),
				ExitIC:    fmt.Sprintf("Exit%d", i%100),
				Amount:    int32(1000 + (i % 5000)),
				CarNumber: fmt.Sprintf("Car%04d", i%9999),
				ETCNumber: fmt.Sprintf("ETC%016d", i),
				Hash:      fmt.Sprintf("hash_%d", i),
				CreatedAt: time.Now(),
				UpdatedAt: time.Now(),
			}
		}

		start := time.Now()
		protoList, err := adapter.ConvertToProtoList(compatList)
		duration := time.Since(start)

		assert.NoError(t, err)
		assert.NotNil(t, protoList)
		assert.Len(t, protoList, recordCount)

		// Performance benchmark: Should complete within reasonable time
		assert.Less(t, duration, 5*time.Second, "Conversion of 10k records should complete within 5 seconds")

		t.Logf("Converted %d records in %v", recordCount, duration)
		t.Logf("Average time per record: %v", duration/recordCount)

		// Verify a few random records for correctness
		assert.Equal(t, int64(1), protoList[0].Id)
		assert.Equal(t, int64(5000), protoList[4999].Id)
		assert.Equal(t, int64(10000), protoList[9999].Id)
	})

	t.Run("memory efficiency test", func(t *testing.T) {
		if testing.Short() {
			t.Skip("Skipping memory test in short mode")
		}

		// Test with smaller batches to verify memory doesn't grow linearly
		const batchSize = 1000
		const batches = 5

		for batch := 0; batch < batches; batch++ {
			compatList := make([]*adapters.ETCMeisaiCompat, batchSize)

			for i := 0; i < batchSize; i++ {
				compatList[i] = &adapters.ETCMeisaiCompat{
					ID:        int64(batch*batchSize + i + 1),
					UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
					UseTime:   "10:30:00",
					EntryIC:   "Entry",
					ExitIC:    "Exit",
					Amount:    1000,
					CarNumber: "TestCar",
					ETCNumber: "TestETC",
					Hash:      "test_hash",
				}
			}

			protoList, err := adapter.ConvertToProtoList(compatList)
			assert.NoError(t, err)
			assert.Len(t, protoList, batchSize)

			// Clear references to help GC
			compatList = nil
			protoList = nil
		}
	})
}

// T007-E: Protocol buffer validation testing with invalid message formats
func TestETCCompatAdapter_ProtocolBufferValidation(t *testing.T) {
	t.Parallel()

	adapter := adapters.NewETCMeisaiCompatAdapter()

	t.Run("timestamp validation", func(t *testing.T) {
		tests := []struct {
			name      string
			compat    *adapters.ETCMeisaiCompat
			wantError bool
		}{
			{
				name: "valid timestamps",
				compat: &adapters.ETCMeisaiCompat{
					ID:        123,
					CreatedAt: time.Date(2024, 1, 15, 10, 30, 0, 0, time.UTC),
					UpdatedAt: time.Date(2024, 1, 15, 10, 31, 0, 0, time.UTC),
				},
				wantError: false,
			},
			{
				name: "zero timestamps should be handled",
				compat: &adapters.ETCMeisaiCompat{
					ID:        456,
					CreatedAt: time.Time{},
					UpdatedAt: time.Time{},
				},
				wantError: false,
			},
			{
				name: "very old timestamp",
				compat: &adapters.ETCMeisaiCompat{
					ID:        789,
					CreatedAt: time.Date(1900, 1, 1, 0, 0, 0, 0, time.UTC),
					UpdatedAt: time.Date(1900, 1, 1, 0, 0, 0, 0, time.UTC),
				},
				wantError: false,
			},
			{
				name: "future timestamp",
				compat: &adapters.ETCMeisaiCompat{
					ID:        999,
					CreatedAt: time.Date(2100, 12, 31, 23, 59, 59, 0, time.UTC),
					UpdatedAt: time.Date(2100, 12, 31, 23, 59, 59, 0, time.UTC),
				},
				wantError: false,
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				proto, err := adapter.ConvertToProto(tt.compat)
				if tt.wantError {
					assert.Error(t, err)
					assert.Nil(t, proto)
				} else {
					assert.NoError(t, err)
					assert.NotNil(t, proto)

					if !tt.compat.CreatedAt.IsZero() {
						assert.NotNil(t, proto.CreatedAt)
						assert.Equal(t, tt.compat.CreatedAt.Unix(), proto.CreatedAt.Seconds)
					} else {
						assert.Nil(t, proto.CreatedAt)
					}

					if !tt.compat.UpdatedAt.IsZero() {
						assert.NotNil(t, proto.UpdatedAt)
						assert.Equal(t, tt.compat.UpdatedAt.Unix(), proto.UpdatedAt.Seconds)
					} else {
						assert.Nil(t, proto.UpdatedAt)
					}
				}
			})
		}
	})

	t.Run("field length validation", func(t *testing.T) {
		tests := []struct {
			name   string
			compat *adapters.ETCMeisaiCompat
		}{
			{
				name: "very long string fields",
				compat: &adapters.ETCMeisaiCompat{
					ID:        123,
					EntryIC:   string(make([]byte, 1000)), // Very long string
					ExitIC:    string(make([]byte, 1000)),
					CarNumber: string(make([]byte, 500)),
					ETCNumber: string(make([]byte, 500)),
					Hash:      string(make([]byte, 1000)),
				},
			},
			{
				name: "empty string fields",
				compat: &adapters.ETCMeisaiCompat{
					ID:        456,
					EntryIC:   "",
					ExitIC:    "",
					CarNumber: "",
					ETCNumber: "",
					Hash:      "",
				},
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				proto, err := adapter.ConvertToProto(tt.compat)
				assert.NoError(t, err)
				assert.NotNil(t, proto)
				assert.Equal(t, tt.compat.ID, proto.Id)
			})
		}
	})

	t.Run("numeric field boundaries", func(t *testing.T) {
		tests := []struct {
			name   string
			compat *adapters.ETCMeisaiCompat
		}{
			{
				name: "maximum int32 values",
				compat: &adapters.ETCMeisaiCompat{
					ID:     9223372036854775807, // Max int64
					Amount: 2147483647,          // Max int32
				},
			},
			{
				name: "minimum values",
				compat: &adapters.ETCMeisaiCompat{
					ID:     -9223372036854775808, // Min int64
					Amount: -2147483648,          // Min int32
				},
			},
			{
				name: "zero values",
				compat: &adapters.ETCMeisaiCompat{
					ID:     0,
					Amount: 0,
				},
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				proto, err := adapter.ConvertToProto(tt.compat)
				assert.NoError(t, err)
				assert.NotNil(t, proto)
				assert.Equal(t, tt.compat.ID, proto.Id)
				assert.Equal(t, tt.compat.Amount, proto.TollAmount)
			})
		}
	})

	t.Run("proto field validation after conversion", func(t *testing.T) {
		compat := &adapters.ETCMeisaiCompat{
			ID:        123,
			UseDate:   time.Date(2024, 1, 15, 0, 0, 0, 0, time.UTC),
			UseTime:   "10:30:00",
			EntryIC:   "Tokyo IC",
			ExitIC:    "Osaka IC",
			Amount:    2500,
			CarNumber: "品川500あ1234",
			ETCNumber: "1234567890123456",
			Hash:      "test_hash",
			CreatedAt: time.Date(2024, 1, 15, 10, 30, 0, 0, time.UTC),
			UpdatedAt: time.Date(2024, 1, 15, 10, 30, 0, 0, time.UTC),
		}

		proto, err := adapter.ConvertToProto(compat)
		require.NoError(t, err)
		require.NotNil(t, proto)

		// Validate all required fields are set correctly
		assert.Equal(t, int64(123), proto.Id)
		assert.Equal(t, "test_hash", proto.Hash)
		assert.Equal(t, "2024-01-15", proto.Date)
		assert.Equal(t, "10:30:00", proto.Time)
		assert.Equal(t, "Tokyo IC", proto.EntranceIc)
		assert.Equal(t, "Osaka IC", proto.ExitIc)
		assert.Equal(t, int32(2500), proto.TollAmount)
		assert.Equal(t, "品川500あ1234", proto.CarNumber)
		assert.Equal(t, "1234567890123456", proto.EtcCardNumber)
		assert.NotNil(t, proto.CreatedAt)
		assert.NotNil(t, proto.UpdatedAt)

		// Verify proto is serializable by checking basic fields
		assert.Equal(t, int64(123), proto.Id)
		assert.Equal(t, "test_hash", proto.Hash)
		assert.Equal(t, "2024-01-15", proto.Date)
		assert.Equal(t, "10:30:00", proto.Time)
	})
}

// Benchmark tests for performance monitoring
func BenchmarkETCCompatAdapter_ConvertToProto(b *testing.B) {
	adapter := adapters.NewETCMeisaiCompatAdapter()
	compat := &adapters.ETCMeisaiCompat{
		ID:        123,
		UseDate:   time.Date(2024, 1, 15, 0, 0, 0, 0, time.UTC),
		UseTime:   "10:30:00",
		EntryIC:   "Tokyo IC",
		ExitIC:    "Osaka IC",
		Amount:    2500,
		CarNumber: "品川500あ1234",
		ETCNumber: "1234567890123456",
		Hash:      "test_hash",
		CreatedAt: time.Date(2024, 1, 15, 10, 30, 0, 0, time.UTC),
		UpdatedAt: time.Date(2024, 1, 15, 10, 30, 0, 0, time.UTC),
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, err := adapter.ConvertToProto(compat)
		if err != nil {
			b.Fatal(err)
		}
	}
}

func BenchmarkETCCompatAdapter_ConvertToProtoList_1000(b *testing.B) {
	adapter := adapters.NewETCMeisaiCompatAdapter()

	// Generate 1000 test records
	const recordCount = 1000
	compatList := make([]*adapters.ETCMeisaiCompat, recordCount)

	for i := 0; i < recordCount; i++ {
		compatList[i] = &adapters.ETCMeisaiCompat{
			ID:        int64(i + 1),
			UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
			UseTime:   "10:30:00",
			EntryIC:   "Entry",
			ExitIC:    "Exit",
			Amount:    1000,
			CarNumber: "TestCar",
			ETCNumber: "TestETC",
			Hash:      "test_hash",
		}
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, err := adapter.ConvertToProtoList(compatList)
		if err != nil {
			b.Fatal(err)
		}
	}
}