package adapters_test

import (
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/yhonda-ohishi/etc_meisai/src/adapters"
	"github.com/yhonda-ohishi/etc_meisai/src/models"
	"github.com/yhonda-ohishi/etc_meisai/src/pb"
	"google.golang.org/protobuf/types/known/timestamppb"
)

func TestETCMeisaiRecordToProto(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   *models.ETCMeisaiRecord
		want    *pb.ETCMeisaiRecord
		wantErr bool
		errMsg  string
	}{
		{
			name: "valid conversion with all fields",
			input: &models.ETCMeisaiRecord{
				ID:           1,
				Hash:         "hash123",
				Date:         time.Date(2025, 7, 30, 0, 0, 0, 0, time.UTC),
				Time:         "08:15",
				EntranceIC:   "東京IC",
				ExitIC:       "横浜IC",
				TollAmount:   1000,
				CarNumber:    "品川300あ1234",
				ETCCardNumber: "1234-5678-9012-3456",
				ETCNum:       stringPtr("ETC001"),
				DtakoRowID:   int64Ptr(123),
				CreatedAt:    time.Date(2025, 7, 30, 10, 0, 0, 0, time.UTC),
				UpdatedAt:    time.Date(2025, 7, 30, 11, 0, 0, 0, time.UTC),
			},
			want: &pb.ETCMeisaiRecord{
				Id:            1,
				Hash:          "hash123",
				Date:          "2025-07-30",
				Time:          "08:15",
				EntranceIc:    "東京IC",
				ExitIc:        "横浜IC",
				TollAmount:    1000,
				CarNumber:     "品川300あ1234",
				EtcCardNumber: "1234-5678-9012-3456",
				EtcNum:        stringPtr("ETC001"),
				DtakoRowId:    int64Ptr(123),
				CreatedAt:     timestamppb.New(time.Date(2025, 7, 30, 10, 0, 0, 0, time.UTC)),
				UpdatedAt:     timestamppb.New(time.Date(2025, 7, 30, 11, 0, 0, 0, time.UTC)),
			},
			wantErr: false,
		},
		{
			name: "valid conversion without optional fields",
			input: &models.ETCMeisaiRecord{
				ID:            2,
				Hash:          "hash456",
				Date:          time.Date(2025, 8, 1, 0, 0, 0, 0, time.UTC),
				Time:          "12:30",
				EntranceIC:    "静岡IC",
				ExitIC:        "名古屋IC",
				TollAmount:    2500,
				CarNumber:     "名古屋500な5678",
				ETCCardNumber: "9876-5432-1098-7654",
			},
			want: &pb.ETCMeisaiRecord{
				Id:            2,
				Hash:          "hash456",
				Date:          "2025-08-01",
				Time:          "12:30",
				EntranceIc:    "静岡IC",
				ExitIc:        "名古屋IC",
				TollAmount:    2500,
				CarNumber:     "名古屋500な5678",
				EtcCardNumber: "9876-5432-1098-7654",
			},
			wantErr: false,
		},
		{
			name:    "nil model",
			input:   nil,
			want:    nil,
			wantErr: true,
			errMsg:  "model cannot be nil",
		},
		{
			name: "zero timestamps",
			input: &models.ETCMeisaiRecord{
				ID:            3,
				Hash:          "hash789",
				Date:          time.Date(2025, 8, 2, 0, 0, 0, 0, time.UTC),
				Time:          "14:45",
				EntranceIC:    "京都IC",
				ExitIC:        "大阪IC",
				TollAmount:    1200,
				CarNumber:     "大阪400さ9012",
				ETCCardNumber: "5555-6666-7777-8888",
				CreatedAt:     time.Time{},
				UpdatedAt:     time.Time{},
			},
			want: &pb.ETCMeisaiRecord{
				Id:            3,
				Hash:          "hash789",
				Date:          "2025-08-02",
				Time:          "14:45",
				EntranceIc:    "京都IC",
				ExitIc:        "大阪IC",
				TollAmount:    1200,
				CarNumber:     "大阪400さ9012",
				EtcCardNumber: "5555-6666-7777-8888",
			},
			wantErr: false,
		},
		{
			name: "large toll amount",
			input: &models.ETCMeisaiRecord{
				ID:            4,
				Hash:          "hash999",
				Date:          time.Date(2025, 8, 3, 0, 0, 0, 0, time.UTC),
				Time:          "16:00",
				EntranceIC:    "青森IC",
				ExitIC:        "鹿児島IC",
				TollAmount:    999999,
				CarNumber:     "青森100た1234",
				ETCCardNumber: "1111-2222-3333-4444",
			},
			want: &pb.ETCMeisaiRecord{
				Id:            4,
				Hash:          "hash999",
				Date:          "2025-08-03",
				Time:          "16:00",
				EntranceIc:    "青森IC",
				ExitIc:        "鹿児島IC",
				TollAmount:    999999,
				CarNumber:     "青森100た1234",
				EtcCardNumber: "1111-2222-3333-4444",
			},
			wantErr: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := adapters.ETCMeisaiRecordToProto(tt.input)

			if tt.wantErr {
				assert.Error(t, err)
				if tt.errMsg != "" {
					assert.Contains(t, err.Error(), tt.errMsg)
				}
			} else {
				assert.NoError(t, err)
				assert.NotNil(t, got)

				// Compare fields
				assert.Equal(t, tt.want.Id, got.Id)
				assert.Equal(t, tt.want.Hash, got.Hash)
				assert.Equal(t, tt.want.Date, got.Date)
				assert.Equal(t, tt.want.Time, got.Time)
				assert.Equal(t, tt.want.EntranceIc, got.EntranceIc)
				assert.Equal(t, tt.want.ExitIc, got.ExitIc)
				assert.Equal(t, tt.want.TollAmount, got.TollAmount)
				assert.Equal(t, tt.want.CarNumber, got.CarNumber)
				assert.Equal(t, tt.want.EtcCardNumber, got.EtcCardNumber)

				// Check optional fields
				if tt.want.EtcNum != nil {
					assert.NotNil(t, got.EtcNum)
					assert.Equal(t, *tt.want.EtcNum, *got.EtcNum)
				} else {
					assert.Nil(t, got.EtcNum)
				}

				if tt.want.DtakoRowId != nil {
					assert.NotNil(t, got.DtakoRowId)
					assert.Equal(t, *tt.want.DtakoRowId, *got.DtakoRowId)
				} else {
					assert.Nil(t, got.DtakoRowId)
				}

				// Check timestamps
				if tt.want.CreatedAt != nil {
					assert.NotNil(t, got.CreatedAt)
					assert.Equal(t, tt.want.CreatedAt.AsTime(), got.CreatedAt.AsTime())
				} else {
					assert.Nil(t, got.CreatedAt)
				}

				if tt.want.UpdatedAt != nil {
					assert.NotNil(t, got.UpdatedAt)
					assert.Equal(t, tt.want.UpdatedAt.AsTime(), got.UpdatedAt.AsTime())
				} else {
					assert.Nil(t, got.UpdatedAt)
				}
			}
		})
	}
}

func TestProtoToETCMeisaiRecord(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   *pb.ETCMeisaiRecord
		want    *models.ETCMeisaiRecord
		wantErr bool
		errMsg  string
	}{
		{
			name: "valid conversion with all fields",
			input: &pb.ETCMeisaiRecord{
				Id:            1,
				Hash:          "hash123",
				Date:          "2025-07-30",
				Time:          "08:15",
				EntranceIc:    "東京IC",
				ExitIc:        "横浜IC",
				TollAmount:    1000,
				CarNumber:     "品川300あ1234",
				EtcCardNumber: "1234-5678-9012-3456",
				EtcNum:        stringPtr("ETC001"),
				DtakoRowId:    int64Ptr(123),
				CreatedAt:     timestamppb.New(time.Date(2025, 7, 30, 10, 0, 0, 0, time.UTC)),
				UpdatedAt:     timestamppb.New(time.Date(2025, 7, 30, 11, 0, 0, 0, time.UTC)),
			},
			want: &models.ETCMeisaiRecord{
				ID:            1,
				Hash:          "hash123",
				Date:          time.Date(2025, 7, 30, 0, 0, 0, 0, time.UTC),
				Time:          "08:15",
				EntranceIC:    "東京IC",
				ExitIC:        "横浜IC",
				TollAmount:    1000,
				CarNumber:     "品川300あ1234",
				ETCCardNumber: "1234-5678-9012-3456",
				ETCNum:        stringPtr("ETC001"),
				DtakoRowID:    int64Ptr(123),
				CreatedAt:     time.Date(2025, 7, 30, 10, 0, 0, 0, time.UTC),
				UpdatedAt:     time.Date(2025, 7, 30, 11, 0, 0, 0, time.UTC),
			},
			wantErr: false,
		},
		{
			name: "valid conversion without optional fields",
			input: &pb.ETCMeisaiRecord{
				Id:            2,
				Hash:          "hash456",
				Date:          "2025-08-01",
				Time:          "12:30",
				EntranceIc:    "静岡IC",
				ExitIc:        "名古屋IC",
				TollAmount:    2500,
				CarNumber:     "名古屋500な5678",
				EtcCardNumber: "9876-5432-1098-7654",
			},
			want: &models.ETCMeisaiRecord{
				ID:            2,
				Hash:          "hash456",
				Date:          time.Date(2025, 8, 1, 0, 0, 0, 0, time.UTC),
				Time:          "12:30",
				EntranceIC:    "静岡IC",
				ExitIC:        "名古屋IC",
				TollAmount:    2500,
				CarNumber:     "名古屋500な5678",
				ETCCardNumber: "9876-5432-1098-7654",
			},
			wantErr: false,
		},
		{
			name:    "nil proto",
			input:   nil,
			want:    nil,
			wantErr: true,
			errMsg:  "proto cannot be nil",
		},
		{
			name: "invalid date format",
			input: &pb.ETCMeisaiRecord{
				Id:            3,
				Hash:          "hash789",
				Date:          "invalid-date",
				Time:          "14:45",
				EntranceIc:    "京都IC",
				ExitIc:        "大阪IC",
				TollAmount:    1200,
				CarNumber:     "大阪400さ9012",
				EtcCardNumber: "5555-6666-7777-8888",
			},
			want:    nil,
			wantErr: true,
			errMsg:  "invalid date format",
		},
		{
			name: "nil timestamps",
			input: &pb.ETCMeisaiRecord{
				Id:            4,
				Hash:          "hash999",
				Date:          "2025-08-03",
				Time:          "16:00",
				EntranceIc:    "青森IC",
				ExitIc:        "鹿児島IC",
				TollAmount:    999999,
				CarNumber:     "青森100た1234",
				EtcCardNumber: "1111-2222-3333-4444",
				CreatedAt:     nil,
				UpdatedAt:     nil,
			},
			want: &models.ETCMeisaiRecord{
				ID:            4,
				Hash:          "hash999",
				Date:          time.Date(2025, 8, 3, 0, 0, 0, 0, time.UTC),
				Time:          "16:00",
				EntranceIC:    "青森IC",
				ExitIC:        "鹿児島IC",
				TollAmount:    999999,
				CarNumber:     "青森100た1234",
				ETCCardNumber: "1111-2222-3333-4444",
			},
			wantErr: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := adapters.ProtoToETCMeisaiRecord(tt.input)

			if tt.wantErr {
				assert.Error(t, err)
				if tt.errMsg != "" {
					assert.Contains(t, err.Error(), tt.errMsg)
				}
			} else {
				assert.NoError(t, err)
				assert.NotNil(t, got)

				// Compare fields
				assert.Equal(t, tt.want.ID, got.ID)
				assert.Equal(t, tt.want.Hash, got.Hash)
				assert.Equal(t, tt.want.Date.Format("2006-01-02"), got.Date.Format("2006-01-02"))
				assert.Equal(t, tt.want.Time, got.Time)
				assert.Equal(t, tt.want.EntranceIC, got.EntranceIC)
				assert.Equal(t, tt.want.ExitIC, got.ExitIC)
				assert.Equal(t, tt.want.TollAmount, got.TollAmount)
				assert.Equal(t, tt.want.CarNumber, got.CarNumber)
				assert.Equal(t, tt.want.ETCCardNumber, got.ETCCardNumber)

				// Check optional fields
				if tt.want.ETCNum != nil {
					assert.NotNil(t, got.ETCNum)
					assert.Equal(t, *tt.want.ETCNum, *got.ETCNum)
				} else {
					assert.Nil(t, got.ETCNum)
				}

				if tt.want.DtakoRowID != nil {
					assert.NotNil(t, got.DtakoRowID)
					assert.Equal(t, *tt.want.DtakoRowID, *got.DtakoRowID)
				} else {
					assert.Nil(t, got.DtakoRowID)
				}

				// Check timestamps
				if !tt.want.CreatedAt.IsZero() {
					assert.Equal(t, tt.want.CreatedAt.Unix(), got.CreatedAt.Unix())
				}
				if !tt.want.UpdatedAt.IsZero() {
					assert.Equal(t, tt.want.UpdatedAt.Unix(), got.UpdatedAt.Unix())
				}
			}
		})
	}
}

func TestETCMeisaiRecordConversionRoundtrip(t *testing.T) {
	t.Parallel()

	original := &models.ETCMeisaiRecord{
		ID:            100,
		Hash:          "roundtrip-hash",
		Date:          time.Date(2025, 9, 15, 0, 0, 0, 0, time.UTC),
		Time:          "09:30",
		EntranceIC:    "仙台IC",
		ExitIC:        "福島IC",
		TollAmount:    3500,
		CarNumber:     "仙台300ま4567",
		ETCCardNumber: "9999-8888-7777-6666",
		ETCNum:        stringPtr("ETC999"),
		DtakoRowID:    int64Ptr(999),
		CreatedAt:     time.Date(2025, 9, 15, 10, 0, 0, 0, time.UTC),
		UpdatedAt:     time.Date(2025, 9, 15, 11, 0, 0, 0, time.UTC),
	}

	// Convert to proto
	proto, err := adapters.ETCMeisaiRecordToProto(original)
	assert.NoError(t, err)
	assert.NotNil(t, proto)

	// Convert back to model
	converted, err := adapters.ProtoToETCMeisaiRecord(proto)
	assert.NoError(t, err)
	assert.NotNil(t, converted)

	// Compare
	assert.Equal(t, original.ID, converted.ID)
	assert.Equal(t, original.Hash, converted.Hash)
	assert.Equal(t, original.Date.Format("2006-01-02"), converted.Date.Format("2006-01-02"))
	assert.Equal(t, original.Time, converted.Time)
	assert.Equal(t, original.EntranceIC, converted.EntranceIC)
	assert.Equal(t, original.ExitIC, converted.ExitIC)
	assert.Equal(t, original.TollAmount, converted.TollAmount)
	assert.Equal(t, original.CarNumber, converted.CarNumber)
	assert.Equal(t, original.ETCCardNumber, converted.ETCCardNumber)

	// Check optional fields
	assert.NotNil(t, converted.ETCNum)
	assert.Equal(t, *original.ETCNum, *converted.ETCNum)
	assert.NotNil(t, converted.DtakoRowID)
	assert.Equal(t, *original.DtakoRowID, *converted.DtakoRowID)

	// Check timestamps (might lose nanoseconds in conversion)
	assert.Equal(t, original.CreatedAt.Unix(), converted.CreatedAt.Unix())
	assert.Equal(t, original.UpdatedAt.Unix(), converted.UpdatedAt.Unix())
}

// Helper function to create int64 pointer
func int64Ptr(i int64) *int64 {
	return &i
}