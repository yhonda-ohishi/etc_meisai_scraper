package adapters_test

import (
	"fmt"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"github.com/yhonda-ohishi/etc_meisai/src/adapters"
	"github.com/yhonda-ohishi/etc_meisai/src/models"
	"github.com/yhonda-ohishi/etc_meisai/src/pb"
	"google.golang.org/protobuf/types/known/timestamppb"
)

// Enhanced tests for all protocol buffer converters focusing on edge cases and error handling
func TestETCRecordConverter_EnhancedErrorHandling(t *testing.T) {
	t.Parallel()

	t.Run("ETCMeisaiRecordToProto error handling", func(t *testing.T) {
		tests := []struct {
			name      string
			model     *models.ETCMeisaiRecord
			wantError bool
			errorMsg  string
		}{
			{
				name:      "nil model",
				model:     nil,
				wantError: true,
				errorMsg:  "model cannot be nil",
			},
			{
				name: "valid model with minimal fields",
				model: &models.ETCMeisaiRecord{
					ID:   1,
					Hash: "test_hash",
					Date: time.Date(2024, 1, 15, 0, 0, 0, 0, time.UTC),
				},
				wantError: false,
			},
			{
				name: "model with zero date",
				model: &models.ETCMeisaiRecord{
					ID:   2,
					Hash: "test_hash",
					Date: time.Time{}, // Zero time
				},
				wantError: false, // Should handle zero time gracefully
			},
			{
				name: "model with negative ID",
				model: &models.ETCMeisaiRecord{
					ID:   -1,
					Hash: "test_hash",
					Date: time.Date(2024, 1, 15, 0, 0, 0, 0, time.UTC),
				},
				wantError: false, // Should handle negative ID
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				proto, err := adapters.ETCMeisaiRecordToProto(tt.model)
				if tt.wantError {
					assert.Error(t, err)
					assert.Nil(t, proto)
					if tt.errorMsg != "" {
						assert.Contains(t, err.Error(), tt.errorMsg)
					}
				} else {
					assert.NoError(t, err)
					assert.NotNil(t, proto)
				}
			})
		}
	})

	t.Run("ProtoToETCMeisaiRecord error handling", func(t *testing.T) {
		tests := []struct {
			name      string
			proto     *pb.ETCMeisaiRecord
			wantError bool
			errorMsg  string
		}{
			{
				name:      "nil proto",
				proto:     nil,
				wantError: true,
				errorMsg:  "proto cannot be nil",
			},
			{
				name: "invalid date format",
				proto: &pb.ETCMeisaiRecord{
					Id:   1,
					Hash: "test_hash",
					Date: "invalid-date",
				},
				wantError: true,
				errorMsg:  "invalid date format",
			},
			{
				name: "empty date string",
				proto: &pb.ETCMeisaiRecord{
					Id:   2,
					Hash: "test_hash",
					Date: "",
				},
				wantError: true,
				errorMsg:  "invalid date format",
			},
			{
				name: "valid minimal proto",
				proto: &pb.ETCMeisaiRecord{
					Id:   3,
					Hash: "test_hash",
					Date: "2024-01-15",
				},
				wantError: false,
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				model, err := adapters.ProtoToETCMeisaiRecord(tt.proto)
				if tt.wantError {
					assert.Error(t, err)
					assert.Nil(t, model)
					if tt.errorMsg != "" {
						assert.Contains(t, err.Error(), tt.errorMsg)
					}
				} else {
					assert.NoError(t, err)
					assert.NotNil(t, model)
				}
			})
		}
	})

	t.Run("ETCMeisaiRecordsToProto slice error handling", func(t *testing.T) {
		tests := []struct {
			name      string
			models    []*models.ETCMeisaiRecord
			wantError bool
			errorMsg  string
		}{
			{
				name:      "nil slice",
				models:    nil,
				wantError: false, // Should return nil, nil
			},
			{
				name:      "empty slice",
				models:    []*models.ETCMeisaiRecord{},
				wantError: false,
			},
			{
				name: "slice with nil element",
				models: []*models.ETCMeisaiRecord{
					{ID: 1, Hash: "hash1", Date: time.Now()},
					nil,
					{ID: 3, Hash: "hash3", Date: time.Now()},
				},
				wantError: true,
				errorMsg:  "model at index 1 cannot be nil",
			},
			{
				name: "valid slice",
				models: []*models.ETCMeisaiRecord{
					{ID: 1, Hash: "hash1", Date: time.Date(2024, 1, 15, 0, 0, 0, 0, time.UTC)},
					{ID: 2, Hash: "hash2", Date: time.Date(2024, 1, 16, 0, 0, 0, 0, time.UTC)},
				},
				wantError: false,
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				protos, err := adapters.ETCMeisaiRecordsToProto(tt.models)
				if tt.wantError {
					assert.Error(t, err)
					assert.Nil(t, protos)
					if tt.errorMsg != "" {
						assert.Contains(t, err.Error(), tt.errorMsg)
					}
				} else {
					assert.NoError(t, err)
					if tt.models == nil {
						assert.Nil(t, protos)
					} else {
						assert.NotNil(t, protos)
						assert.Len(t, protos, len(tt.models))
					}
				}
			})
		}
	})
}

func TestETCRecordConverter_FieldMappingEdgeCases(t *testing.T) {
	t.Parallel()

	t.Run("optional field handling", func(t *testing.T) {
		tests := []struct {
			name  string
			model *models.ETCMeisaiRecord
		}{
			{
				name: "with nil optional fields",
				model: &models.ETCMeisaiRecord{
					ID:          1,
					Hash:        "test_hash",
					Date:        time.Date(2024, 1, 15, 0, 0, 0, 0, time.UTC),
					ETCNum:      nil, // Nil pointer
					DtakoRowID:  nil, // Nil pointer
				},
			},
			{
				name: "with valid optional fields",
				model: &models.ETCMeisaiRecord{
					ID:         2,
					Hash:       "test_hash",
					Date:       time.Date(2024, 1, 15, 0, 0, 0, 0, time.UTC),
					ETCNum:     stringPtr("ETC123"),
					DtakoRowID: int64PtrProto(456),
				},
			},
			{
				name: "with empty string optional fields",
				model: &models.ETCMeisaiRecord{
					ID:         3,
					Hash:       "test_hash",
					Date:       time.Date(2024, 1, 15, 0, 0, 0, 0, time.UTC),
					ETCNum:     stringPtr(""),
					DtakoRowID: int64PtrProto(0),
				},
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				proto, err := adapters.ETCMeisaiRecordToProto(tt.model)
				assert.NoError(t, err)
				assert.NotNil(t, proto)

				if tt.model.ETCNum != nil {
					assert.NotNil(t, proto.EtcNum)
					assert.Equal(t, *tt.model.ETCNum, *proto.EtcNum)
				} else {
					assert.Nil(t, proto.EtcNum)
				}

				if tt.model.DtakoRowID != nil {
					assert.NotNil(t, proto.DtakoRowId)
					assert.Equal(t, *tt.model.DtakoRowID, *proto.DtakoRowId)
				} else {
					assert.Nil(t, proto.DtakoRowId)
				}
			})
		}
	})

	t.Run("timestamp handling edge cases", func(t *testing.T) {
		tests := []struct {
			name       string
			model      *models.ETCMeisaiRecord
			checkProto func(*testing.T, *pb.ETCMeisaiRecord)
		}{
			{
				name: "zero timestamps",
				model: &models.ETCMeisaiRecord{
					ID:        1,
					Hash:      "test_hash",
					Date:      time.Date(2024, 1, 15, 0, 0, 0, 0, time.UTC),
					CreatedAt: time.Time{},
					UpdatedAt: time.Time{},
				},
				checkProto: func(t *testing.T, proto *pb.ETCMeisaiRecord) {
					assert.Nil(t, proto.CreatedAt)
					assert.Nil(t, proto.UpdatedAt)
				},
			},
			{
				name: "valid timestamps",
				model: &models.ETCMeisaiRecord{
					ID:        2,
					Hash:      "test_hash",
					Date:      time.Date(2024, 1, 15, 0, 0, 0, 0, time.UTC),
					CreatedAt: time.Date(2024, 1, 15, 10, 30, 0, 0, time.UTC),
					UpdatedAt: time.Date(2024, 1, 15, 11, 30, 0, 0, time.UTC),
				},
				checkProto: func(t *testing.T, proto *pb.ETCMeisaiRecord) {
					assert.NotNil(t, proto.CreatedAt)
					assert.NotNil(t, proto.UpdatedAt)
					assert.Equal(t, int64(1705314600), proto.CreatedAt.Seconds)
					assert.Equal(t, int64(1705318200), proto.UpdatedAt.Seconds)
				},
			},
			{
				name: "very old timestamp",
				model: &models.ETCMeisaiRecord{
					ID:        3,
					Hash:      "test_hash",
					Date:      time.Date(2024, 1, 15, 0, 0, 0, 0, time.UTC),
					CreatedAt: time.Date(1900, 1, 1, 0, 0, 0, 0, time.UTC),
					UpdatedAt: time.Date(1900, 1, 1, 0, 0, 0, 0, time.UTC),
				},
				checkProto: func(t *testing.T, proto *pb.ETCMeisaiRecord) {
					assert.NotNil(t, proto.CreatedAt)
					assert.NotNil(t, proto.UpdatedAt)
					// Very old dates should still be convertible
					assert.Less(t, proto.CreatedAt.Seconds, int64(0))
				},
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				proto, err := adapters.ETCMeisaiRecordToProto(tt.model)
				assert.NoError(t, err)
				assert.NotNil(t, proto)
				tt.checkProto(t, proto)
			})
		}
	})

	t.Run("large numeric values", func(t *testing.T) {
		model := &models.ETCMeisaiRecord{
			ID:         9223372036854775807, // Max int64
			Hash:       "test_hash",
			Date:       time.Date(2024, 1, 15, 0, 0, 0, 0, time.UTC),
			TollAmount: 2147483647, // Max int
		}

		proto, err := adapters.ETCMeisaiRecordToProto(model)
		assert.NoError(t, err)
		assert.NotNil(t, proto)
		assert.Equal(t, model.ID, proto.Id)
		assert.Equal(t, int32(model.TollAmount), proto.TollAmount)
	})
}

func TestETCRecordConverter_RoundtripValidation(t *testing.T) {
	t.Parallel()

	t.Run("complete roundtrip conversion", func(t *testing.T) {
		original := &models.ETCMeisaiRecord{
			ID:              123,
			Hash:            "roundtrip_hash",
			Date:            time.Date(2024, 3, 20, 0, 0, 0, 0, time.UTC),
			Time:            "14:30:45",
			EntranceIC:      "Tokyo IC",
			ExitIC:          "Osaka IC",
			TollAmount:      2500,
			CarNumber:       "品川500あ1234",
			ETCCardNumber:   "1234567890123456",
			ETCNum:          stringPtr("ETC999"),
			DtakoRowID:      int64PtrProto(789),
			CreatedAt:       time.Date(2024, 3, 20, 14, 30, 45, 0, time.UTC),
			UpdatedAt:       time.Date(2024, 3, 20, 14, 31, 0, 0, time.UTC),
		}

		// Convert to proto
		proto, err := adapters.ETCMeisaiRecordToProto(original)
		require.NoError(t, err)
		require.NotNil(t, proto)

		// Convert back to model
		restored, err := adapters.ProtoToETCMeisaiRecord(proto)
		require.NoError(t, err)
		require.NotNil(t, restored)

		// Verify all fields match
		assert.Equal(t, original.ID, restored.ID)
		assert.Equal(t, original.Hash, restored.Hash)
		assert.True(t, original.Date.Equal(restored.Date))
		assert.Equal(t, original.Time, restored.Time)
		assert.Equal(t, original.EntranceIC, restored.EntranceIC)
		assert.Equal(t, original.ExitIC, restored.ExitIC)
		assert.Equal(t, original.TollAmount, restored.TollAmount)
		assert.Equal(t, original.CarNumber, restored.CarNumber)
		assert.Equal(t, original.ETCCardNumber, restored.ETCCardNumber)

		// Verify optional fields
		require.NotNil(t, restored.ETCNum)
		assert.Equal(t, *original.ETCNum, *restored.ETCNum)
		require.NotNil(t, restored.DtakoRowID)
		assert.Equal(t, *original.DtakoRowID, *restored.DtakoRowID)

		// Verify timestamps (with some tolerance for precision)
		assert.True(t, original.CreatedAt.Equal(restored.CreatedAt))
		assert.True(t, original.UpdatedAt.Equal(restored.UpdatedAt))
	})

	t.Run("roundtrip with minimal fields", func(t *testing.T) {
		original := &models.ETCMeisaiRecord{
			ID:   456,
			Hash: "minimal_hash",
			Date: time.Date(2024, 4, 10, 0, 0, 0, 0, time.UTC),
		}

		proto, err := adapters.ETCMeisaiRecordToProto(original)
		require.NoError(t, err)

		restored, err := adapters.ProtoToETCMeisaiRecord(proto)
		require.NoError(t, err)

		assert.Equal(t, original.ID, restored.ID)
		assert.Equal(t, original.Hash, restored.Hash)
		assert.True(t, original.Date.Equal(restored.Date))

		// Optional fields should be nil
		assert.Nil(t, restored.ETCNum)
		assert.Nil(t, restored.DtakoRowID)
	})
}

func TestImportSessionConverter_ErrorHandling(t *testing.T) {
	t.Parallel()

	t.Run("ImportSessionToProto error handling", func(t *testing.T) {
		tests := []struct {
			name      string
			model     *models.ImportSession
			wantError bool
			errorMsg  string
		}{
			{
				name:      "nil model",
				model:     nil,
				wantError: true,
				errorMsg:  "model cannot be nil",
			},
			{
				name: "valid minimal model",
				model: &models.ImportSession{
					ID:          "test-id-1",
					AccountType: "test",
					AccountID:   "test_account",
					Status:      "pending",
					StartedAt:   time.Now(),
				},
				wantError: false,
			},
			{
				name: "invalid status",
				model: &models.ImportSession{
					ID:          "test-id-2",
					AccountType: "test",
					AccountID:   "test_account",
					Status:      "invalid_status",
					StartedAt:   time.Now(),
				},
				wantError: true,
				errorMsg:  "invalid import status",
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				proto, err := adapters.ImportSessionToProto(tt.model)
				if tt.wantError {
					assert.Error(t, err)
					assert.Nil(t, proto)
					if tt.errorMsg != "" {
						assert.Contains(t, err.Error(), tt.errorMsg)
					}
				} else {
					assert.NoError(t, err)
					assert.NotNil(t, proto)
				}
			})
		}
	})

	t.Run("ProtoToImportSession error handling", func(t *testing.T) {
		validProto := &pb.ImportSession{
			Id:          "test-id-1",
			AccountType: "test",
			AccountId:   "test_account",
			Status:      pb.ImportStatus_IMPORT_STATUS_PENDING,
			StartedAt:   timestamppb.Now(),
		}

		// Test nil proto
		model, err := adapters.ProtoToImportSession(nil)
		assert.Error(t, err)
		assert.Nil(t, model)
		assert.Contains(t, err.Error(), "proto cannot be nil")

		// Test valid proto
		model, err = adapters.ProtoToImportSession(validProto)
		assert.NoError(t, err)
		assert.NotNil(t, model)
	})
}

func TestETCMappingConverter_ErrorHandling(t *testing.T) {
	t.Parallel()

	t.Run("ETCMappingToProto error handling", func(t *testing.T) {
		tests := []struct {
			name      string
			model     *models.ETCMapping
			wantError bool
			errorMsg  string
		}{
			{
				name:      "nil model",
				model:     nil,
				wantError: true,
				errorMsg:  "model cannot be nil",
			},
			{
				name: "valid minimal model",
				model: &models.ETCMapping{
					ID:           1,
					ETCRecordID:  123,
					MappingType:  "test",
					Status:       "active",
				},
				wantError: false,
			},
			{
				name: "invalid status",
				model: &models.ETCMapping{
					ID:           2,
					ETCRecordID:  124,
					MappingType:  "test",
					Status:       "invalid_status",
				},
				wantError: true,
				errorMsg:  "invalid mapping status",
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				proto, err := adapters.ETCMappingToProto(tt.model)
				if tt.wantError {
					assert.Error(t, err)
					assert.Nil(t, proto)
					if tt.errorMsg != "" {
						assert.Contains(t, err.Error(), tt.errorMsg)
					}
				} else {
					assert.NoError(t, err)
					assert.NotNil(t, proto)
				}
			})
		}
	})
}

// Performance test for large-scale conversions
func TestProtoConverter_Performance(t *testing.T) {
	t.Parallel()

	if testing.Short() {
		t.Skip("Skipping performance test in short mode")
	}

	t.Run("large batch ETCMeisaiRecord conversion", func(t *testing.T) {
		const recordCount = 5000
		records := make([]*models.ETCMeisaiRecord, recordCount)

		for i := 0; i < recordCount; i++ {
			records[i] = &models.ETCMeisaiRecord{
				ID:            int64(i + 1),
				Hash:          fmt.Sprintf("hash_%d", i),
				Date:          time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC).AddDate(0, 0, i%365),
				Time:          fmt.Sprintf("%02d:%02d:%02d", (i%24), (i%60), (i%60)),
				EntranceIC:    fmt.Sprintf("Entry%d", i%100),
				ExitIC:        fmt.Sprintf("Exit%d", i%100),
				TollAmount:    i % 10000,
				CarNumber:     fmt.Sprintf("Car%04d", i%9999),
				ETCCardNumber: fmt.Sprintf("ETC%016d", i),
				CreatedAt:     time.Now(),
				UpdatedAt:     time.Now(),
			}
		}

		start := time.Now()
		protos, err := adapters.ETCMeisaiRecordsToProto(records)
		duration := time.Since(start)

		assert.NoError(t, err)
		assert.NotNil(t, protos)
		assert.Len(t, protos, recordCount)

		// Should complete within reasonable time
		assert.Less(t, duration, 3*time.Second, "Conversion of 5k records should complete within 3 seconds")

		t.Logf("Converted %d records in %v", recordCount, duration)
		t.Logf("Average time per record: %v", duration/recordCount)
	})
}

// Helper functions for proto_converter_enhanced_test.go
func int64PtrProto(i int64) *int64 {
	return &i
}