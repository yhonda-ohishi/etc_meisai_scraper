package adapters_test

import (
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"github.com/yhonda-ohishi/etc_meisai/src/adapters"
	"github.com/yhonda-ohishi/etc_meisai/src/models"
	"github.com/yhonda-ohishi/etc_meisai/src/pb"
	"google.golang.org/protobuf/types/known/timestamppb"
)

// TestETCMeisaiRecordsToProto tests batch conversion from models to proto
func TestETCMeisaiRecordsToProto(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   []*models.ETCMeisaiRecord
		want    []*pb.ETCMeisaiRecord
		wantErr bool
	}{
		{
			name:  "nil input",
			input: nil,
			want:  nil,
		},
		{
			name:  "empty slice",
			input: []*models.ETCMeisaiRecord{},
			want:  []*pb.ETCMeisaiRecord{},
		},
		{
			name: "single record",
			input: []*models.ETCMeisaiRecord{
				{
					ID:            1,
					Hash:          "hash1",
					Date:          time.Date(2025, 1, 15, 0, 0, 0, 0, time.UTC),
					Time:          "09:30:00",
					EntranceIC:    "Tokyo IC",
					ExitIC:        "Yokohama IC",
					TollAmount:    1500,
					CarNumber:     "品川500あ1234",
					ETCCardNumber: "1234567890123456",
				},
			},
			want: []*pb.ETCMeisaiRecord{
				{
					Id:            1,
					Hash:          "hash1",
					Date:          "2025-01-15",
					Time:          "09:30:00",
					EntranceIc:    "Tokyo IC",
					ExitIc:        "Yokohama IC",
					TollAmount:    1500,
					CarNumber:     "品川500あ1234",
					EtcCardNumber: "1234567890123456",
				},
			},
		},
		{
			name: "multiple records",
			input: []*models.ETCMeisaiRecord{
				{
					ID:            1,
					Hash:          "hash1",
					Date:          time.Date(2025, 1, 15, 0, 0, 0, 0, time.UTC),
					Time:          "09:30:00",
					EntranceIC:    "Tokyo IC",
					ExitIC:        "Yokohama IC",
					TollAmount:    1500,
					CarNumber:     "品川500あ1234",
					ETCCardNumber: "1234567890123456",
					CreatedAt:     time.Date(2025, 1, 15, 9, 0, 0, 0, time.UTC),
				},
				{
					ID:            2,
					Hash:          "hash2",
					Date:          time.Date(2025, 1, 16, 0, 0, 0, 0, time.UTC),
					Time:          "14:45:00",
					EntranceIC:    "Nagoya IC",
					ExitIC:        "Osaka IC",
					TollAmount:    3200,
					CarNumber:     "名古屋300た5678",
					ETCCardNumber: "9876543210987654",
					ETCNum:        stringPtr("ETC002"),
					DtakoRowID:    int64Ptr(456),
					UpdatedAt:     time.Date(2025, 1, 16, 15, 0, 0, 0, time.UTC),
				},
				{
					ID:            3,
					Hash:          "hash3",
					Date:          time.Date(2025, 1, 17, 0, 0, 0, 0, time.UTC),
					Time:          "18:00:00",
					EntranceIC:    "Kyoto IC",
					ExitIC:        "Kobe IC",
					TollAmount:    1800,
					CarNumber:     "京都400な9012",
					ETCCardNumber: "5555666677778888",
				},
			},
			want: []*pb.ETCMeisaiRecord{
				{
					Id:            1,
					Hash:          "hash1",
					Date:          "2025-01-15",
					Time:          "09:30:00",
					EntranceIc:    "Tokyo IC",
					ExitIc:        "Yokohama IC",
					TollAmount:    1500,
					CarNumber:     "品川500あ1234",
					EtcCardNumber: "1234567890123456",
					CreatedAt:     timestamppb.New(time.Date(2025, 1, 15, 9, 0, 0, 0, time.UTC)),
				},
				{
					Id:            2,
					Hash:          "hash2",
					Date:          "2025-01-16",
					Time:          "14:45:00",
					EntranceIc:    "Nagoya IC",
					ExitIc:        "Osaka IC",
					TollAmount:    3200,
					CarNumber:     "名古屋300た5678",
					EtcCardNumber: "9876543210987654",
					EtcNum:        stringPtr("ETC002"),
					DtakoRowId:    int64Ptr(456),
					UpdatedAt:     timestamppb.New(time.Date(2025, 1, 16, 15, 0, 0, 0, time.UTC)),
				},
				{
					Id:            3,
					Hash:          "hash3",
					Date:          "2025-01-17",
					Time:          "18:00:00",
					EntranceIc:    "Kyoto IC",
					ExitIc:        "Kobe IC",
					TollAmount:    1800,
					CarNumber:     "京都400な9012",
					EtcCardNumber: "5555666677778888",
				},
			},
		},
		{
			name: "slice with nil element",
			input: []*models.ETCMeisaiRecord{
				{
					ID:         1,
					Hash:       "hash1",
					Date:       time.Date(2025, 1, 15, 0, 0, 0, 0, time.UTC),
					Time:       "09:30:00",
					EntranceIC: "Tokyo IC",
					ExitIC:     "Yokohama IC",
					TollAmount: 1500,
					CarNumber:  "品川500あ1234",
					ETCCardNumber: "1234567890123456",
				},
				nil, // This should cause an error
				{
					ID:         3,
					Hash:       "hash3",
					Date:       time.Date(2025, 1, 17, 0, 0, 0, 0, time.UTC),
					Time:       "18:00:00",
					EntranceIC: "Kyoto IC",
					ExitIC:     "Kobe IC",
					TollAmount: 1800,
					CarNumber:  "京都400な9012",
					ETCCardNumber: "5555666677778888",
				},
			},
			wantErr: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := adapters.ETCMeisaiRecordsToProto(tt.input)

			if tt.wantErr {
				assert.Error(t, err)
				return
			}

			require.NoError(t, err)
			require.Equal(t, len(tt.want), len(got))

			for i, want := range tt.want {
				assert.Equal(t, want.Id, got[i].Id)
				assert.Equal(t, want.Hash, got[i].Hash)
				assert.Equal(t, want.Date, got[i].Date)
				assert.Equal(t, want.Time, got[i].Time)
				assert.Equal(t, want.EntranceIc, got[i].EntranceIc)
				assert.Equal(t, want.ExitIc, got[i].ExitIc)
				assert.Equal(t, want.TollAmount, got[i].TollAmount)
				assert.Equal(t, want.CarNumber, got[i].CarNumber)
				assert.Equal(t, want.EtcCardNumber, got[i].EtcCardNumber)

				// Check optional fields
				if want.EtcNum != nil {
					assert.NotNil(t, got[i].EtcNum)
					assert.Equal(t, *want.EtcNum, *got[i].EtcNum)
				} else {
					assert.Nil(t, got[i].EtcNum)
				}

				if want.DtakoRowId != nil {
					assert.NotNil(t, got[i].DtakoRowId)
					assert.Equal(t, *want.DtakoRowId, *got[i].DtakoRowId)
				} else {
					assert.Nil(t, got[i].DtakoRowId)
				}

				// Check timestamps
				if want.CreatedAt != nil {
					assert.NotNil(t, got[i].CreatedAt)
					assert.Equal(t, want.CreatedAt.AsTime(), got[i].CreatedAt.AsTime())
				}

				if want.UpdatedAt != nil {
					assert.NotNil(t, got[i].UpdatedAt)
					assert.Equal(t, want.UpdatedAt.AsTime(), got[i].UpdatedAt.AsTime())
				}
			}
		})
	}
}

// TestProtoToETCMeisaiRecords tests batch conversion from proto to models
func TestProtoToETCMeisaiRecords(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   []*pb.ETCMeisaiRecord
		want    []*models.ETCMeisaiRecord
		wantErr bool
	}{
		{
			name:  "nil input",
			input: nil,
			want:  nil,
		},
		{
			name:  "empty slice",
			input: []*pb.ETCMeisaiRecord{},
			want:  []*models.ETCMeisaiRecord{},
		},
		{
			name: "multiple proto records",
			input: []*pb.ETCMeisaiRecord{
				{
					Id:            1,
					Hash:          "hash1",
					Date:          "2025-01-15",
					Time:          "09:30:00",
					EntranceIc:    "Tokyo IC",
					ExitIc:        "Yokohama IC",
					TollAmount:    1500,
					CarNumber:     "品川500あ1234",
					EtcCardNumber: "1234567890123456",
				},
				{
					Id:            2,
					Hash:          "hash2",
					Date:          "2025-01-16",
					Time:          "14:45:00",
					EntranceIc:    "Nagoya IC",
					ExitIc:        "Osaka IC",
					TollAmount:    3200,
					CarNumber:     "名古屋300た5678",
					EtcCardNumber: "9876543210987654",
					EtcNum:        stringPtr("ETC002"),
					DtakoRowId:    int64Ptr(456),
				},
			},
			want: []*models.ETCMeisaiRecord{
				{
					ID:            1,
					Hash:          "hash1",
					Date:          time.Date(2025, 1, 15, 0, 0, 0, 0, time.UTC),
					Time:          "09:30:00",
					EntranceIC:    "Tokyo IC",
					ExitIC:        "Yokohama IC",
					TollAmount:    1500,
					CarNumber:     "品川500あ1234",
					ETCCardNumber: "1234567890123456",
				},
				{
					ID:            2,
					Hash:          "hash2",
					Date:          time.Date(2025, 1, 16, 0, 0, 0, 0, time.UTC),
					Time:          "14:45:00",
					EntranceIC:    "Nagoya IC",
					ExitIC:        "Osaka IC",
					TollAmount:    3200,
					CarNumber:     "名古屋300た5678",
					ETCCardNumber: "9876543210987654",
					ETCNum:        stringPtr("ETC002"),
					DtakoRowID:    int64Ptr(456),
				},
			},
		},
		{
			name: "proto with nil element",
			input: []*pb.ETCMeisaiRecord{
				{
					Id:   1,
					Hash: "hash1",
					Date: "2025-01-15",
				},
				nil, // This should cause an error
			},
			wantErr: true,
		},
		{
			name: "proto with invalid date",
			input: []*pb.ETCMeisaiRecord{
				{
					Id:   1,
					Hash: "hash1",
					Date: "invalid-date",
					Time: "09:30:00",
				},
			},
			wantErr: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := adapters.ProtoToETCMeisaiRecords(tt.input)

			if tt.wantErr {
				assert.Error(t, err)
				return
			}

			require.NoError(t, err)
			require.Equal(t, len(tt.want), len(got))

			for i, want := range tt.want {
				assert.Equal(t, want.ID, got[i].ID)
				assert.Equal(t, want.Hash, got[i].Hash)
				assert.Equal(t, want.Date, got[i].Date)
				assert.Equal(t, want.Time, got[i].Time)
				assert.Equal(t, want.EntranceIC, got[i].EntranceIC)
				assert.Equal(t, want.ExitIC, got[i].ExitIC)
				assert.Equal(t, want.TollAmount, got[i].TollAmount)
				assert.Equal(t, want.CarNumber, got[i].CarNumber)
				assert.Equal(t, want.ETCCardNumber, got[i].ETCCardNumber)

				// Check optional fields
				if want.ETCNum != nil {
					assert.NotNil(t, got[i].ETCNum)
					assert.Equal(t, *want.ETCNum, *got[i].ETCNum)
				}

				if want.DtakoRowID != nil {
					assert.NotNil(t, got[i].DtakoRowID)
					assert.Equal(t, *want.DtakoRowID, *got[i].DtakoRowID)
				}
			}
		})
	}
}

// TestProtoToETCMeisaiRecord_EdgeCases tests edge cases for single record conversion
func TestProtoToETCMeisaiRecord_EdgeCases(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		input   *pb.ETCMeisaiRecord
		wantErr bool
		errMsg  string
	}{
		{
			name: "minimal valid record",
			input: &pb.ETCMeisaiRecord{
				Id:            1,
				Hash:          "hash",
				Date:          "2025-01-15",
				Time:          "09:00:00",
				EntranceIc:    "Entry",
				ExitIc:        "Exit",
				TollAmount:    100,
				CarNumber:     "123",
				EtcCardNumber: "1234567890123456",
			},
			wantErr: false,
		},
		{
			name: "date with different format",
			input: &pb.ETCMeisaiRecord{
				Id:   1,
				Hash: "hash",
				Date: "01/15/2025", // Wrong format
				Time: "09:00:00",
			},
			wantErr: true,
			errMsg:  "cannot parse",
		},
		{
			name: "empty required fields",
			input: &pb.ETCMeisaiRecord{
				Id:   1,
				Hash: "", // Empty hash should be ok in conversion
				Date: "2025-01-15",
				Time: "",
			},
			wantErr: false,
		},
		{
			name: "with all optional fields",
			input: &pb.ETCMeisaiRecord{
				Id:            1,
				Hash:          "hash",
				Date:          "2025-01-15",
				Time:          "09:00:00",
				EntranceIc:    "Entry",
				ExitIc:        "Exit",
				TollAmount:    100,
				CarNumber:     "123",
				EtcCardNumber: "1234567890123456",
				EtcNum:        stringPtr("ETC123"),
				DtakoRowId:    int64Ptr(999),
				CreatedAt:     timestamppb.New(time.Now()),
				UpdatedAt:     timestamppb.New(time.Now()),
			},
			wantErr: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := adapters.ProtoToETCMeisaiRecord(tt.input)

			if tt.wantErr {
				assert.Error(t, err)
				if tt.errMsg != "" {
					assert.Contains(t, err.Error(), tt.errMsg)
				}
				return
			}

			require.NoError(t, err)
			assert.NotNil(t, got)
			assert.Equal(t, tt.input.Id, got.ID)
			assert.Equal(t, tt.input.Hash, got.Hash)
		})
	}
}

