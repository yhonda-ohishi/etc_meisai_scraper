package parser_test

import (
	"bytes"
	"strings"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"github.com/yhonda-ohishi/etc_meisai/src/parser"
)

// TestCSVParser_MalformedData tests edge cases and malformed CSV data (T008)
func TestCSVParser_MalformedData(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name           string
		csvData        string
		expectErrors   bool
		expectedErrors int
		description    string
	}{
		{
			name:           "null bytes in data",
			csvData:        "2025/07/30,08:15\x00,東京IC,横浜IC,1000,普通車,1234,5678,東名高速道路,現金,なし,2025/08,1234-5678-9012-3456",
			expectErrors:   true,
			expectedErrors: 1,
			description:    "CSV with null bytes should be handled",
		},
		{
			name:           "extremely long line",
			csvData:        "2025/07/30,08:15," + strings.Repeat("A", 10000) + ",横浜IC,1000,普通車,1234,5678,東名高速道路,現金,なし,2025/08,1234-5678-9012-3456",
			expectErrors:   false,
			expectedErrors: 0,
			description:    "Very long IC names should be handled",
		},
		{
			name:           "mixed line endings",
			csvData:        "2025/07/30,08:15,東京IC,横浜IC,1000,普通車,1234,5678,東名高速道路,現金,なし,2025/08,1234-5678-9012-3456\r\n2025/07/31,09:30,横浜IC,静岡IC,2500,普通車,1234,5678,東名高速道路,現金,なし,2025/08,1234-5678-9012-3456\r2025/08/01,10:45,静岡IC,名古屋IC,3000,普通車,1234,5678,東名高速道路,現金,なし,2025/08,1234-5678-9012-3456\n",
			expectErrors:   false,
			expectedErrors: 0,
			description:    "Mixed CRLF, CR, and LF should all work",
		},
		{
			name:           "incomplete escape sequences",
			csvData:        `"2025/07/30","08:15","東京IC\"`,
			expectErrors:   true,
			expectedErrors: 1,
			description:    "Incomplete escape sequences in quoted fields",
		},
		{
			name:           "mismatched quotes",
			csvData:        `"2025/07/30,"08:15",東京IC,横浜IC,1000,普通車,1234,5678,東名高速道路,現金,なし,2025/08,1234-5678-9012-3456`,
			expectErrors:   true,
			expectedErrors: 1,
			description:    "Mismatched quotes in CSV fields",
		},
		{
			name:           "only commas",
			csvData:        ",,,,,,,,,,,,,",
			expectErrors:   false,
			expectedErrors: 0,
			description:    "Row with only commas (empty fields)",
		},
		{
			name:           "tab separated instead of comma",
			csvData:        "2025/07/30\t08:15\t東京IC\t横浜IC\t1000\t普通車\t1234\t5678\t東名高速道路\t現金\tなし\t2025/08\t1234-5678-9012-3456",
			expectErrors:   true,
			expectedErrors: 1,
			description:    "Tab-separated data should fail",
		},
		{
			name:           "extra columns",
			csvData:        "2025/07/30,08:15,東京IC,横浜IC,1000,普通車,1234,5678,東名高速道路,現金,なし,2025/08,1234-5678-9012-3456,extra1,extra2,extra3",
			expectErrors:   false,
			expectedErrors: 0,
			description:    "Extra columns should be ignored",
		},
		{
			name:           "unicode normalization issues",
			csvData:        "2025/07/30,08:15,東京ＩＣ,横浜ＩＣ,1000,普通車,1234,5678,東名高速道路,現金,なし,2025/08,1234-5678-9012-3456", // Full-width IC
			expectErrors:   false,
			expectedErrors: 0,
			description:    "Full-width characters should be handled",
		},
		{
			name:           "amount with comma separator",
			csvData:        "2025/07/30,08:15,東京IC,横浜IC,\"1,000\",普通車,1234,5678,東名高速道路,現金,なし,2025/08,1234-5678-9012-3456",
			expectErrors:   true,
			expectedErrors: 1,
			description:    "Amount with comma separator should fail to parse",
		},
		{
			name:           "invalid UTF-8 sequence",
			csvData:        "2025/07/30,08:15,\xff\xfe,横浜IC,1000,普通車,1234,5678,東名高速道路,現金,なし,2025/08,1234-5678-9012-3456",
			expectErrors:   false, // Parser should handle invalid UTF-8 gracefully
			expectedErrors: 0,
			description:    "Invalid UTF-8 sequences should be handled",
		},
		{
			name:           "carriage return in field",
			csvData:        "2025/07/30,08:15,\"東京\rIC\",横浜IC,1000,普通車,1234,5678,東名高速道路,現金,なし,2025/08,1234-5678-9012-3456",
			expectErrors:   false,
			expectedErrors: 0,
			description:    "Carriage return within quoted field",
		},
		{
			name:           "empty quoted field",
			csvData:        "2025/07/30,08:15,\"\",横浜IC,1000,普通車,1234,5678,東名高速道路,現金,なし,2025/08,1234-5678-9012-3456",
			expectErrors:   false,
			expectedErrors: 0,
			description:    "Empty quoted field should be valid",
		},
		{
			name:           "consecutive commas",
			csvData:        "2025/07/30,08:15,,横浜IC,1000,普通車,1234,5678,東名高速道路,現金,なし,2025/08,1234-5678-9012-3456",
			expectErrors:   false,
			expectedErrors: 0,
			description:    "Consecutive commas (empty field) should be valid",
		},
		{
			name:           "amount overflow",
			csvData:        "2025/07/30,08:15,東京IC,横浜IC,99999999999999999999,普通車,1234,5678,東名高速道路,現金,なし,2025/08,1234-5678-9012-3456",
			expectErrors:   false,
			expectedErrors: 0,
			description:    "Amount overflow should be handled",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			parser := parser.NewETCCSVParser()
			reader := strings.NewReader(tt.csvData)

			result, err := parser.Parse(reader)
			assert.NoError(t, err, "Parse should not return error")
			assert.NotNil(t, result, "Result should not be nil")

			if tt.expectErrors {
				assert.GreaterOrEqual(t, result.ErrorRows, tt.expectedErrors,
					"Expected at least %d errors for: %s", tt.expectedErrors, tt.description)
			} else {
				assert.Equal(t, tt.expectedErrors, result.ErrorRows,
					"Expected exactly %d errors for: %s", tt.expectedErrors, tt.description)
			}
		})
	}
}

// TestCSVParser_ReaderErrors tests handling of reader errors (T008)
func TestCSVParser_ReaderErrors(t *testing.T) {
	t.Parallel()

	t.Run("empty reader", func(t *testing.T) {
		parser := parser.NewETCCSVParser()
		reader := strings.NewReader("")

		result, err := parser.Parse(reader)
		assert.NoError(t, err)
		assert.NotNil(t, result)
		assert.Equal(t, 0, result.TotalRows)
		assert.Equal(t, 0, result.ValidRows)
	})

	t.Run("reader with single invalid row", func(t *testing.T) {
		parser := parser.NewETCCSVParser()
		reader := strings.NewReader("invalid")

		result, err := parser.Parse(reader)
		assert.NoError(t, err)
		assert.NotNil(t, result)
		assert.Equal(t, 0, result.TotalRows)
		assert.Equal(t, 1, result.ErrorRows)
	})

	t.Run("very large CSV", func(t *testing.T) {
		// Generate a large CSV to test memory handling
		var buf bytes.Buffer
		for i := 0; i < 10000; i++ {
			buf.WriteString("2025/07/30,08:15,東京IC,横浜IC,1000,普通車,1234,5678,東名高速道路,現金,なし,2025/08,1234-5678-9012-3456\n")
		}

		parser := parser.NewETCCSVParser()
		result, err := parser.Parse(&buf)

		assert.NoError(t, err)
		assert.NotNil(t, result)
		assert.Equal(t, 0, result.TotalRows) // All rows have insufficient columns
		assert.Equal(t, 10000, result.ErrorRows)
	})
}

// TestCSVParser_BoundaryConditions tests boundary conditions (T008)
func TestCSVParser_BoundaryConditions(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name        string
		csvData     string
		description string
	}{
		{
			name:        "single character fields",
			csvData:     "a,b,c,d,e,f,g,h,i,j,k,l,m",
			description: "Single character in each field",
		},
		{
			name:        "maximum int32 amount",
			csvData:     "2025/07/30,08:15,東京IC,横浜IC,2147483647,普通車,1234,5678,東名高速道路,現金,なし,2025/08,1234-5678-9012-3456",
			description: "Maximum int32 value for amount",
		},
		{
			name:        "minimum int32 amount",
			csvData:     "2025/07/30,08:15,東京IC,横浜IC,-2147483648,普通車,1234,5678,東名高速道路,現金,なし,2025/08,1234-5678-9012-3456",
			description: "Minimum int32 value for amount",
		},
		{
			name:        "year 9999",
			csvData:     "9999/12/31,23:59,東京IC,横浜IC,1000,普通車,1234,5678,東名高速道路,現金,なし,9999/12,1234-5678-9012-3456",
			description: "Maximum year value",
		},
		{
			name:        "year 0000",
			csvData:     "0000/01/01,00:00,東京IC,横浜IC,1000,普通車,1234,5678,東名高速道路,現金,なし,0000/01,1234-5678-9012-3456",
			description: "Minimum year value",
		},
		{
			name:        "exactly 13 columns",
			csvData:     "1,2,3,4,5,6,7,8,9,10,11,12,13",
			description: "Exactly 13 columns",
		},
		{
			name:        "exactly 12 columns",
			csvData:     "1,2,3,4,5,6,7,8,9,10,11,12",
			description: "One column short",
		},
		{
			name:        "exactly 14 columns",
			csvData:     "1,2,3,4,5,6,7,8,9,10,11,12,13,14",
			description: "One column extra",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			parser := parser.NewETCCSVParser()
			reader := strings.NewReader(tt.csvData)

			result, err := parser.Parse(reader)
			require.NoError(t, err, "Parse should not return error for: %s", tt.description)
			require.NotNil(t, result, "Result should not be nil for: %s", tt.description)

			// Just ensure the parser doesn't panic on boundary conditions
			t.Logf("%s - Processed: Total=%d, Valid=%d, Errors=%d",
				tt.description, result.TotalRows, result.ValidRows, result.ErrorRows)
		})
	}
}

