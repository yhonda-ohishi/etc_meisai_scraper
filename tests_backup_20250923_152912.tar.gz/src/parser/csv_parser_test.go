package parser_test

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"github.com/yhonda-ohishi/etc_meisai/src/parser"
)

func TestNewETCCSVParser(t *testing.T) {
	t.Parallel()

	p := parser.NewETCCSVParser()
	assert.NotNil(t, p)
}

func TestETCCSVParser_Parse(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name      string
		csvData   string
		wantRows  int
		wantValid int
		wantError int
		verify    func(*testing.T, *parser.ParseResult)
	}{
		{
			name: "valid ETC data",
			csvData: `2025/07/30,08:15,2025/07/30,08:30,東京IC,横浜IC,横浜料金所,1000,通常,普通車,品川300あ1234,1234-5678-9012-3456,備考
2025/07/31,09:30,2025/07/31,10:00,横浜IC,静岡IC,静岡料金所,2500,通常,普通車,品川300あ1234,1234-5678-9012-3456,備考`,
			wantRows:  2,
			wantValid: 2,
			wantError: 0,
			verify: func(t *testing.T, result *parser.ParseResult) {
				assert.Len(t, result.Records, 2)

				// First record
				rec1 := result.Records[0]
				assert.Equal(t, "東京IC", rec1.EntryIC)
				assert.Equal(t, "横浜IC", rec1.ExitIC)
				assert.Equal(t, int32(1000), rec1.Amount)
				assert.Equal(t, "1234-5678-9012-3456", rec1.ETCNumber)

				// Second record
				rec2 := result.Records[1]
				assert.Equal(t, "横浜IC", rec2.EntryIC)
				assert.Equal(t, "静岡IC", rec2.ExitIC)
				assert.Equal(t, int32(2500), rec2.Amount)
			},
		},
		{
			name: "skip header row",
			csvData: `利用年月日（自）,時刻（自）,利用年月日（至）,時刻（至）,利用ＩＣ（自）,利用ＩＣ（至）,料金所名,通行料金,通行区分,車種,車両番号,ＥＴＣカード番号,備考
2025/07/30,08:15,2025/07/30,08:30,東京IC,横浜IC,横浜料金所,1000,通常,普通車,品川300あ1234,1234-5678-9012-3456,備考`,
			wantRows:  2,
			wantValid: 1,
			wantError: 0,
			verify: func(t *testing.T, result *parser.ParseResult) {
				assert.Len(t, result.Records, 1)
			},
		},
		{
			name: "invalid row - insufficient columns",
			csvData: `2025/07/30,08:15,東京IC,横浜IC,1000`,
			wantRows:  1,
			wantValid: 0,
			wantError: 1,
			verify: func(t *testing.T, result *parser.ParseResult) {
				assert.Len(t, result.Records, 0)
				assert.Len(t, result.Errors, 1)
				assert.Contains(t, result.Errors[0].Message, "insufficient columns")
			},
		},
		{
			name: "mixed valid and invalid rows",
			csvData: `2025/07/30,08:15,2025/07/30,08:30,東京IC,横浜IC,横浜IC,1000,通常,普通車,品川300あ1234,1234-5678-9012-3456,備考
invalid row with too few columns
2025/07/31,09:30,2025/07/31,10:00,横浜IC,静岡IC,静岡IC,2500,通常,普通車,品川300あ1234,1234-5678-9012-3456,備考`,
			wantRows:  2,
			wantValid: 2,
			wantError: 1,
			verify: func(t *testing.T, result *parser.ParseResult) {
				assert.Len(t, result.Records, 2)
				assert.Len(t, result.Errors, 1)
			},
		},
		{
			name:      "empty CSV",
			csvData:   "",
			wantRows:  0,
			wantValid: 0,
			wantError: 0,
			verify: func(t *testing.T, result *parser.ParseResult) {
				assert.Len(t, result.Records, 0)
				assert.Len(t, result.Errors, 0)
			},
		},
		{
			name: "various date formats",
			csvData: `25/07/30,08:15,東京IC,横浜IC,1000,普通車,1234,5678,東名高速道路,現金,なし,2025/08,1234-5678-9012-3456
2025/7/31,09:30,横浜IC,静岡IC,2500,普通車,1234,5678,東名高速道路,現金,なし,2025/08,1234-5678-9012-3456
2025-08-01,10:45,静岡IC,名古屋IC,3000,普通車,1234,5678,東名高速道路,現金,なし,2025/08,1234-5678-9012-3456`,
			wantRows:  3,
			wantValid: 3,
			wantError: 0,
			verify: func(t *testing.T, result *parser.ParseResult) {
				assert.Len(t, result.Records, 3)
				// Check that dates were parsed correctly
				for _, rec := range result.Records {
					assert.NotZero(t, rec.UseDate)
				}
			},
		},
		{
			name: "invalid amount value",
			csvData: `2025/07/30,08:15,2025/07/30,08:30,東京IC,横浜IC,横浜料金所,invalid,通常,普通車,品川300あ1234,1234-5678-9012-3456,備考`,
			wantRows:  1,
			wantValid: 1,  // parseAmount returns 0 for invalid, which is accepted as valid
			wantError: 0,
			verify: func(t *testing.T, result *parser.ParseResult) {
				assert.Len(t, result.Records, 1)
				assert.Len(t, result.Errors, 0)
				// Invalid amount becomes 0
				assert.Equal(t, int32(0), result.Records[0].Amount)
			},
		},
		{
			name: "CSV with quotes",
			csvData: `"2025/07/30","08:15","2025/07/30","08:30","東京IC","横浜IC","横浜料金所","1000","通常","普通車","品川300あ1234","1234-5678-9012-3456","備考"`,
			wantRows:  1,
			wantValid: 1,
			wantError: 0,
			verify: func(t *testing.T, result *parser.ParseResult) {
				assert.Len(t, result.Records, 1)
			},
		},
		{
			name: "CSV with leading spaces",
			csvData: `  2025/07/30,  08:15,  2025/07/30,  08:30,  東京IC,  横浜IC,  横浜料金所,  1000,  通常,  普通車,  品川300あ1234,  1234-5678-9012-3456,  備考`,
			wantRows:  1,
			wantValid: 1,
			wantError: 0,
			verify: func(t *testing.T, result *parser.ParseResult) {
				assert.Len(t, result.Records, 1)
				assert.Equal(t, "東京IC", result.Records[0].EntryIC)
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			parser := parser.NewETCCSVParser()
			reader := strings.NewReader(tt.csvData)

			result, err := parser.Parse(reader)
			assert.NoError(t, err)
			assert.NotNil(t, result)

			assert.Equal(t, tt.wantRows, result.TotalRows, "Total rows mismatch")
			assert.Equal(t, tt.wantValid, result.ValidRows, "Valid rows mismatch")
			assert.Equal(t, tt.wantError, result.ErrorRows, "Error rows mismatch")

			if tt.verify != nil {
				tt.verify(t, result)
			}
		})
	}
}

func TestETCCSVParser_ParseFile(t *testing.T) {
	// This test requires creating a temporary file
	t.Run("parse valid file", func(t *testing.T) {
		// Create temporary directory
		tmpDir := t.TempDir()

		// Create test CSV file
		csvPath := filepath.Join(tmpDir, "test.csv")
		csvData := `2025/07/30,08:15,2025/07/30,08:30,東京IC,横浜IC,横浜料金所,1000,通常,普通車,品川300あ1234,1234-5678-9012-3456,備考`

		err := os.WriteFile(csvPath, []byte(csvData), 0644)
		require.NoError(t, err)

		// Parse the file
		parser := parser.NewETCCSVParser()
		records, err := parser.ParseFile(csvPath)

		assert.NoError(t, err)
		assert.Len(t, records, 1)
		assert.Equal(t, "東京IC", records[0].EntryIC)
		assert.Equal(t, "横浜IC", records[0].ExitIC)
		assert.Equal(t, int32(1000), records[0].Amount)
	})

	t.Run("file not found", func(t *testing.T) {
		parser := parser.NewETCCSVParser()
		_, err := parser.ParseFile("/non/existent/file.csv")
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "failed to open CSV file")
	})
}

func TestETCCSVParser_ParseCSVFile(t *testing.T) {
	// This is an alias method test
	t.Run("compatibility method", func(t *testing.T) {
		// Create temporary directory
		tmpDir := t.TempDir()

		// Create test CSV file
		csvPath := filepath.Join(tmpDir, "test.csv")
		csvData := `2025/07/30,08:15,2025/07/30,08:30,東京IC,横浜IC,横浜料金所,1000,通常,普通車,品川300あ1234,1234-5678-9012-3456,備考`

		err := os.WriteFile(csvPath, []byte(csvData), 0644)
		require.NoError(t, err)

		// Parse the file using compatibility method
		parser := parser.NewETCCSVParser()
		records, err := parser.ParseCSVFile(csvPath, true) // isCorporate parameter is ignored

		assert.NoError(t, err)
		assert.Len(t, records, 1)
	})
}

func TestETCCSVParser_EdgeCases(t *testing.T) {
	t.Parallel()

	parser := parser.NewETCCSVParser()

	t.Run("reader returns error", func(t *testing.T) {
		// Create a reader with malformed CSV data
		reader := strings.NewReader("unclosed quote: \"malformed data without closing quote\nasdf")

		result, err := parser.Parse(reader)
		assert.NoError(t, err) // Parse doesn't return error, but captures it
		assert.NotNil(t, result)
		assert.Greater(t, result.ErrorRows, 0)
	})

	t.Run("malformed CSV", func(t *testing.T) {
		csvData := `"unterminated quote
2025/07/30,08:15,東京IC,横浜IC,1000,普通車,1234,5678,東名高速道路,現金,なし,2025/08,1234-5678-9012-3456`

		reader := strings.NewReader(csvData)
		result, err := parser.Parse(reader)

		assert.NoError(t, err)
		assert.NotNil(t, result)
		// Should have at least one error from malformed line
		assert.Greater(t, result.ErrorRows, 0)
	})

	t.Run("unicode in CSV", func(t *testing.T) {
		csvData := `2025/07/30,08:15,2025/07/30,08:30,東京IC🗼,横浜IC⚓,横浜料金所,1000,通常,普通車,品川300あ1234,1234-5678-9012-3456,備考`

		reader := strings.NewReader(csvData)
		result, err := parser.Parse(reader)

		assert.NoError(t, err)
		assert.NotNil(t, result)
		assert.Equal(t, 1, result.ValidRows)
		assert.Contains(t, result.Records[0].EntryIC, "東京IC")
	})

	t.Run("very large amount", func(t *testing.T) {
		csvData := `2025/07/30,08:15,2025/07/30,08:30,東京IC,横浜IC,横浜料金所,999999999,通常,普通車,品川300あ1234,1234-5678-9012-3456,備考`

		reader := strings.NewReader(csvData)
		result, err := parser.Parse(reader)

		assert.NoError(t, err)
		assert.NotNil(t, result)
		assert.Equal(t, 1, result.ValidRows)
		assert.Equal(t, int32(999999999), result.Records[0].Amount)
	})

	t.Run("negative amount", func(t *testing.T) {
		csvData := `2025/07/30,08:15,2025/07/30,08:30,東京IC,横浜IC,横浜料金所,-1000,通常,普通車,品川300あ1234,1234-5678-9012-3456,備考`

		reader := strings.NewReader(csvData)
		result, err := parser.Parse(reader)

		assert.NoError(t, err)
		assert.NotNil(t, result)
		assert.Equal(t, 1, result.ValidRows)
		assert.Equal(t, int32(-1000), result.Records[0].Amount)
	})
}

func TestETCCSVParser_DateFormats(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name       string
		dateStr    string
		wantYear   int
		wantMonth  time.Month
		wantDay    int
	}{
		{"2-digit year", "25/07/30", 2025, time.July, 30},
		{"4-digit year", "2025/07/30", 2025, time.July, 30},
		{"2-digit no padding", "25/7/3", 2025, time.July, 3},
		{"4-digit no padding", "2025/7/3", 2025, time.July, 3},
		{"hyphen format", "2025-07-30", 2025, time.July, 30},
		{"dot format", "2025.07.30", 2025, time.July, 30},
		{"no separator", "20250730", 2025, time.July, 30},
	}

	parser := parser.NewETCCSVParser()

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			csvData := tt.dateStr + `,08:15,東京IC,横浜IC,1000,普通車,1234,5678,東名高速道路,現金,なし,2025/08,1234-5678-9012-3456`

			reader := strings.NewReader(csvData)
			result, err := parser.Parse(reader)

			assert.NoError(t, err)
			assert.NotNil(t, result)
			assert.Equal(t, 1, result.ValidRows)

			if len(result.Records) > 0 {
				date := result.Records[0].UseDate
				assert.Equal(t, tt.wantYear, date.Year())
				assert.Equal(t, tt.wantMonth, date.Month())
				assert.Equal(t, tt.wantDay, date.Day())
			}
		})
	}
}

func TestETCCSVParser_ParseResult(t *testing.T) {
	t.Parallel()

	parser := parser.NewETCCSVParser()

	t.Run("accumulates statistics correctly", func(t *testing.T) {
		csvData := `header row with insufficient columns
2025/07/30,08:15,2025/07/30,08:30,東京IC,横浜IC,横浜料金所,1000,通常,普通車,品川300あ1234,1234-5678-9012-3456,備考
invalid row
2025/07/31,09:30,2025/07/31,10:00,横浜IC,静岡IC,静岡料金所,2500,通常,普通車,品川300あ1234,1234-5678-9012-3456,備考
malformed,row,with,too,few,columns
2025/08/01,10:45,2025/08/01,11:30,静岡IC,名古屋IC,名古屋料金所,3000,通常,普通車,品川300あ1234,1234-5678-9012-3456,備考`

		reader := strings.NewReader(csvData)
		result, err := parser.Parse(reader)

		assert.NoError(t, err)
		assert.NotNil(t, result)

		assert.Equal(t, 2, result.TotalRows)
		assert.Equal(t, 0, result.ValidRows)
		assert.Equal(t, 6, result.ErrorRows) // All rows are errors due to insufficient columns
		assert.Len(t, result.Records, 0)
		assert.Len(t, result.Errors, 6)
	})
}

