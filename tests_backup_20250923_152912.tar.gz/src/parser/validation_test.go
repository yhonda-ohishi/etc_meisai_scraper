package parser_test

import (
	"encoding/json"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/yhonda-ohishi/etc_meisai/src/models"
	"github.com/yhonda-ohishi/etc_meisai/src/parser"
)

func TestParseResult(t *testing.T) {
	t.Parallel()

	t.Run("new parse result", func(t *testing.T) {
		result := &parser.ParseResult{
			Records:        []*models.ETCMeisai{},
			TotalRows:      10,
			ValidRows:      8,
			ErrorRows:      2,
			DuplicateCount: 1,
			Errors:         []parser.ParseError{},
		}

		assert.NotNil(t, result)
		assert.Equal(t, 10, result.TotalRows)
		assert.Equal(t, 8, result.ValidRows)
		assert.Equal(t, 2, result.ErrorRows)
		assert.Equal(t, 1, result.DuplicateCount)
		assert.Empty(t, result.Records)
		assert.Empty(t, result.Errors)
	})

	t.Run("add records to result", func(t *testing.T) {
		result := &parser.ParseResult{
			Records: []*models.ETCMeisai{},
		}

		// Add some records
		rec1 := &models.ETCMeisai{
			EntryIC: "東京IC",
			ExitIC:  "横浜IC",
			Amount:  1000,
		}
		rec2 := &models.ETCMeisai{
			EntryIC: "横浜IC",
			ExitIC:  "静岡IC",
			Amount:  2500,
		}

		result.Records = append(result.Records, rec1, rec2)
		result.ValidRows = 2
		result.TotalRows = 2

		assert.Len(t, result.Records, 2)
		assert.Equal(t, 2, result.ValidRows)
		assert.Equal(t, 2, result.TotalRows)
		assert.Equal(t, "東京IC", result.Records[0].EntryIC)
		assert.Equal(t, "静岡IC", result.Records[1].ExitIC)
	})

	t.Run("add errors to result", func(t *testing.T) {
		result := &parser.ParseResult{
			Errors: []parser.ParseError{},
		}

		err1 := parser.ParseError{
			Row:     1,
			Column:  "amount",
			Message: "invalid amount format",
			Value:   "abc",
		}
		err2 := parser.ParseError{
			Row:     5,
			Message: "insufficient columns",
		}

		result.Errors = append(result.Errors, err1, err2)
		result.ErrorRows = 2
		result.TotalRows = 10
		result.ValidRows = 8

		assert.Len(t, result.Errors, 2)
		assert.Equal(t, 2, result.ErrorRows)
		assert.Equal(t, 1, result.Errors[0].Row)
		assert.Equal(t, "amount", result.Errors[0].Column)
		assert.Equal(t, "abc", result.Errors[0].Value)
		assert.Equal(t, 5, result.Errors[1].Row)
		assert.Empty(t, result.Errors[1].Column)
	})

	t.Run("JSON marshaling", func(t *testing.T) {
		result := &parser.ParseResult{
			Records: []*models.ETCMeisai{
				{
					EntryIC:   "東京IC",
					ExitIC:    "横浜IC",
					Amount:    1000,
					ETCNumber: "1234-5678",
				},
			},
			TotalRows:      5,
			ValidRows:      4,
			ErrorRows:      1,
			DuplicateCount: 0,
			Errors: []parser.ParseError{
				{
					Row:     3,
					Column:  "date",
					Message: "invalid date format",
					Value:   "not-a-date",
				},
			},
		}

		// Marshal to JSON
		data, err := json.Marshal(result)
		assert.NoError(t, err)
		assert.NotEmpty(t, data)

		// Unmarshal back
		var decoded parser.ParseResult
		err = json.Unmarshal(data, &decoded)
		assert.NoError(t, err)

		assert.Equal(t, result.TotalRows, decoded.TotalRows)
		assert.Equal(t, result.ValidRows, decoded.ValidRows)
		assert.Equal(t, result.ErrorRows, decoded.ErrorRows)
		assert.Equal(t, result.DuplicateCount, decoded.DuplicateCount)
		assert.Len(t, decoded.Records, 1)
		assert.Len(t, decoded.Errors, 1)
		assert.Equal(t, "東京IC", decoded.Records[0].EntryIC)
		assert.Equal(t, "invalid date format", decoded.Errors[0].Message)
	})
}

func TestParseError(t *testing.T) {
	t.Parallel()

	t.Run("create parse error", func(t *testing.T) {
		err := parser.ParseError{
			Row:     10,
			Column:  "amount",
			Message: "amount must be positive",
			Value:   "-100",
		}

		assert.Equal(t, 10, err.Row)
		assert.Equal(t, "amount", err.Column)
		assert.Equal(t, "amount must be positive", err.Message)
		assert.Equal(t, "-100", err.Value)
	})

	t.Run("parse error without column", func(t *testing.T) {
		err := parser.ParseError{
			Row:     5,
			Message: "row has insufficient columns",
		}

		assert.Equal(t, 5, err.Row)
		assert.Empty(t, err.Column)
		assert.Equal(t, "row has insufficient columns", err.Message)
		assert.Empty(t, err.Value)
	})

	t.Run("JSON marshaling", func(t *testing.T) {
		err := parser.ParseError{
			Row:     15,
			Column:  "date",
			Message: "invalid date format",
			Value:   "2025-13-40", // Invalid month and day
		}

		// Marshal to JSON
		data, err2 := json.Marshal(err)
		assert.NoError(t, err2)
		assert.NotEmpty(t, data)

		// Unmarshal back
		var decoded parser.ParseError
		err2 = json.Unmarshal(data, &decoded)
		assert.NoError(t, err2)

		assert.Equal(t, err.Row, decoded.Row)
		assert.Equal(t, err.Column, decoded.Column)
		assert.Equal(t, err.Message, decoded.Message)
		assert.Equal(t, err.Value, decoded.Value)
	})

	t.Run("JSON omit empty fields", func(t *testing.T) {
		err := parser.ParseError{
			Row:     20,
			Message: "general error",
			// Column and Value are empty
		}

		data, err2 := json.Marshal(err)
		assert.NoError(t, err2)

		// Check that empty fields are omitted
		var decoded map[string]interface{}
		err2 = json.Unmarshal(data, &decoded)
		assert.NoError(t, err2)

		assert.Contains(t, decoded, "row")
		assert.Contains(t, decoded, "message")
		// Column and Value should be omitted when empty
		_, hasColumn := decoded["column"]
		_, hasValue := decoded["value"]
		assert.False(t, hasColumn || hasValue)
	})
}

func TestParseResult_Statistics(t *testing.T) {
	t.Parallel()

	t.Run("calculate success rate", func(t *testing.T) {
		result := &parser.ParseResult{
			TotalRows: 100,
			ValidRows: 95,
			ErrorRows: 5,
		}

		successRate := float64(result.ValidRows) / float64(result.TotalRows) * 100
		assert.Equal(t, 95.0, successRate)
	})

	t.Run("handle zero total rows", func(t *testing.T) {
		result := &parser.ParseResult{
			TotalRows: 0,
			ValidRows: 0,
			ErrorRows: 0,
		}

		// Should handle division by zero gracefully
		if result.TotalRows > 0 {
			successRate := float64(result.ValidRows) / float64(result.TotalRows) * 100
			assert.Equal(t, 0.0, successRate)
		} else {
			// No calculation when total is zero
			assert.Equal(t, 0, result.TotalRows)
		}
	})

	t.Run("track duplicates", func(t *testing.T) {
		result := &parser.ParseResult{
			TotalRows:      100,
			ValidRows:      90,
			ErrorRows:      5,
			DuplicateCount: 5,
		}

		// Duplicates are counted separately from errors
		assert.Equal(t, 5, result.DuplicateCount)
		assert.Equal(t, 5, result.ErrorRows)

		// Total unique valid records
		uniqueValid := result.ValidRows - result.DuplicateCount
		assert.Equal(t, 85, uniqueValid)
	})
}

func TestParseResult_Validation(t *testing.T) {
	t.Parallel()

	t.Run("validate consistency", func(t *testing.T) {
		result := &parser.ParseResult{
			Records:   make([]*models.ETCMeisai, 10),
			TotalRows: 15,
			ValidRows: 10,
			ErrorRows: 5,
			Errors:    make([]parser.ParseError, 5),
		}

		// Check consistency
		assert.Equal(t, result.TotalRows, result.ValidRows+result.ErrorRows)
		assert.Len(t, result.Records, result.ValidRows)
		assert.Len(t, result.Errors, result.ErrorRows)
	})

	t.Run("nil records slice", func(t *testing.T) {
		result := &parser.ParseResult{
			Records: nil,
		}

		assert.Nil(t, result.Records)

		// Initialize if needed
		if result.Records == nil {
			result.Records = make([]*models.ETCMeisai, 0)
		}
		assert.NotNil(t, result.Records)
		assert.Empty(t, result.Records)
	})
}

func TestParseError_ErrorTypes(t *testing.T) {
	t.Parallel()

	errorTypes := []struct {
		name string
		err  parser.ParseError
	}{
		{
			name: "date parse error",
			err: parser.ParseError{
				Row:     1,
				Column:  "use_date",
				Message: "cannot parse date",
				Value:   "invalid-date",
			},
		},
		{
			name: "amount parse error",
			err: parser.ParseError{
				Row:     2,
				Column:  "amount",
				Message: "invalid number format",
				Value:   "abc123",
			},
		},
		{
			name: "missing required field",
			err: parser.ParseError{
				Row:     3,
				Column:  "entry_ic",
				Message: "required field is empty",
				Value:   "",
			},
		},
		{
			name: "row format error",
			err: parser.ParseError{
				Row:     4,
				Message: "row has wrong number of columns",
			},
		},
		{
			name: "encoding error",
			err: parser.ParseError{
				Row:     5,
				Message: "invalid character encoding",
			},
		},
	}

	for _, tt := range errorTypes {
		t.Run(tt.name, func(t *testing.T) {
			assert.NotEmpty(t, tt.err.Message)
			assert.Greater(t, tt.err.Row, 0)

			// Serialize and deserialize
			data, err := json.Marshal(tt.err)
			assert.NoError(t, err)

			var decoded parser.ParseError
			err = json.Unmarshal(data, &decoded)
			assert.NoError(t, err)
			assert.Equal(t, tt.err.Row, decoded.Row)
			assert.Equal(t, tt.err.Message, decoded.Message)
		})
	}
}