package parser_test

import (
	"io"
	"os"
	"path/filepath"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"github.com/yhonda-ohishi/etc_meisai/src/parser"
	"golang.org/x/text/encoding"
	"golang.org/x/text/encoding/japanese"
	"golang.org/x/text/encoding/unicode"
)

func TestNewEncodingDetector(t *testing.T) {
	t.Parallel()

	detector := parser.NewEncodingDetector()
	assert.NotNil(t, detector)
}

func TestEncodingDetector_DetectEncoding(t *testing.T) {
	t.Parallel()

	detector := parser.NewEncodingDetector()

	tests := []struct {
		name         string
		data         []byte
		wantEncoding encoding.Encoding
	}{
		{
			name:         "UTF-8 with BOM",
			data:         append([]byte{0xEF, 0xBB, 0xBF}, []byte("Hello, 世界")...),
			wantEncoding: unicode.UTF8BOM,
		},
		{
			name:         "UTF-8 without BOM",
			data:         []byte("Hello, 世界"),
			wantEncoding: unicode.UTF8,
		},
		{
			name:         "ASCII only",
			data:         []byte("Hello, World!"),
			wantEncoding: unicode.UTF8, // ASCII is valid UTF-8
		},
		{
			name:         "empty data",
			data:         []byte{},
			wantEncoding: unicode.UTF8, // Default to UTF-8
		},
		{
			name: "Shift-JIS data",
			// "こんにちは" in Shift-JIS
			data:         []byte{0x82, 0xb1, 0x82, 0xf1, 0x82, 0xc9, 0x82, 0xbf, 0x82, 0xcd},
			wantEncoding: japanese.ShiftJIS,
		},
		{
			name: "EUC-JP data",
			// "こんにちは" in EUC-JP
			data:         []byte{0xa4, 0xb3, 0xa4, 0xf3, 0xa4, 0xcb, 0xa4, 0xc1, 0xa4, 0xcf},
			wantEncoding: japanese.EUCJP,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			enc := detector.DetectEncoding(tt.data)
			// Note: Exact encoding detection can be difficult,
			// so we may need to be flexible with assertions
			assert.NotNil(t, enc)

			// For known UTF-8, we can be more specific
			if tt.name == "UTF-8 with BOM" || tt.name == "UTF-8 without BOM" || tt.name == "ASCII only" {
				// UTF-8 family should be detected
				assert.NotNil(t, enc)
			}
		})
	}
}

func TestEncodingDetector_OpenFileWithDetectedEncoding(t *testing.T) {
	detector := parser.NewEncodingDetector()

	t.Run("open UTF-8 file", func(t *testing.T) {
		// Create a temporary UTF-8 file
		tmpDir := t.TempDir()
		filePath := filepath.Join(tmpDir, "utf8.txt")
		content := "Hello, 世界\n"
		err := os.WriteFile(filePath, []byte(content), 0644)
		require.NoError(t, err)

		// Open with encoding detection
		reader, enc, err := detector.OpenFileWithDetectedEncoding(filePath)
		assert.NoError(t, err)
		assert.NotNil(t, reader)
		assert.NotNil(t, enc)

		// Read content
		data, err := io.ReadAll(reader)
		assert.NoError(t, err)
		assert.Contains(t, string(data), "Hello")

		// Close if it's a closer
		if closer, ok := reader.(io.Closer); ok {
			closer.Close()
		}
	})

	t.Run("open non-existent file", func(t *testing.T) {
		_, _, err := detector.OpenFileWithDetectedEncoding("/non/existent/file.txt")
		assert.Error(t, err)
	})

	t.Run("open Shift-JIS file", func(t *testing.T) {
		// Create a temporary Shift-JIS file
		tmpDir := t.TempDir()
		filePath := filepath.Join(tmpDir, "sjis.txt")

		// "こんにちは" in Shift-JIS
		sjisData := []byte{0x82, 0xb1, 0x82, 0xf1, 0x82, 0xc9, 0x82, 0xbf, 0x82, 0xcd}
		err := os.WriteFile(filePath, sjisData, 0644)
		require.NoError(t, err)

		// Open with encoding detection
		reader, enc, err := detector.OpenFileWithDetectedEncoding(filePath)
		assert.NoError(t, err)
		assert.NotNil(t, reader)
		assert.NotNil(t, enc)

		// The reader should decode the Shift-JIS to UTF-8
		data, err := io.ReadAll(reader)
		assert.NoError(t, err)
		// After decoding, should contain Japanese text
		assert.NotEmpty(t, data)

		// Close if it's a closer
		if closer, ok := reader.(io.Closer); ok {
			closer.Close()
		}
	})
}

func TestEncodingDetector_EdgeCases(t *testing.T) {
	t.Parallel()

	detector := parser.NewEncodingDetector()

	t.Run("detect encoding with small buffer", func(t *testing.T) {
		// Very small data that might not be enough for detection
		data := []byte{0x41, 0x42} // "AB"
		enc := detector.DetectEncoding(data)
		assert.NotNil(t, enc)
	})

	t.Run("detect encoding with null bytes", func(t *testing.T) {
		// Data with null bytes (might indicate binary or UTF-16)
		data := []byte{0x00, 0x41, 0x00, 0x42} // Could be UTF-16
		enc := detector.DetectEncoding(data)
		assert.NotNil(t, enc)
	})

	t.Run("detect encoding with mixed content", func(t *testing.T) {
		// Mixed ASCII and high bytes
		data := []byte("Hello" + string([]byte{0x80, 0x81, 0x82}) + "World")
		enc := detector.DetectEncoding(data)
		assert.NotNil(t, enc)
	})
}


func TestEncodingDetector_WithCSVFiles(t *testing.T) {
	// Test with actual CSV test data files
	detector := parser.NewEncodingDetector()

	testDataDir := "testdata"
	if _, err := os.Stat(testDataDir); os.IsNotExist(err) {
		t.Skip("testdata directory not found")
	}

	csvFiles := []string{
		"valid_corporate.csv",
		"valid_personal.csv",
		"various_date_formats.csv",
	}

	for _, fileName := range csvFiles {
		t.Run(fileName, func(t *testing.T) {
			filePath := filepath.Join(testDataDir, fileName)
			if _, err := os.Stat(filePath); os.IsNotExist(err) {
				t.Skipf("test file %s not found", fileName)
			}

			reader, enc, err := detector.OpenFileWithDetectedEncoding(filePath)
			assert.NoError(t, err)
			assert.NotNil(t, reader)
			assert.NotNil(t, enc)

			// Should be able to read some content
			buf := make([]byte, 100)
			n, _ := reader.Read(buf)
			assert.Greater(t, n, 0)

			// Close if it's a closer
			if closer, ok := reader.(io.Closer); ok {
				closer.Close()
			}
		})
	}
}