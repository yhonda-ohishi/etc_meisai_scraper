package parser_test

import (
	"strings"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"github.com/yhonda-ohishi/etc_meisai/src/models"
	"github.com/yhonda-ohishi/etc_meisai/src/parser"
)

// TestValidation_BoundaryConditions tests validation edge cases (T010)
func TestValidation_BoundaryConditions(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name        string
		record      *models.ETCMeisai
		expectValid bool
		description string
	}{
		{
			name: "minimum valid values",
			record: &models.ETCMeisai{
				UseDate:   time.Date(1900, 1, 1, 0, 0, 0, 0, time.UTC),
				EntryIC:   "A",
				ExitIC:    "B",
				Amount:    0,
				ETCNumber: "0",
				CarNumber: "0",
			},
			expectValid: true,
			description: "Minimum valid field values",
		},
		{
			name: "maximum field lengths",
			record: &models.ETCMeisai{
				UseDate:   time.Date(9999, 12, 31, 23, 59, 59, 0, time.UTC),
				UseTime:   "23:59:59",
				EntryIC:   strings.Repeat("あ", 100),
				ExitIC:    strings.Repeat("い", 100),
				Amount:    2147483647, // Max int32
				ETCNumber: strings.Repeat("9", 20),
				CarNumber: strings.Repeat("車", 20),
			},
			expectValid: true,
			description: "Maximum valid field lengths",
		},
		{
			name: "zero date",
			record: &models.ETCMeisai{
				UseDate:   time.Time{}, // Zero value
				EntryIC:   "東京IC",
				ExitIC:    "横浜IC",
				Amount:    1000,
				ETCNumber: "1234-5678-9012-3456",
			},
			expectValid: true, // Zero time is considered valid in Go
			description: "Zero time value",
		},
		{
			name: "negative amount",
			record: &models.ETCMeisai{
				UseDate:   time.Now(),
				EntryIC:   "東京IC",
				ExitIC:    "横浜IC",
				Amount:    -1,
				ETCNumber: "1234-5678-9012-3456",
			},
			expectValid: true, // Negative amounts are allowed
			description: "Negative amount value",
		},
		{
			name: "empty required fields",
			record: &models.ETCMeisai{
				UseDate:   time.Now(),
				EntryIC:   "",
				ExitIC:    "",
				Amount:    1000,
				ETCNumber: "1234-5678-9012-3456",
			},
			expectValid: true, // Empty IC names are allowed
			description: "Empty IC names",
		},
		{
			name: "unicode in all fields",
			record: &models.ETCMeisai{
				UseDate:   time.Now(),
				UseTime:   "12:00:00",
				EntryIC:   "東京IC🗼",
				ExitIC:    "横浜IC⚓",
				Amount:    1000,
				ETCNumber: "1234-5678-9012-3456",
				CarNumber: "品川300あ🚗",
			},
			expectValid: true,
			description: "Unicode characters including emoji",
		},
		{
			name: "special characters",
			record: &models.ETCMeisai{
				UseDate:   time.Now(),
				UseTime:   "12:00:00",
				EntryIC:   "IC!@#$%^&*()",
				ExitIC:    "IC<>?:\"{}|",
				Amount:    1000,
				ETCNumber: "1234-5678-9012-3456",
				CarNumber: "123-45",
			},
			expectValid: true,
			description: "Special characters in text fields",
		},
		{
			name: "null bytes in strings",
			record: &models.ETCMeisai{
				UseDate:   time.Now(),
				EntryIC:   "東京\x00IC",
				ExitIC:    "横浜\x00IC",
				Amount:    1000,
				ETCNumber: "1234-5678-9012-3456",
			},
			expectValid: true,
			description: "Null bytes in string fields",
		},
		{
			name: "whitespace only fields",
			record: &models.ETCMeisai{
				UseDate:   time.Now(),
				UseTime:   "   ",
				EntryIC:   "   ",
				ExitIC:    "\t\t\t",
				Amount:    1000,
				ETCNumber: "1234-5678-9012-3456",
			},
			expectValid: true,
			description: "Whitespace-only fields",
		},
		{
			name: "mixed width characters",
			record: &models.ETCMeisai{
				UseDate:   time.Now(),
				EntryIC:   "東京ＩＣ", // Full-width IC
				ExitIC:    "横浜IC",   // Half-width IC
				Amount:    1000,
				ETCNumber: "１２３４-５６７８-９０１２-３４５６", // Full-width numbers
				CarNumber: "品川３００あ１２３４",                   // Mixed width
			},
			expectValid: true,
			description: "Mixed full-width and half-width characters",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// Test that the record can be processed without panic
			assert.NotNil(t, tt.record)

			// If we had a validation function, we would call it here
			// For now, just ensure the record structure is valid
			if tt.expectValid {
				assert.NotNil(t, tt.record, "Record should be valid: %s", tt.description)
			}
		})
	}
}

// TestCSVParser_ValidationBoundaries tests CSV parsing validation boundaries (T010)
func TestCSVParser_ValidationBoundaries(t *testing.T) {
	t.Parallel()

	parser := parser.NewETCCSVParser()

	tests := []struct {
		name           string
		csvData        string
		expectedValid  int
		expectedErrors int
		description    string
	}{
		{
			name:           "exactly minimum columns",
			csvData:        "a,b,c,d,e,f,g,h,i,j,k,l,m",
			expectedValid:  0,
			expectedErrors: 1,
			description:    "13 columns with minimal data",
		},
		{
			name:           "one column short",
			csvData:        "a,b,c,d,e,f,g,h,i,j,k,l",
			expectedValid:  0,
			expectedErrors: 1,
			description:    "12 columns (insufficient)",
		},
		{
			name:           "many extra columns",
			csvData:        strings.Repeat("col,", 100) + "col",
			expectedValid:  0,
			expectedErrors: 1,
			description:    "100+ columns",
		},
		{
			name:           "maximum int32 amount",
			csvData:        "2025/07/30,08:15,東京IC,横浜IC,2147483647,普通車,1234,5678,東名高速道路,現金,なし,2025/08,1234-5678-9012-3456",
			expectedValid:  0,
			expectedErrors: 1,
			description:    "Amount at int32 max",
		},
		{
			name:           "amount overflow",
			csvData:        "2025/07/30,08:15,東京IC,横浜IC,9999999999999999999,普通車,1234,5678,東名高速道路,現金,なし,2025/08,1234-5678-9012-3456",
			expectedValid:  0,
			expectedErrors: 1,
			description:    "Amount exceeding int32",
		},
		{
			name:           "empty CSV",
			csvData:        "",
			expectedValid:  0,
			expectedErrors: 0,
			description:    "Empty input",
		},
		{
			name:           "only newlines",
			csvData:        "\n\n\n\n\n",
			expectedValid:  0,
			expectedErrors: 0,
			description:    "Only newline characters",
		},
		{
			name:           "only commas",
			csvData:        ",,,,,,,,,,,,",
			expectedValid:  0,
			expectedErrors: 1,
			description:    "Only comma separators",
		},
		{
			name:           "single column",
			csvData:        "single",
			expectedValid:  0,
			expectedErrors: 1,
			description:    "Single column only",
		},
		{
			name:           "very long single field",
			csvData:        strings.Repeat("A", 10000),
			expectedValid:  0,
			expectedErrors: 1,
			description:    "Single very long field",
		},
		{
			name:           "date at year boundary",
			csvData:        "99/12/31,23:59,東京IC,横浜IC,1000,普通車,1234,5678,東名高速道路,現金,なし,2025/08,1234-5678-9012-3456",
			expectedValid:  0,
			expectedErrors: 1,
			description:    "Date at year 2099 boundary",
		},
		{
			name:           "date at epoch",
			csvData:        "70/01/01,00:00,東京IC,横浜IC,1000,普通車,1234,5678,東名高速道路,現金,なし,2025/08,1234-5678-9012-3456",
			expectedValid:  0,
			expectedErrors: 1,
			description:    "Date at Unix epoch",
		},
		{
			name:           "all fields empty",
			csvData:        ",,,,,,,,,,,,",
			expectedValid:  0,
			expectedErrors: 1,
			description:    "All fields empty but present",
		},
		{
			name:           "quoted empty fields",
			csvData:        `"","","","","","","","","","","","",""`,
			expectedValid:  0,
			expectedErrors: 1,
			description:    "All fields quoted empty",
		},
		{
			name:           "mixed valid and boundary",
			csvData:        "2025/07/30,08:15,東京IC,横浜IC,1000,普通車,1234,5678,東名高速道路,現金,なし,2025/08,1234-5678-9012-3456\n,,,,,,,,,,,,\na,b,c",
			expectedValid:  0,
			expectedErrors: 3,
			description:    "Mix of valid and boundary cases",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			reader := strings.NewReader(tt.csvData)
			result, err := parser.Parse(reader)

			require.NoError(t, err, "Parse should not return error for: %s", tt.description)
			require.NotNil(t, result, "Result should not be nil for: %s", tt.description)

			assert.Equal(t, tt.expectedValid, result.ValidRows,
				"Valid rows mismatch for: %s", tt.description)
			assert.Equal(t, tt.expectedErrors, result.ErrorRows,
				"Error rows mismatch for: %s", tt.description)
		})
	}
}

// TestParseResult_BoundaryValues tests ParseResult with boundary values (T010)
func TestParseResult_BoundaryValues(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name   string
		result *parser.ParseResult
		check  func(*testing.T, *parser.ParseResult)
	}{
		{
			name: "zero values",
			result: &parser.ParseResult{
				Records:        nil,
				TotalRows:      0,
				ValidRows:      0,
				ErrorRows:      0,
				DuplicateCount: 0,
				Errors:         nil,
			},
			check: func(t *testing.T, r *parser.ParseResult) {
				assert.Nil(t, r.Records)
				assert.Nil(t, r.Errors)
				assert.Equal(t, 0, r.TotalRows)
			},
		},
		{
			name: "maximum values",
			result: &parser.ParseResult{
				Records:        make([]*models.ETCMeisai, 10000),
				TotalRows:      2147483647,
				ValidRows:      2147483647,
				ErrorRows:      0,
				DuplicateCount: 2147483647,
				Errors:         make([]parser.ParseError, 10000),
			},
			check: func(t *testing.T, r *parser.ParseResult) {
				assert.Len(t, r.Records, 10000)
				assert.Len(t, r.Errors, 10000)
				assert.Equal(t, 2147483647, r.TotalRows)
			},
		},
		{
			name: "negative values",
			result: &parser.ParseResult{
				TotalRows:      -1,
				ValidRows:      -1,
				ErrorRows:      -1,
				DuplicateCount: -1,
			},
			check: func(t *testing.T, r *parser.ParseResult) {
				// Negative values should be allowed in the struct
				assert.Equal(t, -1, r.TotalRows)
				assert.Equal(t, -1, r.ValidRows)
				assert.Equal(t, -1, r.ErrorRows)
				assert.Equal(t, -1, r.DuplicateCount)
			},
		},
		{
			name: "inconsistent counts",
			result: &parser.ParseResult{
				Records:        make([]*models.ETCMeisai, 5),
				TotalRows:      100,
				ValidRows:      10,
				ErrorRows:      5,
				DuplicateCount: 200,
				Errors:         make([]parser.ParseError, 3),
			},
			check: func(t *testing.T, r *parser.ParseResult) {
				// Struct allows inconsistent values
				assert.Len(t, r.Records, 5)
				assert.NotEqual(t, r.ValidRows, len(r.Records))
				assert.NotEqual(t, r.ErrorRows, len(r.Errors))
				assert.Greater(t, r.DuplicateCount, r.TotalRows)
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			tt.check(t, tt.result)
		})
	}
}

// TestParseError_BoundaryValues tests ParseError with boundary values (T010)
func TestParseError_BoundaryValues(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name  string
		err   parser.ParseError
		check func(*testing.T, parser.ParseError)
	}{
		{
			name: "zero row number",
			err: parser.ParseError{
				Row:     0,
				Message: "error at row 0",
			},
			check: func(t *testing.T, e parser.ParseError) {
				assert.Equal(t, 0, e.Row)
			},
		},
		{
			name: "negative row number",
			err: parser.ParseError{
				Row:     -1,
				Message: "error at negative row",
			},
			check: func(t *testing.T, e parser.ParseError) {
				assert.Equal(t, -1, e.Row)
			},
		},
		{
			name: "maximum row number",
			err: parser.ParseError{
				Row:     2147483647,
				Message: "error at max row",
			},
			check: func(t *testing.T, e parser.ParseError) {
				assert.Equal(t, 2147483647, e.Row)
			},
		},
		{
			name: "empty strings",
			err: parser.ParseError{
				Row:     1,
				Column:  "",
				Message: "",
				Value:   "",
			},
			check: func(t *testing.T, e parser.ParseError) {
				assert.Empty(t, e.Column)
				assert.Empty(t, e.Message)
				assert.Empty(t, e.Value)
			},
		},
		{
			name: "very long strings",
			err: parser.ParseError{
				Row:     1,
				Column:  strings.Repeat("col", 1000),
				Message: strings.Repeat("error", 1000),
				Value:   strings.Repeat("val", 1000),
			},
			check: func(t *testing.T, e parser.ParseError) {
				assert.Len(t, e.Column, 3000)
				assert.Len(t, e.Message, 5000)
				assert.Len(t, e.Value, 3000)
			},
		},
		{
			name: "unicode in all fields",
			err: parser.ParseError{
				Row:     1,
				Column:  "列名🔢",
				Message: "エラーメッセージ⚠️",
				Value:   "値😊",
			},
			check: func(t *testing.T, e parser.ParseError) {
				assert.Contains(t, e.Column, "🔢")
				assert.Contains(t, e.Message, "⚠️")
				assert.Contains(t, e.Value, "😊")
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			tt.check(t, tt.err)
		})
	}
}

// TestCSVParser_PerformanceBoundaries tests performance with boundary conditions (T010)
func TestCSVParser_PerformanceBoundaries(t *testing.T) {
	t.Parallel()

	parser := parser.NewETCCSVParser()

	t.Run("many small rows", func(t *testing.T) {
		// Generate 1000 minimal rows
		var csvData strings.Builder
		for i := 0; i < 1000; i++ {
			csvData.WriteString("a,b,c,d,e,f,g,h,i,j,k,l,m\n")
		}

		reader := strings.NewReader(csvData.String())
		result, err := parser.Parse(reader)

		assert.NoError(t, err)
		assert.NotNil(t, result)
		assert.Equal(t, 0, result.TotalRows)
		assert.Equal(t, 1000, result.ErrorRows)
	})

	t.Run("single huge row", func(t *testing.T) {
		// Generate one row with very long fields
		fields := make([]string, 13)
		for i := range fields {
			fields[i] = strings.Repeat("A", 1000)
		}
		csvData := strings.Join(fields, ",")

		reader := strings.NewReader(csvData)
		result, err := parser.Parse(reader)

		assert.NoError(t, err)
		assert.NotNil(t, result)
	})

	t.Run("deeply nested quotes", func(t *testing.T) {
		// Generate CSV with nested quotes
		csvData := `"""""nested""""",b,c,d,e,f,g,h,i,j,k,l,m`

		reader := strings.NewReader(csvData)
		result, err := parser.Parse(reader)

		assert.NoError(t, err)
		assert.NotNil(t, result)
	})
}