package mocks_test

import (
	"context"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.com/yhonda-ohishi/etc_meisai/src/mocks"
	"github.com/yhonda-ohishi/etc_meisai/src/models"
	"github.com/yhonda-ohishi/etc_meisai/src/services"
)

func TestMockETCMeisaiService_Example(t *testing.T) {
	// Create mock service
	mockService := &mocks.MockETCMeisaiService{}

	// Setup expectations
	expectedRecord := &models.ETCMeisaiRecord{
		ID:            1,
		Date:          time.Now(),
		CarNumber:     "TEST-001",
		TollAmount:    500,
		EntranceIC:    "Test Entrance",
		ExitIC:        "Test Exit",
		ETCCardNumber: "1234567890",
	}

	params := &services.CreateRecordParams{
		Date:          time.Now(),
		CarNumber:     "TEST-001",
		TollAmount:    500,
		EntranceIC:    "Test Entrance",
		ExitIC:        "Test Exit",
		ETCCardNumber: "1234567890",
		Time:          "10:00",
	}

	mockService.On("CreateRecord", mock.Anything, params).Return(expectedRecord, nil)

	// Test the mock
	ctx := context.Background()
	result, err := mockService.CreateRecord(ctx, params)

	// Assertions
	assert.NoError(t, err)
	assert.Equal(t, expectedRecord, result)
	mockService.AssertExpectations(t)
}

func TestMockETCMappingService_Example(t *testing.T) {
	// Create mock service
	mockService := &mocks.MockETCMappingService{}

	// Setup expectations
	expectedMapping := &models.ETCMapping{
		ID:               1,
		ETCRecordID:      1,
		MappingType:      "test_mapping",
		MappedEntityID:   100,
		MappedEntityType: "test_entity",
		Confidence:       0.95,
		Status:           "active",
	}

	params := &services.CreateMappingParams{
		ETCRecordID:      1,
		MappingType:      "test_mapping",
		MappedEntityID:   100,
		MappedEntityType: "test_entity",
		Confidence:       0.95,
		Status:           "active",
	}

	mockService.On("CreateMapping", mock.Anything, params).Return(expectedMapping, nil)

	// Test the mock
	ctx := context.Background()
	result, err := mockService.CreateMapping(ctx, params)

	// Assertions
	assert.NoError(t, err)
	assert.Equal(t, expectedMapping, result)
	mockService.AssertExpectations(t)
}

func TestMockLogger_Example(t *testing.T) {
	// Create mock logger
	mockLogger := &mocks.MockLogger{}

	// Setup expectations
	mockLogger.On("Printf", "Test message: %s", "test").Return()
	mockLogger.On("Println", "Test message").Return()

	// Test the mock
	mockLogger.Printf("Test message: %s", "test")
	mockLogger.Println("Test message")

	// Verify expectations
	mockLogger.AssertExpectations(t)
}