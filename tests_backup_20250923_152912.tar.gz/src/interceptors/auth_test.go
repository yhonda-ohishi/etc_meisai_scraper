package interceptors_test

import (
	"context"
	"testing"
	"time"

	"github.com/golang-jwt/jwt/v5"
	"github.com/stretchr/testify/assert"
	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/metadata"
	"google.golang.org/grpc/status"

	"github.com/yhonda-ohishi/etc_meisai/src/interceptors"
)

// Helper function to create a valid JWT token
func createTestToken(t *testing.T, userID, username string, roles []string, secret string, expiresIn time.Duration) string {
	claims := &interceptors.UserClaims{
		UserID:   userID,
		Username: username,
		Roles:    roles,
		RegisteredClaims: jwt.RegisteredClaims{
			ExpiresAt: jwt.NewNumericDate(time.Now().Add(expiresIn)),
			IssuedAt:  jwt.NewNumericDate(time.Now()),
			NotBefore: jwt.NewNumericDate(time.Now()),
		},
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	tokenString, err := token.SignedString([]byte(secret))
	assert.NoError(t, err)
	return tokenString
}

func TestNewAuthConfig(t *testing.T) {
	t.Parallel()

	config := interceptors.NewAuthConfig()

	assert.NotNil(t, config)
	assert.NotEmpty(t, config.JWTSecret)
	assert.Contains(t, config.PublicMethods, "/etc.v1.EtcService/Health")
	assert.Contains(t, config.AdminOnlyMethods, "/etc.v1.EtcService/DeleteAllRecords")
}

func TestUnaryAuthInterceptor(t *testing.T) {
	t.Parallel()

	config := &interceptors.AuthConfig{
		JWTSecret: "test-secret",
		PublicMethods: []string{
			"/etc.v1.EtcService/Health",
			"/etc.v1.EtcService/GetVersion",
		},
		AdminOnlyMethods: []string{
			"/etc.v1.EtcService/DeleteAllRecords",
		},
	}

	interceptor := interceptors.UnaryAuthInterceptor(config)

	tests := []struct {
		name          string
		method        string
		setupContext  func() context.Context
		expectedError codes.Code
		expectSuccess bool
		checkContext  func(t *testing.T, ctx context.Context)
	}{
		{
			name:   "public method without auth",
			method: "/etc.v1.EtcService/Health",
			setupContext: func() context.Context {
				return metadata.NewIncomingContext(context.Background(), metadata.MD{})
			},
			expectSuccess: true,
		},
		{
			name:   "valid token for protected method",
			method: "/etc.v1.EtcService/GetRecords",
			setupContext: func() context.Context {
				token := createTestToken(t, "user123", "testuser", []string{"user"}, config.JWTSecret, time.Hour)
				md := metadata.Pairs("authorization", "Bearer "+token)
				return metadata.NewIncomingContext(context.Background(), md)
			},
			expectSuccess: true,
			checkContext: func(t *testing.T, ctx context.Context) {
				userID, ok := interceptors.GetUserIDFromContext(ctx)
				assert.True(t, ok)
				assert.Equal(t, "user123", userID)
			},
		},
		{
			name:   "admin token for admin-only method",
			method: "/etc.v1.EtcService/DeleteAllRecords",
			setupContext: func() context.Context {
				token := createTestToken(t, "admin123", "admin", []string{"admin"}, config.JWTSecret, time.Hour)
				md := metadata.Pairs("authorization", "Bearer "+token)
				return metadata.NewIncomingContext(context.Background(), md)
			},
			expectSuccess: true,
		},
		{
			name:   "non-admin token for admin-only method",
			method: "/etc.v1.EtcService/DeleteAllRecords",
			setupContext: func() context.Context {
				token := createTestToken(t, "user123", "testuser", []string{"user"}, config.JWTSecret, time.Hour)
				md := metadata.Pairs("authorization", "Bearer "+token)
				return metadata.NewIncomingContext(context.Background(), md)
			},
			expectedError: codes.PermissionDenied,
		},
		{
			name:   "missing authorization header",
			method: "/etc.v1.EtcService/GetRecords",
			setupContext: func() context.Context {
				return metadata.NewIncomingContext(context.Background(), metadata.MD{})
			},
			expectedError: codes.Unauthenticated,
		},
		{
			name:   "invalid authorization format",
			method: "/etc.v1.EtcService/GetRecords",
			setupContext: func() context.Context {
				md := metadata.Pairs("authorization", "InvalidFormat token")
				return metadata.NewIncomingContext(context.Background(), md)
			},
			expectedError: codes.Unauthenticated,
		},
		{
			name:   "empty bearer token",
			method: "/etc.v1.EtcService/GetRecords",
			setupContext: func() context.Context {
				md := metadata.Pairs("authorization", "Bearer ")
				return metadata.NewIncomingContext(context.Background(), md)
			},
			expectedError: codes.Unauthenticated,
		},
		{
			name:   "expired token",
			method: "/etc.v1.EtcService/GetRecords",
			setupContext: func() context.Context {
				token := createTestToken(t, "user123", "testuser", []string{"user"}, config.JWTSecret, -time.Hour)
				md := metadata.Pairs("authorization", "Bearer "+token)
				return metadata.NewIncomingContext(context.Background(), md)
			},
			expectedError: codes.Unauthenticated,
		},
		{
			name:   "invalid token signature",
			method: "/etc.v1.EtcService/GetRecords",
			setupContext: func() context.Context {
				token := createTestToken(t, "user123", "testuser", []string{"user"}, "wrong-secret", time.Hour)
				md := metadata.Pairs("authorization", "Bearer "+token)
				return metadata.NewIncomingContext(context.Background(), md)
			},
			expectedError: codes.Unauthenticated,
		},
		{
			name:   "malformed token",
			method: "/etc.v1.EtcService/GetRecords",
			setupContext: func() context.Context {
				md := metadata.Pairs("authorization", "Bearer not.a.valid.jwt.token")
				return metadata.NewIncomingContext(context.Background(), md)
			},
			expectedError: codes.Unauthenticated,
		},
		{
			name:   "missing metadata",
			method: "/etc.v1.EtcService/GetRecords",
			setupContext: func() context.Context {
				return context.Background()
			},
			expectedError: codes.Unauthenticated,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ctx := tt.setupContext()
			info := &grpc.UnaryServerInfo{
				FullMethod: tt.method,
			}

			var handlerCtx context.Context
			handler := func(ctx context.Context, req interface{}) (interface{}, error) {
				handlerCtx = ctx
				return "success", nil
			}

			resp, err := interceptor(ctx, nil, info, handler)

			if tt.expectSuccess {
				assert.NoError(t, err)
				assert.Equal(t, "success", resp)
				if tt.checkContext != nil {
					tt.checkContext(t, handlerCtx)
				}
			} else {
				assert.Error(t, err)
				st, ok := status.FromError(err)
				assert.True(t, ok)
				assert.Equal(t, tt.expectedError, st.Code())
			}
		})
	}
}

func TestStreamAuthInterceptor(t *testing.T) {
	t.Parallel()

	config := &interceptors.AuthConfig{
		JWTSecret: "test-secret",
		PublicMethods: []string{
			"/etc.v1.EtcService/Health",
		},
		AdminOnlyMethods: []string{
			"/etc.v1.EtcService/StreamDeleteRecords",
		},
	}

	interceptor := interceptors.StreamAuthInterceptor(config)

	tests := []struct {
		name          string
		method        string
		setupContext  func() context.Context
		expectedError codes.Code
		expectSuccess bool
	}{
		{
			name:   "public stream method without auth",
			method: "/etc.v1.EtcService/Health",
			setupContext: func() context.Context {
				return metadata.NewIncomingContext(context.Background(), metadata.MD{})
			},
			expectSuccess: true,
		},
		{
			name:   "valid token for protected stream",
			method: "/etc.v1.EtcService/StreamRecords",
			setupContext: func() context.Context {
				token := createTestToken(t, "user123", "testuser", []string{"user"}, config.JWTSecret, time.Hour)
				md := metadata.Pairs("authorization", "Bearer "+token)
				return metadata.NewIncomingContext(context.Background(), md)
			},
			expectSuccess: true,
		},
		{
			name:   "admin token for admin-only stream",
			method: "/etc.v1.EtcService/StreamDeleteRecords",
			setupContext: func() context.Context {
				token := createTestToken(t, "admin123", "admin", []string{"administrator"}, config.JWTSecret, time.Hour)
				md := metadata.Pairs("authorization", "Bearer "+token)
				return metadata.NewIncomingContext(context.Background(), md)
			},
			expectSuccess: true,
		},
		{
			name:   "non-admin token for admin-only stream",
			method: "/etc.v1.EtcService/StreamDeleteRecords",
			setupContext: func() context.Context {
				token := createTestToken(t, "user123", "testuser", []string{"user"}, config.JWTSecret, time.Hour)
				md := metadata.Pairs("authorization", "Bearer "+token)
				return metadata.NewIncomingContext(context.Background(), md)
			},
			expectedError: codes.PermissionDenied,
		},
		{
			name:   "missing authorization for protected stream",
			method: "/etc.v1.EtcService/StreamRecords",
			setupContext: func() context.Context {
				return metadata.NewIncomingContext(context.Background(), metadata.MD{})
			},
			expectedError: codes.Unauthenticated,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ctx := tt.setupContext()
			info := &grpc.StreamServerInfo{
				FullMethod: tt.method,
			}

			mockStream := &MockServerStream{ctx: ctx}
			handler := func(srv interface{}, stream grpc.ServerStream) error {
				// Verify context propagation in stream
				if tt.expectSuccess && tt.method != "/etc.v1.EtcService/Health" {
					userID, ok := interceptors.GetUserIDFromContext(stream.Context())
					assert.True(t, ok)
					assert.NotEmpty(t, userID)
				}
				return nil
			}

			err := interceptor(nil, mockStream, info, handler)

			if tt.expectSuccess {
				assert.NoError(t, err)
			} else {
				assert.Error(t, err)
				st, ok := status.FromError(err)
				assert.True(t, ok)
				assert.Equal(t, tt.expectedError, st.Code())
			}
		})
	}
}

func TestGetUserFromContext(t *testing.T) {
	t.Parallel()

	t.Run("user exists in context", func(t *testing.T) {
		claims := &interceptors.UserClaims{
			UserID:   "user123",
			Username: "testuser",
			Roles:    []string{"user"},
		}
		ctx := context.WithValue(context.Background(), "user_claims", claims)

		retrievedClaims, ok := interceptors.GetUserFromContext(ctx)
		assert.True(t, ok)
		assert.Equal(t, claims, retrievedClaims)
	})

	t.Run("user not in context", func(t *testing.T) {
		ctx := context.Background()

		retrievedClaims, ok := interceptors.GetUserFromContext(ctx)
		assert.False(t, ok)
		assert.Nil(t, retrievedClaims)
	})
}

func TestGetUserIDFromContext(t *testing.T) {
	t.Parallel()

	t.Run("user ID exists in context", func(t *testing.T) {
		ctx := context.WithValue(context.Background(), "user_id", "user123")

		userID, ok := interceptors.GetUserIDFromContext(ctx)
		assert.True(t, ok)
		assert.Equal(t, "user123", userID)
	})

	t.Run("user ID not in context", func(t *testing.T) {
		ctx := context.Background()

		userID, ok := interceptors.GetUserIDFromContext(ctx)
		assert.False(t, ok)
		assert.Empty(t, userID)
	})
}

func TestGetUsernameFromContext(t *testing.T) {
	t.Parallel()

	t.Run("username exists in context", func(t *testing.T) {
		ctx := context.WithValue(context.Background(), "username", "testuser")

		username, ok := interceptors.GetUsernameFromContext(ctx)
		assert.True(t, ok)
		assert.Equal(t, "testuser", username)
	})

	t.Run("username not in context", func(t *testing.T) {
		ctx := context.Background()

		username, ok := interceptors.GetUsernameFromContext(ctx)
		assert.False(t, ok)
		assert.Empty(t, username)
	})
}

func TestValidateTokenString(t *testing.T) {
	t.Parallel()

	jwtSecret := "test-secret"

	t.Run("valid token", func(t *testing.T) {
		token := createTestToken(t, "user123", "testuser", []string{"user"}, jwtSecret, time.Hour)

		claims, err := interceptors.ValidateTokenString(token, jwtSecret)
		assert.NoError(t, err)
		assert.NotNil(t, claims)
		assert.Equal(t, "user123", claims.UserID)
		assert.Equal(t, "testuser", claims.Username)
		assert.Contains(t, claims.Roles, "user")
	})

	t.Run("expired token", func(t *testing.T) {
		token := createTestToken(t, "user123", "testuser", []string{"user"}, jwtSecret, -time.Hour)

		claims, err := interceptors.ValidateTokenString(token, jwtSecret)
		assert.Error(t, err)
		assert.Nil(t, claims)
		assert.Contains(t, err.Error(), "expired")
	})

	t.Run("invalid signature", func(t *testing.T) {
		token := createTestToken(t, "user123", "testuser", []string{"user"}, "wrong-secret", time.Hour)

		claims, err := interceptors.ValidateTokenString(token, jwtSecret)
		assert.Error(t, err)
		assert.Nil(t, claims)
	})

	t.Run("malformed token", func(t *testing.T) {
		claims, err := interceptors.ValidateTokenString("not.a.valid.token", jwtSecret)
		assert.Error(t, err)
		assert.Nil(t, claims)
	})
}

func TestTokenWithMissingClaims(t *testing.T) {
	t.Parallel()

	config := &interceptors.AuthConfig{
		JWTSecret:     "test-secret",
		PublicMethods: []string{},
	}

	interceptor := interceptors.UnaryAuthInterceptor(config)

	t.Run("token with empty user ID", func(t *testing.T) {
		// Create token with empty UserID
		claims := &interceptors.UserClaims{
			UserID:   "",
			Username: "testuser",
			Roles:    []string{"user"},
			RegisteredClaims: jwt.RegisteredClaims{
				ExpiresAt: jwt.NewNumericDate(time.Now().Add(time.Hour)),
			},
		}
		token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
		tokenString, err := token.SignedString([]byte(config.JWTSecret))
		assert.NoError(t, err)

		md := metadata.Pairs("authorization", "Bearer "+tokenString)
		ctx := metadata.NewIncomingContext(context.Background(), md)
		info := &grpc.UnaryServerInfo{
			FullMethod: "/etc.v1.EtcService/GetRecords",
		}

		handler := func(ctx context.Context, req interface{}) (interface{}, error) {
			return "success", nil
		}

		_, err = interceptor(ctx, nil, info, handler)
		assert.Error(t, err)
		st, ok := status.FromError(err)
		assert.True(t, ok)
		assert.Equal(t, codes.Unauthenticated, st.Code())
	})

	t.Run("token with empty username", func(t *testing.T) {
		// Create token with empty Username
		claims := &interceptors.UserClaims{
			UserID:   "user123",
			Username: "",
			Roles:    []string{"user"},
			RegisteredClaims: jwt.RegisteredClaims{
				ExpiresAt: jwt.NewNumericDate(time.Now().Add(time.Hour)),
			},
		}
		token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
		tokenString, err := token.SignedString([]byte(config.JWTSecret))
		assert.NoError(t, err)

		md := metadata.Pairs("authorization", "Bearer "+tokenString)
		ctx := metadata.NewIncomingContext(context.Background(), md)
		info := &grpc.UnaryServerInfo{
			FullMethod: "/etc.v1.EtcService/GetRecords",
		}

		handler := func(ctx context.Context, req interface{}) (interface{}, error) {
			return "success", nil
		}

		_, err = interceptor(ctx, nil, info, handler)
		assert.Error(t, err)
		st, ok := status.FromError(err)
		assert.True(t, ok)
		assert.Equal(t, codes.Unauthenticated, st.Code())
	})
}

// Mock ServerStream for testing
type MockServerStream struct {
	grpc.ServerStream
	ctx context.Context
}

func (m *MockServerStream) Context() context.Context {
	return m.ctx
}

func (m *MockServerStream) SendMsg(msg interface{}) error {
	return nil
}

func (m *MockServerStream) RecvMsg(msg interface{}) error {
	return nil
}

// Benchmark tests
func BenchmarkUnaryAuthInterceptor_ValidToken(b *testing.B) {
	config := &interceptors.AuthConfig{
		JWTSecret:     "test-secret",
		PublicMethods: []string{},
	}

	interceptor := interceptors.UnaryAuthInterceptor(config)
	// Create token directly for benchmark
	claims := &interceptors.UserClaims{
		UserID:   "user123",
		Username: "testuser",
		Roles:    []string{"user"},
		RegisteredClaims: jwt.RegisteredClaims{
			ExpiresAt: jwt.NewNumericDate(time.Now().Add(time.Hour)),
		},
	}
	tokenObj := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	token, _ := tokenObj.SignedString([]byte(config.JWTSecret))
	md := metadata.Pairs("authorization", "Bearer "+token)
	ctx := metadata.NewIncomingContext(context.Background(), md)
	info := &grpc.UnaryServerInfo{
		FullMethod: "/etc.v1.EtcService/GetRecords",
	}

	handler := func(ctx context.Context, req interface{}) (interface{}, error) {
		return "success", nil
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		interceptor(ctx, nil, info, handler)
	}
}

func BenchmarkUnaryAuthInterceptor_PublicMethod(b *testing.B) {
	config := &interceptors.AuthConfig{
		JWTSecret: "test-secret",
		PublicMethods: []string{
			"/etc.v1.EtcService/Health",
		},
	}

	interceptor := interceptors.UnaryAuthInterceptor(config)
	ctx := metadata.NewIncomingContext(context.Background(), metadata.MD{})
	info := &grpc.UnaryServerInfo{
		FullMethod: "/etc.v1.EtcService/Health",
	}

	handler := func(ctx context.Context, req interface{}) (interface{}, error) {
		return "success", nil
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		interceptor(ctx, nil, info, handler)
	}
}