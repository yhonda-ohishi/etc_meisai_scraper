package interceptors_test

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"log/slog"
	"testing"

	"github.com/stretchr/testify/assert"
	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/metadata"
	"google.golang.org/grpc/status"

	"github.com/yhonda-ohishi/etc_meisai/src/interceptors"
)

func TestNewErrorConfig(t *testing.T) {
	t.Parallel()

	config := interceptors.NewErrorConfig()

	assert.NotNil(t, config)
	assert.NotNil(t, config.Logger)
	assert.NotNil(t, config.ErrorCodeMapping)
	assert.Contains(t, config.ErrorCodeMapping, "VALIDATION_ERROR")
	assert.Equal(t, codes.InvalidArgument, config.ErrorCodeMapping["VALIDATION_ERROR"])
}

func TestServiceError(t *testing.T) {
	t.Parallel()

	t.Run("error without cause", func(t *testing.T) {
		err := &interceptors.ServiceError{
			Code:    "TEST_ERROR",
			Message: "Test error message",
			Details: map[string]interface{}{
				"field": "value",
			},
		}

		assert.Equal(t, "TEST_ERROR: Test error message", err.Error())
	})

	t.Run("error with cause", func(t *testing.T) {
		cause := errors.New("underlying error")
		err := &interceptors.ServiceError{
			Code:    "TEST_ERROR",
			Message: "Test error message",
			Cause:   cause,
		}

		assert.Contains(t, err.Error(), "TEST_ERROR: Test error message")
		assert.Contains(t, err.Error(), "caused by: underlying error")
	})
}

func TestUnaryErrorHandlerInterceptor(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name           string
		handlerFunc    func(ctx context.Context, req interface{}) (interface{}, error)
		expectedCode   codes.Code
		expectedMsg    string
		expectError    bool
		checkLogs      func(t *testing.T, logs string)
	}{
		{
			name: "successful request",
			handlerFunc: func(ctx context.Context, req interface{}) (interface{}, error) {
				return "success", nil
			},
			expectError: false,
		},
		{
			name: "gRPC status error",
			handlerFunc: func(ctx context.Context, req interface{}) (interface{}, error) {
				return nil, status.Error(codes.InvalidArgument, "invalid input")
			},
			expectedCode: codes.InvalidArgument,
			expectedMsg:  "invalid input",
			expectError:  true,
		},
		{
			name: "service error with code mapping",
			handlerFunc: func(ctx context.Context, req interface{}) (interface{}, error) {
				return nil, &interceptors.ServiceError{
					Code:    "VALIDATION_ERROR",
					Message: "Validation failed",
					Details: map[string]interface{}{
						"field": "email",
						"error": "invalid format",
					},
				}
			},
			expectedCode: codes.InvalidArgument,
			expectError:  true,
		},
		{
			name: "generic error",
			handlerFunc: func(ctx context.Context, req interface{}) (interface{}, error) {
				return nil, errors.New("generic error")
			},
			expectedCode: codes.Internal,
			expectError:  true,
		},
		{
			name: "context deadline exceeded",
			handlerFunc: func(ctx context.Context, req interface{}) (interface{}, error) {
				return nil, context.DeadlineExceeded
			},
			expectedCode: codes.DeadlineExceeded,
			expectError:  true,
		},
		{
			name: "context canceled",
			handlerFunc: func(ctx context.Context, req interface{}) (interface{}, error) {
				return nil, context.Canceled
			},
			expectedCode: codes.Internal, // The current implementation doesn't handle context.Canceled specially
			expectError:  true,
		},
		{
			name: "panic recovery",
			handlerFunc: func(ctx context.Context, req interface{}) (interface{}, error) {
				panic("test panic")
			},
			expectedCode: codes.Internal,
			expectError:  true,
			checkLogs: func(t *testing.T, logs string) {
				assert.Contains(t, logs, "panic")
			},
		},
		{
			name: "panic with error object",
			handlerFunc: func(ctx context.Context, req interface{}) (interface{}, error) {
				panic(errors.New("error panic"))
			},
			expectedCode: codes.Internal,
			expectError:  true,
		},
		{
			name: "database error mapping",
			handlerFunc: func(ctx context.Context, req interface{}) (interface{}, error) {
				return nil, &interceptors.ServiceError{
					Code:    "DATABASE_ERROR",
					Message: "Database connection failed",
				}
			},
			expectedCode: codes.Internal,
			expectError:  true,
		},
		{
			name: "rate limiting error",
			handlerFunc: func(ctx context.Context, req interface{}) (interface{}, error) {
				return nil, &interceptors.ServiceError{
					Code:    "RATE_LIMITED",
					Message: "Too many requests",
				}
			},
			expectedCode: codes.ResourceExhausted,
			expectError:  true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// Setup logger with buffer
			var logBuffer bytes.Buffer
			logger := slog.New(slog.NewTextHandler(&logBuffer, &slog.HandlerOptions{
				Level: slog.LevelDebug,
			}))

			config := &interceptors.ErrorConfig{
				Logger:            logger,
				IncludeStackTrace: true,
				SanitizeErrors:    false,
				EnableMetrics:     true,
				ProductionMode:    false,
				ErrorCodeMapping:  interceptors.NewErrorConfig().ErrorCodeMapping,
			}

			interceptor := interceptors.UnaryErrorHandlerInterceptor(config)

			ctx := metadata.NewIncomingContext(context.Background(), metadata.Pairs(
				"request-id", "test-request-123",
			))
			info := &grpc.UnaryServerInfo{
				FullMethod: "/TestService/TestMethod",
			}

			resp, err := interceptor(ctx, nil, info, tt.handlerFunc)

			if tt.expectError {
				assert.Error(t, err)
				st, ok := status.FromError(err)
				assert.True(t, ok)
				assert.Equal(t, tt.expectedCode, st.Code())
				if tt.expectedMsg != "" {
					assert.Contains(t, st.Message(), tt.expectedMsg)
				}
			} else {
				assert.NoError(t, err)
				assert.Equal(t, "success", resp)
			}

			if tt.checkLogs != nil {
				tt.checkLogs(t, logBuffer.String())
			}
		})
	}
}

func TestStreamErrorHandlerInterceptor(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name         string
		handlerFunc  func(srv interface{}, stream grpc.ServerStream) error
		expectedCode codes.Code
		expectError  bool
	}{
		{
			name: "successful stream",
			handlerFunc: func(srv interface{}, stream grpc.ServerStream) error {
				return nil
			},
			expectError: false,
		},
		{
			name: "stream error",
			handlerFunc: func(srv interface{}, stream grpc.ServerStream) error {
				return status.Error(codes.NotFound, "stream not found")
			},
			expectedCode: codes.NotFound,
			expectError:  true,
		},
		{
			name: "stream panic recovery",
			handlerFunc: func(srv interface{}, stream grpc.ServerStream) error {
				panic("stream panic")
			},
			expectedCode: codes.Internal,
			expectError:  true,
		},
		{
			name: "service error in stream",
			handlerFunc: func(srv interface{}, stream grpc.ServerStream) error {
				return &interceptors.ServiceError{
					Code:    "NETWORK_ERROR",
					Message: "Network connection lost",
				}
			},
			expectedCode: codes.Unavailable,
			expectError:  true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// Setup logger with buffer
			var logBuffer bytes.Buffer
			logger := slog.New(slog.NewTextHandler(&logBuffer, &slog.HandlerOptions{
				Level: slog.LevelDebug,
			}))

			config := &interceptors.ErrorConfig{
				Logger:            logger,
				IncludeStackTrace: true,
				ErrorCodeMapping:  interceptors.NewErrorConfig().ErrorCodeMapping,
			}

			interceptor := interceptors.StreamErrorHandlerInterceptor(config)

			ctx := metadata.NewIncomingContext(context.Background(), metadata.MD{})
			mockStream := &MockServerStream{ctx: ctx}
			info := &grpc.StreamServerInfo{
				FullMethod: "/TestService/TestStreamMethod",
			}

			err := interceptor(nil, mockStream, info, tt.handlerFunc)

			if tt.expectError {
				assert.Error(t, err)
				st, ok := status.FromError(err)
				assert.True(t, ok)
				assert.Equal(t, tt.expectedCode, st.Code())
			} else {
				assert.NoError(t, err)
			}
		})
	}
}

func TestProductionModeErrorHandling(t *testing.T) {
	t.Parallel()

	t.Run("production mode sanitizes errors", func(t *testing.T) {
		var logBuffer bytes.Buffer
		logger := slog.New(slog.NewTextHandler(&logBuffer, nil))

		config := &interceptors.ErrorConfig{
			Logger:            logger,
			IncludeStackTrace: false,
			SanitizeErrors:    true,
			ProductionMode:    true,
			ErrorCodeMapping:  interceptors.NewErrorConfig().ErrorCodeMapping,
		}

		interceptor := interceptors.UnaryErrorHandlerInterceptor(config)

		ctx := context.Background()
		info := &grpc.UnaryServerInfo{
			FullMethod: "/TestService/TestMethod",
		}

		handler := func(ctx context.Context, req interface{}) (interface{}, error) {
			return nil, errors.New("sensitive database connection string: postgres://user:pass@host/db")
		}

		_, err := interceptor(ctx, nil, info, handler)
		assert.Error(t, err)

		// In production mode, sensitive details should be sanitized
		st, _ := status.FromError(err)
		assert.NotContains(t, st.Message(), "postgres://user:pass@host/db")
	})

	t.Run("development mode includes details", func(t *testing.T) {
		var logBuffer bytes.Buffer
		logger := slog.New(slog.NewTextHandler(&logBuffer, nil))

		config := &interceptors.ErrorConfig{
			Logger:            logger,
			IncludeStackTrace: true,
			SanitizeErrors:    false,
			ProductionMode:    false,
			ErrorCodeMapping:  interceptors.NewErrorConfig().ErrorCodeMapping,
		}

		interceptor := interceptors.UnaryErrorHandlerInterceptor(config)

		ctx := context.Background()
		info := &grpc.UnaryServerInfo{
			FullMethod: "/TestService/TestMethod",
		}

		handler := func(ctx context.Context, req interface{}) (interface{}, error) {
			return nil, errors.New("detailed error message")
		}

		_, err := interceptor(ctx, nil, info, handler)
		assert.Error(t, err)

		// In development mode, detailed errors are preserved
		st, _ := status.FromError(err)
		assert.Contains(t, st.Message(), "detailed error message")
	})
}

func TestErrorCodeMapping(t *testing.T) {
	t.Parallel()

	config := interceptors.NewErrorConfig()

	testCases := []struct {
		errorCode    string
		expectedGRPC codes.Code
	}{
		{"VALIDATION_ERROR", codes.InvalidArgument},
		{"NOT_FOUND", codes.NotFound},
		{"ALREADY_EXISTS", codes.AlreadyExists},
		{"PERMISSION_DENIED", codes.PermissionDenied},
		{"UNAUTHENTICATED", codes.Unauthenticated},
		{"RESOURCE_EXHAUSTED", codes.ResourceExhausted},
		{"FAILED_PRECONDITION", codes.FailedPrecondition},
		{"ABORTED", codes.Aborted},
		{"OUT_OF_RANGE", codes.OutOfRange},
		{"UNIMPLEMENTED", codes.Unimplemented},
		{"INTERNAL", codes.Internal},
		{"UNAVAILABLE", codes.Unavailable},
		{"DATA_LOSS", codes.DataLoss},
		{"TIMEOUT", codes.DeadlineExceeded},
		{"CANCELLED", codes.Canceled},
		{"UNKNOWN", codes.Unknown},
		{"DATABASE_ERROR", codes.Internal},
		{"NETWORK_ERROR", codes.Unavailable},
		{"PARSING_ERROR", codes.InvalidArgument},
		{"EXTERNAL_API_ERROR", codes.Unavailable},
		{"RATE_LIMITED", codes.ResourceExhausted},
	}

	for _, tc := range testCases {
		t.Run(tc.errorCode, func(t *testing.T) {
			mappedCode, exists := config.ErrorCodeMapping[tc.errorCode]
			assert.True(t, exists)
			assert.Equal(t, tc.expectedGRPC, mappedCode)
		})
	}
}

func TestComplexErrorScenarios(t *testing.T) {
	t.Parallel()

	t.Run("nested service error with cause", func(t *testing.T) {
		var logBuffer bytes.Buffer
		logger := slog.New(slog.NewTextHandler(&logBuffer, nil))

		config := &interceptors.ErrorConfig{
			Logger:           logger,
			ErrorCodeMapping: interceptors.NewErrorConfig().ErrorCodeMapping,
		}

		interceptor := interceptors.UnaryErrorHandlerInterceptor(config)

		ctx := context.Background()
		info := &grpc.UnaryServerInfo{
			FullMethod: "/TestService/TestMethod",
		}

		handler := func(ctx context.Context, req interface{}) (interface{}, error) {
			dbErr := errors.New("connection refused")
			return nil, &interceptors.ServiceError{
				Code:    "DATABASE_ERROR",
				Message: "Failed to connect to database",
				Details: map[string]interface{}{
					"host": "localhost",
					"port": 5432,
				},
				Cause: dbErr,
			}
		}

		_, err := interceptor(ctx, nil, info, handler)
		assert.Error(t, err)
		st, _ := status.FromError(err)
		assert.Equal(t, codes.Internal, st.Code())
	})

	t.Run("chain of interceptors with error", func(t *testing.T) {
		var logBuffer bytes.Buffer
		logger := slog.New(slog.NewTextHandler(&logBuffer, nil))

		config := &interceptors.ErrorConfig{
			Logger:           logger,
			ErrorCodeMapping: interceptors.NewErrorConfig().ErrorCodeMapping,
		}

		errorInterceptor := interceptors.UnaryErrorHandlerInterceptor(config)

		// Simulate a chain where an earlier interceptor adds context
		ctx := context.WithValue(context.Background(), "user_id", "user123")
		ctx = metadata.NewIncomingContext(ctx, metadata.Pairs(
			"request-id", "req-456",
		))

		info := &grpc.UnaryServerInfo{
			FullMethod: "/TestService/TestMethod",
		}

		handler := func(ctx context.Context, req interface{}) (interface{}, error) {
			// Check that context values are preserved
			userID := ctx.Value("user_id")
			assert.Equal(t, "user123", userID)

			return nil, &interceptors.ServiceError{
				Code:    "PERMISSION_DENIED",
				Message: "User does not have access",
			}
		}

		_, err := errorInterceptor(ctx, nil, info, handler)
		assert.Error(t, err)
		st, _ := status.FromError(err)
		assert.Equal(t, codes.PermissionDenied, st.Code())
	})
}

func TestConcurrentErrorHandling(t *testing.T) {
	t.Parallel()

	var logBuffer bytes.Buffer
	logger := slog.New(slog.NewTextHandler(&logBuffer, nil))

	config := &interceptors.ErrorConfig{
		Logger:           logger,
		ErrorCodeMapping: interceptors.NewErrorConfig().ErrorCodeMapping,
	}

	interceptor := interceptors.UnaryErrorHandlerInterceptor(config)

	// Run multiple concurrent requests
	concurrency := 10
	errChan := make(chan error, concurrency)

	for i := 0; i < concurrency; i++ {
		go func(id int) {
			ctx := context.Background()
			info := &grpc.UnaryServerInfo{
				FullMethod: fmt.Sprintf("/TestService/Method%d", id),
			}

			handler := func(ctx context.Context, req interface{}) (interface{}, error) {
				if id%2 == 0 {
					return nil, errors.New(fmt.Sprintf("error from handler %d", id))
				}
				return fmt.Sprintf("success %d", id), nil
			}

			_, err := interceptor(ctx, nil, info, handler)
			errChan <- err
		}(i)
	}

	// Collect results
	var errorCount int
	for i := 0; i < concurrency; i++ {
		err := <-errChan
		if err != nil {
			errorCount++
		}
	}

	// Half should have errors
	assert.Equal(t, concurrency/2, errorCount)
}

// Benchmark tests
func BenchmarkUnaryErrorHandlerInterceptor_NoError(b *testing.B) {
	config := interceptors.NewErrorConfig()
	interceptor := interceptors.UnaryErrorHandlerInterceptor(config)

	ctx := context.Background()
	info := &grpc.UnaryServerInfo{
		FullMethod: "/TestService/TestMethod",
	}

	handler := func(ctx context.Context, req interface{}) (interface{}, error) {
		return "success", nil
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		interceptor(ctx, nil, info, handler)
	}
}

func BenchmarkUnaryErrorHandlerInterceptor_WithError(b *testing.B) {
	config := interceptors.NewErrorConfig()
	interceptor := interceptors.UnaryErrorHandlerInterceptor(config)

	ctx := context.Background()
	info := &grpc.UnaryServerInfo{
		FullMethod: "/TestService/TestMethod",
	}

	handler := func(ctx context.Context, req interface{}) (interface{}, error) {
		return nil, errors.New("test error")
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		interceptor(ctx, nil, info, handler)
	}
}