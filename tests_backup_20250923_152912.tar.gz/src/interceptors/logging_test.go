package interceptors_test

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"io"
	"log/slog"
	"strings"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/metadata"
	"google.golang.org/grpc/status"

	"github.com/yhonda-ohishi/etc_meisai/src/interceptors"
)

// T003-A & T003-B: Comprehensive logging interceptor tests

func TestNewLoggingConfig(t *testing.T) {
	t.Parallel()

	config := interceptors.NewLoggingConfig()

	assert.NotNil(t, config)
	assert.NotNil(t, config.Logger)
	assert.True(t, config.LogPayloads)
	assert.Equal(t, 1024, config.MaxPayloadSize)
	assert.True(t, config.MaskSensitiveData)
	assert.Contains(t, config.SensitiveFields, "etc_card_number")
	assert.Equal(t, slog.LevelInfo, config.LogLevel)
	assert.Contains(t, config.ExcludedMethods, "/grpc.health.v1.Health/Check")
}

func TestUnaryLoggingInterceptor(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name          string
		fullMethod    string
		request       interface{}
		response      interface{}
		responseError error
		setupConfig   func(*interceptors.LoggingConfig)
		validateLogs  func(t *testing.T, logs string)
	}{
		{
			name:       "successful request with payload logging",
			fullMethod: "/TestService/TestMethod",
			request:    map[string]string{"test": "data"},
			response:   map[string]string{"result": "success"},
			setupConfig: func(c *interceptors.LoggingConfig) {
				c.LogPayloads = true
			},
			validateLogs: func(t *testing.T, logs string) {
				assert.Contains(t, logs, "gRPC request")
				assert.Contains(t, logs, "gRPC response")
				assert.Contains(t, logs, `"status":"OK"`)
			},
		},
		{
			name:       "error response logging",
			fullMethod: "/TestService/ErrorMethod",
			request:    map[string]string{"test": "data"},
			responseError: status.Error(codes.NotFound, "resource not found"),
			setupConfig: func(c *interceptors.LoggingConfig) {
				c.LogPayloads = true
			},
			validateLogs: func(t *testing.T, logs string) {
				assert.Contains(t, logs, "gRPC request")
				assert.Contains(t, logs, "gRPC response")
				assert.Contains(t, logs, "NotFound")
				assert.Contains(t, logs, "resource not found")
			},
		},
		{
			name:       "excluded method not logged",
			fullMethod: "/grpc.health.v1.Health/Check",
			request:    nil,
			response:   map[string]string{"status": "ok"},
			setupConfig: func(c *interceptors.LoggingConfig) {
				c.ExcludedMethods = []string{"/grpc.health.v1.Health/Check"}
			},
			validateLogs: func(t *testing.T, logs string) {
				assert.NotContains(t, logs, "gRPC request")
				assert.NotContains(t, logs, "gRPC response")
			},
		},
		{
			name:       "sensitive data masking",
			fullMethod: "/TestService/SensitiveMethod",
			request: map[string]string{
				"etc_card_number": "1234-5678-9012-3456",
				"normal_field":    "visible_data",
			},
			response: map[string]string{"result": "success"},
			setupConfig: func(c *interceptors.LoggingConfig) {
				c.LogPayloads = true
				c.MaskSensitiveData = true
				c.SensitiveFields = []string{"etc_card_number"}
			},
			validateLogs: func(t *testing.T, logs string) {
				assert.Contains(t, logs, "****-****-****-****")
				assert.NotContains(t, logs, "1234-5678-9012-3456")
				assert.Contains(t, logs, "visible_data")
			},
		},
		{
			name:       "large payload truncation",
			fullMethod: "/TestService/LargePayload",
			request:    strings.Repeat("x", 2000),
			response:   map[string]string{"result": "success"},
			setupConfig: func(c *interceptors.LoggingConfig) {
				c.LogPayloads = true
				c.MaxPayloadSize = 100
			},
			validateLogs: func(t *testing.T, logs string) {
				assert.Contains(t, logs, "truncated")
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// Capture logs
			var buf bytes.Buffer
			config := &interceptors.LoggingConfig{
				Logger: slog.New(slog.NewTextHandler(&buf, &slog.HandlerOptions{
					Level: slog.LevelDebug,
				})),
				LogPayloads:       false,
				MaxPayloadSize:    1024,
				MaskSensitiveData: false,
				LogLevel:          slog.LevelInfo,
			}

			if tt.setupConfig != nil {
				tt.setupConfig(config)
			}

			interceptor := interceptors.UnaryLoggingInterceptor(config)

			// Create mock handler
			handler := func(ctx context.Context, req interface{}) (interface{}, error) {
				return tt.response, tt.responseError
			}

			// Create server info
			info := &grpc.UnaryServerInfo{
				FullMethod: tt.fullMethod,
			}

			// Execute interceptor
			ctx := context.Background()
			resp, err := interceptor(ctx, tt.request, info, handler)

			// Validate response
			if tt.responseError != nil {
				assert.Error(t, err)
				assert.Equal(t, tt.responseError, err)
			} else {
				assert.NoError(t, err)
				assert.Equal(t, tt.response, resp)
			}

			// Validate logs
			if tt.validateLogs != nil {
				tt.validateLogs(t, buf.String())
			}
		})
	}
}

// T003-C: Request ID tracking and correlation testing
func TestRequestIDTracking(t *testing.T) {
	t.Parallel()

	t.Run("generates new request ID when not provided", func(t *testing.T) {
		var buf bytes.Buffer
		config := &interceptors.LoggingConfig{
			Logger: slog.New(slog.NewTextHandler(&buf, nil)),
		}

		interceptor := interceptors.UnaryLoggingInterceptor(config)

		handler := func(ctx context.Context, req interface{}) (interface{}, error) {
			// Verify request ID was added to context
			requestID := interceptors.GetRequestIDFromContext(ctx)
			assert.NotEmpty(t, requestID)
			return "response", nil
		}

		info := &grpc.UnaryServerInfo{FullMethod: "/test/method"}
		ctx := context.Background()

		_, err := interceptor(ctx, nil, info, handler)
		assert.NoError(t, err)

		// Verify request ID in logs
		logs := buf.String()
		assert.Contains(t, logs, "request_id")
	})

	t.Run("uses existing request ID from metadata", func(t *testing.T) {
		var buf bytes.Buffer
		config := &interceptors.LoggingConfig{
			Logger: slog.New(slog.NewTextHandler(&buf, nil)),
		}

		interceptor := interceptors.UnaryLoggingInterceptor(config)
		expectedID := "test-request-123"

		handler := func(ctx context.Context, req interface{}) (interface{}, error) {
			// Verify correct request ID was used
			requestID := interceptors.GetRequestIDFromContext(ctx)
			assert.Equal(t, expectedID, requestID)
			return "response", nil
		}

		info := &grpc.UnaryServerInfo{FullMethod: "/test/method"}

		// Add request ID to metadata
		md := metadata.Pairs("x-request-id", expectedID)
		ctx := metadata.NewIncomingContext(context.Background(), md)

		_, err := interceptor(ctx, nil, info, handler)
		assert.NoError(t, err)

		// Verify correct request ID in logs
		logs := buf.String()
		assert.Contains(t, logs, expectedID)
	})

	t.Run("request ID propagates through interceptor chain", func(t *testing.T) {
		var capturedIDs []string

		// First interceptor - logging
		loggingConfig := &interceptors.LoggingConfig{
			Logger: slog.New(slog.NewTextHandler(io.Discard, nil)),
		}
		loggingInterceptor := interceptors.UnaryLoggingInterceptor(loggingConfig)

		// Second interceptor - captures request ID
		captureInterceptor := func(ctx context.Context, req interface{}, info *grpc.UnaryServerInfo, handler grpc.UnaryHandler) (interface{}, error) {
			requestID := interceptors.GetRequestIDFromContext(ctx)
			capturedIDs = append(capturedIDs, requestID)
			return handler(ctx, req)
		}

		// Chain interceptors
		chainedHandler := func(ctx context.Context, req interface{}) (interface{}, error) {
			requestID := interceptors.GetRequestIDFromContext(ctx)
			capturedIDs = append(capturedIDs, requestID)
			return "response", nil
		}

		info := &grpc.UnaryServerInfo{FullMethod: "/test/method"}
		ctx := context.Background()

		// Execute chain
		wrappedHandler := func(ctx context.Context, req interface{}) (interface{}, error) {
			return captureInterceptor(ctx, req, info, chainedHandler)
		}

		_, err := loggingInterceptor(ctx, nil, info, wrappedHandler)
		assert.NoError(t, err)

		// Verify all interceptors saw the same request ID
		assert.Len(t, capturedIDs, 2)
		assert.Equal(t, capturedIDs[0], capturedIDs[1])
		assert.NotEmpty(t, capturedIDs[0])
	})
}

func TestStreamLoggingInterceptor(t *testing.T) {
	t.Parallel()

	t.Run("logs stream lifecycle", func(t *testing.T) {
		var buf bytes.Buffer
		config := &interceptors.LoggingConfig{
			Logger: slog.New(slog.NewTextHandler(&buf, nil)),
		}

		interceptor := interceptors.StreamLoggingInterceptor(config)

		// Mock stream
		stream := &mockServerStream{
			ctx: context.Background(),
		}

		handler := func(srv interface{}, stream grpc.ServerStream) error {
			// Simulate stream operations
			time.Sleep(10 * time.Millisecond)
			return nil
		}

		info := &grpc.StreamServerInfo{
			FullMethod:     "/test/stream",
			IsServerStream: true,
			IsClientStream: false,
		}

		err := interceptor(nil, stream, info, handler)
		assert.NoError(t, err)

		logs := buf.String()
		assert.Contains(t, logs, "gRPC stream started")
		assert.Contains(t, logs, "gRPC stream completed")
		assert.Contains(t, logs, "stream_type")
		assert.Contains(t, logs, "server_stream")
	})

	t.Run("logs bidirectional stream", func(t *testing.T) {
		var buf bytes.Buffer
		config := &interceptors.LoggingConfig{
			Logger: slog.New(slog.NewTextHandler(&buf, nil)),
		}

		interceptor := interceptors.StreamLoggingInterceptor(config)

		stream := &mockServerStream{
			ctx: context.Background(),
		}

		handler := func(srv interface{}, stream grpc.ServerStream) error {
			return nil
		}

		info := &grpc.StreamServerInfo{
			FullMethod:     "/test/bidi",
			IsServerStream: true,
			IsClientStream: true,
		}

		err := interceptor(nil, stream, info, handler)
		assert.NoError(t, err)

		logs := buf.String()
		assert.Contains(t, logs, "bidirectional")
	})

	t.Run("logs stream errors", func(t *testing.T) {
		var buf bytes.Buffer
		config := &interceptors.LoggingConfig{
			Logger: slog.New(slog.NewTextHandler(&buf, nil)),
		}

		interceptor := interceptors.StreamLoggingInterceptor(config)

		stream := &mockServerStream{
			ctx: context.Background(),
		}

		expectedErr := status.Error(codes.Internal, "stream failed")
		handler := func(srv interface{}, stream grpc.ServerStream) error {
			return expectedErr
		}

		info := &grpc.StreamServerInfo{
			FullMethod:     "/test/error",
			IsServerStream: true,
		}

		err := interceptor(nil, stream, info, handler)
		assert.Error(t, err)
		assert.Equal(t, expectedErr, err)

		logs := buf.String()
		assert.Contains(t, logs, "ERROR")
		assert.Contains(t, logs, "Internal")
		assert.Contains(t, logs, "stream failed")
	})

	t.Run("excludes configured methods", func(t *testing.T) {
		var buf bytes.Buffer
		config := &interceptors.LoggingConfig{
			Logger:          slog.New(slog.NewTextHandler(&buf, nil)),
			ExcludedMethods: []string{"/test/excluded"},
		}

		interceptor := interceptors.StreamLoggingInterceptor(config)

		stream := &mockServerStream{
			ctx: context.Background(),
		}

		handler := func(srv interface{}, stream grpc.ServerStream) error {
			return nil
		}

		info := &grpc.StreamServerInfo{
			FullMethod: "/test/excluded",
		}

		err := interceptor(nil, stream, info, handler)
		assert.NoError(t, err)

		logs := buf.String()
		assert.NotContains(t, logs, "gRPC stream")
	})
}

// T003-D: Performance metrics collection testing
func TestPerformanceMetrics(t *testing.T) {
	t.Parallel()

	t.Run("measures request duration", func(t *testing.T) {
		var buf bytes.Buffer
		config := &interceptors.LoggingConfig{
			Logger: slog.New(slog.NewJSONHandler(&buf, nil)),
		}

		interceptor := interceptors.UnaryLoggingInterceptor(config)

		handler := func(ctx context.Context, req interface{}) (interface{}, error) {
			time.Sleep(50 * time.Millisecond)
			return "response", nil
		}

		info := &grpc.UnaryServerInfo{FullMethod: "/test/method"}
		ctx := context.Background()

		start := time.Now()
		_, err := interceptor(ctx, nil, info, handler)
		elapsed := time.Since(start)

		assert.NoError(t, err)
		assert.GreaterOrEqual(t, elapsed, 50*time.Millisecond)

		// Parse logs to verify duration was recorded
		var logEntry map[string]interface{}
		lines := strings.Split(buf.String(), "\n")
		for _, line := range lines {
			if strings.Contains(line, "duration_ms") && strings.Contains(line, "response") {
				err := json.Unmarshal([]byte(line), &logEntry)
				if err == nil {
					duration, ok := logEntry["duration_ms"].(float64)
					assert.True(t, ok)
					assert.GreaterOrEqual(t, duration, float64(50))
					break
				}
			}
		}
	})

	t.Run("tracks concurrent requests", func(t *testing.T) {
		var buf bytes.Buffer
		config := &interceptors.LoggingConfig{
			Logger: slog.New(slog.NewJSONHandler(&buf, nil)),
		}

		interceptor := interceptors.UnaryLoggingInterceptor(config)

		// Track request IDs
		var requestIDs []string
		handler := func(ctx context.Context, req interface{}) (interface{}, error) {
			requestID := interceptors.GetRequestIDFromContext(ctx)
			requestIDs = append(requestIDs, requestID)
			time.Sleep(10 * time.Millisecond)
			return "response", nil
		}

		info := &grpc.UnaryServerInfo{FullMethod: "/test/concurrent"}

		// Run multiple requests concurrently
		const numRequests = 5
		done := make(chan bool, numRequests)

		for i := 0; i < numRequests; i++ {
			go func() {
				ctx := context.Background()
				_, _ = interceptor(ctx, nil, info, handler)
				done <- true
			}()
		}

		// Wait for all requests
		for i := 0; i < numRequests; i++ {
			<-done
		}

		// Verify each request had a unique ID
		assert.Len(t, requestIDs, numRequests)
		uniqueIDs := make(map[string]bool)
		for _, id := range requestIDs {
			uniqueIDs[id] = true
		}
		assert.Len(t, uniqueIDs, numRequests)
	})
}

// T003-E: Error recovery testing
func TestErrorRecovery(t *testing.T) {
	t.Parallel()

	t.Run("logs panic in handler", func(t *testing.T) {
		// Note: The logging interceptor doesn't handle panics directly,
		// that's the job of the error handler interceptor.
		// But we can test that logging continues to work after errors.

		var buf bytes.Buffer
		config := &interceptors.LoggingConfig{
			Logger: slog.New(slog.NewTextHandler(&buf, nil)),
		}

		interceptor := interceptors.UnaryLoggingInterceptor(config)

		// First request succeeds
		handler1 := func(ctx context.Context, req interface{}) (interface{}, error) {
			return "success", nil
		}

		info := &grpc.UnaryServerInfo{FullMethod: "/test/method"}
		ctx := context.Background()

		resp1, err1 := interceptor(ctx, "req1", info, handler1)
		assert.NoError(t, err1)
		assert.Equal(t, "success", resp1)

		// Second request fails
		handler2 := func(ctx context.Context, req interface{}) (interface{}, error) {
			return nil, errors.New("handler error")
		}

		resp2, err2 := interceptor(ctx, "req2", info, handler2)
		assert.Error(t, err2)
		assert.Nil(t, resp2)

		// Third request succeeds (verify interceptor still works)
		handler3 := func(ctx context.Context, req interface{}) (interface{}, error) {
			return "recovery", nil
		}

		resp3, err3 := interceptor(ctx, "req3", info, handler3)
		assert.NoError(t, err3)
		assert.Equal(t, "recovery", resp3)

		// Verify all requests were logged
		logs := buf.String()
		assert.Contains(t, logs, "req1")
		assert.Contains(t, logs, "req2")
		assert.Contains(t, logs, "req3")
		assert.Contains(t, logs, "handler error")
	})

	t.Run("handles nil logger gracefully", func(t *testing.T) {
		// Test that even with a nil logger, the interceptor doesn't panic
		config := &interceptors.LoggingConfig{
			Logger: nil, // Intentionally nil
		}

		// This should create a default logger internally
		config = interceptors.NewLoggingConfig()
		assert.NotNil(t, config.Logger)

		interceptor := interceptors.UnaryLoggingInterceptor(config)

		handler := func(ctx context.Context, req interface{}) (interface{}, error) {
			return "response", nil
		}

		info := &grpc.UnaryServerInfo{FullMethod: "/test/method"}
		ctx := context.Background()

		// Should not panic even with nil logger initially
		resp, err := interceptor(ctx, nil, info, handler)
		assert.NoError(t, err)
		assert.Equal(t, "response", resp)
	})
}

// Mock server stream for testing
type mockServerStream struct {
	grpc.ServerStream
	ctx context.Context
	sentMessages []interface{}
	recvMessages []interface{}
}

func (m *mockServerStream) Context() context.Context {
	return m.ctx
}

func (m *mockServerStream) SendMsg(msg interface{}) error {
	m.sentMessages = append(m.sentMessages, msg)
	return nil
}

func (m *mockServerStream) RecvMsg(msg interface{}) error {
	if len(m.recvMessages) > 0 {
		return nil
	}
	return io.EOF
}

func (m *mockServerStream) SetHeader(metadata.MD) error {
	return nil
}

func (m *mockServerStream) SendHeader(metadata.MD) error {
	return nil
}

func (m *mockServerStream) SetTrailer(metadata.MD) {
}

// Benchmarks
func BenchmarkUnaryLoggingInterceptor(b *testing.B) {
	config := &interceptors.LoggingConfig{
		Logger:         slog.New(slog.NewTextHandler(io.Discard, nil)),
		LogPayloads:    true,
		MaxPayloadSize: 1024,
	}

	interceptor := interceptors.UnaryLoggingInterceptor(config)

	handler := func(ctx context.Context, req interface{}) (interface{}, error) {
		return "response", nil
	}

	info := &grpc.UnaryServerInfo{FullMethod: "/test/method"}
	ctx := context.Background()
	req := map[string]string{"test": "data"}

	b.ResetTimer()
	b.RunParallel(func(pb *testing.PB) {
		for pb.Next() {
			_, _ = interceptor(ctx, req, info, handler)
		}
	})
}

func BenchmarkRequestIDGeneration(b *testing.B) {
	ctx := context.Background()

	b.RunParallel(func(pb *testing.PB) {
		for pb.Next() {
			// Simulate what happens in the interceptor
			md := metadata.Pairs("x-request-id", "test-id")
			_ = metadata.NewIncomingContext(ctx, md)
		}
	})
}