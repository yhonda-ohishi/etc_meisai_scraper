package models

import (
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)


// TestValidateETCMeisai_ComprehensiveEdgeCases tests ValidateETCMeisai function for edge cases
func TestValidateETCMeisai_ComprehensiveEdgeCases(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		record  *ETCMeisai
		wantErr bool
		errMsg  string
	}{
		{
			name: "nil record",
			record: nil,
			wantErr: true,
			errMsg: "Record cannot be nil",
		},
		{
			name: "record with invalid use time format",
			record: &ETCMeisai{
				UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
				UseTime:   "25:70", // Invalid time format
				EntryIC:   "東京IC",
				ExitIC:    "横浜IC",
				Amount:    1000,
				CarNumber: "品川300あ1234",
				ETCNumber: "123456789012",
			},
			wantErr: true,
			errMsg: "UseTime must be in HH:MM format",
		},
		{
			name: "record with invalid ETC number format",
			record: &ETCMeisai{
				UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
				UseTime:   "10:30",
				EntryIC:   "東京IC",
				ExitIC:    "樬浜IC",
				Amount:    1000,
				CarNumber: "品川300あ1234",
				ETCNumber: "invalid-etc", // Invalid ETC number format (contains non-digits)
			},
			wantErr: true,
			errMsg: "ETCNumber contains invalid characters",
		},
		{
			name: "record with unicode characters in IC names",
			record: &ETCMeisai{
				UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
				UseTime:   "10:30",
				EntryIC:   "東京インターチェンジ",
				ExitIC:    "横浜ベイブリッジ",
				Amount:    1000,
				CarNumber: "品川300あ1234",
				ETCNumber: "123456789012",  // Valid ETC number (digits only)
			},
			wantErr: false,
		},
		{
			name: "record with maximum valid amount",
			record: &ETCMeisai{
				UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
				UseTime:   "10:30",
				EntryIC:   "東京IC",
				ExitIC:    "横浜IC",
				Amount:    999999,  // Above 100000 triggers "unusually high" warning
				CarNumber: "品川300あ1234",
				ETCNumber: "123456789012",
			},
			wantErr: true,  // ValidateETCMeisai treats >100000 as suspicious
			errMsg:  "Amount seems unusually high",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			result := ValidateETCMeisai(tt.record)
			if tt.wantErr {
				assert.False(t, result.Valid)
				assert.NotEmpty(t, result.Errors)
				if tt.errMsg != "" {
					found := false
					for _, err := range result.Errors {
						if assert.Contains(t, err.Message, tt.errMsg) {
							found = true
							break
						}
					}
					assert.True(t, found, "Expected error message not found: %s", tt.errMsg)
				}
			} else {
				assert.True(t, result.Valid)
				assert.Empty(t, result.Errors)
			}
		})
	}
}

// TestETCMeisaiRecord_ValidateEdgeCases tests the validate method for ETCMeisaiRecord
func TestETCMeisaiRecord_ValidateEdgeCases(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		record  *ETCMeisaiRecord
		wantErr bool
		errMsg  string
	}{
		{
			name: "record with boundary ETC card number length",
			record: &ETCMeisaiRecord{
				ID:            1,
				Date:          time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
				Time:          "10:30:00",
				EntranceIC:    "東京IC",
				ExitIC:        "横浜IC",
				TollAmount:    1000,
				CarNumber:     "123-45",  // Valid Japanese vehicle number format
				ETCCardNumber: "1234567890123456", // Exactly 16 digits
				ETCNum:        stringPtr("ETC001"),
				Hash:          "test-hash",
			},
			wantErr: false,
		},
		{
			name: "record with nil ETC number (should be allowed)",
			record: &ETCMeisaiRecord{
				ID:            1,
				Date:          time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
				Time:          "10:30:00",
				EntranceIC:    "東京IC",
				ExitIC:        "横浜IC",
				TollAmount:    1000,
				CarNumber:     "123-45",  // Valid Japanese vehicle number format
				ETCCardNumber: "1234567890123456",
				ETCNum:        nil, // Nil ETC number
				Hash:          "test-hash",
			},
			wantErr: false,
		},
		{
			name: "record with very long ETC number",
			record: &ETCMeisaiRecord{
				ID:            1,
				Date:          time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
				Time:          "10:30:00",
				EntranceIC:    "東京IC",
				ExitIC:        "横浜IC",
				TollAmount:    1000,
				CarNumber:     "123-45",  // Valid Japanese vehicle number format
				ETCCardNumber: "1234567890123456",
				ETCNum:        stringPtr("12345678901234567890123456789012345678901234567890123"), // > 50 chars
				Hash:          "test-hash",
			},
			wantErr: true,
			errMsg:  "ETC number must be 5-50 characters",
		},
		{
			name: "record with empty hash (should be allowed)",
			record: &ETCMeisaiRecord{
				ID:            1,
				Date:          time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
				Time:          "10:30:00",
				EntranceIC:    "東京IC",
				ExitIC:        "横浜IC",
				TollAmount:    1000,
				CarNumber:     "123-45",  // Valid Japanese vehicle number format
				ETCCardNumber: "1234567890123456",
				ETCNum:        stringPtr("ETC001"),
				Hash:          "", // Empty hash is allowed, not validated
			},
			wantErr: false,  // validate() doesn't check hash
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			err := tt.record.validate()
			if tt.wantErr {
				require.Error(t, err)
				if tt.errMsg != "" {
					assert.Contains(t, err.Error(), tt.errMsg)
				}
			} else {
				assert.NoError(t, err)
			}
		})
	}
}

// TestETCMapping_ValidateExtendedEdgeCases tests the validate method for ETCMapping
func TestETCMapping_ValidateExtendedEdgeCases(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		mapping *ETCMapping
		wantErr bool
		errMsg  string
	}{
		{
			name: "mapping with zero ETC record ID",
			mapping: &ETCMapping{
				ETCRecordID:      0, // Invalid
				MappingType:      "dtako",
				MappedEntityID:   200,
				MappedEntityType: "dtako_record",
				Confidence:       0.95,
			},
			wantErr: true,
			errMsg:  "must be positive",
		},
		{
			name: "mapping with negative mapped entity ID",
			mapping: &ETCMapping{
				ETCRecordID:      100,
				MappingType:      "dtako",
				MappedEntityID:   -1, // Invalid
				MappedEntityType: "dtako_record",
				Confidence:       0.95,
			},
			wantErr: true,
			errMsg:  "must be positive",
		},
		{
			name: "mapping with invalid mapping type",
			mapping: &ETCMapping{
				ETCRecordID:      100,
				MappingType:      "invalid", // Invalid type
				MappedEntityID:   200,
				MappedEntityType: "dtako_record",
				Confidence:       0.95,
			},
			wantErr: true,
			errMsg:  "invalid mapping type",
		},
		{
			name: "mapping with invalid entity type",
			mapping: &ETCMapping{
				ETCRecordID:      100,
				MappingType:      "dtako",
				MappedEntityID:   200,
				MappedEntityType: "invalid", // Invalid entity type
				Confidence:       0.95,
			},
			wantErr: true,
			errMsg:  "invalid mapped entity type",
		},
		{
			name: "mapping with boundary confidence values",
			mapping: &ETCMapping{
				ETCRecordID:      100,
				MappingType:      "dtako",
				MappedEntityID:   200,
				MappedEntityType: "dtako_record",
				Confidence:       1.0, // Maximum valid value
			},
			wantErr: false,
		},
		{
			name: "mapping with confidence above 1.0",
			mapping: &ETCMapping{
				ETCRecordID:      100,
				MappingType:      "dtako",
				MappedEntityID:   200,
				MappedEntityType: "dtako_record",
				Confidence:       1.5, // Invalid
			},
			wantErr: true,
			errMsg:  "confidence must be between 0.0 and 1.0",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			err := tt.mapping.validate()
			if tt.wantErr {
				require.Error(t, err)
				if tt.errMsg != "" {
					assert.Contains(t, err.Error(), tt.errMsg)
				}
			} else {
				assert.NoError(t, err)
			}
		})
	}
}

// TestImportSession_CanTransitionTo_EdgeCases tests CanTransitionTo method edge cases
func TestImportSession_CanTransitionTo_EdgeCases(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name          string
		currentStatus string
		targetStatus  string
		canTransition bool
	}{
		{
			name:          "pending to processing",
			currentStatus: "pending",
			targetStatus:  "processing",
			canTransition: true,
		},
		{
			name:          "pending to cancelled",
			currentStatus: "pending",
			targetStatus:  "cancelled",
			canTransition: true,
		},
		{
			name:          "pending to completed (invalid)",
			currentStatus: "pending",
			targetStatus:  "completed",
			canTransition: false,
		},
		{
			name:          "processing to completed",
			currentStatus: "processing",
			targetStatus:  "completed",
			canTransition: true,
		},
		{
			name:          "processing to failed",
			currentStatus: "processing",
			targetStatus:  "failed",
			canTransition: true,
		},
		{
			name:          "processing to cancelled",
			currentStatus: "processing",
			targetStatus:  "cancelled",
			canTransition: true,
		},
		{
			name:          "completed to processing (invalid)",
			currentStatus: "completed",
			targetStatus:  "processing",
			canTransition: false,
		},
		{
			name:          "failed to processing (invalid)",
			currentStatus: "failed",
			targetStatus:  "processing",
			canTransition: false,
		},
		{
			name:          "cancelled to processing (invalid)",
			currentStatus: "cancelled",
			targetStatus:  "processing",
			canTransition: false,
		},
		{
			name:          "unknown status",
			currentStatus: "unknown",
			targetStatus:  "processing",
			canTransition: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			session := &ImportSession{Status: tt.currentStatus}
			result := session.CanTransitionTo(tt.targetStatus)
			assert.Equal(t, tt.canTransition, result)
		})
	}
}