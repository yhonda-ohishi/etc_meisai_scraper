package models

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestETCMapping_ValidateEdgeCases(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		setup   func() *ETCMapping
		wantErr bool
		errMsg  string
	}{
		{
			name: "metadata marshaling error",
			setup: func() *ETCMapping {
				mapping := &ETCMapping{
					ETCRecordID:      1,
					MappingType:      "dtako",
					MappedEntityID:   1,
					MappedEntityType: "dtako_record",
					Confidence:       0.8,
					Status:           "active",
				}
				// Set metadata directly to invalid JSON
				mapping.Metadata = []byte("invalid json")
				return mapping
			},
			wantErr: false, // This won't fail validation, only GetMetadata will fail
		},
		{
			name: "very long created_by field",
			setup: func() *ETCMapping {
				return &ETCMapping{
					ETCRecordID:      1,
					MappingType:      "dtako",
					MappedEntityID:   1,
					MappedEntityType: "dtako_record",
					Confidence:       0.8,
					Status:           "active",
					CreatedBy:        string(make([]byte, 101)), // 101 characters
				}
			},
			wantErr: true,
			errMsg:  "too long",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			mapping := tt.setup()
			err := mapping.validate()
			if tt.wantErr {
				assert.Error(t, err)
				if tt.errMsg != "" {
					assert.Contains(t, err.Error(), tt.errMsg)
				}
			} else {
				assert.NoError(t, err)
			}
		})
	}
}

func TestETCMapping_SetMetadataEdgeCases(t *testing.T) {
	t.Parallel()

	mapping := &ETCMapping{}

	// Test nil metadata
	err := mapping.SetMetadata(nil)
	assert.NoError(t, err)
	assert.Nil(t, mapping.Metadata)

	// Test valid metadata
	metadata := map[string]interface{}{
		"source": "auto_match",
		"score":  0.95,
	}
	err = mapping.SetMetadata(metadata)
	assert.NoError(t, err)
	assert.NotNil(t, mapping.Metadata)
}

func TestETCMapping_GetMetadataEdgeCases(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name     string
		setup    func() *ETCMapping
		wantErr  bool
		expected map[string]interface{}
	}{
		{
			name: "nil metadata",
			setup: func() *ETCMapping {
				return &ETCMapping{Metadata: nil}
			},
			wantErr:  false,
			expected: nil,
		},
		{
			name: "invalid JSON metadata",
			setup: func() *ETCMapping {
				return &ETCMapping{Metadata: []byte("invalid json")}
			},
			wantErr:  true,
			expected: nil,
		},
		{
			name: "valid metadata",
			setup: func() *ETCMapping {
				mapping := &ETCMapping{}
				mapping.SetMetadata(map[string]interface{}{"test": "value"})
				return mapping
			},
			wantErr:  false,
			expected: map[string]interface{}{"test": "value"},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			mapping := tt.setup()
			result, err := mapping.GetMetadata()
			if tt.wantErr {
				assert.Error(t, err)
				assert.Nil(t, result)
			} else {
				assert.NoError(t, err)
				assert.Equal(t, tt.expected, result)
			}
		})
	}
}