package models

import (
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
)

// TestETCMapping_StatusTransitionMethods tests all status transition methods
func TestETCMapping_StatusTransitionMethods(t *testing.T) {
	t.Parallel()

	t.Run("Activate method", func(t *testing.T) {
		tests := []struct {
			name          string
			currentStatus string
			wantErr       bool
		}{
			{
				name:          "activate from pending",
				currentStatus: "pending",
				wantErr:       false,
			},
			{
				name:          "activate from inactive",
				currentStatus: "inactive",
				wantErr:       false,
			},
			{
				name:          "activate from active (should fail)",
				currentStatus: "active",
				wantErr:       true,
			},
			{
				name:          "activate from rejected (should fail)",
				currentStatus: "rejected",
				wantErr:       true,
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				mapping := &ETCMapping{
					ETCRecordID:      100,
					MappingType:      "dtako",
					MappedEntityID:   200,
					MappedEntityType: "dtako_record",
					Confidence:       0.95,
					Status:           tt.currentStatus,
				}

				err := mapping.Activate()
				if tt.wantErr {
					assert.Error(t, err)
				} else {
					assert.NoError(t, err)
					assert.Equal(t, "active", mapping.Status)
				}
			})
		}
	})

	t.Run("Deactivate method", func(t *testing.T) {
		tests := []struct {
			name          string
			currentStatus string
			wantErr       bool
		}{
			{
				name:          "deactivate from active",
				currentStatus: "active",
				wantErr:       false,
			},
			{
				name:          "deactivate from pending (should fail)",
				currentStatus: "pending",
				wantErr:       true,  // pending cannot transition to inactive
			},
			{
				name:          "deactivate from inactive (should fail)",
				currentStatus: "inactive",
				wantErr:       true,
			},
			{
				name:          "deactivate from rejected (should fail)",
				currentStatus: "rejected",
				wantErr:       true,
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				mapping := &ETCMapping{
					ETCRecordID:      100,
					MappingType:      "dtako",
					MappedEntityID:   200,
					MappedEntityType: "dtako_record",
					Confidence:       0.95,
					Status:           tt.currentStatus,
				}

				err := mapping.Deactivate()
				if tt.wantErr {
					assert.Error(t, err)
				} else {
					assert.NoError(t, err)
					assert.Equal(t, "inactive", mapping.Status)
				}
			})
		}
	})

	t.Run("Approve method", func(t *testing.T) {
		tests := []struct {
			name          string
			currentStatus string
			wantErr       bool
		}{
			{
				name:          "approve from pending",
				currentStatus: "pending",
				wantErr:       false,
			},
			{
				name:          "approve from inactive (should fail)",
				currentStatus: "inactive",
				wantErr:       true,  // can only approve from pending
			},
			{
				name:          "approve from active (should fail)",
				currentStatus: "active",
				wantErr:       true,
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				mapping := &ETCMapping{
					ETCRecordID:      100,
					MappingType:      "dtako",
					MappedEntityID:   200,
					MappedEntityType: "dtako_record",
					Confidence:       0.95,
					Status:           tt.currentStatus,
				}

				err := mapping.Approve()
				if tt.wantErr {
					assert.Error(t, err)
				} else {
					assert.NoError(t, err)
					assert.Equal(t, "active", mapping.Status)
				}
			})
		}
	})

	t.Run("Reject method", func(t *testing.T) {
		tests := []struct {
			name          string
			currentStatus string
			wantErr       bool
		}{
			{
				name:          "reject from pending",
				currentStatus: "pending",
				wantErr:       false,
			},
			{
				name:          "reject from active (should fail)",
				currentStatus: "active",
				wantErr:       true,  // can only reject from pending
			},
			{
				name:          "reject from rejected (should fail)",
				currentStatus: "rejected",
				wantErr:       true,
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				mapping := &ETCMapping{
					ETCRecordID:      100,
					MappingType:      "dtako",
					MappedEntityID:   200,
					MappedEntityType: "dtako_record",
					Confidence:       0.95,
					Status:           tt.currentStatus,
				}

				err := mapping.Reject()
				if tt.wantErr {
					assert.Error(t, err)
				} else {
					assert.NoError(t, err)
					assert.Equal(t, "rejected", mapping.Status)
				}
			})
		}
	})
}

// TestETCMapping_MetadataOperations tests metadata get/set operations
func TestETCMapping_MetadataOperations(t *testing.T) {
	t.Parallel()

	t.Run("SetMetadata and GetMetadata", func(t *testing.T) {
		mapping := &ETCMapping{
			ETCRecordID:      100,
			MappingType:      "dtako",
			MappedEntityID:   200,
			MappedEntityType: "dtako_record",
			Confidence:       0.95,
		}

		// Test setting valid metadata
		testData := map[string]interface{}{
			"reason":     "automatic_match",
			"confidence": 0.95,
			"algorithm":  "fuzzy_match",
		}

		err := mapping.SetMetadata(testData)
		assert.NoError(t, err)

		// Test getting metadata
		retrievedData, err := mapping.GetMetadata()
		assert.NoError(t, err)
		assert.Equal(t, testData, retrievedData)

		// Test setting nil metadata
		err = mapping.SetMetadata(nil)
		assert.NoError(t, err)

		retrievedData, err = mapping.GetMetadata()
		assert.NoError(t, err)
		assert.Nil(t, retrievedData)
	})

	t.Run("GetMetadata with invalid JSON", func(t *testing.T) {
		mapping := &ETCMapping{
			ETCRecordID:      100,
			MappingType:      "dtako",
			MappedEntityID:   200,
			MappedEntityType: "dtako_record",
			Confidence:       0.95,
			Metadata:         []byte("invalid json{"), // Invalid JSON
		}

		_, err := mapping.GetMetadata()
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "unmarshal")
	})
}

// TestImportSession_StateManagement tests state transition methods
func TestImportSession_StateManagement(t *testing.T) {
	t.Parallel()

	t.Run("StartProcessing", func(t *testing.T) {
		session := &ImportSession{
			ID:          "550e8400-e29b-41d4-a716-446655440000",
			AccountType: "corporate",
			AccountID:   "ACC001",
			FileName:    "test.csv",
			FileSize:    1024,
			Status:      "pending",
			StartedAt:   time.Time{}, // Zero time
		}

		err := session.StartProcessing()
		assert.NoError(t, err)
		assert.Equal(t, "processing", session.Status)
		assert.False(t, session.StartedAt.IsZero())
	})

	t.Run("Complete with file size validation", func(t *testing.T) {
		session := &ImportSession{
			ID:          "550e8400-e29b-41d4-a716-446655440000",
			AccountType: "corporate",
			AccountID:   "ACC001",
			FileName:    "test.csv",
			FileSize:    104857601, // > 100MB (too large)
			Status:      "processing",
			StartedAt:   time.Now(),
		}

		// Test that validation catches oversized file
		err := session.validate()
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "file size too large")
	})
}

// TestValidateETCImportBatch_EdgeCases tests ValidateETCImportBatch function
func TestValidateETCImportBatch_EdgeCases(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		batch   *ETCImportBatch
		wantErr bool
		errMsg  string
	}{
		{
			name:    "nil batch",
			batch:   nil,
			wantErr: true,
			errMsg:  "cannot be nil",
		},
		{
			name: "batch with huge file size",
			batch: &ETCImportBatch{
				FileName:     "test.csv",
				FileSize:     99999999999, // Very large file
				TotalRecords: 1000000,
				Status:       "pending",
			},
			wantErr: false, // Our validation doesn't have an upper limit check
		},
		{
			name: "batch with unicode filename",
			batch: &ETCImportBatch{
				FileName:     "テスト.csv",
				FileSize:     1024,
				TotalRecords: 100,
				Status:       "pending",
			},
			wantErr: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			result := ValidateETCImportBatch(tt.batch)
			if tt.wantErr {
				assert.False(t, result.Valid)
				assert.NotEmpty(t, result.Errors)
				if tt.errMsg != "" {
					found := false
					for _, err := range result.Errors {
						if assert.Contains(t, err.Message, tt.errMsg) {
							found = true
							break
						}
					}
					assert.True(t, found, "Expected error message not found: %s", tt.errMsg)
				}
			} else {
				assert.True(t, result.Valid)
			}
		})
	}
}

// TestImportSession_GetErrors_EdgeCases tests error handling edge cases
func TestImportSession_GetErrors_EdgeCases(t *testing.T) {
	t.Parallel()

	t.Run("GetErrors with invalid JSON", func(t *testing.T) {
		session := &ImportSession{
			ErrorLog: []byte("invalid json{"), // Invalid JSON
		}

		errors, err := session.GetErrors()
		assert.Error(t, err)
		assert.Nil(t, errors)
		assert.Contains(t, err.Error(), "unmarshal")
	})

	t.Run("AddError with invalid JSON state", func(t *testing.T) {
		session := &ImportSession{
			ErrorLog: []byte("invalid json{"), // Invalid JSON
		}

		err := session.AddError(1, "test", "test error", "raw data")
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "unmarshal")
	})
}

// TestETCImportBatch_GetDuration_EdgeCases tests GetDuration method edge cases
func TestETCImportBatch_GetDuration_EdgeCases(t *testing.T) {
	t.Parallel()

	t.Run("GetDuration with completed batch", func(t *testing.T) {
		startTime := time.Now()
		endTime := startTime.Add(2 * time.Hour)

		batch := &ETCImportBatch{
			FileName:     "test.csv",
			FileSize:     1024,
			TotalRecords: 100,
			Status:       "completed",
			StartTime:    &startTime,
			CompleteTime:  &endTime,
		}

		duration := batch.GetDuration()
		assert.NotNil(t, duration)
		assert.Equal(t, 2*time.Hour, *duration)
	})

	t.Run("GetDuration with nil start time", func(t *testing.T) {
		batch := &ETCImportBatch{
			FileName:     "test.csv",
			FileSize:     1024,
			TotalRecords: 100,
			Status:       "pending",
			StartTime:    nil,
			CompleteTime:  nil,
		}

		duration := batch.GetDuration()
		assert.Nil(t, duration)
	})
}