package models

import (
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
)

func TestETCImportBatch_Validate(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		batch   *ETCImportBatch
		wantErr bool
		errMsg  string
	}{
		{
			name: "valid batch",
			batch: &ETCImportBatch{
				ID:             1,
				BatchHash:      "hash123",
				FileName:       "test.csv",
				FileSize:       1024,
				AccountID:      "ACC001",
				ImportType:     "manual",
				TotalRows:      100,
				ProcessedRows:  0,
				SuccessCount:   0,
				ErrorCount:     0,
				Status:         "pending",
				CreatedAt:      time.Now(),
				UpdatedAt:      time.Now(),
			},
			wantErr: false,
		},
		{
			name: "missing filename",
			batch: &ETCImportBatch{
				ID:        1,
				BatchHash: "hash123",
				FileName:  "",
				FileSize:  1024,
				Status:    "pending",
			},
			wantErr: true,
			errMsg:  "FileName is required",
		},
		{
			name: "invalid status",
			batch: &ETCImportBatch{
				ID:        1,
				BatchHash: "hash123",
				FileName:  "test.csv",
				FileSize:  1024,
				Status:    "invalid",
			},
			wantErr: true,
			errMsg:  "invalid Status",
		},
		{
			name: "negative total records",
			batch: &ETCImportBatch{
				ID:           1,
				BatchHash:    "hash123",
				FileName:     "test.csv",
				FileSize:     1024,
				TotalRecords: -1,
				Status:       "pending",
			},
			wantErr: true,
			errMsg:  "TotalRecords cannot be negative",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			err := tt.batch.Validate()

			if tt.wantErr {
				assert.Error(t, err)
				if tt.errMsg != "" {
					assert.Contains(t, err.Error(), tt.errMsg)
				}
			} else {
				assert.NoError(t, err)
			}
		})
	}
}

func TestETCImportBatch_GetDuration(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name     string
		batch    *ETCImportBatch
		expected bool // whether duration should be nil
	}{
		{
			name: "no start time",
			batch: &ETCImportBatch{
				StartTime: nil,
			},
			expected: true, // duration should be nil
		},
		{
			name: "with start time but no complete time",
			batch: &ETCImportBatch{
				StartTime: &time.Time{},
			},
			expected: false, // duration should not be nil
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			duration := tt.batch.GetDuration()
			if tt.expected {
				assert.Nil(t, duration)
			} else {
				assert.NotNil(t, duration)
			}
		})
	}
}

func TestETCImportBatch_GetProgress(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name           string
		batch          *ETCImportBatch
		expectedPercent float32
	}{
		{
			name: "no progress",
			batch: &ETCImportBatch{
				TotalRecords:   100,
				ProcessedCount: 0,
			},
			expectedPercent: 0.0,
		},
		{
			name: "half complete",
			batch: &ETCImportBatch{
				TotalRecords:   100,
				ProcessedCount: 50,
			},
			expectedPercent: 50.0,
		},
		{
			name: "complete",
			batch: &ETCImportBatch{
				TotalRecords:   100,
				ProcessedCount: 100,
			},
			expectedPercent: 100.0,
		},
		{
			name: "zero total rows",
			batch: &ETCImportBatch{
				TotalRecords:   0,
				ProcessedCount: 0,
			},
			expectedPercent: 0.0, // Returns 0 when no records to process
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			percent := tt.batch.GetProgress()
			assert.Equal(t, tt.expectedPercent, percent)
		})
	}
}

func TestETCImportBatch_IsCompleted(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name      string
		batch     *ETCImportBatch
		completed bool
	}{
		{
			name: "completed status",
			batch: &ETCImportBatch{
				Status: "completed",
			},
			completed: true,
		},
		{
			name: "failed status",
			batch: &ETCImportBatch{
				Status: "failed",
			},
			completed: true,
		},
		{
			name: "pending status",
			batch: &ETCImportBatch{
				Status: "pending",
			},
			completed: false,
		},
		{
			name: "processing status",
			batch: &ETCImportBatch{
				Status: "processing",
			},
			completed: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			result := tt.batch.IsCompleted()
			assert.Equal(t, tt.completed, result)
		})
	}
}

func TestETCImportBatch_BeforeCreate(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		batch   *ETCImportBatch
		wantErr bool
	}{
		{
			name: "valid batch passes before create",
			batch: &ETCImportBatch{
				BatchHash:  "hash123",
				FileName:   "test.csv",
				FileSize:   1024,
				TotalRows:  100,
				Status:     "pending",
			},
			wantErr: false,
		},
		{
			name: "invalid batch fails before create",
			batch: &ETCImportBatch{
				BatchHash: "hash123",
				FileName:  "", // Invalid
				FileSize:  1024,
				Status:    "pending",
			},
			wantErr: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			err := tt.batch.BeforeCreate()

			if tt.wantErr {
				assert.Error(t, err)
			} else {
				assert.NoError(t, err)
			}
		})
	}
}

func TestETCImportBatch_BeforeUpdate(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		batch   *ETCImportBatch
		wantErr bool
	}{
		{
			name: "valid batch passes before update",
			batch: &ETCImportBatch{
				BatchHash:  "hash123",
				FileName:   "test.csv",
				FileSize:   1024,
				TotalRows:  100,
				Status:     "processing",
			},
			wantErr: false,
		},
		{
			name: "invalid batch fails before update",
			batch: &ETCImportBatch{
				BatchHash: "hash123",
				FileName:  "", // Invalid
				FileSize:  1024,
				Status:    "processing",
			},
			wantErr: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			err := tt.batch.BeforeUpdate()

			if tt.wantErr {
				assert.Error(t, err)
			} else {
				assert.NoError(t, err)
			}
		})
	}
}