package models

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestETCListParams_SetDefaults(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name      string
		params    *ETCListParams
		expected  *ETCListParams
	}{
		{
			name:   "empty params get default values",
			params: &ETCListParams{},
			expected: &ETCListParams{
				Limit:  100,
				Offset: 0,
			},
		},
		{
			name: "negative limit gets default",
			params: &ETCListParams{
				Limit:  -10,
				Offset: 5,
			},
			expected: &ETCListParams{
				Limit:  100,
				Offset: 5,
			},
		},
		{
			name: "zero limit gets default",
			params: &ETCListParams{
				Limit:  0,
				Offset: 10,
			},
			expected: &ETCListParams{
				Limit:  100,
				Offset: 10,
			},
		},
		{
			name: "excessive limit gets capped",
			params: &ETCListParams{
				Limit:  2000,
				Offset: 0,
			},
			expected: &ETCListParams{
				Limit:  1000,
				Offset: 0,
			},
		},
		{
			name: "negative offset gets corrected",
			params: &ETCListParams{
				Limit:  50,
				Offset: -5,
			},
			expected: &ETCListParams{
				Limit:  50,
				Offset: 0,
			},
		},
		{
			name: "valid values preserved",
			params: &ETCListParams{
				Limit:  50,
				Offset: 25,
			},
			expected: &ETCListParams{
				Limit:  50,
				Offset: 25,
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			tt.params.SetDefaults()
			assert.Equal(t, tt.expected.Limit, tt.params.Limit)
			assert.Equal(t, tt.expected.Offset, tt.params.Offset)
		})
	}
}