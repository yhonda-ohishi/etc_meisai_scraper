package models_test

import (
	"strings"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"github.com/yhonda-ohishi/etc_meisai/src/models"
)

// TestETCMeisai_ValidateEdgeCases tests additional edge cases for ETC number length validation
func TestETCMeisai_ValidateEdgeCases(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		setup   func() *models.ETCMeisai
		wantErr bool
		errMsg  string
	}{
		{
			name: "ETC number exactly 20 characters (boundary test)",
			setup: func() *models.ETCMeisai {
				return &models.ETCMeisai{
					UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
					UseTime:   "10:30",
					EntryIC:   "東京IC",
					ExitIC:    "横浜IC",
					Amount:    1000,
					CarNumber: "品川300あ1234",
					ETCNumber: strings.Repeat("1", 20), // Exactly 20 characters
				}
			},
			wantErr: false,
		},
		{
			name: "ETC number 21 characters (too long)",
			setup: func() *models.ETCMeisai {
				return &models.ETCMeisai{
					UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
					UseTime:   "10:30",
					EntryIC:   "東京IC",
					ExitIC:    "横浜IC",
					Amount:    1000,
					CarNumber: "品川300あ1234",
					ETCNumber: strings.Repeat("1", 21), // 21 characters - too long
				}
			},
			wantErr: true,
			errMsg:  "ETCNumber too long",
		},
		{
			name: "ETC number significantly too long",
			setup: func() *models.ETCMeisai {
				return &models.ETCMeisai{
					UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
					UseTime:   "10:30",
					EntryIC:   "東京IC",
					ExitIC:    "横浜IC",
					Amount:    1000,
					CarNumber: "品川300あ1234",
					ETCNumber: strings.Repeat("1234567890", 10), // 100 characters - way too long
				}
			},
			wantErr: true,
			errMsg:  "ETCNumber too long",
		},
		{
			name: "single character ETC number (minimum valid)",
			setup: func() *models.ETCMeisai {
				return &models.ETCMeisai{
					UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
					UseTime:   "10:30",
					EntryIC:   "東京IC",
					ExitIC:    "横浜IC",
					Amount:    1000,
					CarNumber: "品川300あ1234",
					ETCNumber: "1", // Single character
				}
			},
			wantErr: false,
		},
	}

	for _, tt := range tests {
		tt := tt
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			etc := tt.setup()
			err := etc.Validate()

			if tt.wantErr {
				require.Error(t, err)
				if tt.errMsg != "" {
					assert.Contains(t, err.Error(), tt.errMsg)
				}
			} else {
				require.NoError(t, err)
			}
		})
	}
}

// TestETCMeisai_BeforeCreatePreservesTimestamps tests that existing timestamps are preserved
func TestETCMeisai_BeforeCreatePreservesTimestamps(t *testing.T) {
	t.Parallel()

	t.Run("preserves existing timestamps", func(t *testing.T) {
		fixedTime := time.Date(2023, 12, 31, 23, 59, 59, 0, time.UTC)
		etc := &models.ETCMeisai{
			UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
			UseTime:   "10:30",
			EntryIC:   "東京IC",
			ExitIC:    "横浜IC",
			Amount:    1000,
			CarNumber: "品川300あ1234",
			ETCNumber: "1234-5678-9012-3456",
			CreatedAt: fixedTime,
			UpdatedAt: fixedTime,
		}

		err := etc.BeforeCreate()
		require.NoError(t, err)
		assert.Equal(t, fixedTime, etc.CreatedAt)
		assert.Equal(t, fixedTime, etc.UpdatedAt)
	})
}

// TestETCMeisai_BeforeUpdateRegeneratesHash tests that BeforeUpdate always regenerates hash
func TestETCMeisai_BeforeUpdateRegeneratesHash(t *testing.T) {
	t.Parallel()

	t.Run("regenerates hash on update", func(t *testing.T) {
		etc := &models.ETCMeisai{
			UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
			UseTime:   "10:30",
			EntryIC:   "東京IC",
			ExitIC:    "横浜IC",
			Amount:    1000,
			CarNumber: "品川300あ1234",
			ETCNumber: "1234-5678-9012-3456",
			Hash:      "old-hash-value",
		}
		originalHash := etc.Hash

		err := etc.BeforeUpdate()
		require.NoError(t, err)
		assert.NotEqual(t, originalHash, etc.Hash)
		assert.NotEmpty(t, etc.Hash)
	})
}

// TestETCListParams_SetDefaultsEdgeCases tests edge cases for SetDefaults
func TestETCListParams_SetDefaultsEdgeCases(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name     string
		params   *models.ETCListParams
		expected *models.ETCListParams
	}{
		{
			name: "exactly 1000 limit preserved",
			params: &models.ETCListParams{
				Limit:  1000,
				Offset: 0,
			},
			expected: &models.ETCListParams{
				Limit:  1000,
				Offset: 0,
			},
		},
		{
			name: "exactly 1001 limit gets capped",
			params: &models.ETCListParams{
				Limit:  1001,
				Offset: 0,
			},
			expected: &models.ETCListParams{
				Limit:  1000,
				Offset: 0,
			},
		},
		{
			name: "limit 1 is preserved",
			params: &models.ETCListParams{
				Limit:  1,
				Offset: 50,
			},
			expected: &models.ETCListParams{
				Limit:  1,
				Offset: 50,
			},
		},
		{
			name: "zero offset is preserved",
			params: &models.ETCListParams{
				Limit:  50,
				Offset: 0,
			},
			expected: &models.ETCListParams{
				Limit:  50,
				Offset: 0,
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			tt.params.SetDefaults()
			assert.Equal(t, tt.expected.Limit, tt.params.Limit)
			assert.Equal(t, tt.expected.Offset, tt.params.Offset)
		})
	}
}

// TestETCMeisai_GenerateHashFieldVariations tests hash generation with field variations
func TestETCMeisai_GenerateHashFieldVariations(t *testing.T) {
	t.Parallel()

	baseRecord := &models.ETCMeisai{
		UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
		UseTime:   "10:30",
		EntryIC:   "東京IC",
		ExitIC:    "横浜IC",
		Amount:    1000,
		CarNumber: "品川300あ1234",
		ETCNumber: "1234-5678-9012-3456",
	}

	baseHash := baseRecord.GenerateHash()

	tests := []struct {
		name   string
		modify func(*models.ETCMeisai)
	}{
		{
			name: "different date produces different hash",
			modify: func(e *models.ETCMeisai) {
				e.UseDate = time.Date(2024, 1, 2, 0, 0, 0, 0, time.UTC)
			},
		},
		{
			name: "different time produces different hash",
			modify: func(e *models.ETCMeisai) {
				e.UseTime = "11:30"
			},
		},
		{
			name: "different amount produces different hash",
			modify: func(e *models.ETCMeisai) {
				e.Amount = 2000
			},
		},
		{
			name: "different ETC number produces different hash",
			modify: func(e *models.ETCMeisai) {
				e.ETCNumber = "9876-5432-1098-7654"
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			// Create a copy of the base record
			modifiedRecord := *baseRecord
			tt.modify(&modifiedRecord)

			modifiedHash := modifiedRecord.GenerateHash()
			assert.NotEqual(t, baseHash, modifiedHash)
			assert.NotEmpty(t, modifiedHash)
			assert.Len(t, modifiedHash, 64) // SHA256 produces 64 hex characters
		})
	}
}