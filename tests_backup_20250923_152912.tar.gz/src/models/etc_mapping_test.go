package models

import (
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
)

func TestETCMeisaiMapping_Validate(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		mapping *ETCMeisaiMapping
		wantErr bool
		errMsg  string
	}{
		{
			name: "valid mapping",
			mapping: &ETCMeisaiMapping{
				ID:          1,
				ETCMeisaiID: 100,
				DTakoRowID:  "DTAKO001",
				MappingType: "auto",
				Confidence:  0.95,
				CreatedAt:   time.Now(),
				UpdatedAt:   time.Now(),
			},
			wantErr: false,
		},
		{
			name: "missing ETCMeisaiID",
			mapping: &ETCMeisaiMapping{
				ID:          1,
				ETCMeisaiID: 0,
				DTakoRowID:  "DTAKO001",
				MappingType: "auto",
				Confidence:  0.95,
			},
			wantErr: true,
			errMsg:  "ETCMeisaiID must be positive",
		},
		{
			name: "missing DTakoRowID",
			mapping: &ETCMeisaiMapping{
				ID:          1,
				ETCMeisaiID: 100,
				DTakoRowID:  "",
				MappingType: "auto",
				Confidence:  0.95,
			},
			wantErr: true,
			errMsg:  "DTakoRowID is required",
		},
		{
			name: "invalid mapping type",
			mapping: &ETCMeisaiMapping{
				ID:          1,
				ETCMeisaiID: 100,
				DTakoRowID:  "DTAKO001",
				MappingType: "invalid",
				Confidence:  0.95,
			},
			wantErr: true,
			errMsg:  "MappingType must be 'auto' or 'manual'",
		},
		{
			name: "negative confidence",
			mapping: &ETCMeisaiMapping{
				ID:          1,
				ETCMeisaiID: 100,
				DTakoRowID:  "DTAKO001",
				MappingType: "auto",
				Confidence:  -0.1,
			},
			wantErr: true,
			errMsg:  "Confidence must be between 0 and 1",
		},
		{
			name: "confidence over 1",
			mapping: &ETCMeisaiMapping{
				ID:          1,
				ETCMeisaiID: 100,
				DTakoRowID:  "DTAKO001",
				MappingType: "auto",
				Confidence:  1.1,
			},
			wantErr: true,
			errMsg:  "Confidence must be between 0 and 1",
		},
		{
			name: "manual mapping type",
			mapping: &ETCMeisaiMapping{
				ID:          1,
				ETCMeisaiID: 100,
				DTakoRowID:  "DTAKO001",
				MappingType: "manual",
				Confidence:  1.0,
				CreatedBy:   "user123",
			},
			wantErr: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			err := tt.mapping.Validate()

			if tt.wantErr {
				assert.Error(t, err)
				if tt.errMsg != "" {
					assert.Contains(t, err.Error(), tt.errMsg)
				}
			} else {
				assert.NoError(t, err)
			}
		})
	}
}

func TestETCMeisaiMapping_BeforeCreate(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		mapping *ETCMeisaiMapping
		wantErr bool
	}{
		{
			name: "valid mapping passes before create",
			mapping: &ETCMeisaiMapping{
				ETCMeisaiID: 100,
				DTakoRowID:  "DTAKO001",
				MappingType: "auto",
				Confidence:  0.95,
			},
			wantErr: false,
		},
		{
			name: "invalid mapping fails before create",
			mapping: &ETCMeisaiMapping{
				ETCMeisaiID: 0, // Invalid
				DTakoRowID:  "DTAKO001",
				MappingType: "auto",
				Confidence:  0.95,
			},
			wantErr: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			err := tt.mapping.BeforeCreate()

			if tt.wantErr {
				assert.Error(t, err)
			} else {
				assert.NoError(t, err)
			}
		})
	}
}

func TestETCMeisaiMapping_BeforeUpdate(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		mapping *ETCMeisaiMapping
		wantErr bool
	}{
		{
			name: "valid mapping passes before update",
			mapping: &ETCMeisaiMapping{
				ID:          1,
				ETCMeisaiID: 100,
				DTakoRowID:  "DTAKO001",
				MappingType: "manual",
				Confidence:  0.99,
				UpdatedAt:   time.Now(),
			},
			wantErr: false,
		},
		{
			name: "invalid mapping fails before update",
			mapping: &ETCMeisaiMapping{
				ID:          1,
				ETCMeisaiID: 100,
				DTakoRowID:  "", // Invalid
				MappingType: "auto",
				Confidence:  0.95,
			},
			wantErr: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			err := tt.mapping.BeforeUpdate()

			if tt.wantErr {
				assert.Error(t, err)
			} else {
				assert.NoError(t, err)
			}
		})
	}
}

func TestETCMeisaiMapping_ConfidenceTypes(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name        string
		confidence  float32
		description string
	}{
		{
			name:        "perfect match",
			confidence:  1.0,
			description: "Perfect confidence match",
		},
		{
			name:        "high confidence",
			confidence:  0.95,
			description: "High confidence automatic match",
		},
		{
			name:        "medium confidence",
			confidence:  0.75,
			description: "Medium confidence match requiring review",
		},
		{
			name:        "low confidence",
			confidence:  0.50,
			description: "Low confidence match requiring manual verification",
		},
		{
			name:        "minimum confidence",
			confidence:  0.0,
			description: "No confidence - manual mapping required",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			mapping := &ETCMeisaiMapping{
				ETCMeisaiID: 100,
				DTakoRowID:  "DTAKO001",
				MappingType: "auto",
				Confidence:  tt.confidence,
				Notes:       tt.description,
			}

			err := mapping.Validate()
			assert.NoError(t, err)
			assert.Equal(t, tt.confidence, mapping.Confidence)
		})
	}
}

func TestETCMeisaiMapping_MappingTypes(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name        string
		mappingType string
		valid       bool
	}{
		{
			name:        "auto mapping",
			mappingType: "auto",
			valid:       true,
		},
		{
			name:        "manual mapping",
			mappingType: "manual",
			valid:       true,
		},
		{
			name:        "invalid mapping type",
			mappingType: "unknown",
			valid:       false,
		},
		{
			name:        "empty mapping type",
			mappingType: "",
			valid:       false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			mapping := &ETCMeisaiMapping{
				ETCMeisaiID: 100,
				DTakoRowID:  "DTAKO001",
				MappingType: tt.mappingType,
				Confidence:  0.95,
			}

			err := mapping.Validate()
			if tt.valid {
				assert.NoError(t, err)
			} else {
				assert.Error(t, err)
			}
		})
	}
}

// Tests for ETCMapping model (different from ETCMeisaiMapping above)

func TestETCMapping_TableName(t *testing.T) {
	t.Parallel()
	mapping := &ETCMapping{}
	tableName := mapping.TableName()
	assert.Equal(t, "etc_mappings", tableName)
}

func TestETCMapping_BeforeCreate(t *testing.T) {
	t.Parallel()

	mapping := &ETCMapping{
		ETCRecordID:      100,
		MappingType:      "dtako",
		MappedEntityID:   200,
		MappedEntityType: "dtako_record",
		Confidence:       0.95,
	}

	err := mapping.BeforeCreate(nil)
	assert.NoError(t, err)
	assert.False(t, mapping.CreatedAt.IsZero())
}

func TestETCMapping_BeforeSave(t *testing.T) {
	t.Parallel()

	mapping := &ETCMapping{
		ETCRecordID:      100,
		MappingType:      "dtako",
		MappedEntityID:   200,
		MappedEntityType: "dtako_record",
		Confidence:       0.95,
		CreatedAt:        time.Now(),
	}

	err := mapping.BeforeSave(nil)
	assert.NoError(t, err)
	assert.False(t, mapping.UpdatedAt.IsZero())
}

func TestETCMapping_Validate(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		mapping *ETCMapping
		wantErr bool
	}{
		{
			name: "valid mapping",
			mapping: &ETCMapping{
				ETCRecordID:      100,
				MappingType:      "dtako",
				MappedEntityID:   200,
				MappedEntityType: "dtako_record",
				Confidence:       0.95,
				Status:           "active",
			},
			wantErr: false,
		},
		{
			name: "invalid mapping type",
			mapping: &ETCMapping{
				ETCRecordID:      100,
				MappingType:      "invalid",
				MappedEntityID:   200,
				MappedEntityType: "dtako_record",
				Confidence:       0.95,
				Status:           "active",
			},
			wantErr: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			err := tt.mapping.validate()
			if tt.wantErr {
				assert.Error(t, err)
			} else {
				assert.NoError(t, err)
			}
		})
	}
}

func TestETCMapping_StatusMethods(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name     string
		status   string
		isActive bool
		isPending bool
	}{
		{
			name:     "active status",
			status:   "active",
			isActive: true,
			isPending: false,
		},
		{
			name:     "pending status",
			status:   "pending",
			isActive: false,
			isPending: true,
		},
		{
			name:     "inactive status",
			status:   "inactive",
			isActive: false,
			isPending: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			mapping := &ETCMapping{Status: tt.status}
			assert.Equal(t, tt.isActive, mapping.IsActive())
			assert.Equal(t, tt.isPending, mapping.IsPending())
		})
	}
}

func TestETCMapping_CanTransitionTo(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name        string
		fromStatus  string
		toStatus    string
		canTransition bool
	}{
		{
			name:        "pending to active",
			fromStatus:  "pending",
			toStatus:    "active",
			canTransition: true,
		},
		{
			name:        "active to inactive",
			fromStatus:  "active",
			toStatus:    "inactive",
			canTransition: true,
		},
		{
			name:        "inactive to active",
			fromStatus:  "inactive",
			toStatus:    "active",
			canTransition: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			mapping := &ETCMapping{Status: tt.fromStatus}
			result := mapping.CanTransitionTo(tt.toStatus)
			assert.Equal(t, tt.canTransition, result)
		})
	}
}

func TestETCMapping_StatusTransitions(t *testing.T) {
	t.Parallel()

	mapping := &ETCMapping{
		ETCRecordID:      100,
		MappingType:      "dtako",
		MappedEntityID:   200,
		MappedEntityType: "dtako_record",
		Status:           "pending",
	}

	// Test Activate
	err := mapping.Activate()
	assert.NoError(t, err)
	assert.Equal(t, "active", mapping.Status)

	// Test Deactivate
	err = mapping.Deactivate()
	assert.NoError(t, err)
	assert.Equal(t, "inactive", mapping.Status)

	// Test Approve (back to pending first)
	mapping.Status = "pending"
	err = mapping.Approve()
	assert.NoError(t, err)
	assert.Equal(t, "active", mapping.Status)

	// Test Reject (back to pending first)
	mapping.Status = "pending"
	err = mapping.Reject()
	assert.NoError(t, err)
	assert.Equal(t, "rejected", mapping.Status)
}

func TestETCMapping_Metadata(t *testing.T) {
	t.Parallel()

	mapping := &ETCMapping{}

	// Test SetMetadata
	metadata := map[string]interface{}{
		"source": "auto_match",
		"confidence_threshold": 0.8,
	}
	err := mapping.SetMetadata(metadata)
	assert.NoError(t, err)

	// Test GetMetadata
	retrieved, err := mapping.GetMetadata()
	assert.NoError(t, err)
	assert.Equal(t, "auto_match", retrieved["source"])
	assert.Equal(t, 0.8, retrieved["confidence_threshold"])
}

func TestETCMapping_ConfidenceMethods(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name           string
		confidence     float32
		percentage     float64
		isHighConf     bool
		isLowConf      bool
	}{
		{
			name:       "high confidence",
			confidence: 0.95,
			percentage: 95.0,
			isHighConf: true,
			isLowConf:  false,
		},
		{
			name:       "medium confidence",
			confidence: 0.65,
			percentage: 65.0,
			isHighConf: false,
			isLowConf:  false,
		},
		{
			name:       "low confidence",
			confidence: 0.45,
			percentage: 45.0,
			isHighConf: false,
			isLowConf:  true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			mapping := &ETCMapping{Confidence: tt.confidence}
			assert.Equal(t, tt.percentage, mapping.GetConfidencePercentage())
			assert.Equal(t, tt.isHighConf, mapping.IsHighConfidence())
			assert.Equal(t, tt.isLowConf, mapping.IsLowConfidence())
		})
	}
}