package models

import (
	"encoding/json"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// TestBulkOperations_StructSerialization tests serialization of bulk operation models
func TestBulkOperations_StructSerialization(t *testing.T) {
	t.Parallel()

	t.Run("BulkMappingResult serialization", func(t *testing.T) {
		result := &BulkMappingResult{
			Success:      true,
			TotalCount:   100,
			SuccessCount: 95,
			FailureCount: 5,
			Errors: []BulkOperationError{
				{
					Index:   1,
					ID:      123,
					Message: "validation failed",
					Code:    "VALIDATION_ERROR",
				},
			},
			Duration:    5 * time.Minute,
			ProcessedAt: time.Date(2024, 1, 1, 12, 0, 0, 0, time.UTC),
		}

		// Test JSON serialization
		jsonData, err := json.Marshal(result)
		require.NoError(t, err)
		assert.Contains(t, string(jsonData), "success")
		assert.Contains(t, string(jsonData), "total_count")

		// Test JSON deserialization
		var deserialized BulkMappingResult
		err = json.Unmarshal(jsonData, &deserialized)
		require.NoError(t, err)
		assert.Equal(t, result.Success, deserialized.Success)
		assert.Equal(t, result.TotalCount, deserialized.TotalCount)
		assert.Len(t, deserialized.Errors, 1)
	})

	t.Run("ImportValidationResult with warnings", func(t *testing.T) {
		result := &ImportValidationResult{
			Valid:       false,
			TotalRows:   100,
			ValidRows:   85,
			InvalidRows: 15,
			Errors: []ImportValidationError{
				{
					Row:     10,
					Column:  "amount",
					Message: "invalid amount format",
					Value:   "abc",
				},
			},
			Warnings: []ImportValidationWarning{
				{
					Row:     20,
					Column:  "etc_number",
					Message: "unusual ETC number format",
					Value:   "1234",
				},
			},
			Duration: 2 * time.Second,
		}

		// Test struct field access
		assert.False(t, result.Valid)
		assert.Equal(t, 100, result.TotalRows)
		assert.Len(t, result.Errors, 1)
		assert.Len(t, result.Warnings, 1)
		assert.Equal(t, "amount", result.Errors[0].Column)
		assert.Equal(t, "etc_number", result.Warnings[0].Column)
	})

	t.Run("ImportPreviewResult with detected fields", func(t *testing.T) {
		preview := &ImportPreviewResult{
			Headers:     []string{"date", "time", "entry", "exit", "amount"},
			SampleRows:  [][]string{{"2024-01-01", "10:30", "Tokyo", "Yokohama", "1000"}},
			TotalRows:   1000,
			PreviewRows: 5,
			DetectedType: "etc_meisai",
			Encoding:     "UTF-8",
			Delimiter:    ",",
			ValidFields: []string{"date", "time", "entry", "exit", "amount"},
			InvalidFields: []string{},
			Warnings:    []string{"some unicode characters detected"},
		}

		assert.Len(t, preview.Headers, 5)
		assert.Equal(t, "etc_meisai", preview.DetectedType)
		assert.Equal(t, "UTF-8", preview.Encoding)
		assert.Len(t, preview.ValidFields, 5)
		assert.Empty(t, preview.InvalidFields)
		assert.Len(t, preview.Warnings, 1)
	})
}

// TestDownloadModels_StructSerialization tests download model serialization
func TestDownloadModels_StructSerialization(t *testing.T) {
	t.Parallel()

	t.Run("DownloadParams validation", func(t *testing.T) {
		params := &DownloadParams{
			AccountType: "corporate",
			AccountID:   "ACC001",
			StartDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
			EndDate:     time.Date(2024, 1, 31, 23, 59, 59, 0, time.UTC),
			SessionID:   "session-123",
		}

		// Test field access
		assert.Equal(t, "corporate", params.AccountType)
		assert.Equal(t, "ACC001", params.AccountID)
		assert.False(t, params.StartDate.IsZero())
		assert.False(t, params.EndDate.IsZero())
		assert.True(t, params.EndDate.After(params.StartDate))

		// Test JSON serialization
		jsonData, err := json.Marshal(params)
		require.NoError(t, err)
		assert.Contains(t, string(jsonData), "account_type")
		assert.Contains(t, string(jsonData), "start_date")
	})

	t.Run("DownloadResult with errors", func(t *testing.T) {
		result := &DownloadResult{
			Status:     "partial_success",
			TotalFiles: 10,
			Downloaded: 8,
			Failed:     2,
			FilePaths:  []string{"file1.csv", "file2.csv"},
			Errors:     []string{"timeout on file3.csv", "access denied for file4.csv"},
		}

		assert.Equal(t, 10, result.TotalFiles)
		assert.Equal(t, 8, result.Downloaded)
		assert.Equal(t, 2, result.Failed)
		assert.Len(t, result.FilePaths, 2)
		assert.Len(t, result.Errors, 2)
		assert.Contains(t, result.Errors[0], "timeout")
	})

	t.Run("DownloadStatus lifecycle", func(t *testing.T) {
		startTime := time.Now()
		status := &DownloadStatus{
			SessionID:   "session-456",
			Status:      "in_progress",
			Progress:    50,
			TotalFiles:  20,
			Processed:   10,
			StartTime:   startTime,
			EndTime:     time.Time{}, // Not completed yet
		}

		assert.Equal(t, "session-456", status.SessionID)
		assert.Equal(t, 50, status.Progress)
		assert.True(t, status.EndTime.IsZero())

		// Simulate completion
		status.Status = "completed"
		status.Progress = 100
		status.Processed = 20
		status.EndTime = startTime.Add(5 * time.Minute)

		assert.Equal(t, "completed", status.Status)
		assert.Equal(t, 100, status.Progress)
		assert.False(t, status.EndTime.IsZero())
	})

	t.Run("ProcessResult summary", func(t *testing.T) {
		result := &ProcessResult{
			TotalRecords: 1000,
			Imported:     950,
			Duplicates:   30,
			Errors:       20,
			ErrorDetails: []string{"invalid date format in row 10", "missing amount in row 25"},
		}

		// Verify totals make sense
		assert.Equal(t, 1000, result.TotalRecords)
		assert.Equal(t, 950+30+20, result.TotalRecords) // imported + duplicates + errors should equal total
		assert.Len(t, result.ErrorDetails, 2)
	})
}

// TestJobStatus_StructSerialization tests job status model
func TestJobStatus_StructSerialization(t *testing.T) {
	t.Parallel()

	t.Run("JobStatus lifecycle", func(t *testing.T) {
		startTime := time.Now()
		job := &JobStatus{
			ID:        "job-789",
			Type:      "import",
			Status:    "running",
			Progress:  25,
			Message:   "processing file 1 of 4",
			StartTime: startTime,
		}

		assert.Equal(t, "job-789", job.ID)
		assert.Equal(t, "import", job.Type)
		assert.Equal(t, 25, job.Progress)
		assert.True(t, job.EndTime.IsZero())
		assert.Empty(t, job.Error)

		// Test JSON serialization
		jsonData, err := json.Marshal(job)
		require.NoError(t, err)
		assert.Contains(t, string(jsonData), "job-789")

		// Simulate job completion
		job.Status = "completed"
		job.Progress = 100
		job.Message = "import completed successfully"
		job.EndTime = startTime.Add(10 * time.Minute)
		job.Result = map[string]interface{}{
			"imported_count": 500,
			"error_count":    0,
		}

		assert.Equal(t, "completed", job.Status)
		assert.Equal(t, 100, job.Progress)
		assert.NotNil(t, job.Result)

		// Test with error state
		errorJob := &JobStatus{
			ID:        "job-error",
			Type:      "import",
			Status:    "failed",
			Progress:  50,
			Error:     "database connection failed",
			StartTime: startTime,
			EndTime:   startTime.Add(2 * time.Minute),
		}

		assert.Equal(t, "failed", errorJob.Status)
		assert.NotEmpty(t, errorJob.Error)
		assert.False(t, errorJob.EndTime.IsZero())
	})
}

// TestMatchCandidate_StructSerialization tests match candidate model
func TestMatchCandidate_StructSerialization(t *testing.T) {
	t.Parallel()

	t.Run("MatchCandidate with details", func(t *testing.T) {
		candidate := &MatchCandidate{
			ID:          1,
			ETCMeisaiID: 100,
			DTakoRowID:  "DTAKO-001",
			Confidence:  0.85,
			MatchReason: "time_and_amount_match",
			MatchDetails: map[string]interface{}{
				"time_diff_seconds": 30,
				"amount_diff":       0,
				"location_match":    true,
			},
			CreatedAt: time.Date(2024, 1, 1, 12, 0, 0, 0, time.UTC),
		}

		assert.Equal(t, int64(1), candidate.ID)
		assert.Equal(t, int64(100), candidate.ETCMeisaiID)
		assert.Equal(t, "DTAKO-001", candidate.DTakoRowID)
		assert.Equal(t, float32(0.85), candidate.Confidence)
		assert.Contains(t, candidate.MatchReason, "match")
		assert.NotNil(t, candidate.MatchDetails)
		assert.Equal(t, true, candidate.MatchDetails["location_match"])

		// Test JSON serialization
		jsonData, err := json.Marshal(candidate)
		require.NoError(t, err)
		assert.Contains(t, string(jsonData), "DTAKO-001")
		assert.Contains(t, string(jsonData), "match_details")
	})
}

// TestServiceStatus_StructSerialization tests service status model
func TestServiceStatus_StructSerialization(t *testing.T) {
	t.Parallel()

	t.Run("ServiceStatus healthy", func(t *testing.T) {
		status := &ServiceStatus{
			Healthy:   true,
			Message:   "all systems operational",
			Timestamp: time.Date(2024, 1, 1, 12, 0, 0, 0, time.UTC),
		}

		assert.True(t, status.Healthy)
		assert.Equal(t, "all systems operational", status.Message)
		assert.False(t, status.Timestamp.IsZero())

		// Test JSON serialization
		jsonData, err := json.Marshal(status)
		require.NoError(t, err)
		assert.Contains(t, string(jsonData), "healthy")
		assert.Contains(t, string(jsonData), "true")
	})

	t.Run("ServiceStatus unhealthy", func(t *testing.T) {
		status := &ServiceStatus{
			Healthy:   false,
			Message:   "database connection failed",
			Timestamp: time.Now(),
		}

		assert.False(t, status.Healthy)
		assert.Contains(t, status.Message, "failed")
		assert.False(t, status.Timestamp.IsZero())
	})
}

// TestErrorResponse_StructSerialization tests error response model
func TestErrorResponse_StructSerialization(t *testing.T) {
	t.Parallel()

	t.Run("ErrorResponse structure", func(t *testing.T) {
		errResp := &ErrorResponse{
			Code:  "VALIDATION_ERROR",
			Error: "invalid input parameters",
		}

		assert.Equal(t, "VALIDATION_ERROR", errResp.Code)
		assert.Equal(t, "invalid input parameters", errResp.Error)

		// Test JSON serialization
		jsonData, err := json.Marshal(errResp)
		require.NoError(t, err)
		assert.Contains(t, string(jsonData), "VALIDATION_ERROR")
		assert.Contains(t, string(jsonData), "invalid input parameters")

		// Test deserialization
		var deserialized ErrorResponse
		err = json.Unmarshal(jsonData, &deserialized)
		require.NoError(t, err)
		assert.Equal(t, errResp.Code, deserialized.Code)
		assert.Equal(t, errResp.Error, deserialized.Error)
	})
}

// TestETCImportRequest_StructSerialization tests import request model
func TestETCImportRequest_StructSerialization(t *testing.T) {
	t.Parallel()

	t.Run("ETCImportRequest validation", func(t *testing.T) {
		request := &ETCImportRequest{
			FromDate: "2024-01-01",
			ToDate:   "2024-01-31",
			Source:   "web_scraping",
			BatchID:  "batch-123",
		}

		assert.Equal(t, "2024-01-01", request.FromDate)
		assert.Equal(t, "2024-01-31", request.ToDate)
		assert.Equal(t, "web_scraping", request.Source)
		assert.Equal(t, "batch-123", request.BatchID)

		// Test JSON serialization
		jsonData, err := json.Marshal(request)
		require.NoError(t, err)
		assert.Contains(t, string(jsonData), "from_date")
		assert.Contains(t, string(jsonData), "to_date")
	})

	t.Run("ETCImportResult success case", func(t *testing.T) {
		result := &ETCImportResult{
			Success:      true,
			RecordCount:  1000,
			RecordsRead:  1000,
			RecordsSaved: 950,
			ImportedRows: 950,
			Duration:     5000, // 5 seconds in milliseconds
			Message:      "import completed successfully",
			ImportedAt:   time.Date(2024, 1, 1, 12, 0, 0, 0, time.UTC),
		}

		assert.True(t, result.Success)
		assert.Equal(t, 1000, result.RecordCount)
		assert.Equal(t, 950, result.RecordsSaved)
		assert.Empty(t, result.ErrorMessage)
		assert.Empty(t, result.Errors)
		assert.False(t, result.ImportedAt.IsZero())
	})

	t.Run("ETCImportResult with errors", func(t *testing.T) {
		result := &ETCImportResult{
			Success:      false,
			RecordCount:  100,
			RecordsRead:  100,
			RecordsSaved: 80,
			ImportedRows: 80,
			Duration:     3000,
			Message:      "import completed with errors",
			ErrorMessage: "validation failed for some records",
			Errors:       []string{"row 10: invalid date", "row 25: missing amount"},
			ImportedAt:   time.Now(),
		}

		assert.False(t, result.Success)
		assert.NotEmpty(t, result.ErrorMessage)
		assert.Len(t, result.Errors, 2)
		assert.Contains(t, result.Errors[0], "invalid date")
	})
}