package models

import (
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
)

func TestETCSummary_Structure(t *testing.T) {
	t.Parallel()

	summary := &ETCSummary{
		TotalAmount: 15000,
		TotalCount:  10,
		StartDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
		EndDate:     time.Date(2024, 1, 31, 0, 0, 0, 0, time.UTC),
		ByETCNumber: make(map[string]*ETCNumberSummary),
		ByMonth:     make(map[string]*ETCMonthlySummary),
	}

	// Test basic structure
	assert.Equal(t, int64(15000), summary.TotalAmount)
	assert.Equal(t, int64(10), summary.TotalCount)
	assert.Equal(t, time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC), summary.StartDate)
	assert.Equal(t, time.Date(2024, 1, 31, 0, 0, 0, 0, time.UTC), summary.EndDate)
	assert.NotNil(t, summary.ByETCNumber)
	assert.NotNil(t, summary.ByMonth)
}

func TestETCSummary_ManualCalculations(t *testing.T) {
	t.Parallel()

	summary := &ETCSummary{
		TotalAmount: 0,
		TotalCount:  0,
		StartDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
		EndDate:     time.Date(2024, 1, 31, 0, 0, 0, 0, time.UTC),
		ByETCNumber: make(map[string]*ETCNumberSummary),
		ByMonth:     make(map[string]*ETCMonthlySummary),
	}

	// Manually add ETC number summary
	summary.ByETCNumber["1234-5678-9012-3456"] = &ETCNumberSummary{
		ETCNumber:   "1234-5678-9012-3456",
		TotalAmount: 5000,
		TotalCount:  5,
	}

	// Manually add monthly summary
	summary.ByMonth["2024-01"] = &ETCMonthlySummary{
		Year:        2024,
		Month:       1,
		TotalAmount: 5000,
		TotalCount:  5,
	}

	// Update totals
	summary.TotalAmount = 5000
	summary.TotalCount = 5

	// Verify data integrity
	assert.Equal(t, int64(5000), summary.TotalAmount)
	assert.Equal(t, int64(5), summary.TotalCount)

	etcSummary := summary.ByETCNumber["1234-5678-9012-3456"]
	assert.Equal(t, "1234-5678-9012-3456", etcSummary.ETCNumber)
	assert.Equal(t, int64(5000), etcSummary.TotalAmount)
	assert.Equal(t, int64(5), etcSummary.TotalCount)

	monthlySummary := summary.ByMonth["2024-01"]
	assert.Equal(t, 2024, monthlySummary.Year)
	assert.Equal(t, 1, monthlySummary.Month)
	assert.Equal(t, int64(5000), monthlySummary.TotalAmount)
	assert.Equal(t, int64(5), monthlySummary.TotalCount)
}

func TestETCNumberSummary_Structure(t *testing.T) {
	t.Parallel()

	summary := &ETCNumberSummary{
		ETCNumber:   "1234-5678-9012-3456",
		TotalAmount: 10000,
		TotalCount:  5,
	}

	assert.Equal(t, "1234-5678-9012-3456", summary.ETCNumber)
	assert.Equal(t, int64(10000), summary.TotalAmount)
	assert.Equal(t, int64(5), summary.TotalCount)
}

func TestETCMonthlySummary_Structure(t *testing.T) {
	t.Parallel()

	summary := &ETCMonthlySummary{
		Year:        2024,
		Month:       1,
		TotalAmount: 15000,
		TotalCount:  10,
	}

	assert.Equal(t, 2024, summary.Year)
	assert.Equal(t, 1, summary.Month)
	assert.Equal(t, int64(15000), summary.TotalAmount)
	assert.Equal(t, int64(10), summary.TotalCount)
}

func TestETCSummary_MultipleETCNumbers(t *testing.T) {
	t.Parallel()

	summary := &ETCSummary{
		TotalAmount: 25000,
		TotalCount:  15,
		StartDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
		EndDate:     time.Date(2024, 12, 31, 0, 0, 0, 0, time.UTC),
		ByETCNumber: map[string]*ETCNumberSummary{
			"1111-1111-1111-1111": {
				ETCNumber:   "1111-1111-1111-1111",
				TotalAmount: 10000,
				TotalCount:  5,
			},
			"2222-2222-2222-2222": {
				ETCNumber:   "2222-2222-2222-2222",
				TotalAmount: 15000,
				TotalCount:  10,
			},
		},
		ByMonth: map[string]*ETCMonthlySummary{
			"2024-01": {
				Year:        2024,
				Month:       1,
				TotalAmount: 12000,
				TotalCount:  8,
			},
			"2024-02": {
				Year:        2024,
				Month:       2,
				TotalAmount: 13000,
				TotalCount:  7,
			},
		},
	}

	// Test aggregated data
	assert.Equal(t, int64(25000), summary.TotalAmount)
	assert.Equal(t, int64(15), summary.TotalCount)

	// Test ETC number breakdown
	assert.Len(t, summary.ByETCNumber, 2)
	assert.Contains(t, summary.ByETCNumber, "1111-1111-1111-1111")
	assert.Contains(t, summary.ByETCNumber, "2222-2222-2222-2222")

	// Test monthly breakdown
	assert.Len(t, summary.ByMonth, 2)
	assert.Contains(t, summary.ByMonth, "2024-01")
	assert.Contains(t, summary.ByMonth, "2024-02")
}