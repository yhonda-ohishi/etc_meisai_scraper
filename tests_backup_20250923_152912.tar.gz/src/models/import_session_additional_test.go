package models

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestImportSession_ValidateEdgeCases(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		setup   func() *ImportSession
		wantErr bool
		errMsg  string
	}{
		{
			name: "invalid UUID format",
			setup: func() *ImportSession {
				return &ImportSession{
					ID:          "invalid-uuid",
					AccountType: "corporate",
					AccountID:   "ACC001",
					FileName:    "test.csv",
					FileSize:    1024,
					Status:      "pending",
				}
			},
			wantErr: true,
			errMsg:  "invalid UUID format",
		},
		{
			name: "very long account ID",
			setup: func() *ImportSession {
				return &ImportSession{
					ID:          "550e8400-e29b-41d4-a716-446655440000",
					AccountType: "corporate",
					AccountID:   string(make([]byte, 51)), // 51 characters
					FileName:    "test.csv",
					FileSize:    1024,
					Status:      "pending",
				}
			},
			wantErr: true,
			errMsg:  "too long",
		},
		{
			name: "empty account ID for corporate",
			setup: func() *ImportSession {
				return &ImportSession{
					ID:          "550e8400-e29b-41d4-a716-446655440000",
					AccountType: "corporate",
					AccountID:   "",
					FileName:    "test.csv",
					FileSize:    1024,
					Status:      "pending",
				}
			},
			wantErr: true,
			errMsg:  "account ID cannot be empty",
		},
		{
			name: "account ID for personal (should be valid)",
			setup: func() *ImportSession {
				return &ImportSession{
					ID:          "550e8400-e29b-41d4-a716-446655440000",
					AccountType: "personal",
					AccountID:   "should-be-valid",
					FileName:    "test.csv",
					FileSize:    1024,
					Status:      "pending",
				}
			},
			wantErr: false,
		},
		{
			name: "file extension not CSV",
			setup: func() *ImportSession {
				return &ImportSession{
					ID:          "550e8400-e29b-41d4-a716-446655440000",
					AccountType: "corporate",
					AccountID:   "ACC001",
					FileName:    "test.txt",
					FileSize:    1024,
					Status:      "pending",
				}
			},
			wantErr: true,
			errMsg:  "must have .csv extension",
		},
		{
			name: "file name too long",
			setup: func() *ImportSession {
				return &ImportSession{
					ID:          "550e8400-e29b-41d4-a716-446655440000",
					AccountType: "corporate",
					AccountID:   "ACC001",
					FileName:    string(make([]byte, 256)) + ".csv", // Too long
					FileSize:    1024,
					Status:      "pending",
				}
			},
			wantErr: true,
			errMsg:  "too long",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			session := tt.setup()
			err := session.validate()
			if tt.wantErr {
				assert.Error(t, err)
				if tt.errMsg != "" {
					assert.Contains(t, err.Error(), tt.errMsg)
				}
			} else {
				assert.NoError(t, err)
			}
		})
	}
}