package models

import (
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
)

func TestImportSession_Validate(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		session *ImportSession
		wantErr bool
		errMsg  string
	}{
		{
			name: "valid import session",
			session: &ImportSession{
				ID:            "550e8400-e29b-41d4-a716-446655440000",
				AccountType:   "corporate",
				AccountID:     "ACC001",
				FileName:      "test.csv",
				FileSize:      1024,
				Status:        "pending",
				TotalRows:     100,
				ProcessedRows: 0,
				SuccessRows:   0,
				ErrorRows:     0,
				DuplicateRows: 0,
				StartedAt:     time.Now(),
				CreatedBy:     "user1",
				CreatedAt:     time.Now(),
			},
			wantErr: false,
		},
		{
			name: "missing account type",
			session: &ImportSession{
				ID:        "550e8400-e29b-41d4-a716-446655440000",
				AccountID: "ACC001",
				FileName:  "test.csv",
				FileSize:  1024,
				Status:    "pending",
			},
			wantErr: true,
			errMsg:  "account type cannot be empty",
		},
		{
			name: "invalid account type",
			session: &ImportSession{
				ID:          "550e8400-e29b-41d4-a716-446655440000",
				AccountType: "invalid",
				AccountID:   "ACC001",
				FileName:    "test.csv",
				FileSize:    1024,
				Status:      "pending",
			},
			wantErr: true,
			errMsg:  "invalid account type",
		},
		{
			name: "missing filename",
			session: &ImportSession{
				ID:          "550e8400-e29b-41d4-a716-446655440000",
				AccountType: "corporate",
				AccountID:   "ACC001",
				FileSize:    1024,
				Status:      "pending",
			},
			wantErr: true,
			errMsg:  "file name cannot be empty",
		},
		{
			name: "negative file size",
			session: &ImportSession{
				ID:          "550e8400-e29b-41d4-a716-446655440000",
				AccountType: "corporate",
				AccountID:   "ACC001",
				FileName:    "test.csv",
				FileSize:    -1,
				Status:      "pending",
			},
			wantErr: true,
			errMsg:  "file size must be greater than 0",
		},
		{
			name: "invalid status",
			session: &ImportSession{
				ID:          "550e8400-e29b-41d4-a716-446655440000",
				AccountType: "corporate",
				AccountID:   "ACC001",
				FileName:    "test.csv",
				FileSize:    1024,
				Status:      "invalid",
			},
			wantErr: true,
			errMsg:  "invalid status",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			err := tt.session.validate()

			if tt.wantErr {
				assert.Error(t, err)
				if tt.errMsg != "" {
					assert.Contains(t, err.Error(), tt.errMsg)
				}
			} else {
				assert.NoError(t, err)
			}
		})
	}
}

func TestImportSession_BeforeCreate(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		session *ImportSession
		wantErr bool
	}{
		{
			name: "valid session generates UUID",
			session: &ImportSession{
				AccountType: "corporate",
				AccountID:   "ACC001",
				FileName:    "test.csv",
				FileSize:    1024,
				Status:      "pending",
			},
			wantErr: false,
		},
		{
			name: "preserves existing ID",
			session: &ImportSession{
				ID:          "550e8400-e29b-41d4-a716-446655440001",
				AccountType: "corporate",
				AccountID:   "ACC001",
				FileName:    "test.csv",
				FileSize:    1024,
				Status:      "pending",
			},
			wantErr: false,
		},
		{
			name: "invalid session fails",
			session: &ImportSession{
				AccountType: "invalid",
				AccountID:   "ACC001",
				FileName:    "test.csv",
				FileSize:    1024,
				Status:      "pending",
			},
			wantErr: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			originalID := tt.session.ID
			err := tt.session.BeforeCreate(nil)

			if tt.wantErr {
				assert.Error(t, err)
			} else {
				assert.NoError(t, err)
				if originalID == "" {
					assert.NotEmpty(t, tt.session.ID)
				} else {
					assert.Equal(t, originalID, tt.session.ID)
				}
				assert.False(t, tt.session.StartedAt.IsZero())
			}
		})
	}
}

func TestImportSession_UpdateProgress(t *testing.T) {
	t.Parallel()

	session := &ImportSession{
		ID:            "550e8400-e29b-41d4-a716-446655440000",
		AccountType:   "corporate",
		AccountID:     "ACC001",
		FileName:      "test.csv",
		FileSize:      1024,
		Status:        "processing",
		TotalRows:     100,
		ProcessedRows: 0,
		SuccessRows:   0,
		ErrorRows:     0,
		DuplicateRows: 0,
	}

	// Test updating progress
	session.UpdateProgress(45, 3, 2)

	assert.Equal(t, 50, session.ProcessedRows)
	assert.Equal(t, 45, session.SuccessRows)
	assert.Equal(t, 3, session.ErrorRows)
	assert.Equal(t, 2, session.DuplicateRows)
}

func TestImportSession_CalculateProgress(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name            string
		session         *ImportSession
		expectedPercent float64
	}{
		{
			name: "no progress",
			session: &ImportSession{
				TotalRows:     100,
				ProcessedRows: 0,
			},
			expectedPercent: 0.0,
		},
		{
			name: "half complete",
			session: &ImportSession{
				TotalRows:     100,
				ProcessedRows: 50,
			},
			expectedPercent: 50.0,
		},
		{
			name: "complete",
			session: &ImportSession{
				TotalRows:     100,
				ProcessedRows: 100,
			},
			expectedPercent: 100.0,
		},
		{
			name: "zero total rows",
			session: &ImportSession{
				TotalRows:     0,
				ProcessedRows: 0,
			},
			expectedPercent: 0.0,
		},
		{
			name: "over-processed (edge case)",
			session: &ImportSession{
				TotalRows:     100,
				ProcessedRows: 150,
			},
			expectedPercent: 150.0, // No capping in actual implementation
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			percent := tt.session.GetProgressPercentage()
			assert.Equal(t, tt.expectedPercent, percent)
		})
	}
}

func TestImportSession_IsCompleted(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name      string
		status    string
		completed bool
	}{
		{
			name:      "completed status",
			status:    "completed",
			completed: true,
		},
		{
			name:      "failed status",
			status:    "failed",
			completed: false,
		},
		{
			name:      "cancelled status",
			status:    "cancelled",
			completed: false,
		},
		{
			name:      "pending status",
			status:    "pending",
			completed: false,
		},
		{
			name:      "processing status",
			status:    "processing",
			completed: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			session := &ImportSession{Status: tt.status}
			result := session.IsCompleted()
			assert.Equal(t, tt.completed, result)
		})
	}
}

func TestImportSession_Complete(t *testing.T) {
	t.Parallel()

	session := &ImportSession{
		ID:            "550e8400-e29b-41d4-a716-446655440000",
		AccountType:   "corporate",
		AccountID:     "ACC001",
		FileName:      "test.csv",
		Status:        "processing",
		TotalRows:     100,
		ProcessedRows: 100,
		SuccessRows:   95,
		ErrorRows:     5,
	}

	// Test completion
	session.Complete()

	assert.Equal(t, "completed", session.Status)
	assert.NotNil(t, session.CompletedAt)
	assert.WithinDuration(t, time.Now(), *session.CompletedAt, time.Second)
}

func TestImportSession_Fail(t *testing.T) {
	t.Parallel()

	session := &ImportSession{
		ID:          "550e8400-e29b-41d4-a716-446655440000",
		AccountType: "corporate",
		AccountID:   "ACC001",
		FileName:    "test.csv",
		Status:      "processing",
	}

	session.Fail()

	assert.Equal(t, "failed", session.Status)
	assert.NotNil(t, session.CompletedAt)
}

func TestImportSession_Cancel(t *testing.T) {
	t.Parallel()

	session := &ImportSession{
		ID:          "550e8400-e29b-41d4-a716-446655440000",
		AccountType: "corporate",
		AccountID:   "ACC001",
		FileName:    "test.csv",
		Status:      "processing",
	}

	session.Cancel()

	assert.Equal(t, "cancelled", session.Status)
	assert.NotNil(t, session.CompletedAt)
}

func TestImportSession_AddError(t *testing.T) {
	t.Parallel()

	session := &ImportSession{
		ID:          "550e8400-e29b-41d4-a716-446655440000",
		AccountType: "corporate",
		AccountID:   "ACC001",
		FileName:    "test.csv",
		Status:      "processing",
	}

	// Add errors
	session.AddError(5, "validation", "Invalid amount", "invalid,data,row")
	session.AddError(10, "format", "Invalid date format", "bad,date,format")

	// Check that errors are stored in ErrorLog
	assert.NotEmpty(t, session.ErrorLog)
}

func TestImportSession_GetErrors(t *testing.T) {
	t.Parallel()

	session := &ImportSession{
		ID:          "550e8400-e29b-41d4-a716-446655440000",
		AccountType: "corporate",
		AccountID:   "ACC001",
		FileName:    "test.csv",
		Status:      "processing",
	}

	// Add some errors
	session.AddError(5, "validation", "Invalid amount", "invalid,data,row")

	// Get errors
	errors, err := session.GetErrors()
	assert.NoError(t, err)
	assert.Len(t, errors, 1)
	assert.Equal(t, 5, errors[0].RowNumber)
	assert.Equal(t, "validation", errors[0].ErrorType)
	assert.Equal(t, "Invalid amount", errors[0].ErrorMessage)
}

func TestImportSession_TableName(t *testing.T) {
	t.Parallel()
	session := &ImportSession{}
	tableName := session.TableName()
	assert.Equal(t, "import_sessions", tableName)
}

func TestImportSession_BeforeSave(t *testing.T) {
	t.Parallel()

	session := &ImportSession{
		ID:            "550e8400-e29b-41d4-a716-446655440000",
		AccountType:   "corporate",
		AccountID:     "ACC001",
		FileName:      "test.csv",
		FileSize:      1024,
		Status:        "processing",
		CreatedAt:     time.Now(),
	}

	err := session.BeforeSave(nil)
	assert.NoError(t, err)
	// BeforeSave doesn't modify any fields in ImportSession
}

func TestImportSession_StatusMethods(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name         string
		status       string
		isFailed     bool
		isInProgress bool
		isPending    bool
	}{
		{
			name:         "pending status",
			status:       "pending",
			isFailed:     false,
			isInProgress: false,
			isPending:    true,
		},
		{
			name:         "processing status",
			status:       "processing",
			isFailed:     false,
			isInProgress: true,
			isPending:    false,
		},
		{
			name:         "failed status",
			status:       "failed",
			isFailed:     true,
			isInProgress: false,
			isPending:    false,
		},
		{
			name:         "completed status",
			status:       "completed",
			isFailed:     false,
			isInProgress: false,
			isPending:    false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			session := &ImportSession{Status: tt.status}
			assert.Equal(t, tt.isFailed, session.IsFailed())
			assert.Equal(t, tt.isInProgress, session.IsInProgress())
			assert.Equal(t, tt.isPending, session.IsPending())
		})
	}
}

func TestImportSession_StartProcessing(t *testing.T) {
	t.Parallel()

	session := &ImportSession{
		ID:          "550e8400-e29b-41d4-a716-446655440000",
		AccountType: "corporate",
		AccountID:   "ACC001",
		FileName:    "test.csv",
		FileSize:    1024,
		Status:      "pending",
	}

	err := session.StartProcessing()
	assert.NoError(t, err)
	assert.Equal(t, "processing", session.Status)
	assert.False(t, session.StartedAt.IsZero())
}

func TestImportSession_GetSuccessRate(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name         string
		session      *ImportSession
		expectedRate float64
	}{
		{
			name: "100% success rate",
			session: &ImportSession{
				ProcessedRows: 100,
				SuccessRows:   100,
				ErrorRows:     0,
			},
			expectedRate: 100.0,
		},
		{
			name: "80% success rate",
			session: &ImportSession{
				ProcessedRows: 100,
				SuccessRows:   80,
				ErrorRows:     20,
			},
			expectedRate: 80.0,
		},
		{
			name: "no processed rows",
			session: &ImportSession{
				ProcessedRows: 0,
				SuccessRows:   0,
				ErrorRows:     0,
			},
			expectedRate: 0.0,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			rate := tt.session.GetSuccessRate()
			assert.Equal(t, tt.expectedRate, rate)
		})
	}
}

func TestImportSession_GetDuration(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name            string
		session         *ImportSession
		expectZero      bool
		expectPositive  bool
	}{
		{
			name: "completed session with duration",
			session: &ImportSession{
				StartedAt:   time.Now().Add(-1 * time.Hour),
				CompletedAt: timePtr(time.Now()),
				Status:      "completed",
			},
			expectZero:      false,
			expectPositive:  true,
		},
		{
			name: "in progress session",
			session: &ImportSession{
				StartedAt:   time.Now().Add(-30 * time.Minute),
				CompletedAt: nil,
				Status:      "processing",
			},
			expectZero:      false,
			expectPositive:  true,
		},
		{
			name: "pending session (not started)",
			session: &ImportSession{
				StartedAt:   time.Time{},
				CompletedAt: nil,
				Status:      "pending",
			},
			expectZero:      true,
			expectPositive:  false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			duration := tt.session.GetDuration()
			if tt.expectZero {
				assert.Equal(t, time.Duration(0), duration)
			} else if tt.expectPositive {
				assert.True(t, duration > 0)
			}
		})
	}
}

// Helper function to create time pointer
func timePtr(t time.Time) *time.Time {
	return &t
}