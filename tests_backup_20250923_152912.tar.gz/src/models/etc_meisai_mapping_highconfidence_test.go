package models

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestETCMeisaiMapping_IsHighConfidence(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name       string
		confidence float32
		expected   bool
	}{
		{
			name:       "high confidence (0.9)",
			confidence: 0.9,
			expected:   true,
		},
		{
			name:       "exact threshold (0.8)",
			confidence: 0.8,
			expected:   true,
		},
		{
			name:       "medium confidence (0.7)",
			confidence: 0.7,
			expected:   false,
		},
		{
			name:       "low confidence (0.5)",
			confidence: 0.5,
			expected:   false,
		},
		{
			name:       "very low confidence (0.1)",
			confidence: 0.1,
			expected:   false,
		},
		{
			name:       "perfect confidence (1.0)",
			confidence: 1.0,
			expected:   true,
		},
		{
			name:       "zero confidence",
			confidence: 0.0,
			expected:   false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			mapping := &ETCMeisaiMapping{
				Confidence: tt.confidence,
			}
			result := mapping.IsHighConfidence()
			assert.Equal(t, tt.expected, result)
		})
	}
}