package models

import (
	"strings"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// TestComprehensiveValidation_StructTags tests all GORM, JSON, and validation tags
func TestComprehensiveValidation_StructTags(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name   string
		test   func(t *testing.T)
	}{
		{
			name: "ETCMeisai struct tags",
			test: func(t *testing.T) {
				// Test JSON serialization
				etcMeisai := &ETCMeisai{
					ID:        1,
					UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
					UseTime:   "10:30",
					EntryIC:   "東京IC",
					ExitIC:    "横浜IC",
					Amount:    1000,
					CarNumber: "品川300あ1234",
					ETCNumber: "1234-5678-9012-3456",
					Hash:      "test-hash",
					CreatedAt: time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
					UpdatedAt: time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
				}

				// Verify struct has correct fields and tags
				assert.NotNil(t, etcMeisai)
				assert.Equal(t, int64(1), etcMeisai.ID)
			},
		},
		{
			name: "ImportSession struct tags",
			test: func(t *testing.T) {
				session := &ImportSession{
					ID:            "550e8400-e29b-41d4-a716-446655440000",
					AccountType:   "corporate",
					AccountID:     "ACC001",
					FileName:      "test.csv",
					FileSize:      1024,
					Status:        "pending",
					TotalRows:     100,
					ProcessedRows: 0,
					SuccessRows:   0,
					ErrorRows:     0,
					DuplicateRows: 0,
					StartedAt:     time.Now(),
					CreatedBy:     "user1",
					CreatedAt:     time.Now(),
				}

				assert.NotNil(t, session)
				assert.Equal(t, "550e8400-e29b-41d4-a716-446655440000", session.ID)
			},
		},
		{
			name: "ETCMapping struct tags",
			test: func(t *testing.T) {
				mapping := &ETCMapping{
					ID:               1,
					ETCRecordID:      100,
					MappingType:      "dtako",
					MappedEntityID:   200,
					MappedEntityType: "dtako_record",
					Confidence:       0.95,
					Status:           "active",
					CreatedBy:        "user1",
					CreatedAt:        time.Now(),
					UpdatedAt:        time.Now(),
				}

				assert.NotNil(t, mapping)
				assert.Equal(t, int64(1), mapping.ID)
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			tt.test(t)
		})
	}
}

// TestValidationEdgeCases tests edge cases for validation methods
func TestValidationEdgeCases(t *testing.T) {
	t.Parallel()

	t.Run("ETCMeisai validation edge cases", func(t *testing.T) {
		tests := []struct {
			name    string
			setup   func() *ETCMeisai
			wantErr bool
			errMsg  string
		}{
			{
				name: "future date validation",
				setup: func() *ETCMeisai {
					future := time.Now().Add(24 * time.Hour)
					return &ETCMeisai{
						UseDate:   future,
						UseTime:   "10:30",
						EntryIC:   "東京IC",
						ExitIC:    "横浜IC",
						Amount:    1000,
						CarNumber: "品川300あ1234",
						ETCNumber: "1234-5678-9012-3456",
					}
				},
				wantErr: false, // Our current validation doesn't check for future dates
			},
			{
				name: "very long ETC number",
				setup: func() *ETCMeisai {
					return &ETCMeisai{
						UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
						UseTime:   "10:30",
						EntryIC:   "東京IC",
						ExitIC:    "横浜IC",
						Amount:    1000,
						CarNumber: "品川300あ1234",
						ETCNumber: strings.Repeat("1234567890", 5), // 50 characters
					}
				},
				wantErr: true,
				errMsg:  "too long",
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				etc := tt.setup()
				err := etc.Validate()
				if tt.wantErr {
					require.Error(t, err)
					if tt.errMsg != "" {
						assert.Contains(t, err.Error(), tt.errMsg)
					}
				} else {
					assert.NoError(t, err)
				}
			})
		}
	})

	t.Run("ImportSession validateRowCounts edge cases", func(t *testing.T) {
		tests := []struct {
			name    string
			setup   func() *ImportSession
			wantErr bool
			errMsg  string
		}{
			{
				name: "processed exceeds total",
				setup: func() *ImportSession {
					return &ImportSession{
						ID:            "550e8400-e29b-41d4-a716-446655440000",
						AccountType:   "corporate",
						AccountID:     "ACC001",
						FileName:      "test.csv",
						FileSize:      1024,
						Status:        "pending",
						TotalRows:     10,
						ProcessedRows: 15, // Exceeds total
						SuccessRows:   10,
						ErrorRows:     5,
						DuplicateRows: 0,
						StartedAt:     time.Now(),
					}
				},
				wantErr: true,
				errMsg:  "cannot exceed total rows",
			},
			{
				name: "row count mismatch",
				setup: func() *ImportSession {
					return &ImportSession{
						ID:            "550e8400-e29b-41d4-a716-446655440000",
						AccountType:   "corporate",
						AccountID:     "ACC001",
						FileName:      "test.csv",
						FileSize:      1024,
						Status:        "pending",
						TotalRows:     100,
						ProcessedRows: 10, // Doesn't match sum
						SuccessRows:   5,
						ErrorRows:     3,
						DuplicateRows: 1, // 5+3+1=9, but ProcessedRows=10
						StartedAt:     time.Now(),
					}
				},
				wantErr: true,
				errMsg:  "must equal sum",
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				session := tt.setup()
				err := session.validate()
				if tt.wantErr {
					require.Error(t, err)
					if tt.errMsg != "" {
						assert.Contains(t, err.Error(), tt.errMsg)
					}
				} else {
					assert.NoError(t, err)
				}
			})
		}
	})
}

// TestSerializationEdgeCases tests JSON serialization/deserialization edge cases
func TestSerializationEdgeCases(t *testing.T) {
	t.Parallel()

	t.Run("ETCMeisai serialization", func(t *testing.T) {
		// Test with nil/empty values
		etcEmpty := &ETCMeisai{}
		assert.NotNil(t, etcEmpty)

		// Test with zero values
		etcZero := &ETCMeisai{
			Amount: 0, // Valid according to our validation
		}
		assert.Equal(t, int32(0), etcZero.Amount)
	})

	t.Run("ImportSession error log serialization", func(t *testing.T) {
		session := &ImportSession{
			ID:          "550e8400-e29b-41d4-a716-446655440000",
			AccountType: "corporate",
			AccountID:   "ACC001",
			FileName:    "test.csv",
			FileSize:    1024,
			Status:      "pending",
			StartedAt:   time.Now(),
		}

		// Test adding errors and retrieving them
		err := session.AddError(1, "validation", "invalid data", "raw data")
		assert.NoError(t, err)

		errors, err := session.GetErrors()
		assert.NoError(t, err)
		assert.Len(t, errors, 1)
		assert.Equal(t, 1, errors[0].RowNumber)
		assert.Equal(t, "validation", errors[0].ErrorType)
		assert.Equal(t, "invalid data", errors[0].ErrorMessage)
		assert.Equal(t, "raw data", errors[0].RawData)
	})
}