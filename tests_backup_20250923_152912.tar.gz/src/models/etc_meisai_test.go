package models_test

import (
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"github.com/yhonda-ohishi/etc_meisai/src/models"
)

func TestETCMeisai_Validate(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		setup   func() *models.ETCMeisai
		wantErr bool
		errMsg  string
	}{
		{
			name: "valid record",
			setup: func() *models.ETCMeisai {
				return &models.ETCMeisai{
					UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
					UseTime:   "10:30",
					EntryIC:   "東京IC",
					ExitIC:    "横浜IC",
					Amount:    1000,
					CarNumber: "品川300あ1234",
					ETCNumber: "1234-5678-9012-3456",
				}
			},
			wantErr: false,
		},
		{
			name: "missing use date",
			setup: func() *models.ETCMeisai {
				return &models.ETCMeisai{
					UseTime:   "10:30",
					EntryIC:   "東京IC",
					ExitIC:    "横浜IC",
					Amount:    1000,
					CarNumber: "品川300あ1234",
					ETCNumber: "1234-5678-9012-3456",
				}
			},
			wantErr: true,
			errMsg:  "UseDate",
		},
		{
			name: "missing use time",
			setup: func() *models.ETCMeisai {
				return &models.ETCMeisai{
					UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
					EntryIC:   "東京IC",
					ExitIC:    "横浜IC",
					Amount:    1000,
					CarNumber: "品川300あ1234",
					ETCNumber: "1234-5678-9012-3456",
				}
			},
			wantErr: true,
			errMsg:  "UseTime",
		},
		{
			name: "missing entry IC",
			setup: func() *models.ETCMeisai {
				return &models.ETCMeisai{
					UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
					UseTime:   "10:30",
					ExitIC:    "横浜IC",
					Amount:    1000,
					CarNumber: "品川300あ1234",
					ETCNumber: "1234-5678-9012-3456",
				}
			},
			wantErr: true,
			errMsg:  "EntryIC",
		},
		{
			name: "missing exit IC",
			setup: func() *models.ETCMeisai {
				return &models.ETCMeisai{
					UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
					UseTime:   "10:30",
					EntryIC:   "東京IC",
					Amount:    1000,
					CarNumber: "品川300あ1234",
					ETCNumber: "1234-5678-9012-3456",
				}
			},
			wantErr: true,
			errMsg:  "ExitIC",
		},
		{
			name: "negative amount",
			setup: func() *models.ETCMeisai {
				return &models.ETCMeisai{
					UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
					UseTime:   "10:30",
					EntryIC:   "東京IC",
					ExitIC:    "横浜IC",
					Amount:    -100,
					CarNumber: "品川300あ1234",
					ETCNumber: "1234-5678-9012-3456",
				}
			},
			wantErr: true,
			errMsg:  "Amount",
		},
		{
			name: "missing car number",
			setup: func() *models.ETCMeisai {
				return &models.ETCMeisai{
					UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
					UseTime:   "10:30",
					EntryIC:   "東京IC",
					ExitIC:    "横浜IC",
					Amount:    1000,
					ETCNumber: "1234-5678-9012-3456",
				}
			},
			wantErr: true,
			errMsg:  "CarNumber",
		},
		{
			name: "missing ETC number",
			setup: func() *models.ETCMeisai {
				return &models.ETCMeisai{
					UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
					UseTime:   "10:30",
					EntryIC:   "東京IC",
					ExitIC:    "横浜IC",
					Amount:    1000,
					CarNumber: "品川300あ1234",
				}
			},
			wantErr: true,
			errMsg:  "ETCNumber",
		},
		{
			name: "zero amount is valid",
			setup: func() *models.ETCMeisai {
				return &models.ETCMeisai{
					UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
					UseTime:   "10:30",
					EntryIC:   "東京IC",
					ExitIC:    "横浜IC",
					Amount:    0,
					CarNumber: "品川300あ1234",
					ETCNumber: "1234-5678-9012-3456",
				}
			},
			wantErr: false,
		},
	}

	for _, tt := range tests {
		tt := tt
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			etc := tt.setup()
			err := etc.Validate()

			if tt.wantErr {
				require.Error(t, err)
				if tt.errMsg != "" {
					assert.Contains(t, err.Error(), tt.errMsg)
				}
			} else {
				require.NoError(t, err)
			}
		})
	}
}

func TestETCMeisai_GenerateHash(t *testing.T) {
	t.Parallel()

	t.Run("generates consistent hash", func(t *testing.T) {
		etc := &models.ETCMeisai{
			UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
			UseTime:   "10:30",
			EntryIC:   "東京IC",
			ExitIC:    "横浜IC",
			Amount:    1000,
			CarNumber: "品川300あ1234",
			ETCNumber: "1234-5678-9012-3456",
		}
		hash1 := etc.GenerateHash()
		hash2 := etc.GenerateHash()

		assert.NotEmpty(t, hash1)
		assert.Equal(t, hash1, hash2)
	})

	t.Run("different records have different hashes", func(t *testing.T) {
		etc1 := &models.ETCMeisai{
			UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
			UseTime:   "10:30",
			EntryIC:   "東京IC",
			ExitIC:    "横浜IC",
			Amount:    1000,
			CarNumber: "品川300あ1234",
			ETCNumber: "1234-5678-9012-3456",
		}
		etc2 := &models.ETCMeisai{
			UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
			UseTime:   "10:30",
			EntryIC:   "東京IC",
			ExitIC:    "横浜IC",
			Amount:    1000,
			CarNumber: "品川500か5678",
			ETCNumber: "1234-5678-9012-3456",
		}

		hash1 := etc1.GenerateHash()
		hash2 := etc2.GenerateHash()

		assert.NotEqual(t, hash1, hash2)
	})

	t.Run("hash is SHA256 format", func(t *testing.T) {
		etc := &models.ETCMeisai{
			UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
			UseTime:   "10:30",
			EntryIC:   "東京IC",
			ExitIC:    "横浜IC",
			Amount:    1000,
			CarNumber: "品川300あ1234",
			ETCNumber: "1234-5678-9012-3456",
		}
		hash := etc.GenerateHash()

		assert.Len(t, hash, 64) // SHA256 produces 64 hex characters
		assert.Regexp(t, "^[a-f0-9]{64}$", hash)
	})
}

func TestETCMeisai_BeforeCreate(t *testing.T) {
	t.Parallel()

	t.Run("sets hash if empty", func(t *testing.T) {
		etc := &models.ETCMeisai{
			UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
			UseTime:   "10:30",
			EntryIC:   "東京IC",
			ExitIC:    "横浜IC",
			Amount:    1000,
			CarNumber: "品川300あ1234",
			ETCNumber: "1234-5678-9012-3456",
			Hash:      "",
		}

		err := etc.BeforeCreate()
		require.NoError(t, err)
		assert.NotEmpty(t, etc.Hash)
	})

	t.Run("preserves existing hash", func(t *testing.T) {
		originalHash := "existing-hash"
		etc := &models.ETCMeisai{
			UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
			UseTime:   "10:30",
			EntryIC:   "東京IC",
			ExitIC:    "横浜IC",
			Amount:    1000,
			CarNumber: "品川300あ1234",
			ETCNumber: "1234-5678-9012-3456",
			Hash:      originalHash,
		}

		err := etc.BeforeCreate()
		require.NoError(t, err)
		assert.Equal(t, originalHash, etc.Hash)
	})

	t.Run("sets timestamps", func(t *testing.T) {
		etc := &models.ETCMeisai{
			UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
			UseTime:   "10:30",
			EntryIC:   "東京IC",
			ExitIC:    "横浜IC",
			Amount:    1000,
			CarNumber: "品川300あ1234",
			ETCNumber: "1234-5678-9012-3456",
		}

		err := etc.BeforeCreate()
		require.NoError(t, err)
		assert.NotZero(t, etc.CreatedAt)
		assert.NotZero(t, etc.UpdatedAt)
	})
}

func TestETCMeisai_BeforeUpdate(t *testing.T) {
	t.Parallel()

	t.Run("updates timestamp", func(t *testing.T) {
		etc := &models.ETCMeisai{
			UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
			UseTime:   "10:30",
			EntryIC:   "東京IC",
			ExitIC:    "横浜IC",
			Amount:    1000,
			CarNumber: "品川300あ1234",
			ETCNumber: "1234-5678-9012-3456",
			UpdatedAt: time.Now().Add(-1 * time.Hour),
		}
		originalTime := etc.UpdatedAt

		err := etc.BeforeUpdate()
		require.NoError(t, err)
		assert.True(t, etc.UpdatedAt.After(originalTime))
	})
}