package models

import (
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
)

func TestETCMeisaiRecord_TableName(t *testing.T) {
	t.Parallel()
	record := &ETCMeisaiRecord{}
	tableName := record.TableName()
	assert.Equal(t, "etc_meisai_records", tableName)
}

func TestETCMeisaiRecord_BeforeCreate(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		record  *ETCMeisaiRecord
		wantErr bool
	}{
		{
			name: "valid record generates hash",
			record: &ETCMeisaiRecord{
				Date:            time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
				Time:            "10:30:00",
				EntranceIC:      "東京IC",
				ExitIC:          "横浜IC",
				TollAmount:      1000,
				CarNumber:       "ABC-1234",
				ETCCardNumber:   "1234567890123456",
			},
			wantErr: false,
		},
		{
			name: "preserves existing hash",
			record: &ETCMeisaiRecord{
				Hash:            "existing-hash",
				Date:            time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
				Time:            "10:30:00",
				EntranceIC:      "東京IC",
				ExitIC:          "横浜IC",
				TollAmount:      1000,
				CarNumber:       "ABC-1234",
				ETCCardNumber:   "1234567890123456",
			},
			wantErr: false,
		},
		{
			name: "invalid record fails",
			record: &ETCMeisaiRecord{
				Date:            time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
				Time:            "10:30:00",
				EntranceIC:      "",  // Invalid
				ExitIC:          "横浜IC",
				TollAmount:      1000,
				CarNumber:       "ABC-1234",
				ETCCardNumber:   "1234567890123456",
			},
			wantErr: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			originalHash := tt.record.Hash
			err := tt.record.BeforeCreate(nil)

			if tt.wantErr {
				assert.Error(t, err)
			} else {
				assert.NoError(t, err)
				if originalHash == "" {
					assert.NotEmpty(t, tt.record.Hash)
				} else {
					assert.Equal(t, originalHash, tt.record.Hash)
				}
			}
		})
	}
}

func TestETCMeisaiRecord_BeforeSave(t *testing.T) {
	t.Parallel()

	record := &ETCMeisaiRecord{
		Date:            time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
		Time:            "10:30:00",
		EntranceIC:      "東京IC",
		ExitIC:          "横浜IC",
		TollAmount:      1000,
		CarNumber:       "ABC-1234",
		ETCCardNumber:   "1234567890123456",
	}

	err := record.BeforeSave(nil)
	assert.NoError(t, err)
}

func TestETCMeisaiRecord_Validate(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		record  *ETCMeisaiRecord
		wantErr bool
	}{
		{
			name: "valid record",
			record: &ETCMeisaiRecord{
				Date:            time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
				Time:            "10:30:00",
				EntranceIC:      "東京IC",
				ExitIC:          "横浜IC",
				TollAmount:      1000,
				CarNumber:       "ABC-1234",
				ETCCardNumber:   "1234567890123456",
			},
			wantErr: false,
		},
		{
			name: "invalid car number",
			record: &ETCMeisaiRecord{
				Date:            time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
				Time:            "10:30:00",
				EntranceIC:      "東京IC",
				ExitIC:          "横浜IC",
				TollAmount:      1000,
				CarNumber:       "",  // Invalid
				ETCCardNumber:   "1234567890123456",
			},
			wantErr: true,
		},
		{
			name: "invalid ETC card number",
			record: &ETCMeisaiRecord{
				Date:            time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
				Time:            "10:30:00",
				EntranceIC:      "東京IC",
				ExitIC:          "横浜IC",
				TollAmount:      1000,
				CarNumber:       "ABC-1234",
				ETCCardNumber:   "invalid",  // Invalid
			},
			wantErr: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			err := tt.record.Validate()
			if tt.wantErr {
				assert.Error(t, err)
			} else {
				assert.NoError(t, err)
			}
		})
	}
}

func TestETCMeisaiRecord_validateCarNumber(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name      string
		carNumber string
		wantErr   bool
	}{
		{
			name:      "valid alphanumeric car number",
			carNumber: "ABC-1234",
			wantErr:   false,
		},
		{
			name:      "valid 4-digit number",
			carNumber: "1234",
			wantErr:   false,
		},
		{
			name:      "empty car number",
			carNumber: "",
			wantErr:   true,
		},
		{
			name:      "too short car number",
			carNumber: "A1",
			wantErr:   true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			record := &ETCMeisaiRecord{CarNumber: tt.carNumber}
			err := record.validateCarNumber()
			if tt.wantErr {
				assert.Error(t, err)
			} else {
				assert.NoError(t, err)
			}
		})
	}
}

func TestETCMeisaiRecord_validateETCCardNumber(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name          string
		etcCardNumber string
		wantErr       bool
	}{
		{
			name:          "valid 16-digit card number",
			etcCardNumber: "1234567890123456",
			wantErr:       false,
		},
		{
			name:          "valid card number with dashes",
			etcCardNumber: "1234-5678-9012-3456",
			wantErr:       false,
		},
		{
			name:          "empty card number",
			etcCardNumber: "",
			wantErr:       true,
		},
		{
			name:          "too short card number",
			etcCardNumber: "12345",
			wantErr:       true,
		},
		{
			name:          "card number with letters",
			etcCardNumber: "1234ABCD90123456",
			wantErr:       true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			record := &ETCMeisaiRecord{ETCCardNumber: tt.etcCardNumber}
			err := record.validateETCCardNumber()
			if tt.wantErr {
				assert.Error(t, err)
			} else {
				assert.NoError(t, err)
			}
		})
	}
}

func TestETCMeisaiRecord_validateETCNum(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		etcNum  *string
		wantErr bool
	}{
		{
			name:    "nil ETC num (optional)",
			etcNum:  nil,
			wantErr: false,
		},
		{
			name:    "empty ETC num",
			etcNum:  stringPtr(""),
			wantErr: false, // Empty is allowed
		},
		{
			name:    "valid ETC num",
			etcNum:  stringPtr("ETC001"),
			wantErr: false,
		},
		{
			name:    "too long ETC num",
			etcNum:  stringPtr("this-is-a-very-long-etc-number-that-exceeds-fifty-characters-limit"),
			wantErr: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			record := &ETCMeisaiRecord{ETCNum: tt.etcNum}
			err := record.validateETCNum()
			if tt.wantErr {
				assert.Error(t, err)
			} else {
				assert.NoError(t, err)
			}
		})
	}
}

func TestETCMeisaiRecord_GenerateHash(t *testing.T) {
	t.Parallel()

	record := &ETCMeisaiRecord{
		Date:            time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
		Time:            "10:30:00",
		EntranceIC:      "東京IC",
		ExitIC:          "横浜IC",
		TollAmount:      1000,
		CarNumber:       "ABC-1234",
		ETCCardNumber:   "1234567890123456",
	}

	hash := record.GenerateHash()
	assert.NotEmpty(t, hash)
	assert.Len(t, hash, 64) // SHA256 produces 64 character hex string

	// Test consistency - same record should generate same hash
	hash2 := record.GenerateHash()
	assert.Equal(t, hash, hash2)

	// Test different records produce different hashes
	record2 := &ETCMeisaiRecord{
		Date:            time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
		Time:            "11:30:00", // Different time
		EntranceIC:      "東京IC",
		ExitIC:          "横浜IC",
		TollAmount:      1000,
		CarNumber:       "ABC-1234",
		ETCCardNumber:   "1234567890123456",
	}

	hash3 := record2.GenerateHash()
	assert.NotEqual(t, hash, hash3)
}

func TestETCMeisaiRecord_GetDateString(t *testing.T) {
	t.Parallel()

	record := &ETCMeisaiRecord{
		Date: time.Date(2024, 1, 15, 0, 0, 0, 0, time.UTC),
	}

	dateString := record.GetDateString()
	assert.Equal(t, "2024-01-15", dateString)
}

func TestETCMeisaiRecord_GetMaskedETCCardNumber(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name          string
		etcCardNumber string
		expected      string
	}{
		{
			name:          "16-digit card number",
			etcCardNumber: "1234567890123456",
			expected:      "****-****-****-3456",
		},
		{
			name:          "card number with dashes",
			etcCardNumber: "1234-5678-9012-3456",
			expected:      "****-****-****-3456",
		},
		{
			name:          "short card number",
			etcCardNumber: "1234",
			expected:      "****", // All masked if too short
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			record := &ETCMeisaiRecord{ETCCardNumber: tt.etcCardNumber}
			masked := record.GetMaskedETCCardNumber()
			assert.Equal(t, tt.expected, masked)
		})
	}
}

func TestETCMeisaiRecord_IsValidForMapping(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name     string
		record   *ETCMeisaiRecord
		expected bool
	}{
		{
			name: "valid record with all required fields",
			record: &ETCMeisaiRecord{
				ID:              1,
				Hash:            "valid-hash",
				Date:            time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
				Time:            "10:30:00",
				EntranceIC:      "東京IC",
				ExitIC:          "横浜IC",
				TollAmount:      1000,
				CarNumber:       "ABC-1234",
				ETCCardNumber:   "1234567890123456",
			},
			expected: true,
		},
		{
			name: "invalid record with zero ID",
			record: &ETCMeisaiRecord{
				ID:              0, // Zero ID
				Hash:            "valid-hash",
				Date:            time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
				Time:            "10:30:00",
				EntranceIC:      "東京IC",
				ExitIC:          "横浜IC",
				TollAmount:      1000,
				CarNumber:       "ABC-1234",
				ETCCardNumber:   "1234567890123456",
			},
			expected: false,
		},
		{
			name: "invalid record with empty hash",
			record: &ETCMeisaiRecord{
				ID:              1,
				Hash:            "", // Empty hash
				Date:            time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
				Time:            "10:30:00",
				EntranceIC:      "東京IC",
				ExitIC:          "横浜IC",
				TollAmount:      1000,
				CarNumber:       "ABC-1234",
				ETCCardNumber:   "1234567890123456",
			},
			expected: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			result := tt.record.IsValidForMapping()
			assert.Equal(t, tt.expected, result)
		})
	}
}

// Helper function to create string pointer
func stringPtr(s string) *string {
	return &s
}