package models

import (
	"strings"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// TestETCMapping_ValidateComprehensiveEdgeCases tests edge cases to achieve 100% coverage
func TestETCMapping_ValidateComprehensiveEdgeCases(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		mapping *ETCMapping
		wantErr bool
		errMsg  string
	}{
		{
			name: "created_by exactly 100 characters (boundary test)",
			mapping: &ETCMapping{
				ETCRecordID:      100,
				MappingType:      "dtako",
				MappedEntityID:   200,
				MappedEntityType: "dtako_record",
				Confidence:       0.95,
				Status:           "active",
				CreatedBy:        strings.Repeat("a", 100), // Exactly 100 characters
			},
			wantErr: false,
		},
		{
			name: "created_by 101 characters (too long)",
			mapping: &ETCMapping{
				ETCRecordID:      100,
				MappingType:      "dtako",
				MappedEntityID:   200,
				MappedEntityType: "dtako_record",
				Confidence:       0.95,
				Status:           "active",
				CreatedBy:        strings.Repeat("a", 101), // 101 characters - too long
			},
			wantErr: true,
			errMsg:  "created_by field too long",
		},
		{
			name: "empty created_by is valid",
			mapping: &ETCMapping{
				ETCRecordID:      100,
				MappingType:      "dtako",
				MappedEntityID:   200,
				MappedEntityType: "dtako_record",
				Confidence:       0.95,
				Status:           "active",
				CreatedBy:        "", // Empty string should be valid
			},
			wantErr: false,
		},
		{
			name: "confidence below 0.0 (boundary test)",
			mapping: &ETCMapping{
				ETCRecordID:      100,
				MappingType:      "dtako",
				MappedEntityID:   200,
				MappedEntityType: "dtako_record",
				Confidence:       -0.1, // Below 0.0
				Status:           "active",
			},
			wantErr: true,
			errMsg:  "confidence must be between 0.0 and 1.0",
		},
		{
			name: "confidence above 1.0 (boundary test)",
			mapping: &ETCMapping{
				ETCRecordID:      100,
				MappingType:      "dtako",
				MappedEntityID:   200,
				MappedEntityType: "dtako_record",
				Confidence:       1.1, // Above 1.0
				Status:           "active",
			},
			wantErr: true,
			errMsg:  "confidence must be between 0.0 and 1.0",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			err := tt.mapping.validate()
			if tt.wantErr {
				require.Error(t, err)
				assert.Contains(t, err.Error(), tt.errMsg)
			} else {
				require.NoError(t, err)
			}
		})
	}
}

// TestETCMapping_ValidateMappingTypeEdgeCases tests missing edge cases for mapping type validation
func TestETCMapping_ValidateMappingTypeEdgeCases(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name        string
		mappingType string
		wantErr     bool
		errMsg      string
		expected    string // Expected normalized value
	}{
		{
			name:        "empty mapping type",
			mappingType: "",
			wantErr:     true,
			errMsg:      "mapping type cannot be empty",
		},
		{
			name:        "whitespace only mapping type",
			mappingType: "   ",
			wantErr:     true,
			errMsg:      "mapping type cannot be empty",
		},
		{
			name:        "uppercase mapping type gets normalized",
			mappingType: "DTAKO",
			wantErr:     false,
			expected:    "dtako",
		},
		{
			name:        "mixed case mapping type gets normalized",
			mappingType: "DtAkO",
			wantErr:     false,
			expected:    "dtako",
		},
		{
			name:        "mapping type with leading/trailing spaces gets trimmed",
			mappingType: "  dtako  ",
			wantErr:     false,
			expected:    "dtako",
		},
		{
			name:        "expense mapping type",
			mappingType: "expense",
			wantErr:     false,
			expected:    "expense",
		},
		{
			name:        "invoice mapping type",
			mappingType: "invoice",
			wantErr:     false,
			expected:    "invoice",
		},
		{
			name:        "invalid mapping type",
			mappingType: "unknown",
			wantErr:     true,
			errMsg:      "invalid mapping type",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			mapping := &ETCMapping{
				ETCRecordID:      100,
				MappingType:      tt.mappingType,
				MappedEntityID:   200,
				MappedEntityType: "dtako_record",
				Confidence:       0.95,
				Status:           "active",
			}

			err := mapping.validateMappingType()
			if tt.wantErr {
				require.Error(t, err)
				assert.Contains(t, err.Error(), tt.errMsg)
			} else {
				require.NoError(t, err)
				if tt.expected != "" {
					assert.Equal(t, tt.expected, mapping.MappingType)
				}
			}
		})
	}
}

// TestETCMapping_ValidateMappedEntityTypeEdgeCases tests missing edge cases for entity type validation
func TestETCMapping_ValidateMappedEntityTypeEdgeCases(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name       string
		entityType string
		wantErr    bool
		errMsg     string
		expected   string // Expected normalized value
	}{
		{
			name:       "empty entity type",
			entityType: "",
			wantErr:    true,
			errMsg:     "mapped entity type cannot be empty",
		},
		{
			name:       "whitespace only entity type",
			entityType: "   ",
			wantErr:    true,
			errMsg:     "mapped entity type cannot be empty",
		},
		{
			name:       "uppercase entity type gets normalized",
			entityType: "DTAKO_RECORD",
			wantErr:    false,
			expected:   "dtako_record",
		},
		{
			name:       "mixed case entity type gets normalized",
			entityType: "DtAkO_ReCorD",
			wantErr:    false,
			expected:   "dtako_record",
		},
		{
			name:       "entity type with leading/trailing spaces gets trimmed",
			entityType: "  dtako_record  ",
			wantErr:    false,
			expected:   "dtako_record",
		},
		{
			name:       "expense_record entity type",
			entityType: "expense_record",
			wantErr:    false,
			expected:   "expense_record",
		},
		{
			name:       "invoice_record entity type",
			entityType: "invoice_record",
			wantErr:    false,
			expected:   "invoice_record",
		},
		{
			name:       "invalid entity type",
			entityType: "unknown_record",
			wantErr:    true,
			errMsg:     "invalid mapped entity type",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			mapping := &ETCMapping{
				ETCRecordID:      100,
				MappingType:      "dtako",
				MappedEntityID:   200,
				MappedEntityType: tt.entityType,
				Confidence:       0.95,
				Status:           "active",
			}

			err := mapping.validateMappedEntityType()
			if tt.wantErr {
				require.Error(t, err)
				assert.Contains(t, err.Error(), tt.errMsg)
			} else {
				require.NoError(t, err)
				if tt.expected != "" {
					assert.Equal(t, tt.expected, mapping.MappedEntityType)
				}
			}
		})
	}
}

// TestETCMapping_ValidateStatusEdgeCases tests missing edge cases for status validation
func TestETCMapping_ValidateStatusEdgeCases(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name     string
		status   string
		wantErr  bool
		errMsg   string
		expected string // Expected normalized value
	}{
		{
			name:     "empty status gets default",
			status:   "",
			wantErr:  false,
			expected: "active", // Default status
		},
		{
			name:     "whitespace only status gets default",
			status:   "   ",
			wantErr:  false,
			expected: "active", // Default status
		},
		{
			name:     "uppercase status gets normalized",
			status:   "ACTIVE",
			wantErr:  false,
			expected: "active",
		},
		{
			name:     "mixed case status gets normalized",
			status:   "PeNdInG",
			wantErr:  false,
			expected: "pending",
		},
		{
			name:     "status with leading/trailing spaces gets trimmed",
			status:   "  inactive  ",
			wantErr:  false,
			expected: "inactive",
		},
		{
			name:     "rejected status",
			status:   "rejected",
			wantErr:  false,
			expected: "rejected",
		},
		{
			name:    "invalid status",
			status:  "unknown",
			wantErr: true,
			errMsg:  "invalid status",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			mapping := &ETCMapping{
				ETCRecordID:      100,
				MappingType:      "dtako",
				MappedEntityID:   200,
				MappedEntityType: "dtako_record",
				Confidence:       0.95,
				Status:           tt.status,
			}

			err := mapping.validateStatus()
			if tt.wantErr {
				require.Error(t, err)
				assert.Contains(t, err.Error(), tt.errMsg)
			} else {
				require.NoError(t, err)
				if tt.expected != "" {
					assert.Equal(t, tt.expected, mapping.Status)
				}
			}
		})
	}
}

// TestETCMapping_CanTransitionToComprehensive tests missing edge cases for status transitions
func TestETCMapping_CanTransitionToComprehensive(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name          string
		currentStatus string
		targetStatus  string
		canTransition bool
	}{
		// Pending transitions (covered in existing tests)
		{
			name:          "pending to rejected",
			currentStatus: "pending",
			targetStatus:  "rejected",
			canTransition: true,
		},
		{
			name:          "pending to inactive (invalid)",
			currentStatus: "pending",
			targetStatus:  "inactive",
			canTransition: false,
		},
		// Rejected transitions (missing coverage)
		{
			name:          "rejected to pending",
			currentStatus: "rejected",
			targetStatus:  "pending",
			canTransition: true,
		},
		{
			name:          "rejected to active (invalid)",
			currentStatus: "rejected",
			targetStatus:  "active",
			canTransition: false,
		},
		{
			name:          "rejected to inactive (invalid)",
			currentStatus: "rejected",
			targetStatus:  "inactive",
			canTransition: false,
		},
		// Unknown status (missing coverage)
		{
			name:          "unknown status to active",
			currentStatus: "unknown",
			targetStatus:  "active",
			canTransition: false,
		},
		{
			name:          "active to rejected (invalid)",
			currentStatus: "active",
			targetStatus:  "rejected",
			canTransition: false,
		},
		{
			name:          "inactive to rejected (invalid)",
			currentStatus: "inactive",
			targetStatus:  "rejected",
			canTransition: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			mapping := &ETCMapping{Status: tt.currentStatus}
			result := mapping.CanTransitionTo(tt.targetStatus)
			assert.Equal(t, tt.canTransition, result)
		})
	}
}

// TestETCMapping_SetMetadataAdvancedCases tests additional edge cases for metadata handling
func TestETCMapping_SetMetadataAdvancedCases(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name     string
		metadata map[string]interface{}
		wantErr  bool
		errMsg   string
	}{
		{
			name:     "empty metadata",
			metadata: map[string]interface{}{},
			wantErr:  false,
		},
		{
			name: "metadata too large",
			metadata: map[string]interface{}{
				"large_field": strings.Repeat("x", 70000), // > 64KB when JSON encoded
			},
			wantErr: true,
			errMsg:  "metadata too large",
		},
		{
			name: "complex nested metadata",
			metadata: map[string]interface{}{
				"nested": map[string]interface{}{
					"level1": map[string]interface{}{
						"level2": "value",
					},
				},
				"array": []interface{}{1, 2, 3},
			},
			wantErr: false,
		},
		{
			name: "unmarshallable data type (function)",
			metadata: map[string]interface{}{
				"invalid": func() {}, // Functions cannot be marshaled to JSON
			},
			wantErr: true,
			errMsg:  "failed to marshal metadata",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			mapping := &ETCMapping{}
			err := mapping.SetMetadata(tt.metadata)

			if tt.wantErr {
				require.Error(t, err)
				assert.Contains(t, err.Error(), tt.errMsg)
			} else {
				require.NoError(t, err)

				// Test that GetMetadata works as expected
				retrieved, err := mapping.GetMetadata()
				require.NoError(t, err)

				if tt.metadata == nil {
					assert.Nil(t, retrieved)
				} else {
					assert.Equal(t, len(tt.metadata), len(retrieved))
				}
			}
		})
	}
}

// TestETCMapping_StatusTransitionMethods tests individual status transition method edge cases
func TestETCMapping_StatusTransitionMethodsEdgeCases(t *testing.T) {
	t.Parallel()

	t.Run("Activate from invalid status", func(t *testing.T) {
		mapping := &ETCMapping{Status: "rejected"}
		err := mapping.Activate()
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "cannot activate mapping from status")
	})

	t.Run("Deactivate from invalid status", func(t *testing.T) {
		mapping := &ETCMapping{Status: "pending"}
		err := mapping.Deactivate()
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "cannot deactivate mapping from status")
	})

	t.Run("Approve from non-pending status", func(t *testing.T) {
		mapping := &ETCMapping{Status: "active"}
		err := mapping.Approve()
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "can only approve pending mappings")
	})

	t.Run("Reject from non-pending status", func(t *testing.T) {
		mapping := &ETCMapping{Status: "active"}
		err := mapping.Reject()
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "can only reject pending mappings")
	})
}

// TestETCMapping_BeforeCreatePreservesTimestamps tests that existing timestamps are preserved
func TestETCMapping_BeforeCreatePreservesTimestamps(t *testing.T) {
	t.Parallel()

	t.Run("preserves existing timestamps", func(t *testing.T) {
		// Use a fixed time in the past
		fixedTime := mustParseTime("2023-12-31T23:59:59Z")

		mapping := &ETCMapping{
			ETCRecordID:      100,
			MappingType:      "dtako",
			MappedEntityID:   200,
			MappedEntityType: "dtako_record",
			Confidence:       0.95,
			CreatedAt:        fixedTime,
			UpdatedAt:        fixedTime,
		}

		err := mapping.BeforeCreate(nil)
		require.NoError(t, err)

		// Timestamps should be preserved
		assert.Equal(t, fixedTime, mapping.CreatedAt)
		assert.Equal(t, fixedTime, mapping.UpdatedAt)
	})

	t.Run("sets default status when empty", func(t *testing.T) {
		mapping := &ETCMapping{
			ETCRecordID:      100,
			MappingType:      "dtako",
			MappedEntityID:   200,
			MappedEntityType: "dtako_record",
			Confidence:       0.95,
			Status:           "", // Empty status
		}

		err := mapping.BeforeCreate(nil)
		require.NoError(t, err)

		// Status should be set to default
		assert.Equal(t, "active", mapping.Status)
	})
}

// TestETCMapping_GetMetadataInvalidJSON tests error handling in GetMetadata
func TestETCMapping_GetMetadataInvalidJSON(t *testing.T) {
	t.Parallel()

	mapping := &ETCMapping{}
	// Manually set invalid JSON
	mapping.Metadata = []byte(`{"invalid": json}`) // Invalid JSON

	metadata, err := mapping.GetMetadata()
	assert.Error(t, err)
	assert.Nil(t, metadata)
	assert.Contains(t, err.Error(), "failed to unmarshal metadata")
}

// Helper function to parse time
func mustParseTime(timeStr string) time.Time {
	t, err := time.Parse(time.RFC3339, timeStr)
	if err != nil {
		panic(err)
	}
	return t
}