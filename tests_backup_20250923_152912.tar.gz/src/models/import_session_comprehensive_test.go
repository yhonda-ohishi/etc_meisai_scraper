package models

import (
	"strings"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// TestImportSession_BeforeCreateEdgeCases tests edge cases for BeforeCreate to achieve 100% coverage
func TestImportSession_BeforeCreateEdgeCases(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		session *ImportSession
		wantErr bool
		check   func(*testing.T, *ImportSession)
	}{
		{
			name: "preserves existing ID when provided",
			session: &ImportSession{
				ID:          "existing-id-12345",
				AccountType: "corporate",
				AccountID:   "ACC001",
				FileName:    "test.csv",
				FileSize:    1000,
			},
			wantErr: false,
			check: func(t *testing.T, s *ImportSession) {
				assert.Equal(t, "existing-id-12345", s.ID)
			},
		},
		{
			name: "generates new ID when empty",
			session: &ImportSession{
				ID:          "", // Empty ID should be generated
				AccountType: "corporate",
				AccountID:   "ACC001",
				FileName:    "test.csv",
				FileSize:    1000,
			},
			wantErr: false,
			check: func(t *testing.T, s *ImportSession) {
				assert.NotEmpty(t, s.ID)
				assert.Len(t, s.ID, 36) // UUID length
			},
		},
		{
			name: "preserves existing StartedAt when provided",
			session: &ImportSession{
				AccountType: "corporate",
				AccountID:   "ACC001",
				FileName:    "test.csv",
				FileSize:    1000,
				StartedAt:   time.Date(2023, 1, 1, 12, 0, 0, 0, time.UTC),
			},
			wantErr: false,
			check: func(t *testing.T, s *ImportSession) {
				expected := time.Date(2023, 1, 1, 12, 0, 0, 0, time.UTC)
				assert.Equal(t, expected, s.StartedAt)
			},
		},
		{
			name: "sets StartedAt when zero",
			session: &ImportSession{
				AccountType: "corporate",
				AccountID:   "ACC001",
				FileName:    "test.csv",
				FileSize:    1000,
				StartedAt:   time.Time{}, // Zero time
			},
			wantErr: false,
			check: func(t *testing.T, s *ImportSession) {
				assert.False(t, s.StartedAt.IsZero())
			},
		},
		{
			name: "preserves existing status when provided",
			session: &ImportSession{
				AccountType: "corporate",
				AccountID:   "ACC001",
				FileName:    "test.csv",
				FileSize:    1000,
				Status:      "processing", // Existing status
			},
			wantErr: false,
			check: func(t *testing.T, s *ImportSession) {
				assert.Equal(t, "processing", s.Status)
			},
		},
		{
			name: "sets default status when empty",
			session: &ImportSession{
				AccountType: "corporate",
				AccountID:   "ACC001",
				FileName:    "test.csv",
				FileSize:    1000,
				Status:      "", // Empty status should get default
			},
			wantErr: false,
			check: func(t *testing.T, s *ImportSession) {
				assert.Equal(t, "pending", s.Status)
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			err := tt.session.BeforeCreate(nil)

			if tt.wantErr {
				require.Error(t, err)
			} else {
				require.NoError(t, err)
				if tt.check != nil {
					tt.check(t, tt.session)
				}
			}
		})
	}
}

// TestImportSession_ValidateIDEdgeCases tests edge cases for validateID
func TestImportSession_ValidateIDEdgeCases(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		session *ImportSession
		wantErr bool
		errMsg  string
	}{
		{
			name: "valid UUID format",
			session: &ImportSession{
				ID: "123e4567-e89b-12d3-a456-426614174000",
			},
			wantErr: false,
		},
		{
			name: "empty ID triggers warning but no error",
			session: &ImportSession{
				ID: "",
			},
			wantErr: false, // validateID only adds warning for empty ID
		},
		{
			name: "short alphanumeric ID is valid",
			session: &ImportSession{
				ID: "ABC123",
			},
			wantErr: false,
		},
		{
			name: "ID too long (over 100 chars)",
			session: &ImportSession{
				ID: strings.Repeat("a", 101), // 101 characters
			},
			wantErr: true,
			errMsg:  "ID too long",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			err := tt.session.validateID()

			if tt.wantErr {
				require.Error(t, err)
				assert.Contains(t, err.Error(), tt.errMsg)
			} else {
				assert.NoError(t, err)
			}
		})
	}
}

// TestImportSession_ValidateAccountIDEdgeCases tests edge cases for validateAccountID
func TestImportSession_ValidateAccountIDEdgeCases(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		session *ImportSession
		wantErr bool
		errMsg  string
	}{
		{
			name: "valid account ID",
			session: &ImportSession{
				AccountID: "VALID_ACCOUNT_123",
			},
			wantErr: false,
		},
		{
			name: "empty account ID",
			session: &ImportSession{
				AccountID: "",
			},
			wantErr: true,
			errMsg:  "AccountID is required",
		},
		{
			name: "account ID too long (over 50 chars)",
			session: &ImportSession{
				AccountID: strings.Repeat("A", 51), // 51 characters
			},
			wantErr: true,
			errMsg:  "AccountID too long",
		},
		{
			name: "account ID exactly 50 chars (boundary test)",
			session: &ImportSession{
				AccountID: strings.Repeat("A", 50), // Exactly 50 characters
			},
			wantErr: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			err := tt.session.validateAccountID()

			if tt.wantErr {
				require.Error(t, err)
				assert.Contains(t, err.Error(), tt.errMsg)
			} else {
				assert.NoError(t, err)
			}
		})
	}
}

// TestImportSession_ValidateStatusEdgeCases tests edge cases for validateStatus
func TestImportSession_ValidateStatusEdgeCases(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		session *ImportSession
		wantErr bool
		errMsg  string
	}{
		{
			name: "valid pending status",
			session: &ImportSession{
				Status: "pending",
			},
			wantErr: false,
		},
		{
			name: "valid processing status",
			session: &ImportSession{
				Status: "processing",
			},
			wantErr: false,
		},
		{
			name: "valid completed status",
			session: &ImportSession{
				Status: "completed",
			},
			wantErr: false,
		},
		{
			name: "valid failed status",
			session: &ImportSession{
				Status: "failed",
			},
			wantErr: false,
		},
		{
			name: "valid cancelled status",
			session: &ImportSession{
				Status: "cancelled",
			},
			wantErr: false,
		},
		{
			name: "invalid status",
			session: &ImportSession{
				Status: "unknown_status",
			},
			wantErr: true,
			errMsg:  "invalid status",
		},
		{
			name: "empty status",
			session: &ImportSession{
				Status: "",
			},
			wantErr: true,
			errMsg:  "status cannot be empty",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			err := tt.session.validateStatus()

			if tt.wantErr {
				require.Error(t, err)
				assert.Contains(t, err.Error(), tt.errMsg)
			} else {
				assert.NoError(t, err)
			}
		})
	}
}

// TestImportSession_ValidateRowCountsEdgeCases tests edge cases for validateRowCounts
func TestImportSession_ValidateRowCountsEdgeCases(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		session *ImportSession
		wantErr bool
		errMsg  string
	}{
		{
			name: "valid row counts",
			session: &ImportSession{
				TotalRows:     100,
				ProcessedRows: 80,
				SuccessRows:   70,
				ErrorRows:     10,
			},
			wantErr: false,
		},
		{
			name: "negative total rows",
			session: &ImportSession{
				TotalRows:     -1,
				ProcessedRows: 0,
				SuccessRows:   0,
				ErrorRows:     0,
			},
			wantErr: true,
			errMsg:  "total rows cannot be negative",
		},
		{
			name: "negative processed rows",
			session: &ImportSession{
				TotalRows:     100,
				ProcessedRows: -1,
				SuccessRows:   0,
				ErrorRows:     0,
			},
			wantErr: true,
			errMsg:  "processed rows cannot be negative",
		},
		{
			name: "negative success rows",
			session: &ImportSession{
				TotalRows:     100,
				ProcessedRows: 50,
				SuccessRows:   -1,
				ErrorRows:     0,
			},
			wantErr: true,
			errMsg:  "success rows cannot be negative",
		},
		{
			name: "negative error rows",
			session: &ImportSession{
				TotalRows:     100,
				ProcessedRows: 50,
				SuccessRows:   40,
				ErrorRows:     -1,
			},
			wantErr: true,
			errMsg:  "error rows cannot be negative",
		},
		{
			name: "processed > total (invalid)",
			session: &ImportSession{
				TotalRows:     100,
				ProcessedRows: 150, // More than total
				SuccessRows:   100,
				ErrorRows:     50,
				DuplicateRows: 0, // 100 + 50 = 150 processed
			},
			wantErr: true,
			errMsg:  "cannot exceed total rows",
		},
		{
			name: "success + error + duplicate != processed (invalid)",
			session: &ImportSession{
				TotalRows:     100,
				ProcessedRows: 50,
				SuccessRows:   30,
				ErrorRows:     15,
				DuplicateRows: 10, // 30 + 15 + 10 = 55 != 50 processed
			},
			wantErr: true,
			errMsg:  "must equal sum of success",
		},
		{
			name: "zero values are valid",
			session: &ImportSession{
				TotalRows:     0,
				ProcessedRows: 0,
				SuccessRows:   0,
				ErrorRows:     0,
			},
			wantErr: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			err := tt.session.validateRowCounts()

			if tt.wantErr {
				require.Error(t, err)
				assert.Contains(t, err.Error(), tt.errMsg)
			} else {
				assert.NoError(t, err)
			}
		})
	}
}

// TestImportSession_StatusTransitionEdgeCases tests edge cases for status transition methods
func TestImportSession_StatusTransitionEdgeCases(t *testing.T) {
	t.Parallel()

	t.Run("StartProcessing from invalid status", func(t *testing.T) {
		session := &ImportSession{Status: "completed"}
		err := session.StartProcessing()
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "cannot start processing")
	})

	t.Run("Complete from invalid status", func(t *testing.T) {
		session := &ImportSession{Status: "pending"}
		err := session.Complete()
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "cannot complete")
	})

	t.Run("Fail from invalid status", func(t *testing.T) {
		session := &ImportSession{Status: "completed"}
		err := session.Fail()
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "cannot fail")
	})

	t.Run("Cancel from invalid status", func(t *testing.T) {
		session := &ImportSession{Status: "completed"}
		err := session.Cancel()
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "cannot cancel")
	})
}

// TestImportSession_AddErrorEdgeCases tests edge cases for AddError
func TestImportSession_AddErrorEdgeCases(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		session *ImportSession
		errMsg  string
		wantErr bool
		check   func(*testing.T, *ImportSession)
	}{
		{
			name: "add first error",
			session: &ImportSession{
				ErrorLog: nil, // No existing errors
			},
			errMsg:  "First error message",
			wantErr: false,
			check: func(t *testing.T, s *ImportSession) {
				errors, err := s.GetErrors()
				require.NoError(t, err)
				assert.Len(t, errors, 1)
				assert.Equal(t, "First error message", errors[0].ErrorMessage)
			},
		},
		{
			name: "add error to existing errors",
			session: &ImportSession{
				ErrorLog: []byte(`[{"row_number":1,"error_type":"validation","error_message":"Existing error"}]`),
			},
			errMsg:  "New error message",
			wantErr: false,
			check: func(t *testing.T, s *ImportSession) {
				errors, err := s.GetErrors()
				require.NoError(t, err)
				assert.Len(t, errors, 2)
				errorMessages := make([]string, len(errors))
				for i, e := range errors {
					errorMessages[i] = e.ErrorMessage
				}
				assert.Contains(t, errorMessages, "Existing error")
				assert.Contains(t, errorMessages, "New error message")
			},
		},
		{
			name: "empty error message",
			session: &ImportSession{
				ErrorLog: nil,
			},
			errMsg:  "",
			wantErr: false, // Empty messages should be allowed
			check: func(t *testing.T, s *ImportSession) {
				errors, err := s.GetErrors()
				require.NoError(t, err)
				assert.Len(t, errors, 1)
				assert.Equal(t, "", errors[0].ErrorMessage)
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			err := tt.session.AddError(1, "test_error", tt.errMsg, "raw_data")

			if tt.wantErr {
				require.Error(t, err)
			} else {
				require.NoError(t, err)
				if tt.check != nil {
					tt.check(t, tt.session)
				}
			}
		})
	}
}

// TestImportSession_GetErrorsEdgeCases tests edge cases for GetErrors
func TestImportSession_GetErrorsEdgeCases(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name     string
		session  *ImportSession
		expected []ImportError
	}{
		{
			name: "no error log",
			session: &ImportSession{
				ErrorLog: nil,
			},
			expected: []ImportError{},
		},
		{
			name: "empty error log",
			session: &ImportSession{
				ErrorLog: []byte(""),
			},
			expected: []ImportError{},
		},
		{
			name: "invalid JSON error log",
			session: &ImportSession{
				ErrorLog: []byte("invalid json"),
			},
			expected: []ImportError{}, // Should return empty slice on JSON parse error
		},
		{
			name: "valid error log",
			session: &ImportSession{
				ErrorLog: []byte(`[{"row_number":1,"error_type":"validation","error_message":"Error 1"},{"row_number":2,"error_type":"parse","error_message":"Error 2"}]`),
			},
			expected: []ImportError{
				{RowNumber: 1, ErrorType: "validation", ErrorMessage: "Error 1"},
				{RowNumber: 2, ErrorType: "parse", ErrorMessage: "Error 2"},
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			errors, err := tt.session.GetErrors()
			if len(tt.expected) == 0 && tt.session.ErrorLog != nil && len(tt.session.ErrorLog) > 0 && string(tt.session.ErrorLog) == "invalid json" {
				// For invalid JSON, expect an error
				assert.Error(t, err)
				assert.Nil(t, errors)
			} else {
				require.NoError(t, err)
				assert.Equal(t, tt.expected, errors)
			}
		})
	}
}