package models

import (
	"strings"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
)

// TestValidateETCMeisai_AdditionalEdgeCases tests missing edge cases for ValidateETCMeisai
func TestValidateETCMeisai_AdditionalEdgeCases(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name        string
		etc         *ETCMeisai
		wantValid   bool
		expectedErr string
	}{
		{
			name:        "nil record",
			etc:         nil,
			wantValid:   false,
			expectedErr: "Record cannot be nil",
		},
		{
			name: "future date",
			etc: &ETCMeisai{
				UseDate:   time.Now().Add(24 * time.Hour), // Tomorrow
				UseTime:   "10:30",
				EntryIC:   "東京IC",
				ExitIC:    "横浜IC",
				Amount:    1000,
				CarNumber: "品川300あ1234",
				ETCNumber: "1234567890123456",
			},
			wantValid:   false,
			expectedErr: "UseDate cannot be in the future",
		},
		{
			name: "date too old (over 2 years ago)",
			etc: &ETCMeisai{
				UseDate:   time.Now().AddDate(-3, 0, 0), // 3 years ago
				UseTime:   "10:30",
				EntryIC:   "東京IC",
				ExitIC:    "横浜IC",
				Amount:    1000,
				CarNumber: "品川300あ1234",
				ETCNumber: "1234567890123456",
			},
			wantValid:   false,
			expectedErr: "UseDate cannot be older than 2 years",
		},
		{
			name: "date exactly 2 years ago (boundary test)",
			etc: &ETCMeisai{
				UseDate:   time.Now().AddDate(-2, 0, 1), // Just under 2 years ago
				UseTime:   "10:30",
				EntryIC:   "東京IC",
				ExitIC:    "横浜IC",
				Amount:    1000,
				CarNumber: "品川300あ1234",
				ETCNumber: "1234567890123456",
			},
			wantValid: true,
		},
		{
			name: "invalid time format",
			etc: &ETCMeisai{
				UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
				UseTime:   "25:70", // Invalid time
				EntryIC:   "東京IC",
				ExitIC:    "横浜IC",
				Amount:    1000,
				CarNumber: "品川300あ1234",
				ETCNumber: "1234567890123456",
			},
			wantValid:   false,
			expectedErr: "UseTime must be in HH:MM format",
		},
		{
			name: "empty time is valid",
			etc: &ETCMeisai{
				UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
				UseTime:   "", // Empty time should be valid
				EntryIC:   "東京IC",
				ExitIC:    "横浜IC",
				Amount:    1000,
				CarNumber: "品川300あ1234",
				ETCNumber: "1234567890123456",
			},
			wantValid: true,
		},
		{
			name: "ETC number too long (over 20 chars)",
			etc: &ETCMeisai{
				UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
				UseTime:   "10:30",
				EntryIC:   "東京IC",
				ExitIC:    "横浜IC",
				Amount:    1000,
				CarNumber: "品川300あ1234",
				ETCNumber: strings.Repeat("1", 21), // 21 characters
			},
			wantValid:   false,
			expectedErr: "ETCNumber cannot exceed 20 characters",
		},
		{
			name: "ETC number exactly 20 chars (boundary test)",
			etc: &ETCMeisai{
				UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
				UseTime:   "10:30",
				EntryIC:   "東京IC",
				ExitIC:    "横浜IC",
				Amount:    1000,
				CarNumber: "品川300あ1234",
				ETCNumber: strings.Repeat("1", 20), // Exactly 20 characters
			},
			wantValid: true,
		},
		{
			name: "ETC number with invalid characters",
			etc: &ETCMeisai{
				UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
				UseTime:   "10:30",
				EntryIC:   "東京IC",
				ExitIC:    "横浜IC",
				Amount:    1000,
				CarNumber: "品川300あ1234",
				ETCNumber: "invalid-chars!", // Invalid characters
			},
			wantValid:   false,
			expectedErr: "ETCNumber contains invalid characters",
		},
		{
			name: "car number too long (over 20 chars)",
			etc: &ETCMeisai{
				UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
				UseTime:   "10:30",
				EntryIC:   "東京IC",
				ExitIC:    "横浜IC",
				Amount:    1000,
				CarNumber: strings.Repeat("A", 21), // 21 characters
				ETCNumber: "1234567890123456",
			},
			wantValid:   false,
			expectedErr: "CarNumber cannot exceed 20 characters",
		},
		{
			name: "car number exactly 20 chars (boundary test)",
			etc: &ETCMeisai{
				UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
				UseTime:   "10:30",
				EntryIC:   "東京IC",
				ExitIC:    "横浜IC",
				Amount:    1000,
				CarNumber: strings.Repeat("A", 20), // Exactly 20 characters
				ETCNumber: "1234567890123456",
			},
			wantValid: true,
		},
		{
			name: "entry IC too long (over 100 chars)",
			etc: &ETCMeisai{
				UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
				UseTime:   "10:30",
				EntryIC:   strings.Repeat("東", 101), // 101 characters
				ExitIC:    "横浜IC",
				Amount:    1000,
				CarNumber: "品川300あ1234",
				ETCNumber: "1234567890123456",
			},
			wantValid:   false,
			expectedErr: "EntryIC cannot exceed 100 characters",
		},
		{
			name: "entry IC exactly 100 chars (boundary test)",
			etc: &ETCMeisai{
				UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
				UseTime:   "10:30",
				EntryIC:   strings.Repeat("A", 100), // Exactly 100 characters (ASCII)
				ExitIC:    "横浜IC",
				Amount:    1000,
				CarNumber: "品川300あ1234",
				ETCNumber: "1234567890123456",
			},
			wantValid: true,
		},
		{
			name: "exit IC too long (over 100 chars)",
			etc: &ETCMeisai{
				UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
				UseTime:   "10:30",
				EntryIC:   "東京IC",
				ExitIC:    strings.Repeat("横", 101), // 101 characters
				Amount:    1000,
				CarNumber: "品川300あ1234",
				ETCNumber: "1234567890123456",
			},
			wantValid:   false,
			expectedErr: "ExitIC cannot exceed 100 characters",
		},
		{
			name: "exit IC exactly 100 chars (boundary test)",
			etc: &ETCMeisai{
				UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
				UseTime:   "10:30",
				EntryIC:   "東京IC",
				ExitIC:    strings.Repeat("B", 100), // Exactly 100 characters (ASCII)
				Amount:    1000,
				CarNumber: "品川300あ1234",
				ETCNumber: "1234567890123456",
			},
			wantValid: true,
		},
		{
			name: "amount exactly 100000 (boundary test)",
			etc: &ETCMeisai{
				UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
				UseTime:   "10:30",
				EntryIC:   "東京IC",
				ExitIC:    "横浜IC",
				Amount:    100000, // Exactly 100,000 yen
				CarNumber: "品川300あ1234",
				ETCNumber: "1234567890123456",
			},
			wantValid: true,
		},
		{
			name: "amount over 100000 (suspicious value)",
			etc: &ETCMeisai{
				UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
				UseTime:   "10:30",
				EntryIC:   "東京IC",
				ExitIC:    "横浜IC",
				Amount:    100001, // Over 100,000 yen
				CarNumber: "品川300あ1234",
				ETCNumber: "1234567890123456",
			},
			wantValid:   false,
			expectedErr: "Amount seems unusually high",
		},
		{
			name: "whitespace only entry IC",
			etc: &ETCMeisai{
				UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
				UseTime:   "10:30",
				EntryIC:   "   ", // Whitespace only
				ExitIC:    "横浜IC",
				Amount:    1000,
				CarNumber: "品川300あ1234",
				ETCNumber: "1234567890123456",
			},
			wantValid:   false,
			expectedErr: "EntryIC is required",
		},
		{
			name: "whitespace only exit IC",
			etc: &ETCMeisai{
				UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
				UseTime:   "10:30",
				EntryIC:   "東京IC",
				ExitIC:    "   ", // Whitespace only
				Amount:    1000,
				CarNumber: "品川300あ1234",
				ETCNumber: "1234567890123456",
			},
			wantValid:   false,
			expectedErr: "ExitIC is required",
		},
		{
			name: "zero amount",
			etc: &ETCMeisai{
				UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
				UseTime:   "10:30",
				EntryIC:   "東京IC",
				ExitIC:    "横浜IC",
				Amount:    0, // Zero amount
				CarNumber: "品川300あ1234",
				ETCNumber: "1234567890123456",
			},
			wantValid:   false,
			expectedErr: "Amount must be positive",
		},
		{
			name: "negative amount",
			etc: &ETCMeisai{
				UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
				UseTime:   "10:30",
				EntryIC:   "東京IC",
				ExitIC:    "横浜IC",
				Amount:    -1000, // Negative amount
				CarNumber: "品川300あ1234",
				ETCNumber: "1234567890123456",
			},
			wantValid:   false,
			expectedErr: "Amount must be positive",
		},
		{
			name: "empty ETC number should pass validation",
			etc: &ETCMeisai{
				UseDate:   time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
				UseTime:   "10:30",
				EntryIC:   "東京IC",
				ExitIC:    "横浜IC",
				Amount:    1000,
				CarNumber: "品川300あ1234",
				ETCNumber: "", // Empty ETC number should pass validation
			},
			wantValid: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			result := ValidateETCMeisai(tt.etc)

			assert.Equal(t, tt.wantValid, result.Valid)

			if !tt.wantValid && tt.expectedErr != "" {
				found := false
				for _, err := range result.Errors {
					if strings.Contains(err.Message, tt.expectedErr) {
						found = true
						break
					}
				}
				assert.True(t, found, "Expected error message '%s' not found in errors: %v", tt.expectedErr, result.Errors)
			}
		})
	}
}

// TestValidateETCMeisaiMapping_EdgeCases tests missing edge cases for ValidateETCMeisaiMapping
func TestValidateETCMeisaiMapping_EdgeCases(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name        string
		mapping     *ETCMeisaiMapping
		wantValid   bool
		expectedErr string
	}{
		{
			name: "zero ETC meisai ID",
			mapping: &ETCMeisaiMapping{
				ETCMeisaiID: 0, // Zero ID should be invalid
				DTakoRowID:  "DTAKO001",
				MappingType: "auto",
				Confidence:  0.95,
			},
			wantValid:   false,
			expectedErr: "ETCMeisaiID must be positive",
		},
		{
			name: "negative ETC meisai ID",
			mapping: &ETCMeisaiMapping{
				ETCMeisaiID: -1, // Negative ID should be invalid
				DTakoRowID:  "DTAKO001",
				MappingType: "auto",
				Confidence:  0.95,
			},
			wantValid:   false,
			expectedErr: "ETCMeisaiID must be positive",
		},
		{
			name: "empty DTako row ID",
			mapping: &ETCMeisaiMapping{
				ETCMeisaiID: 1,
				DTakoRowID:  "", // Empty DTako ID should be invalid
				MappingType: "auto",
				Confidence:  0.95,
			},
			wantValid:   false,
			expectedErr: "DTakoRowID is required",
		},
		{
			name: "whitespace only DTako row ID",
			mapping: &ETCMeisaiMapping{
				ETCMeisaiID: 1,
				DTakoRowID:  "   ", // Whitespace only should be invalid
				MappingType: "auto",
				Confidence:  0.95,
			},
			wantValid:   false,
			expectedErr: "DTakoRowID is required",
		},
		{
			name: "invalid mapping type",
			mapping: &ETCMeisaiMapping{
				ETCMeisaiID: 1,
				DTakoRowID:  "DTAKO001",
				MappingType: "invalid", // Invalid mapping type
				Confidence:  0.95,
			},
			wantValid:   false,
			expectedErr: "MappingType must be 'auto' or 'manual'",
		},
		{
			name: "notes too long (over 500 chars)",
			mapping: &ETCMeisaiMapping{
				ETCMeisaiID: 1,
				DTakoRowID:  "DTAKO001",
				MappingType: "auto",
				Confidence:  0.95,
				Notes:       strings.Repeat("A", 501), // Over 500 characters
			},
			wantValid:   false,
			expectedErr: "Notes cannot exceed 500 characters",
		},
		{
			name: "notes exactly 500 chars (boundary test)",
			mapping: &ETCMeisaiMapping{
				ETCMeisaiID: 1,
				DTakoRowID:  "DTAKO001",
				MappingType: "auto",
				Confidence:  0.95,
				Notes:       strings.Repeat("A", 500), // Exactly 500 characters
			},
			wantValid: true,
		},
		{
			name: "DTako row ID with invalid characters",
			mapping: &ETCMeisaiMapping{
				ETCMeisaiID: 1,
				DTakoRowID:  "DTAKO@#$%", // Invalid characters
				MappingType: "auto",
				Confidence:  0.95,
			},
			wantValid:   false,
			expectedErr: "DTakoRowID has invalid format",
		},
		{
			name: "invalid confidence above 1.0",
			mapping: &ETCMeisaiMapping{
				ETCMeisaiID: 1,
				DTakoRowID:  "DTAKO001",
				MappingType: "auto",
				Confidence:  1.1, // Invalid confidence
			},
			wantValid:   false,
			expectedErr: "Confidence must be between 0 and 1",
		},
		{
			name: "invalid confidence below 0.0",
			mapping: &ETCMeisaiMapping{
				ETCMeisaiID: 1,
				DTakoRowID:  "DTAKO001",
				MappingType: "auto",
				Confidence:  -0.1, // Invalid confidence
			},
			wantValid:   false,
			expectedErr: "Confidence must be between 0 and 1",
		},
		{
			name: "confidence exactly 0.0 (boundary test)",
			mapping: &ETCMeisaiMapping{
				ETCMeisaiID: 1,
				DTakoRowID:  "DTAKO001",
				MappingType: "auto",
				Confidence:  0.0, // Exactly 0.0
			},
			wantValid: true,
		},
		{
			name: "confidence exactly 1.0 (boundary test)",
			mapping: &ETCMeisaiMapping{
				ETCMeisaiID: 1,
				DTakoRowID:  "DTAKO001",
				MappingType: "auto",
				Confidence:  1.0, // Exactly 1.0
			},
			wantValid: true,
		},
		{
			name: "DTako row ID too long (over 50 chars)",
			mapping: &ETCMeisaiMapping{
				ETCMeisaiID: 1,
				DTakoRowID:  strings.Repeat("A", 51), // Over 50 characters
				MappingType: "auto",
				Confidence:  0.95,
			},
			wantValid:   false,
			expectedErr: "DTakoRowID has invalid format",
		},
		{
			name: "DTako row ID exactly 50 chars (boundary test)",
			mapping: &ETCMeisaiMapping{
				ETCMeisaiID: 1,
				DTakoRowID:  strings.Repeat("A", 50), // Exactly 50 characters
				MappingType: "auto",
				Confidence:  0.95,
			},
			wantValid: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			result := ValidateETCMeisaiMapping(tt.mapping)

			assert.Equal(t, tt.wantValid, result.Valid)

			if !tt.wantValid && tt.expectedErr != "" {
				found := false
				for _, err := range result.Errors {
					if strings.Contains(err.Message, tt.expectedErr) {
						found = true
						break
					}
				}
				assert.True(t, found, "Expected error message '%s' not found in errors: %v", tt.expectedErr, result.Errors)
			}
		})
	}
}

// TestValidateETCImportBatch_AdditionalEdgeCases tests missing edge cases for ValidateETCImportBatch
func TestValidateETCImportBatch_AdditionalEdgeCases(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name        string
		batch       *ETCImportBatch
		wantValid   bool
		expectedErr string
	}{
		{
			name:        "nil batch",
			batch:       nil,
			wantValid:   false,
			expectedErr: "Batch cannot be nil",
		},
		{
			name: "negative total records",
			batch: &ETCImportBatch{
				FileName:     "test.csv",
				TotalRecords: -1, // Negative count
				Status:       "pending",
			},
			wantValid:   false,
			expectedErr: "TotalRecords cannot be negative",
		},
		{
			name: "processed count > total records",
			batch: &ETCImportBatch{
				FileName:       "test.csv",
				TotalRecords:   100,
				ProcessedCount: 120, // More than total
				Status:         "pending",
			},
			wantValid:   false,
			expectedErr: "ProcessedCount cannot exceed TotalRecords",
		},
		{
			name: "created count > processed count",
			batch: &ETCImportBatch{
				FileName:       "test.csv",
				TotalRecords:   100,
				ProcessedCount: 80,
				CreatedCount:   90, // More than processed
				Status:         "pending",
			},
			wantValid:   false,
			expectedErr: "CreatedCount cannot exceed ProcessedCount",
		},
		{
			name: "empty file name",
			batch: &ETCImportBatch{
				FileName:     "", // Empty file name
				TotalRecords: 100,
				Status:       "pending",
			},
			wantValid:   false,
			expectedErr: "FileName is required",
		},
		{
			name: "whitespace only file name",
			batch: &ETCImportBatch{
				FileName:     "   ", // Whitespace only
				TotalRecords: 100,
				Status:       "pending",
			},
			wantValid:   false,
			expectedErr: "FileName is required",
		},
		{
			name: "file name too long (over 255 chars)",
			batch: &ETCImportBatch{
				FileName:     strings.Repeat("A", 256), // Over 255 characters
				TotalRecords: 100,
				Status:       "pending",
			},
			wantValid:   false,
			expectedErr: "FileName cannot exceed 255 characters",
		},
		{
			name: "file name exactly 255 chars (boundary test)",
			batch: &ETCImportBatch{
				FileName:     strings.Repeat("A", 255), // Exactly 255 characters
				TotalRecords: 100,
				Status:       "pending",
			},
			wantValid: true,
		},
		{
			name: "invalid status",
			batch: &ETCImportBatch{
				FileName:     "test.csv",
				TotalRecords: 100,
				Status:       "unknown", // Invalid status
			},
			wantValid:   false,
			expectedErr: "Invalid status value",
		},
		{
			name: "valid counts (processed < total)",
			batch: &ETCImportBatch{
				FileName:       "test.csv",
				TotalRecords:   100,
				ProcessedCount: 80,
				CreatedCount:   70,
				Status:         "pending",
			},
			wantValid: true,
		},
		{
			name: "valid counts (processed = total)",
			batch: &ETCImportBatch{
				FileName:       "test.csv",
				TotalRecords:   100,
				ProcessedCount: 100,
				CreatedCount:   80,
				Status:         "completed",
			},
			wantValid: true,
		},
		{
			name: "zero counts are valid",
			batch: &ETCImportBatch{
				FileName:       "test.csv",
				TotalRecords:   0,
				ProcessedCount: 0,
				CreatedCount:   0,
				Status:         "pending",
			},
			wantValid: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			result := ValidateETCImportBatch(tt.batch)

			assert.Equal(t, tt.wantValid, result.Valid)

			if !tt.wantValid && tt.expectedErr != "" {
				found := false
				for _, err := range result.Errors {
					if strings.Contains(err.Message, tt.expectedErr) {
						found = true
						break
					}
				}
				assert.True(t, found, "Expected error message '%s' not found in errors: %v", tt.expectedErr, result.Errors)
			}
		})
	}
}
// TestHelperFunctions_EdgeCases tests helper validation functions
func TestHelperFunctions_EdgeCases(t *testing.T) {
	t.Parallel()

	t.Run("isValidTimeFormat edge cases", func(t *testing.T) {
		tests := []struct {
			name     string
			timeStr  string
			expected bool
		}{
			{"valid time 00:00", "00:00", true},
			{"valid time 23:59", "23:59", true},
			{"valid time 12:30", "12:30", true},
			{"invalid hour 24:00", "24:00", false},
			{"invalid minute 12:60", "12:60", false},
			{"invalid format", "25:70", false},
			{"empty string", "", false},
			{"partial time", "12:", false},
			{"missing colon", "1230", false},
			{"extra characters", "12:30:45", false},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				result := isValidTimeFormat(tt.timeStr)
				assert.Equal(t, tt.expected, result)
			})
		}
	})

	t.Run("isValidETCNumber edge cases", func(t *testing.T) {
		tests := []struct {
			name     string
			etcNum   string
			expected bool
		}{
			{"valid numbers only", "1234567890", true},
			{"empty string", "", false},
			{"with letters", "ABC123", false},
			{"with special chars", "123-456", false},
			{"with spaces", "123 456", false},
			{"leading zeros", "0001234", true},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				result := isValidETCNumber(tt.etcNum)
				assert.Equal(t, tt.expected, result)
			})
		}
	})

	t.Run("isValidDTakoRowID edge cases", func(t *testing.T) {
		tests := []struct {
			name     string
			rowID    string
			expected bool
		}{
			{"valid alphanumeric", "ABC123", true},
			{"valid with hyphen", "ABC-123", true},
			{"valid with underscore", "ABC_123", true},
			{"empty string", "", false},
			{"with spaces", "ABC 123", false},
			{"with special chars", "ABC@123", false},
			{"exactly 50 chars", strings.Repeat("A", 50), true},
			{"over 50 chars", strings.Repeat("A", 51), false},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				result := isValidDTakoRowID(tt.rowID)
				assert.Equal(t, tt.expected, result)
			})
		}
	})
}
