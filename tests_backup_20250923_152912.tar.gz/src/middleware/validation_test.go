package middleware_test

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"net/url"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"github.com/yhonda-ohishi/etc_meisai/src/middleware"
)

// TestRequestSizeValidation tests request size limiting with various scenarios
func TestRequestSizeValidation(t *testing.T) {
	t.Parallel()

	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		w.Write([]byte(`{"status":"success"}`))
	})

	tests := []struct {
		name           string
		maxSize        int64
		bodySize       int
		contentLength  string
		expectedStatus int
		expectedBody   string
	}{
		{
			name:           "valid small request",
			maxSize:        1024,
			bodySize:       100,
			contentLength:  "100",
			expectedStatus: http.StatusOK,
			expectedBody:   `{"status":"success"}`,
		},
		{
			name:           "request at exact limit",
			maxSize:        1024,
			bodySize:       1024,
			contentLength:  "1024",
			expectedStatus: http.StatusOK,
			expectedBody:   `{"status":"success"}`,
		},
		{
			name:           "request exceeds limit by 1 byte",
			maxSize:        1024,
			bodySize:       1025,
			contentLength:  "1025",
			expectedStatus: http.StatusRequestEntityTooLarge,
			expectedBody:   `{"error":"request too large","max_size":1024}`,
		},
		{
			name:           "very large request",
			maxSize:        1024,
			bodySize:       10240,
			contentLength:  "10240",
			expectedStatus: http.StatusRequestEntityTooLarge,
			expectedBody:   `{"error":"request too large","max_size":1024}`,
		},
		{
			name:           "zero size limit",
			maxSize:        0,
			bodySize:       1,
			contentLength:  "1",
			expectedStatus: http.StatusRequestEntityTooLarge,
			expectedBody:   `{"error":"request too large","max_size":0}`,
		},
		{
			name:           "empty request with size limit",
			maxSize:        1024,
			bodySize:       0,
			contentLength:  "0",
			expectedStatus: http.StatusOK,
			expectedBody:   `{"status":"success"}`,
		},
		{
			name:           "missing content-length header",
			maxSize:        1024,
			bodySize:       100,
			contentLength:  "",
			expectedStatus: http.StatusOK,
			expectedBody:   `{"status":"success"}`,
		},
		{
			name:           "invalid content-length header",
			maxSize:        1024,
			bodySize:       100,
			contentLength:  "invalid",
			expectedStatus: http.StatusOK,
			expectedBody:   `{"status":"success"}`,
		},
		{
			name:           "negative content-length",
			maxSize:        1024,
			bodySize:       100,
			contentLength:  "-1",
			expectedStatus: http.StatusOK,
			expectedBody:   `{"status":"success"}`,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			sizeMiddleware := middleware.RequestSize(tt.maxSize)
			handler := sizeMiddleware(baseHandler)

			body := strings.Repeat("a", tt.bodySize)
			req := httptest.NewRequest("POST", "/test", strings.NewReader(body))

			if tt.contentLength != "" {
				req.Header.Set("Content-Length", tt.contentLength)
			}

			w := httptest.NewRecorder()
			handler.ServeHTTP(w, req)

			assert.Equal(t, tt.expectedStatus, w.Code)
			assert.JSONEq(t, tt.expectedBody, w.Body.String())
		})
	}
}

// TestInputSanitizationXSS tests XSS attack prevention
func TestInputSanitizationXSS(t *testing.T) {
	t.Parallel()

	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// Echo back query parameters to test sanitization
		params := r.URL.Query()
		response := make(map[string][]string)
		for key, values := range params {
			response[key] = values
		}
		json.NewEncoder(w).Encode(response)
	})

	handler := middleware.SanitizeMiddleware(baseHandler)

	xssPayloads := []struct {
		name     string
		input    string
		expected string
	}{
		{
			name:     "script tag injection",
			input:    "<script>alert('xss')</script>",
			expected: "<script>alert('xss')</script>", // sanitizeString only removes nulls and trims
		},
		{
			name:     "javascript protocol",
			input:    "javascript:alert('xss')",
			expected: "javascript:alert('xss')",
		},
		{
			name:     "img onerror injection",
			input:    "<img src=x onerror=alert('xss')>",
			expected: "<img src=x onerror=alert('xss')>",
		},
		{
			name:     "null byte injection",
			input:    "test\x00<script>alert('xss')</script>",
			expected: "test<script>alert('xss')</script>", // null bytes should be removed
		},
		{
			name:     "multiple null bytes",
			input:    "test\x00\x00\x00malicious",
			expected: "testmalicious",
		},
		{
			name:     "leading and trailing whitespace",
			input:    "   <script>alert('xss')</script>   ",
			expected: "<script>alert('xss')</script>", // should be trimmed
		},
		{
			name:     "very long input",
			input:    strings.Repeat("a", 2000),
			expected: strings.Repeat("a", 1000), // should be truncated to 1000 chars
		},
		{
			name:     "normal safe input",
			input:    "user123",
			expected: "user123",
		},
	}

	for _, tt := range xssPayloads {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			req := httptest.NewRequest("GET", "/test?param="+url.QueryEscape(tt.input), nil)
			w := httptest.NewRecorder()

			handler.ServeHTTP(w, req)

			var response map[string][]string
			err := json.Unmarshal(w.Body.Bytes(), &response)
			require.NoError(t, err)

			if param, exists := response["param"]; exists && len(param) > 0 {
				assert.Equal(t, tt.expected, param[0])
			}
		})
	}
}

// TestInputSanitizationSQLInjection tests SQL injection prevention
func TestInputSanitizationSQLInjection(t *testing.T) {
	t.Parallel()

	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		params := r.URL.Query()
		response := make(map[string][]string)
		for key, values := range params {
			response[key] = values
		}
		json.NewEncoder(w).Encode(response)
	})

	handler := middleware.SanitizeMiddleware(baseHandler)

	sqlPayloads := []struct {
		name  string
		input string
	}{
		{
			name:  "union select injection",
			input: "1' UNION SELECT * FROM users--",
		},
		{
			name:  "boolean injection",
			input: "1' OR '1'='1",
		},
		{
			name:  "comment injection",
			input: "1'; DROP TABLE users; --",
		},
		{
			name:  "time based injection",
			input: "1' AND SLEEP(5)--",
		},
		{
			name:  "error based injection",
			input: "1' AND (SELECT * FROM (SELECT COUNT(*),CONCAT(version(),FLOOR(RAND(0)*2))x FROM information_schema.tables GROUP BY x)a)--",
		},
		{
			name:  "hex encoded injection",
			input: "0x53454c454354202a2046524f4d207573657273",
		},
		{
			name:  "double encoded injection",
			input: "%2527%2520UNION%2520SELECT%2520*%2520FROM%2520users--",
		},
	}

	for _, tt := range sqlPayloads {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			req := httptest.NewRequest("GET", "/test?id="+url.QueryEscape(tt.input), nil)
			w := httptest.NewRecorder()

			handler.ServeHTTP(w, req)

			assert.Equal(t, http.StatusOK, w.Code)

			var response map[string][]string
			err := json.Unmarshal(w.Body.Bytes(), &response)
			require.NoError(t, err)

			// Verify that null bytes are removed and input is sanitized
			if param, exists := response["id"]; exists && len(param) > 0 {
				sanitized := param[0]
				assert.NotContains(t, sanitized, "\x00", "Null bytes should be removed")
				assert.Equal(t, strings.TrimSpace(sanitized), sanitized, "Should be trimmed")
				if len(tt.input) > 1000 {
					assert.LessOrEqual(t, len(sanitized), 1000, "Should be truncated")
				}
			}
		})
	}
}

// TestQueryParameterSanitization tests query parameter sanitization
func TestQueryParameterSanitization(t *testing.T) {
	t.Parallel()

	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		params := r.URL.Query()
		response := make(map[string][]string)
		for key, values := range params {
			response[key] = values
		}
		json.NewEncoder(w).Encode(response)
	})

	handler := middleware.SanitizeMiddleware(baseHandler)

	tests := []struct {
		name        string
		queryString string
		expected    map[string][]string
	}{
		{
			name:        "multiple parameters",
			queryString: "name=John&age=30&city=Tokyo",
			expected: map[string][]string{
				"name": {"John"},
				"age":  {"30"},
				"city": {"Tokyo"},
			},
		},
		{
			name:        "parameters with null bytes",
			queryString: "name=" + url.QueryEscape("Jo\x00hn") + "&data=" + url.QueryEscape("test\x00\x00value"),
			expected: map[string][]string{
				"name": {"John"},
				"data": {"testvalue"},
			},
		},
		{
			name:        "parameters with whitespace",
			queryString: "name=" + url.QueryEscape("  John  ") + "&age=" + url.QueryEscape("  30  "),
			expected: map[string][]string{
				"name": {"John"},
				"age":  {"30"},
			},
		},
		{
			name:        "very long parameter",
			queryString: fmt.Sprintf("data=%s", strings.Repeat("a", 2000)),
			expected: map[string][]string{
				"data": {strings.Repeat("a", 1000)},
			},
		},
		{
			name:        "empty parameters",
			queryString: "empty=&name=John&blank=",
			expected: map[string][]string{
				"empty": {""},
				"name":  {"John"},
				"blank": {""},
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			req := httptest.NewRequest("GET", "/test?"+tt.queryString, nil)
			w := httptest.NewRecorder()

			handler.ServeHTTP(w, req)

			assert.Equal(t, http.StatusOK, w.Code)

			var response map[string][]string
			err := json.Unmarshal(w.Body.Bytes(), &response)
			require.NoError(t, err)

			for key, expectedValues := range tt.expected {
				actualValues, exists := response[key]
				assert.True(t, exists, "Parameter %s should exist", key)
				assert.Equal(t, expectedValues, actualValues, "Values for %s don't match", key)
			}
		})
	}
}

// TestFormDataValidation tests form data sanitization
func TestFormDataValidation(t *testing.T) {
	t.Parallel()

	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		err := r.ParseForm()
		if err != nil {
			http.Error(w, "Failed to parse form", http.StatusBadRequest)
			return
		}

		response := make(map[string][]string)
		for key, values := range r.Form {
			response[key] = values
		}
		json.NewEncoder(w).Encode(response)
	})

	handler := middleware.SanitizeMiddleware(baseHandler)

	formData := "name=John+Doe&email=john%40example.com&message=Hello\x00World&long=" + strings.Repeat("x", 2000)

	req := httptest.NewRequest("POST", "/test", strings.NewReader(formData))
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	w := httptest.NewRecorder()
	handler.ServeHTTP(w, req)

	assert.Equal(t, http.StatusOK, w.Code)

	var response map[string][]string
	err := json.Unmarshal(w.Body.Bytes(), &response)
	require.NoError(t, err)

	// Check that form data is parsed correctly
	assert.Contains(t, response, "name")
	assert.Contains(t, response, "email")
	assert.Contains(t, response, "message")
	assert.Contains(t, response, "long")
}

// TestJSONPayloadValidation tests JSON payload validation
func TestJSONPayloadValidation(t *testing.T) {
	t.Parallel()

	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		var data map[string]interface{}
		if err := json.NewDecoder(r.Body).Decode(&data); err != nil {
			http.Error(w, "Invalid JSON", http.StatusBadRequest)
			return
		}

		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]interface{}{
			"received": data,
			"status":   "ok",
		})
	})

	// Apply request size limit
	sizeMiddleware := middleware.RequestSize(1024)
	handler := sizeMiddleware(baseHandler)

	tests := []struct {
		name           string
		payload        interface{}
		expectedStatus int
	}{
		{
			name: "valid JSON object",
			payload: map[string]interface{}{
				"name": "John",
				"age":  30,
			},
			expectedStatus: http.StatusOK,
		},
		{
			name: "valid JSON array",
			payload: []interface{}{
				"item1", "item2", "item3",
			},
			expectedStatus: http.StatusOK,
		},
		{
			name: "nested JSON object",
			payload: map[string]interface{}{
				"user": map[string]interface{}{
					"name":    "John",
					"details": map[string]interface{}{
						"age":  30,
						"city": "Tokyo",
					},
				},
			},
			expectedStatus: http.StatusOK,
		},
		{
			name: "very large JSON payload",
			payload: map[string]interface{}{
				"data": strings.Repeat("x", 2000), // Should exceed 1024 byte limit
			},
			expectedStatus: http.StatusRequestEntityTooLarge,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			payloadBytes, err := json.Marshal(tt.payload)
			require.NoError(t, err)

			req := httptest.NewRequest("POST", "/test", bytes.NewReader(payloadBytes))
			req.Header.Set("Content-Type", "application/json")

			w := httptest.NewRecorder()
			handler.ServeHTTP(w, req)

			assert.Equal(t, tt.expectedStatus, w.Code)
		})
	}
}

// TestPathTraversalPrevention tests path traversal attack prevention
func TestPathTraversalPrevention(t *testing.T) {
	t.Parallel()

	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]string{
			"path":   r.URL.Path,
			"status": "ok",
		})
	})

	handler := middleware.SanitizeMiddleware(baseHandler)

	pathTraversalPayloads := []struct {
		name string
		path string
	}{
		{
			name: "simple path traversal",
			path: "/../../etc/passwd",
		},
		{
			name: "encoded path traversal",
			path: "/%2e%2e/%2e%2e/etc/passwd",
		},
		{
			name: "double encoded",
			path: "/%252e%252e/%252e%252e/etc/passwd",
		},
		{
			name: "unicode encoded",
			path: "/\u002e\u002e/\u002e\u002e/etc/passwd",
		},
		{
			name: "mixed case",
			path: "/..%2F..%2Fetc%2Fpasswd",
		},
		{
			name: "null byte injection",
			path: "/../../etc/passwd\x00.txt",
		},
		{
			name: "windows path traversal",
			path: "/..\\..\\windows\\system32\\config\\sam",
		},
	}

	for _, tt := range pathTraversalPayloads {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			req := httptest.NewRequest("GET", tt.path, nil)
			w := httptest.NewRecorder()

			handler.ServeHTTP(w, req)

			// The middleware doesn't prevent path traversal in URLs directly,
			// but we can verify it processes the request
			assert.Equal(t, http.StatusOK, w.Code)

			var response map[string]string
			err := json.Unmarshal(w.Body.Bytes(), &response)
			require.NoError(t, err)

			assert.Equal(t, tt.path, response["path"])
		})
	}
}

// TestSpecialCharacterHandling tests handling of special characters
func TestSpecialCharacterHandling(t *testing.T) {
	t.Parallel()

	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		params := r.URL.Query()
		response := make(map[string][]string)
		for key, values := range params {
			response[key] = values
		}
		json.NewEncoder(w).Encode(response)
	})

	handler := middleware.SanitizeMiddleware(baseHandler)

	specialChars := []struct {
		name  string
		input string
	}{
		{
			name:  "control characters",
			input: "test\t\n\r\x01\x02\x03",
		},
		{
			name:  "high ASCII characters",
			input: "test\x80\x81\x82\xFF",
		},
		{
			name:  "common special characters",
			input: "!@#$%^&*()[]{}|\\:;\"'<>,.?/~`",
		},
		{
			name:  "mathematical symbols",
			input: "±×÷∞∑∏∫∆∇√∂∃∀",
		},
		{
			name:  "currency symbols",
			input: "$€£¥¢₹₽₨₩",
		},
	}

	for _, tt := range specialChars {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			req := httptest.NewRequest("GET", "/test?data="+url.QueryEscape(tt.input), nil)
			w := httptest.NewRecorder()

			handler.ServeHTTP(w, req)

			assert.Equal(t, http.StatusOK, w.Code)

			var response map[string][]string
			err := json.Unmarshal(w.Body.Bytes(), &response)
			require.NoError(t, err)

			// Verify that special characters are handled properly
			if data, exists := response["data"]; exists && len(data) > 0 {
				sanitized := data[0]
				assert.NotContains(t, sanitized, "\x00", "Null bytes should be removed")
				assert.Equal(t, strings.TrimSpace(sanitized), sanitized, "Should be trimmed")
			}
		})
	}
}

// TestUnicodeAndEmojiHandling tests Unicode and emoji handling
func TestUnicodeAndEmojiHandling(t *testing.T) {
	t.Parallel()

	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		params := r.URL.Query()
		response := make(map[string][]string)
		for key, values := range params {
			response[key] = values
		}
		json.NewEncoder(w).Encode(response)
	})

	handler := middleware.SanitizeMiddleware(baseHandler)

	unicodeTests := []struct {
		name  string
		input string
	}{
		{
			name:  "Japanese characters",
			input: "こんにちは世界",
		},
		{
			name:  "Chinese characters",
			input: "你好世界",
		},
		{
			name:  "Arabic characters",
			input: "مرحبا بالعالم",
		},
		{
			name:  "Russian characters",
			input: "Привет мир",
		},
		{
			name:  "Emojis",
			input: "🌍🎉👋😊🚀",
		},
		{
			name:  "Mixed Unicode",
			input: "Hello 世界 🌍 مرحبا",
		},
		{
			name:  "Unicode with null bytes",
			input: "こんにちは\x00世界",
		},
		{
			name:  "Unicode normalization test",
			input: "é vs é", // Different Unicode representations
		},
	}

	for _, tt := range unicodeTests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			req := httptest.NewRequest("GET", "/test?message="+url.QueryEscape(tt.input), nil)
			w := httptest.NewRecorder()

			handler.ServeHTTP(w, req)

			assert.Equal(t, http.StatusOK, w.Code)

			var response map[string][]string
			err := json.Unmarshal(w.Body.Bytes(), &response)
			require.NoError(t, err)

			if message, exists := response["message"]; exists && len(message) > 0 {
				sanitized := message[0]
				assert.NotContains(t, sanitized, "\x00", "Null bytes should be removed")
				assert.Equal(t, strings.TrimSpace(sanitized), sanitized, "Should be trimmed")

				// For Unicode with null bytes test
				if strings.Contains(tt.input, "\x00") {
					expected := strings.ReplaceAll(tt.input, "\x00", "")
					expected = strings.TrimSpace(expected)
					assert.Equal(t, expected, sanitized)
				}
			}
		})
	}
}

// TestConcurrentValidation tests validation under concurrent load
func TestConcurrentValidation(t *testing.T) {
	t.Parallel()

	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		time.Sleep(1 * time.Millisecond) // Simulate some processing time
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("OK"))
	})

	sizeMiddleware := middleware.RequestSize(1024)
	sanitizeMiddleware := middleware.SanitizeMiddleware
	handler := sizeMiddleware(sanitizeMiddleware(baseHandler))

	const numRequests = 100
	const numWorkers = 10

	var wg sync.WaitGroup
	results := make(chan int, numRequests)

	// Create a worker pool
	work := make(chan int, numRequests)
	for i := 0; i < numWorkers; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for requestID := range work {
				func() {
					defer func() {
						if r := recover(); r != nil {
							t.Errorf("Panic in request %d: %v", requestID, r)
						}
					}()

					body := fmt.Sprintf("request_id=%d&data=%s", requestID, strings.Repeat("x", 100))
					req := httptest.NewRequest("POST", "/test?id="+fmt.Sprintf("%d", requestID), strings.NewReader(body))
					req.Header.Set("Content-Type", "application/x-www-form-urlencoded")

					w := httptest.NewRecorder()
					handler.ServeHTTP(w, req)

					results <- w.Code
				}()
			}
		}()
	}

	// Send work
	go func() {
		for i := 0; i < numRequests; i++ {
			work <- i
		}
		close(work)
	}()

	// Wait for all workers to finish
	wg.Wait()
	close(results)

	// Check results
	successCount := 0
	for statusCode := range results {
		if statusCode == http.StatusOK {
			successCount++
		}
	}

	assert.Equal(t, numRequests, successCount, "All concurrent requests should succeed")
}

// TestValidationErrorResponses tests error responses for validation failures
func TestValidationErrorResponses(t *testing.T) {
	t.Parallel()

	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("OK"))
	})

	tests := []struct {
		name           string
		middleware     func(http.Handler) http.Handler
		request        func() *http.Request
		expectedStatus int
		expectedHeader map[string]string
		checkBody      func(t *testing.T, body string)
	}{
		{
			name:       "request size exceeded",
			middleware: middleware.RequestSize(100),
			request: func() *http.Request {
				body := strings.Repeat("x", 200)
				req := httptest.NewRequest("POST", "/test", strings.NewReader(body))
				req.Header.Set("Content-Length", "200")
				return req
			},
			expectedStatus: http.StatusRequestEntityTooLarge,
			expectedHeader: map[string]string{
				"Content-Type": "application/json",
			},
			checkBody: func(t *testing.T, body string) {
				assert.Contains(t, body, "request too large")
				assert.Contains(t, body, "max_size")
			},
		},
		{
			name:       "method not allowed",
			middleware: middleware.AllowedMethods("GET", "POST"),
			request: func() *http.Request {
				return httptest.NewRequest("DELETE", "/test", nil)
			},
			expectedStatus: http.StatusMethodNotAllowed,
			expectedHeader: map[string]string{
				"Allow":        "GET, POST",
				"Content-Type": "application/json",
			},
			checkBody: func(t *testing.T, body string) {
				assert.Contains(t, body, "method not allowed")
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			handler := tt.middleware(baseHandler)
			req := tt.request()
			w := httptest.NewRecorder()

			handler.ServeHTTP(w, req)

			assert.Equal(t, tt.expectedStatus, w.Code)

			for key, expectedValue := range tt.expectedHeader {
				assert.Equal(t, expectedValue, w.Header().Get(key))
			}

			if tt.checkBody != nil {
				tt.checkBody(t, w.Body.String())
			}
		})
	}
}

// TestRequestSizeWithMaxBytesReader tests interaction with MaxBytesReader
func TestRequestSizeWithMaxBytesReader(t *testing.T) {
	t.Parallel()

	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// Try to read the entire body
		body, err := io.ReadAll(r.Body)
		if err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}

		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]interface{}{
			"body_length": len(body),
			"status":      "ok",
		})
	})

	sizeMiddleware := middleware.RequestSize(100)
	handler := sizeMiddleware(baseHandler)

	tests := []struct {
		name           string
		bodySize       int
		expectedStatus int
	}{
		{
			name:           "body within limit",
			bodySize:       50,
			expectedStatus: http.StatusOK,
		},
		{
			name:           "body at limit",
			bodySize:       100,
			expectedStatus: http.StatusOK,
		},
		{
			name:           "body exceeds limit via ContentLength",
			bodySize:       150,
			expectedStatus: http.StatusRequestEntityTooLarge,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			body := strings.Repeat("x", tt.bodySize)
			req := httptest.NewRequest("POST", "/test", strings.NewReader(body))
			req.Header.Set("Content-Length", fmt.Sprintf("%d", tt.bodySize))

			w := httptest.NewRecorder()
			handler.ServeHTTP(w, req)

			assert.Equal(t, tt.expectedStatus, w.Code)
		})
	}
}

// Benchmark tests for performance validation
func BenchmarkRequestSizeValidation(b *testing.B) {
	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
	})

	sizeMiddleware := middleware.RequestSize(1024)
	handler := sizeMiddleware(baseHandler)

	body := strings.Repeat("x", 500) // Within limit
	req := httptest.NewRequest("POST", "/test", strings.NewReader(body))
	req.Header.Set("Content-Length", "500")

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		w := httptest.NewRecorder()
		handler.ServeHTTP(w, req)
	}
}

func BenchmarkInputSanitization(b *testing.B) {
	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
	})

	handler := middleware.SanitizeMiddleware(baseHandler)

	req := httptest.NewRequest("GET", "/test?param1=value1&param2=value2&param3=value3", nil)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		w := httptest.NewRecorder()
		handler.ServeHTTP(w, req)
	}
}

func BenchmarkInputSanitizationWithMaliciousInput(b *testing.B) {
	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
	})

	handler := middleware.SanitizeMiddleware(baseHandler)

	maliciousInput := url.QueryEscape("<script>alert('xss')</script>" + strings.Repeat("a", 1000))
	req := httptest.NewRequest("GET", "/test?param="+maliciousInput, nil)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		w := httptest.NewRecorder()
		handler.ServeHTTP(w, req)
	}
}

func BenchmarkChainedValidationMiddleware(b *testing.B) {
	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
	})

	// Chain multiple validation middleware
	sizeMiddleware := middleware.RequestSize(1024)
	sanitizeMiddleware := middleware.SanitizeMiddleware
	methodMiddleware := middleware.AllowedMethods("GET", "POST", "PUT", "DELETE")

	handler := sizeMiddleware(sanitizeMiddleware(methodMiddleware(baseHandler)))

	req := httptest.NewRequest("POST", "/test?param=value", strings.NewReader("test body"))

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		w := httptest.NewRecorder()
		handler.ServeHTTP(w, req)
	}
}

// TestValidationWithRealWorldScenarios tests validation with realistic attack scenarios
func TestValidationWithRealWorldScenarios(t *testing.T) {
	t.Parallel()

	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		params := r.URL.Query()
		response := make(map[string][]string)
		for key, values := range params {
			response[key] = values
		}
		json.NewEncoder(w).Encode(response)
	})

	handler := middleware.SanitizeMiddleware(baseHandler)

	realWorldAttacks := []struct {
		name    string
		payload string
		desc    string
	}{
		{
			name:    "WordPress login bypass",
			payload: "admin'/**/AND/**/1=1/**/--",
			desc:    "Common WordPress SQL injection attempt",
		},
		{
			name:    "Blind SQL injection",
			payload: "1' AND (SELECT * FROM (SELECT COUNT(*),CONCAT(version(),FLOOR(RAND(0)*2))x FROM information_schema.tables GROUP BY x)a) AND '1'='1",
			desc:    "MySQL error-based blind injection",
		},
		{
			name:    "XSS in search parameter",
			payload: "\"><script>alert(document.cookie)</script>",
			desc:    "Common XSS payload for search boxes",
		},
		{
			name:    "XSS with event handler",
			payload: "javascript:alert('XSS')",
			desc:    "JavaScript protocol XSS attempt",
		},
		{
			name:    "Template injection",
			payload: "{{7*7}}[[7*7]]",
			desc:    "Server-Side Template Injection probe",
		},
		{
			name:    "LDAP injection",
			payload: "*)(uid=*))(|(uid=*",
			desc:    "LDAP filter injection attempt",
		},
		{
			name:    "Command injection",
			payload: "; cat /etc/passwd #",
			desc:    "Unix command injection attempt",
		},
		{
			name:    "XXE payload",
			payload: "<!DOCTYPE test [<!ENTITY xxe SYSTEM \"file:///etc/passwd\">]>",
			desc:    "XML External Entity injection",
		},
		{
			name:    "NoSQL injection",
			payload: "'; return true; var dummy='",
			desc:    "MongoDB NoSQL injection",
		},
		{
			name:    "CRLF injection",
			payload: "test\r\nSet-Cookie: admin=true",
			desc:    "HTTP response splitting attempt",
		},
	}

	for _, attack := range realWorldAttacks {
		t.Run(attack.name, func(t *testing.T) {
			t.Parallel()

			req := httptest.NewRequest("GET", "/test?input="+url.QueryEscape(attack.payload), nil)
			w := httptest.NewRecorder()

			handler.ServeHTTP(w, req)

			assert.Equal(t, http.StatusOK, w.Code, "Request should be processed")

			var response map[string][]string
			err := json.Unmarshal(w.Body.Bytes(), &response)
			require.NoError(t, err, "Response should be valid JSON")

			if input, exists := response["input"]; exists && len(input) > 0 {
				sanitized := input[0]
				// Verify basic sanitization occurred
				assert.NotContains(t, sanitized, "\x00", "Null bytes should be removed")
				assert.Equal(t, strings.TrimSpace(sanitized), sanitized, "Should be trimmed")
				if len(attack.payload) > 1000 {
					assert.LessOrEqual(t, len(sanitized), 1000, "Should be truncated")
				}
			}
		})
	}
}

// TestSanitizationEffectiveness tests the effectiveness of the sanitization
func TestSanitizationEffectiveness(t *testing.T) {
	t.Parallel()

	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		params := r.URL.Query()
		response := make(map[string][]string)
		for key, values := range params {
			response[key] = values
		}
		json.NewEncoder(w).Encode(response)
	})

	handler := middleware.SanitizeMiddleware(baseHandler)

	tests := []struct {
		name           string
		input          string
		expectedOutput string
		description    string
	}{
		{
			name:           "removes null bytes",
			input:          "hello\x00world\x00test",
			expectedOutput: "helloworldtest",
			description:    "Should remove all null bytes",
		},
		{
			name:           "trims whitespace",
			input:          "   hello world   ",
			expectedOutput: "hello world",
			description:    "Should trim leading and trailing whitespace",
		},
		{
			name:           "truncates long input",
			input:          strings.Repeat("a", 1500),
			expectedOutput: strings.Repeat("a", 1000),
			description:    "Should truncate input longer than 1000 characters",
		},
		{
			name:           "handles empty input",
			input:          "",
			expectedOutput: "",
			description:    "Should handle empty input gracefully",
		},
		{
			name:           "handles only whitespace",
			input:          "   \t\n\r   ",
			expectedOutput: "",
			description:    "Should result in empty string after trimming",
		},
		{
			name:           "preserves valid content",
			input:          "hello world 123",
			expectedOutput: "hello world 123",
			description:    "Should preserve valid content unchanged",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			req := httptest.NewRequest("GET", "/test?param="+url.QueryEscape(tt.input), nil)
			w := httptest.NewRecorder()

			handler.ServeHTTP(w, req)

			assert.Equal(t, http.StatusOK, w.Code)

			var response map[string][]string
			err := json.Unmarshal(w.Body.Bytes(), &response)
			require.NoError(t, err)

			if param, exists := response["param"]; exists && len(param) > 0 {
				assert.Equal(t, tt.expectedOutput, param[0], tt.description)
			} else if tt.expectedOutput != "" {
				t.Errorf("Expected param to exist with value %q", tt.expectedOutput)
			}
		})
	}
}