package middleware_test

import (
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/yhonda-ohishi/etc_meisai/src/middleware"
)

func TestCORS(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name               string
		allowedOrigins     []string
		requestOrigin      string
		requestMethod      string
		expectAllowed      bool
		expectedHeaders    map[string]string
	}{
		{
			name:           "wildcard origin allows all",
			allowedOrigins: []string{"*"},
			requestOrigin:  "https://example.com",
			requestMethod:  "GET",
			expectAllowed:  true,
			expectedHeaders: map[string]string{
				"Access-Control-Allow-Origin":      "https://example.com",
				"Access-Control-Allow-Credentials": "true",
			},
		},
		{
			name:           "specific origin allowed",
			allowedOrigins: []string{"https://allowed.com"},
			requestOrigin:  "https://allowed.com",
			requestMethod:  "GET",
			expectAllowed:  true,
			expectedHeaders: map[string]string{
				"Access-Control-Allow-Origin":      "https://allowed.com",
				"Access-Control-Allow-Credentials": "true",
			},
		},
		{
			name:           "origin not in allowed list",
			allowedOrigins: []string{"https://allowed.com"},
			requestOrigin:  "https://notallowed.com",
			requestMethod:  "GET",
			expectAllowed:  false,
		},
		{
			name:           "multiple allowed origins",
			allowedOrigins: []string{"https://site1.com", "https://site2.com"},
			requestOrigin:  "https://site2.com",
			requestMethod:  "GET",
			expectAllowed:  true,
			expectedHeaders: map[string]string{
				"Access-Control-Allow-Origin": "https://site2.com",
			},
		},
		{
			name:           "empty origin header",
			allowedOrigins: []string{"*"},
			requestOrigin:  "",
			requestMethod:  "GET",
			expectAllowed:  false,
		},
		{
			name:           "preflight OPTIONS request",
			allowedOrigins: []string{"*"},
			requestOrigin:  "https://example.com",
			requestMethod:  "OPTIONS",
			expectAllowed:  true,
			expectedHeaders: map[string]string{
				"Access-Control-Allow-Origin": "https://example.com",
				"Access-Control-Max-Age":      "300",
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// Create a simple handler that returns OK
			baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				w.WriteHeader(http.StatusOK)
			})

			// Apply CORS middleware
			corsMiddleware := middleware.CORS(tt.allowedOrigins)
			handler := corsMiddleware(baseHandler)

			// Create request
			req := httptest.NewRequest(tt.requestMethod, "/test", nil)
			if tt.requestOrigin != "" {
				req.Header.Set("Origin", tt.requestOrigin)
			}
			w := httptest.NewRecorder()

			// Execute request
			handler.ServeHTTP(w, req)

			// Check if CORS headers are set
			if tt.expectAllowed {
				// Check expected headers
				for header, expectedValue := range tt.expectedHeaders {
					actualValue := w.Header().Get(header)
					assert.Equal(t, expectedValue, actualValue, "Header %s mismatch", header)
				}

				// OPTIONS requests should return 204
				if tt.requestMethod == "OPTIONS" {
					assert.Equal(t, http.StatusNoContent, w.Code)
				} else {
					assert.Equal(t, http.StatusOK, w.Code)
				}
			} else {
				// When not allowed, origin header should not be set
				assert.Empty(t, w.Header().Get("Access-Control-Allow-Origin"))
			}
		})
	}
}

func TestCORS_PreflightHeaders(t *testing.T) {
	t.Parallel()

	// Test preflight request with custom headers
	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
	})

	corsMiddleware := middleware.CORS([]string{"*"})
	handler := corsMiddleware(baseHandler)

	req := httptest.NewRequest("OPTIONS", "/test", nil)
	req.Header.Set("Origin", "https://example.com")
	req.Header.Set("Access-Control-Request-Method", "POST")
	req.Header.Set("Access-Control-Request-Headers", "Content-Type,X-Custom-Header")

	w := httptest.NewRecorder()
	handler.ServeHTTP(w, req)

	// Check preflight response headers
	assert.Equal(t, http.StatusNoContent, w.Code)
	assert.Equal(t, "https://example.com", w.Header().Get("Access-Control-Allow-Origin"))
	assert.Contains(t, w.Header().Get("Access-Control-Allow-Methods"), "POST")
	assert.Contains(t, w.Header().Get("Access-Control-Allow-Headers"), "Content-Type")
	assert.NotEmpty(t, w.Header().Get("Access-Control-Max-Age"))
}

func TestDefaultCORSConfig(t *testing.T) {
	t.Parallel()

	config := middleware.DefaultCORSConfig()

	assert.Contains(t, config.AllowedOrigins, "*")
	assert.Contains(t, config.AllowedMethods, http.MethodGet)
	assert.Contains(t, config.AllowedMethods, http.MethodPost)
	assert.Contains(t, config.AllowedMethods, http.MethodPut)
	assert.Contains(t, config.AllowedMethods, http.MethodPatch)
	assert.Contains(t, config.AllowedMethods, http.MethodDelete)
	assert.Contains(t, config.AllowedMethods, http.MethodOptions)
	assert.Contains(t, config.AllowedHeaders, "Content-Type")
	assert.Contains(t, config.AllowedHeaders, "Authorization")
	assert.Contains(t, config.ExposedHeaders, "X-Request-ID")
	assert.True(t, config.AllowCredentials)
	assert.Equal(t, 300, config.MaxAge)
}

func TestCORS_VaryHeader(t *testing.T) {
	t.Parallel()

	// Test that Vary header is set for proper cache handling
	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
	})

	corsMiddleware := middleware.CORS([]string{"https://specific.com"})
	handler := corsMiddleware(baseHandler)

	req := httptest.NewRequest("GET", "/test", nil)
	req.Header.Set("Origin", "https://specific.com")
	w := httptest.NewRecorder()

	handler.ServeHTTP(w, req)

	// Check Vary header
	varyHeader := w.Header().Get("Vary")
	assert.Contains(t, varyHeader, "Origin")
}

func TestCORS_CustomMethods(t *testing.T) {
	t.Parallel()

	// Test custom HTTP methods in preflight
	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
	})

	corsMiddleware := middleware.CORS([]string{"*"})
	handler := corsMiddleware(baseHandler)

	// Test custom method like PATCH
	req := httptest.NewRequest("OPTIONS", "/test", nil)
	req.Header.Set("Origin", "https://example.com")
	req.Header.Set("Access-Control-Request-Method", "PATCH")
	w := httptest.NewRecorder()

	handler.ServeHTTP(w, req)

	assert.Equal(t, http.StatusNoContent, w.Code)
	assert.Contains(t, w.Header().Get("Access-Control-Allow-Methods"), "PATCH")
}

func TestCORS_ExposedHeaders(t *testing.T) {
	t.Parallel()

	// Test that exposed headers are properly set
	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("X-Request-ID", "123")
		w.Header().Set("X-Response-Time", "100ms")
		w.WriteHeader(http.StatusOK)
	})

	corsMiddleware := middleware.CORS([]string{"*"})
	handler := corsMiddleware(baseHandler)

	req := httptest.NewRequest("GET", "/test", nil)
	req.Header.Set("Origin", "https://example.com")
	w := httptest.NewRecorder()

	handler.ServeHTTP(w, req)

	exposedHeaders := w.Header().Get("Access-Control-Expose-Headers")
	assert.Contains(t, exposedHeaders, "X-Request-ID")
	assert.Contains(t, exposedHeaders, "X-Response-Time")
}

func TestCORS_ConcurrentRequests(t *testing.T) {
	t.Parallel()

	// Test thread safety with concurrent requests
	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
	})

	corsMiddleware := middleware.CORS([]string{"*"})
	handler := corsMiddleware(baseHandler)

	// Run concurrent requests
	const numRequests = 100
	done := make(chan bool, numRequests)

	for i := 0; i < numRequests; i++ {
		go func(id int) {
			req := httptest.NewRequest("GET", "/test", nil)
			req.Header.Set("Origin", "https://example.com")
			w := httptest.NewRecorder()
			handler.ServeHTTP(w, req)
			assert.Equal(t, http.StatusOK, w.Code)
			assert.Equal(t, "https://example.com", w.Header().Get("Access-Control-Allow-Origin"))
			done <- true
		}(i)
	}

	// Wait for all requests
	for i := 0; i < numRequests; i++ {
		<-done
	}
}

// Benchmark tests
func BenchmarkCORS_WildcardOrigin(b *testing.B) {
	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
	})

	corsMiddleware := middleware.CORS([]string{"*"})
	handler := corsMiddleware(baseHandler)

	req := httptest.NewRequest("GET", "/test", nil)
	req.Header.Set("Origin", "https://example.com")

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		w := httptest.NewRecorder()
		handler.ServeHTTP(w, req)
	}
}

func BenchmarkCORS_SpecificOrigins(b *testing.B) {
	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
	})

	corsMiddleware := middleware.CORS([]string{"https://site1.com", "https://site2.com", "https://site3.com"})
	handler := corsMiddleware(baseHandler)

	req := httptest.NewRequest("GET", "/test", nil)
	req.Header.Set("Origin", "https://site2.com")

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		w := httptest.NewRecorder()
		handler.ServeHTTP(w, req)
	}
}

func BenchmarkCORS_Preflight(b *testing.B) {
	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
	})

	corsMiddleware := middleware.CORS([]string{"*"})
	handler := corsMiddleware(baseHandler)

	req := httptest.NewRequest("OPTIONS", "/test", nil)
	req.Header.Set("Origin", "https://example.com")
	req.Header.Set("Access-Control-Request-Method", "POST")
	req.Header.Set("Access-Control-Request-Headers", "Content-Type")

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		w := httptest.NewRecorder()
		handler.ServeHTTP(w, req)
	}
}