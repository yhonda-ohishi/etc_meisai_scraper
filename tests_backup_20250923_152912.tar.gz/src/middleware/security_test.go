package middleware_test

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/yhonda-ohishi/etc_meisai/src/middleware"
)

func TestChain(t *testing.T) {
	t.Parallel()

	// Create a simple handler that sets a header
	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Base", "true")
		w.WriteHeader(http.StatusOK)
	})

	// Create middleware that add headers
	middleware1 := func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("Middleware1", "true")
			next.ServeHTTP(w, r)
		})
	}

	middleware2 := func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("Middleware2", "true")
			next.ServeHTTP(w, r)
		})
	}

	// Chain middleware
	handler := middleware.Chain(baseHandler, middleware1, middleware2)

	// Test request
	req := httptest.NewRequest("GET", "/test", nil)
	w := httptest.NewRecorder()

	handler.ServeHTTP(w, req)

	// Verify all headers are set
	assert.Equal(t, "true", w.Header().Get("Base"))
	assert.Equal(t, "true", w.Header().Get("Middleware1"))
	assert.Equal(t, "true", w.Header().Get("Middleware2"))
	assert.Equal(t, http.StatusOK, w.Code)
}


func TestSecurity(t *testing.T) {
	t.Parallel()

	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
	})

	securityMiddleware := middleware.Security()
	handler := securityMiddleware(baseHandler)

	req := httptest.NewRequest("GET", "/test", nil)
	w := httptest.NewRecorder()

	handler.ServeHTTP(w, req)

	// Check security headers are set
	assert.Equal(t, "deny", w.Header().Get("X-Frame-Options"))
	assert.Equal(t, "nosniff", w.Header().Get("X-Content-Type-Options"))
	assert.Equal(t, "1; mode=block", w.Header().Get("X-XSS-Protection"))
	assert.NotEmpty(t, w.Header().Get("Content-Security-Policy"))
	assert.NotEmpty(t, w.Header().Get("Strict-Transport-Security"))
}

func TestRequestSize(t *testing.T) {
	t.Parallel()

	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
	})

	tests := []struct {
		name           string
		maxSize        int64
		contentLength  string
		expectedStatus int
	}{
		{
			name:           "within limit",
			maxSize:        1024,
			contentLength:  "500",
			expectedStatus: http.StatusOK,
		},
		{
			name:           "exceeds limit",
			maxSize:        1024,
			contentLength:  "2048",
			expectedStatus: http.StatusRequestEntityTooLarge,
		},
		{
			name:           "no content length",
			maxSize:        1024,
			contentLength:  "",
			expectedStatus: http.StatusOK,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			sizeMiddleware := middleware.RequestSize(tt.maxSize)
			handler := sizeMiddleware(baseHandler)

			req := httptest.NewRequest("POST", "/test", strings.NewReader("test body"))
			if tt.contentLength != "" {
				req.Header.Set("Content-Length", tt.contentLength)
			}
			w := httptest.NewRecorder()

			handler.ServeHTTP(w, req)

			assert.Equal(t, tt.expectedStatus, w.Code)
		})
	}
}

func TestAllowedMethods(t *testing.T) {
	t.Parallel()

	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
	})

	allowedMethods := []string{"GET", "POST"}
	methodMiddleware := middleware.AllowedMethods(allowedMethods...)
	handler := methodMiddleware(baseHandler)

	tests := []struct {
		name           string
		method         string
		expectedStatus int
	}{
		{
			name:           "allowed GET",
			method:         "GET",
			expectedStatus: http.StatusOK,
		},
		{
			name:           "allowed POST",
			method:         "POST",
			expectedStatus: http.StatusOK,
		},
		{
			name:           "disallowed PUT",
			method:         "PUT",
			expectedStatus: http.StatusMethodNotAllowed,
		},
		{
			name:           "disallowed DELETE",
			method:         "DELETE",
			expectedStatus: http.StatusMethodNotAllowed,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			req := httptest.NewRequest(tt.method, "/test", nil)
			w := httptest.NewRecorder()

			handler.ServeHTTP(w, req)

			assert.Equal(t, tt.expectedStatus, w.Code)
		})
	}
}

func TestLogging(t *testing.T) {
	t.Parallel()

	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("OK"))
	})

	loggingMiddleware := middleware.Logging()
	handler := loggingMiddleware(baseHandler)

	req := httptest.NewRequest("GET", "/test", nil)
	w := httptest.NewRecorder()

	handler.ServeHTTP(w, req)

	assert.Equal(t, http.StatusOK, w.Code)
	assert.Equal(t, "OK", w.Body.String())
}

func TestBasicAuthMiddleware(t *testing.T) {
	t.Parallel()

	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
	})

	username := "admin"
	password := "secret"
	authMiddleware := middleware.BasicAuthMiddleware(username, password)
	handler := authMiddleware(baseHandler)

	tests := []struct {
		name           string
		authHeader     string
		expectedStatus int
	}{
		{
			name:           "valid credentials",
			authHeader:     "Basic YWRtaW46c2VjcmV0", // admin:secret in base64
			expectedStatus: http.StatusOK,
		},
		{
			name:           "invalid credentials",
			authHeader:     "Basic aW52YWxpZDppbnZhbGlk", // invalid:invalid in base64
			expectedStatus: http.StatusUnauthorized,
		},
		{
			name:           "no auth header",
			authHeader:     "",
			expectedStatus: http.StatusUnauthorized,
		},
		{
			name:           "malformed auth header",
			authHeader:     "Bearer token",
			expectedStatus: http.StatusUnauthorized,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			req := httptest.NewRequest("GET", "/test", nil)
			if tt.authHeader != "" {
				req.Header.Set("Authorization", tt.authHeader)
			}
			w := httptest.NewRecorder()

			handler.ServeHTTP(w, req)

			assert.Equal(t, tt.expectedStatus, w.Code)
		})
	}
}

func TestAPIKeyMiddleware(t *testing.T) {
	t.Parallel()

	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
	})

	validKeys := []string{"key1", "key2", "key3"}
	apiKeyMiddleware := middleware.APIKeyMiddleware(validKeys)
	handler := apiKeyMiddleware(baseHandler)

	tests := []struct {
		name           string
		apiKey         string
		expectedStatus int
	}{
		{
			name:           "valid API key",
			apiKey:         "key1",
			expectedStatus: http.StatusOK,
		},
		{
			name:           "another valid API key",
			apiKey:         "key3",
			expectedStatus: http.StatusOK,
		},
		{
			name:           "invalid API key",
			apiKey:         "invalid_key",
			expectedStatus: http.StatusUnauthorized,
		},
		{
			name:           "no API key",
			apiKey:         "",
			expectedStatus: http.StatusUnauthorized,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			req := httptest.NewRequest("GET", "/test", nil)
			if tt.apiKey != "" {
				req.Header.Set("X-API-Key", tt.apiKey)
			}
			w := httptest.NewRecorder()

			handler.ServeHTTP(w, req)

			assert.Equal(t, tt.expectedStatus, w.Code)
		})
	}
}

func TestIPWhitelistMiddleware(t *testing.T) {
	t.Parallel()

	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
	})

	allowedIPs := []string{"127.0.0.1", "192.168.1.100"}
	ipMiddleware := middleware.IPWhitelistMiddleware(allowedIPs)
	handler := ipMiddleware(baseHandler)

	tests := []struct {
		name           string
		remoteAddr     string
		xForwardedFor  string
		expectedStatus int
	}{
		{
			name:           "allowed IP",
			remoteAddr:     "127.0.0.1:12345",
			expectedStatus: http.StatusOK,
		},
		{
			name:           "another allowed IP",
			remoteAddr:     "192.168.1.100:54321",
			expectedStatus: http.StatusOK,
		},
		{
			name:           "disallowed IP",
			remoteAddr:     "192.168.1.50:12345",
			expectedStatus: http.StatusForbidden,
		},
		{
			name:           "allowed via X-Forwarded-For",
			remoteAddr:     "192.168.1.50:12345",
			xForwardedFor:  "127.0.0.1",
			expectedStatus: http.StatusOK,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			req := httptest.NewRequest("GET", "/test", nil)
			req.RemoteAddr = tt.remoteAddr
			if tt.xForwardedFor != "" {
				req.Header.Set("X-Forwarded-For", tt.xForwardedFor)
			}
			w := httptest.NewRecorder()

			handler.ServeHTTP(w, req)

			assert.Equal(t, tt.expectedStatus, w.Code)
		})
	}
}

func TestTimeoutMiddleware(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name           string
		timeout        time.Duration
		handlerDelay   time.Duration
		expectedStatus int
	}{
		{
			name:           "request completes within timeout",
			timeout:        100 * time.Millisecond,
			handlerDelay:   50 * time.Millisecond,
			expectedStatus: http.StatusOK,
		},
		{
			name:           "request times out",
			timeout:        50 * time.Millisecond,
			handlerDelay:   100 * time.Millisecond,
			expectedStatus: http.StatusServiceUnavailable,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				time.Sleep(tt.handlerDelay)
				w.WriteHeader(http.StatusOK)
			})

			timeoutMiddleware := middleware.TimeoutMiddleware(tt.timeout)
			handler := timeoutMiddleware(baseHandler)

			req := httptest.NewRequest("GET", "/test", nil)
			w := httptest.NewRecorder()

			handler.ServeHTTP(w, req)

			assert.Equal(t, tt.expectedStatus, w.Code)
		})
	}
}

func TestRateLimit(t *testing.T) {
	t.Parallel()

	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
	})

	rateLimitMiddleware := middleware.RateLimit()
	handler := rateLimitMiddleware(baseHandler)

	// Make multiple requests rapidly
	for i := 0; i < 5; i++ {
		req := httptest.NewRequest("GET", "/test", nil)
		req.RemoteAddr = "127.0.0.1:12345"
		w := httptest.NewRecorder()

		handler.ServeHTTP(w, req)

		// First few requests should succeed
		if i < 3 {
			assert.Equal(t, http.StatusOK, w.Code)
		}
		// Later requests might be rate limited depending on implementation
	}
}

// Benchmark tests
func BenchmarkCORS(b *testing.B) {
	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
	})

	corsMiddleware := middleware.CORS([]string{"*"})
	handler := corsMiddleware(baseHandler)

	req := httptest.NewRequest("GET", "/test", nil)
	req.Header.Set("Origin", "https://example.com")

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		w := httptest.NewRecorder()
		handler.ServeHTTP(w, req)
	}
}

func BenchmarkSecurity(b *testing.B) {
	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
	})

	securityMiddleware := middleware.Security()
	handler := securityMiddleware(baseHandler)

	req := httptest.NewRequest("GET", "/test", nil)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		w := httptest.NewRecorder()
		handler.ServeHTTP(w, req)
	}
}

func BenchmarkChain(b *testing.B) {
	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
	})

	middleware1 := func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			next.ServeHTTP(w, r)
		})
	}

	middleware2 := func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			next.ServeHTTP(w, r)
		})
	}

	handler := middleware.Chain(baseHandler, middleware1, middleware2)
	req := httptest.NewRequest("GET", "/test", nil)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		w := httptest.NewRecorder()
		handler.ServeHTTP(w, req)
	}
}