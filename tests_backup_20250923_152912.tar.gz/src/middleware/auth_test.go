package middleware_test

import (
	"context"
	"crypto/subtle"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/golang-jwt/jwt/v5"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// JWT middleware implementation for HTTP requests
type JWTMiddleware struct {
	secret        string
	publicPaths   []string
	adminPaths    []string
	cookieAuth    bool
	sessionStore  map[string]Session
	sessionMutex  sync.RWMutex
	rateLimiter   *AuthRateLimiter
}

// Session represents an authenticated session
type Session struct {
	UserID    string    `json:"user_id"`
	Username  string    `json:"username"`
	Roles     []string  `json:"roles"`
	ExpiresAt time.Time `json:"expires_at"`
	CreatedAt time.Time `json:"created_at"`
	LastUsed  time.Time `json:"last_used"`
}

// UserClaims for HTTP JWT tokens
type UserClaims struct {
	UserID   string   `json:"user_id"`
	Username string   `json:"username"`
	Roles    []string `json:"roles"`
	jwt.RegisteredClaims
}

// AuthRateLimiter tracks failed authentication attempts
type AuthRateLimiter struct {
	attempts map[string][]time.Time
	mutex    sync.RWMutex
	limit    int
	window   time.Duration
}

// NewAuthRateLimiter creates a new authentication rate limiter
func NewAuthRateLimiter(limit int, window time.Duration) *AuthRateLimiter {
	return &AuthRateLimiter{
		attempts: make(map[string][]time.Time),
		limit:    limit,
		window:   window,
	}
}

// IsAllowed checks if an IP is allowed to attempt authentication
func (rl *AuthRateLimiter) IsAllowed(ip string) bool {
	rl.mutex.Lock()
	defer rl.mutex.Unlock()

	now := time.Now()
	attempts := rl.attempts[ip]

	// Remove expired attempts
	var validAttempts []time.Time
	for _, attempt := range attempts {
		if now.Sub(attempt) <= rl.window {
			validAttempts = append(validAttempts, attempt)
		}
	}

	rl.attempts[ip] = validAttempts
	return len(validAttempts) < rl.limit
}

// RecordFailure records a failed authentication attempt
func (rl *AuthRateLimiter) RecordFailure(ip string) {
	rl.mutex.Lock()
	defer rl.mutex.Unlock()

	now := time.Now()
	rl.attempts[ip] = append(rl.attempts[ip], now)
}

// Reset clears all attempts for an IP (on successful auth)
func (rl *AuthRateLimiter) Reset(ip string) {
	rl.mutex.Lock()
	defer rl.mutex.Unlock()
	delete(rl.attempts, ip)
}

// NewJWTMiddleware creates a new JWT middleware
func NewJWTMiddleware(secret string) *JWTMiddleware {
	return &JWTMiddleware{
		secret:       secret,
		publicPaths:  []string{"/health", "/version", "/login"},
		adminPaths:   []string{"/admin/delete", "/admin/purge"},
		cookieAuth:   true,
		sessionStore: make(map[string]Session),
		rateLimiter:  NewAuthRateLimiter(5, 15*time.Minute), // 5 attempts per 15 minutes
	}
}

// WithPublicPaths sets the public paths that don't require authentication
func (j *JWTMiddleware) WithPublicPaths(paths []string) *JWTMiddleware {
	j.publicPaths = paths
	return j
}

// WithAdminPaths sets the paths that require admin role
func (j *JWTMiddleware) WithAdminPaths(paths []string) *JWTMiddleware {
	j.adminPaths = paths
	return j
}

// WithCookieAuth enables/disables cookie-based authentication
func (j *JWTMiddleware) WithCookieAuth(enabled bool) *JWTMiddleware {
	j.cookieAuth = enabled
	return j
}

// Middleware returns the HTTP middleware function
func (j *JWTMiddleware) Middleware() func(http.Handler) http.Handler {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			// Check if path is public
			if j.isPublicPath(r.URL.Path) {
				next.ServeHTTP(w, r)
				return
			}

			// Extract client IP for rate limiting
			clientIP := getClientIP(r)

			// Check rate limiting
			if !j.rateLimiter.IsAllowed(clientIP) {
				http.Error(w, "Too many failed authentication attempts", http.StatusTooManyRequests)
				return
			}

			// Extract and validate token
			claims, err := j.extractAndValidateToken(r)
			if err != nil {
				j.rateLimiter.RecordFailure(clientIP)
				http.Error(w, err.Error(), http.StatusUnauthorized)
				return
			}

			// Reset rate limiter on successful auth
			j.rateLimiter.Reset(clientIP)

			// Check admin permissions
			if j.isAdminPath(r.URL.Path) && !j.hasAdminRole(claims.Roles) {
				http.Error(w, "Admin role required", http.StatusForbidden)
				return
			}

			// Create or update session
			sessionID := j.createOrUpdateSession(claims)

			// Add user context
			ctx := context.WithValue(r.Context(), "user_claims", claims)
			ctx = context.WithValue(ctx, "user_id", claims.UserID)
			ctx = context.WithValue(ctx, "username", claims.Username)
			ctx = context.WithValue(ctx, "session_id", sessionID)

			// Set session cookie
			if j.cookieAuth {
				http.SetCookie(w, &http.Cookie{
					Name:     "session_id",
					Value:    sessionID,
					Path:     "/",
					HttpOnly: true,
					Secure:   r.TLS != nil,
					SameSite: http.SameSiteStrictMode,
					MaxAge:   3600, // 1 hour
				})
			}

			next.ServeHTTP(w, r.WithContext(ctx))
		})
	}
}

// extractAndValidateToken extracts token from header, query param, or session
func (j *JWTMiddleware) extractAndValidateToken(r *http.Request) (*UserClaims, error) {
	var tokenString string

	// Try Authorization header first
	authHeader := r.Header.Get("Authorization")
	if strings.HasPrefix(authHeader, "Bearer ") {
		tokenString = strings.TrimPrefix(authHeader, "Bearer ")
	}

	// Try query parameter
	if tokenString == "" {
		tokenString = r.URL.Query().Get("token")
	}

	// Try session cookie
	if tokenString == "" && j.cookieAuth {
		if cookie, err := r.Cookie("session_id"); err == nil {
			if session, ok := j.getSession(cookie.Value); ok {
				// Validate session
				if time.Now().After(session.ExpiresAt) {
					j.deleteSession(cookie.Value)
					return nil, fmt.Errorf("session expired")
				}

				// Update last used
				session.LastUsed = time.Now()
				j.updateSession(cookie.Value, session)

				return &UserClaims{
					UserID:   session.UserID,
					Username: session.Username,
					Roles:    session.Roles,
				}, nil
			}
		}
	}

	if tokenString == "" {
		return nil, fmt.Errorf("missing authentication token")
	}

	// Parse and validate JWT token
	token, err := jwt.ParseWithClaims(tokenString, &UserClaims{}, func(token *jwt.Token) (interface{}, error) {
		if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, fmt.Errorf("unexpected signing method: %v", token.Header["alg"])
		}
		return []byte(j.secret), nil
	})

	if err != nil {
		return nil, fmt.Errorf("invalid token: %v", err)
	}

	claims, ok := token.Claims.(*UserClaims)
	if !ok || !token.Valid {
		return nil, fmt.Errorf("invalid token claims")
	}

	// Check expiration
	if claims.ExpiresAt != nil && claims.ExpiresAt.Time.Before(time.Now()) {
		return nil, fmt.Errorf("token expired")
	}

	// Validate required claims
	if claims.UserID == "" || claims.Username == "" {
		return nil, fmt.Errorf("invalid token: missing required claims")
	}

	return claims, nil
}

// Session management methods
func (j *JWTMiddleware) createOrUpdateSession(claims *UserClaims) string {
	j.sessionMutex.Lock()
	defer j.sessionMutex.Unlock()

	sessionID := generateSessionID(claims.UserID)
	session := Session{
		UserID:    claims.UserID,
		Username:  claims.Username,
		Roles:     claims.Roles,
		ExpiresAt: time.Now().Add(time.Hour),
		CreatedAt: time.Now(),
		LastUsed:  time.Now(),
	}

	j.sessionStore[sessionID] = session
	return sessionID
}

func (j *JWTMiddleware) getSession(sessionID string) (Session, bool) {
	j.sessionMutex.RLock()
	defer j.sessionMutex.RUnlock()
	session, ok := j.sessionStore[sessionID]
	return session, ok
}

func (j *JWTMiddleware) updateSession(sessionID string, session Session) {
	j.sessionMutex.Lock()
	defer j.sessionMutex.Unlock()
	j.sessionStore[sessionID] = session
}

func (j *JWTMiddleware) deleteSession(sessionID string) {
	j.sessionMutex.Lock()
	defer j.sessionMutex.Unlock()
	delete(j.sessionStore, sessionID)
}

// Helper methods
func (j *JWTMiddleware) isPublicPath(path string) bool {
	for _, publicPath := range j.publicPaths {
		if path == publicPath || strings.HasPrefix(path, publicPath) {
			return true
		}
	}
	return false
}

func (j *JWTMiddleware) isAdminPath(path string) bool {
	for _, adminPath := range j.adminPaths {
		if path == adminPath || strings.HasPrefix(path, adminPath) {
			return true
		}
	}
	return false
}

func (j *JWTMiddleware) hasAdminRole(roles []string) bool {
	for _, role := range roles {
		if role == "admin" || role == "administrator" {
			return true
		}
	}
	return false
}

func generateSessionID(userID string) string {
	return base64.URLEncoding.EncodeToString([]byte(fmt.Sprintf("%s:%d", userID, time.Now().UnixNano())))
}

// Helper function to extract client IP
func getClientIP(r *http.Request) string {
	// Check X-Forwarded-For header first
	if xff := r.Header.Get("X-Forwarded-For"); xff != "" {
		ips := strings.Split(xff, ",")
		if len(ips) > 0 {
			return strings.TrimSpace(ips[0])
		}
	}

	// Check X-Real-IP header
	if xri := r.Header.Get("X-Real-IP"); xri != "" {
		return xri
	}

	// Fall back to RemoteAddr
	ip := r.RemoteAddr
	if strings.Contains(ip, ":") {
		if host, _, err := splitHostPort(ip); err == nil {
			return host
		}
	}
	return ip
}

func splitHostPort(hostport string) (host, port string, err error) {
	i := strings.LastIndex(hostport, ":")
	if i < 0 {
		return "", "", fmt.Errorf("missing port in address")
	}
	return hostport[:i], hostport[i+1:], nil
}

// Helper function to create test JWT tokens
func createTestJWTToken(t *testing.T, userID, username string, roles []string, secret string, expiresIn time.Duration) string {
	claims := &UserClaims{
		UserID:   userID,
		Username: username,
		Roles:    roles,
		RegisteredClaims: jwt.RegisteredClaims{
			ExpiresAt: jwt.NewNumericDate(time.Now().Add(expiresIn)),
			IssuedAt:  jwt.NewNumericDate(time.Now()),
			NotBefore: jwt.NewNumericDate(time.Now()),
		},
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	tokenString, err := token.SignedString([]byte(secret))
	require.NoError(t, err)
	return tokenString
}

// Test suite for JWT Authentication Middleware
func TestJWTMiddleware(t *testing.T) {
	t.Parallel()

	secret := "test-jwt-secret-key"
	middleware := NewJWTMiddleware(secret)

	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// Extract user info from context
		userID, _ := r.Context().Value("user_id").(string)
		username, _ := r.Context().Value("username").(string)
		sessionID, _ := r.Context().Value("session_id").(string)

		response := map[string]interface{}{
			"message":    "success",
			"user_id":    userID,
			"username":   username,
			"session_id": sessionID,
		}

		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(response)
	})

	tests := []struct {
		name           string
		setupRequest   func(*http.Request)
		path           string
		expectedStatus int
		expectedBody   string
		checkHeaders   func(t *testing.T, w *httptest.ResponseRecorder)
		checkSession   func(t *testing.T, middleware *JWTMiddleware)
	}{
		{
			name: "public path without authentication",
			setupRequest: func(r *http.Request) {
				// No authentication needed
			},
			path:           "/health",
			expectedStatus: http.StatusOK,
			expectedBody:   "success",
		},
		{
			name: "valid JWT token in Authorization header",
			setupRequest: func(r *http.Request) {
				token := createTestJWTToken(t, "user123", "testuser", []string{"user"}, secret, time.Hour)
				r.Header.Set("Authorization", "Bearer "+token)
			},
			path:           "/protected",
			expectedStatus: http.StatusOK,
			expectedBody:   "user123",
			checkHeaders: func(t *testing.T, w *httptest.ResponseRecorder) {
				// Check that session cookie is set
				cookies := w.Header().Values("Set-Cookie")
				assert.NotEmpty(t, cookies)
				found := false
				for _, cookie := range cookies {
					if strings.Contains(cookie, "session_id=") {
						found = true
						assert.Contains(t, cookie, "HttpOnly")
						assert.Contains(t, cookie, "SameSite=Strict")
						break
					}
				}
				assert.True(t, found, "Session cookie should be set")
			},
			checkSession: func(t *testing.T, middleware *JWTMiddleware) {
				// Verify session was created
				assert.NotEmpty(t, middleware.sessionStore)
			},
		},
		{
			name: "valid JWT token in query parameter",
			setupRequest: func(r *http.Request) {
				token := createTestJWTToken(t, "user456", "queryuser", []string{"user"}, secret, time.Hour)
				q := r.URL.Query()
				q.Set("token", token)
				r.URL.RawQuery = q.Encode()
			},
			path:           "/api/data",
			expectedStatus: http.StatusOK,
			expectedBody:   "user456",
		},
		{
			name: "admin token for admin-only path",
			setupRequest: func(r *http.Request) {
				token := createTestJWTToken(t, "admin123", "adminuser", []string{"admin"}, secret, time.Hour)
				r.Header.Set("Authorization", "Bearer "+token)
			},
			path:           "/admin/delete",
			expectedStatus: http.StatusOK,
			expectedBody:   "admin123",
		},
		{
			name: "non-admin token for admin-only path",
			setupRequest: func(r *http.Request) {
				token := createTestJWTToken(t, "user789", "regularuser", []string{"user"}, secret, time.Hour)
				r.Header.Set("Authorization", "Bearer "+token)
			},
			path:           "/admin/purge",
			expectedStatus: http.StatusForbidden,
			expectedBody:   "Admin role required",
		},
		{
			name: "missing authentication token",
			setupRequest: func(r *http.Request) {
				// No token provided
			},
			path:           "/protected",
			expectedStatus: http.StatusUnauthorized,
			expectedBody:   "missing authentication token",
		},
		{
			name: "invalid JWT token format",
			setupRequest: func(r *http.Request) {
				r.Header.Set("Authorization", "Bearer invalid.jwt.token")
			},
			path:           "/protected",
			expectedStatus: http.StatusUnauthorized,
			expectedBody:   "invalid token",
		},
		{
			name: "expired JWT token",
			setupRequest: func(r *http.Request) {
				token := createTestJWTToken(t, "user999", "expireduser", []string{"user"}, secret, -time.Hour)
				r.Header.Set("Authorization", "Bearer "+token)
			},
			path:           "/protected",
			expectedStatus: http.StatusUnauthorized,
			expectedBody:   "invalid token",
		},
		{
			name: "invalid JWT signature",
			setupRequest: func(r *http.Request) {
				token := createTestJWTToken(t, "user888", "fakeuser", []string{"user"}, "wrong-secret", time.Hour)
				r.Header.Set("Authorization", "Bearer "+token)
			},
			path:           "/protected",
			expectedStatus: http.StatusUnauthorized,
			expectedBody:   "invalid token",
		},
		{
			name: "malformed Authorization header",
			setupRequest: func(r *http.Request) {
				r.Header.Set("Authorization", "InvalidFormat sometoken")
			},
			path:           "/protected",
			expectedStatus: http.StatusUnauthorized,
			expectedBody:   "missing authentication token",
		},
		{
			name: "empty Bearer token",
			setupRequest: func(r *http.Request) {
				r.Header.Set("Authorization", "Bearer ")
			},
			path:           "/protected",
			expectedStatus: http.StatusUnauthorized,
			expectedBody:   "missing authentication token",
		},
	}

	for i, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			handler := middleware.Middleware()(baseHandler)

			req := httptest.NewRequest("GET", tt.path, nil)
			req.RemoteAddr = fmt.Sprintf("192.168.1.%d:12345", i+1) // Unique IP for each test
			tt.setupRequest(req)

			w := httptest.NewRecorder()
			handler.ServeHTTP(w, req)

			assert.Equal(t, tt.expectedStatus, w.Code)
			assert.Contains(t, w.Body.String(), tt.expectedBody)

			if tt.checkHeaders != nil {
				tt.checkHeaders(t, w)
			}

			if tt.checkSession != nil {
				tt.checkSession(t, middleware)
			}
		})
	}
}

// Test session-based authentication
func TestJWTMiddleware_SessionAuthentication(t *testing.T) {
	t.Parallel()

	secret := "test-session-secret"
	middleware := NewJWTMiddleware(secret)

	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		userID, _ := r.Context().Value("user_id").(string)
		w.WriteHeader(http.StatusOK)
		w.Write([]byte(userID))
	})

	// First, create a session by authenticating with JWT
	token := createTestJWTToken(t, "session123", "sessionuser", []string{"user"}, secret, time.Hour)

	handler := middleware.Middleware()(baseHandler)

	// First request with JWT token to create session
	req1 := httptest.NewRequest("GET", "/protected", nil)
	req1.Header.Set("Authorization", "Bearer "+token)
	w1 := httptest.NewRecorder()

	handler.ServeHTTP(w1, req1)

	assert.Equal(t, http.StatusOK, w1.Code)
	assert.Equal(t, "session123", w1.Body.String())

	// Extract session cookie
	cookies := w1.Header().Values("Set-Cookie")
	require.NotEmpty(t, cookies)

	var sessionCookie string
	for _, cookie := range cookies {
		if strings.Contains(cookie, "session_id=") {
			parts := strings.Split(cookie, ";")
			for _, part := range parts {
				if strings.HasPrefix(strings.TrimSpace(part), "session_id=") {
					sessionCookie = strings.TrimPrefix(strings.TrimSpace(part), "session_id=")
					break
				}
			}
			break
		}
	}
	require.NotEmpty(t, sessionCookie)

	// Second request using only session cookie
	req2 := httptest.NewRequest("GET", "/protected", nil)
	req2.AddCookie(&http.Cookie{
		Name:  "session_id",
		Value: sessionCookie,
	})
	w2 := httptest.NewRecorder()

	handler.ServeHTTP(w2, req2)

	assert.Equal(t, http.StatusOK, w2.Code)
	assert.Equal(t, "session123", w2.Body.String())
}

// Test session expiration
func TestJWTMiddleware_SessionExpiration(t *testing.T) {
	t.Parallel()

	secret := "test-expiry-secret"
	middleware := NewJWTMiddleware(secret)

	// Create expired session manually
	sessionID := "expired-session"
	expiredSession := Session{
		UserID:    "expired123",
		Username:  "expireduser",
		Roles:     []string{"user"},
		ExpiresAt: time.Now().Add(-time.Hour), // Expired 1 hour ago
		CreatedAt: time.Now().Add(-2 * time.Hour),
		LastUsed:  time.Now().Add(-time.Hour),
	}

	middleware.sessionStore[sessionID] = expiredSession

	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("success"))
	})

	handler := middleware.Middleware()(baseHandler)

	req := httptest.NewRequest("GET", "/protected", nil)
	req.AddCookie(&http.Cookie{
		Name:  "session_id",
		Value: sessionID,
	})
	w := httptest.NewRecorder()

	handler.ServeHTTP(w, req)

	assert.Equal(t, http.StatusUnauthorized, w.Code)
	assert.Contains(t, w.Body.String(), "session expired")

	// Verify session was deleted
	_, exists := middleware.sessionStore[sessionID]
	assert.False(t, exists)
}

// Test rate limiting for failed authentication attempts
func TestJWTMiddleware_AuthenticationRateLimit(t *testing.T) {
	t.Parallel()

	secret := "test-ratelimit-secret"
	middleware := NewJWTMiddleware(secret)

	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		userID, _ := r.Context().Value("user_id").(string)
		w.WriteHeader(http.StatusOK)
		w.Write([]byte(userID))
	})

	handler := middleware.Middleware()(baseHandler)

	// Make multiple failed authentication attempts from unique IP for this test
	testIP := "192.168.1.200:12345" // Unique IP for this test
	for i := 0; i < 6; i++ { // Rate limit is 5 attempts
		req := httptest.NewRequest("GET", "/protected", nil)
		req.Header.Set("Authorization", "Bearer invalid-token")
		req.RemoteAddr = testIP // Same IP for all requests

		w := httptest.NewRecorder()
		handler.ServeHTTP(w, req)

		if i < 5 {
			// First 5 attempts should get 401 Unauthorized
			assert.Equal(t, http.StatusUnauthorized, w.Code)
			assert.Contains(t, w.Body.String(), "invalid token")
		} else {
			// 6th attempt should be rate limited
			assert.Equal(t, http.StatusTooManyRequests, w.Code)
			assert.Contains(t, w.Body.String(), "Too many failed authentication attempts")
		}
	}

	// Reset middleware rate limiter manually to test successful auth after rate limit
	middleware.rateLimiter.Reset("192.168.1.200")

	// Test that after reset, successful authentication works
	token := createTestJWTToken(t, "reset123", "resetuser", []string{"user"}, secret, time.Hour)
	req := httptest.NewRequest("GET", "/protected", nil)
	req.Header.Set("Authorization", "Bearer "+token)
	req.RemoteAddr = testIP // Same IP

	w := httptest.NewRecorder()
	handler.ServeHTTP(w, req)

	assert.Equal(t, http.StatusOK, w.Code)
	assert.Contains(t, w.Body.String(), "reset123")

	// Verify that new failed attempts work after successful auth
	req2 := httptest.NewRequest("GET", "/protected", nil)
	req2.Header.Set("Authorization", "Bearer another-invalid-token")
	req2.RemoteAddr = testIP

	w2 := httptest.NewRecorder()
	handler.ServeHTTP(w2, req2)

	assert.Equal(t, http.StatusUnauthorized, w2.Code) // Not rate limited
}

// Test token validation with missing claims
func TestJWTMiddleware_TokenMissingClaims(t *testing.T) {
	t.Parallel()

	secret := "test-claims-secret"
	middleware := NewJWTMiddleware(secret)

	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("success"))
	})

	handler := middleware.Middleware()(baseHandler)

	tests := []struct {
		name     string
		userID   string
		username string
		roles    []string
	}{
		{
			name:     "missing user ID",
			userID:   "",
			username: "testuser",
			roles:    []string{"user"},
		},
		{
			name:     "missing username",
			userID:   "user123",
			username: "",
			roles:    []string{"user"},
		},
		{
			name:     "missing both user ID and username",
			userID:   "",
			username: "",
			roles:    []string{"user"},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			token := createTestJWTToken(t, tt.userID, tt.username, tt.roles, secret, time.Hour)

			req := httptest.NewRequest("GET", "/protected", nil)
			req.Header.Set("Authorization", "Bearer "+token)

			w := httptest.NewRecorder()
			handler.ServeHTTP(w, req)

			assert.Equal(t, http.StatusUnauthorized, w.Code)
			assert.Contains(t, w.Body.String(), "missing required claims")
		})
	}
}

// Test concurrent authentication requests
func TestJWTMiddleware_ConcurrentRequests(t *testing.T) {
	t.Parallel()

	secret := "test-concurrent-secret"
	middleware := NewJWTMiddleware(secret)

	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		userID, _ := r.Context().Value("user_id").(string)
		w.WriteHeader(http.StatusOK)
		w.Write([]byte(userID))
	})

	handler := middleware.Middleware()(baseHandler)

	const numRequests = 100
	results := make(chan string, numRequests)
	errors := make(chan error, numRequests)

	// Run concurrent requests
	for i := 0; i < numRequests; i++ {
		go func(id int) {
			userID := fmt.Sprintf("user%d", id)
			token := createTestJWTToken(t, userID, fmt.Sprintf("user%d", id), []string{"user"}, secret, time.Hour)

			req := httptest.NewRequest("GET", "/protected", nil)
			req.Header.Set("Authorization", "Bearer "+token)
			req.RemoteAddr = fmt.Sprintf("192.168.1.%d:12345", id%255+1) // Different IPs

			w := httptest.NewRecorder()
			handler.ServeHTTP(w, req)

			if w.Code == http.StatusOK {
				results <- w.Body.String()
			} else {
				errors <- fmt.Errorf("unexpected status: %d, body: %s", w.Code, w.Body.String())
			}
		}(i)
	}

	// Collect results
	successCount := 0
	errorCount := 0

	for i := 0; i < numRequests; i++ {
		select {
		case result := <-results:
			assert.Contains(t, result, "user")
			successCount++
		case err := <-errors:
			t.Logf("Error: %v", err)
			errorCount++
		case <-time.After(5 * time.Second):
			t.Fatal("Timeout waiting for concurrent requests")
		}
	}

	assert.Equal(t, numRequests, successCount)
	assert.Equal(t, 0, errorCount)

	// Verify sessions were created
	assert.Equal(t, numRequests, len(middleware.sessionStore))
}

// Test API Key middleware compatibility
func TestJWTMiddleware_WithAPIKeyFallback(t *testing.T) {
	t.Parallel()

	// Test that JWT middleware can work alongside API key middleware
	secret := "test-combined-secret"
	jwtMiddleware := NewJWTMiddleware(secret)

	// Create a combined middleware that tries JWT first, then falls back to API key
	validAPIKeys := []string{"api-key-123", "api-key-456"}

	combinedHandler := func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			// Try JWT first
			if authHeader := r.Header.Get("Authorization"); strings.HasPrefix(authHeader, "Bearer ") {
				jwtMiddleware.Middleware()(next).ServeHTTP(w, r)
				return
			}

			// Fall back to API key
			apiKey := r.Header.Get("X-API-Key")
			if apiKey == "" {
				apiKey = r.URL.Query().Get("api_key")
			}

			validKey := false
			for _, key := range validAPIKeys {
				if subtle.ConstantTimeCompare([]byte(apiKey), []byte(key)) == 1 {
					validKey = true
					break
				}
			}

			if !validKey {
				http.Error(w, "Invalid API key", http.StatusUnauthorized)
				return
			}

			// Add API key context
			ctx := context.WithValue(r.Context(), "auth_method", "api_key")
			ctx = context.WithValue(ctx, "api_key", apiKey)
			next.ServeHTTP(w, r.WithContext(ctx))
		})
	}

	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		authMethod, _ := r.Context().Value("auth_method").(string)
		if authMethod == "api_key" {
			w.WriteHeader(http.StatusOK)
			w.Write([]byte("api-key-auth"))
		} else {
			userID, _ := r.Context().Value("user_id").(string)
			w.WriteHeader(http.StatusOK)
			w.Write([]byte("jwt-auth:" + userID))
		}
	})

	handler := combinedHandler(baseHandler)

	// Test JWT authentication
	token := createTestJWTToken(t, "jwt123", "jwtuser", []string{"user"}, secret, time.Hour)
	req1 := httptest.NewRequest("GET", "/protected", nil)
	req1.Header.Set("Authorization", "Bearer "+token)
	w1 := httptest.NewRecorder()

	handler.ServeHTTP(w1, req1)

	assert.Equal(t, http.StatusOK, w1.Code)
	assert.Equal(t, "jwt-auth:jwt123", w1.Body.String())

	// Test API key authentication
	req2 := httptest.NewRequest("GET", "/protected", nil)
	req2.Header.Set("X-API-Key", "api-key-123")
	w2 := httptest.NewRecorder()

	handler.ServeHTTP(w2, req2)

	assert.Equal(t, http.StatusOK, w2.Code)
	assert.Equal(t, "api-key-auth", w2.Body.String())

	// Test invalid authentication
	req3 := httptest.NewRequest("GET", "/protected", nil)
	w3 := httptest.NewRecorder()

	handler.ServeHTTP(w3, req3)

	assert.Equal(t, http.StatusUnauthorized, w3.Code)
}

// Test middleware configuration options
func TestJWTMiddleware_Configuration(t *testing.T) {
	t.Parallel()

	secret := "test-config-secret"

	// Test custom configuration
	middleware := NewJWTMiddleware(secret).
		WithPublicPaths([]string{"/custom-public", "/api/status"}).
		WithAdminPaths([]string{"/custom-admin"}).
		WithCookieAuth(false)

	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("success"))
	})

	handler := middleware.Middleware()(baseHandler)

	// Test custom public path
	req1 := httptest.NewRequest("GET", "/custom-public", nil)
	w1 := httptest.NewRecorder()
	handler.ServeHTTP(w1, req1)
	assert.Equal(t, http.StatusOK, w1.Code)

	// Test custom admin path
	adminToken := createTestJWTToken(t, "admin123", "admin", []string{"admin"}, secret, time.Hour)
	req2 := httptest.NewRequest("GET", "/custom-admin", nil)
	req2.Header.Set("Authorization", "Bearer "+adminToken)
	w2 := httptest.NewRecorder()
	handler.ServeHTTP(w2, req2)
	assert.Equal(t, http.StatusOK, w2.Code)

	// Test that cookies are not set when disabled
	userToken := createTestJWTToken(t, "user123", "user", []string{"user"}, secret, time.Hour)
	req3 := httptest.NewRequest("GET", "/protected", nil)
	req3.Header.Set("Authorization", "Bearer "+userToken)
	w3 := httptest.NewRecorder()
	handler.ServeHTTP(w3, req3)
	assert.Equal(t, http.StatusOK, w3.Code)

	cookies := w3.Header().Values("Set-Cookie")
	assert.Empty(t, cookies) // No cookies should be set
}

// Benchmark tests
func BenchmarkJWTMiddleware_ValidToken(b *testing.B) {
	secret := "benchmark-secret"
	middleware := NewJWTMiddleware(secret)

	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
	})

	handler := middleware.Middleware()(baseHandler)
	token := createTestJWTTokenBench(b, "benchmark123", "benchuser", []string{"user"}, secret, time.Hour)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		req := httptest.NewRequest("GET", "/protected", nil)
		req.Header.Set("Authorization", "Bearer "+token)
		w := httptest.NewRecorder()
		handler.ServeHTTP(w, req)
	}
}

func BenchmarkJWTMiddleware_PublicPath(b *testing.B) {
	secret := "benchmark-public-secret"
	middleware := NewJWTMiddleware(secret)

	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
	})

	handler := middleware.Middleware()(baseHandler)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		req := httptest.NewRequest("GET", "/health", nil)
		w := httptest.NewRecorder()
		handler.ServeHTTP(w, req)
	}
}

func BenchmarkJWTMiddleware_SessionAuth(b *testing.B) {
	secret := "benchmark-session-secret"
	middleware := NewJWTMiddleware(secret)

	// Pre-create session
	sessionID := generateSessionID("benchmark123")
	middleware.sessionStore[sessionID] = Session{
		UserID:    "benchmark123",
		Username:  "benchuser",
		Roles:     []string{"user"},
		ExpiresAt: time.Now().Add(time.Hour),
		CreatedAt: time.Now(),
		LastUsed:  time.Now(),
	}

	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
	})

	handler := middleware.Middleware()(baseHandler)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		req := httptest.NewRequest("GET", "/protected", nil)
		req.AddCookie(&http.Cookie{
			Name:  "session_id",
			Value: sessionID,
		})
		w := httptest.NewRecorder()
		handler.ServeHTTP(w, req)
	}
}

// Test rate limiter separately
func TestAuthRateLimiter(t *testing.T) {
	t.Parallel()

	rateLimiter := NewAuthRateLimiter(3, time.Minute) // 3 attempts per minute

	ip := "192.168.1.1"

	// Test initial allowance
	for i := 0; i < 3; i++ {
		assert.True(t, rateLimiter.IsAllowed(ip))
		rateLimiter.RecordFailure(ip)
	}

	// 4th attempt should be blocked
	assert.False(t, rateLimiter.IsAllowed(ip))

	// Reset should allow again
	rateLimiter.Reset(ip)
	assert.True(t, rateLimiter.IsAllowed(ip))
}

func TestAuthRateLimiter_TimeWindow(t *testing.T) {
	t.Parallel()

	rateLimiter := NewAuthRateLimiter(2, 100*time.Millisecond) // 2 attempts per 100ms

	ip := "192.168.1.2"

	// Use up the limit
	assert.True(t, rateLimiter.IsAllowed(ip))
	rateLimiter.RecordFailure(ip)
	assert.True(t, rateLimiter.IsAllowed(ip))
	rateLimiter.RecordFailure(ip)

	// Should be blocked now
	assert.False(t, rateLimiter.IsAllowed(ip))

	// Wait for window to expire
	time.Sleep(150 * time.Millisecond)

	// Should be allowed again
	assert.True(t, rateLimiter.IsAllowed(ip))
}

func TestAuthRateLimiter_MultipleIPs(t *testing.T) {
	t.Parallel()

	rateLimiter := NewAuthRateLimiter(1, time.Minute) // 1 attempt per minute

	ip1 := "192.168.1.1"
	ip2 := "192.168.1.2"

	// Block IP1
	assert.True(t, rateLimiter.IsAllowed(ip1))
	rateLimiter.RecordFailure(ip1)
	assert.False(t, rateLimiter.IsAllowed(ip1))

	// IP2 should still be allowed
	assert.True(t, rateLimiter.IsAllowed(ip2))
	rateLimiter.RecordFailure(ip2)
	assert.False(t, rateLimiter.IsAllowed(ip2))

	// Both should be blocked
	assert.False(t, rateLimiter.IsAllowed(ip1))
	assert.False(t, rateLimiter.IsAllowed(ip2))
}

// Test helper function to create JWT token for benchmarks
func createTestJWTTokenBench(b *testing.B, userID, username string, roles []string, secret string, expiresIn time.Duration) string {
	claims := &UserClaims{
		UserID:   userID,
		Username: username,
		Roles:    roles,
		RegisteredClaims: jwt.RegisteredClaims{
			ExpiresAt: jwt.NewNumericDate(time.Now().Add(expiresIn)),
			IssuedAt:  jwt.NewNumericDate(time.Now()),
			NotBefore: jwt.NewNumericDate(time.Now()),
		},
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	tokenString, err := token.SignedString([]byte(secret))
	if err != nil {
		b.Fatalf("Failed to create test token: %v", err)
	}
	return tokenString
}