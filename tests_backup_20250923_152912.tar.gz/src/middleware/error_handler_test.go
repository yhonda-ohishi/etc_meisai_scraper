package middleware_test

import (
	"bytes"
	"encoding/json"
	"errors"
	"log"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/stretchr/testify/assert"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
	"github.com/yhonda-ohishi/etc_meisai/src/middleware"
)

func TestErrorHandler(t *testing.T) {
	t.Parallel()

	var logBuffer bytes.Buffer
	logger := log.New(&logBuffer, "", 0)

	tests := []struct {
		name           string
		handler        http.HandlerFunc
		expectedStatus int
		expectPanic    bool
		expectedLog    string
	}{
		{
			name: "normal handler execution",
			handler: func(w http.ResponseWriter, r *http.Request) {
				w.WriteHeader(http.StatusOK)
				w.Write([]byte("OK"))
			},
			expectedStatus: http.StatusOK,
			expectPanic:    false,
		},
		{
			name: "handler panic",
			handler: func(w http.ResponseWriter, r *http.Request) {
				panic("test panic")
			},
			expectedStatus: http.StatusInternalServerError,
			expectPanic:    true,
			expectedLog:    "Panic recovered: test panic",
		},
		{
			name: "handler with error status",
			handler: func(w http.ResponseWriter, r *http.Request) {
				w.WriteHeader(http.StatusNotFound)
				w.Write([]byte("Not Found"))
			},
			expectedStatus: http.StatusNotFound,
			expectPanic:    false,
		},
		{
			name: "handler panic with error object",
			handler: func(w http.ResponseWriter, r *http.Request) {
				panic(errors.New("error object panic"))
			},
			expectedStatus: http.StatusInternalServerError,
			expectPanic:    true,
			expectedLog:    "Panic recovered: error object panic",
		},
		{
			name: "handler panic with nil",
			handler: func(w http.ResponseWriter, r *http.Request) {
				panic(nil)
			},
			expectedStatus: http.StatusInternalServerError,
			expectPanic:    true,
			expectedLog:    "Panic recovered: <nil>",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			logBuffer.Reset()

			errorHandler := middleware.ErrorHandler(logger)
			handler := errorHandler(tt.handler)

			req := httptest.NewRequest("GET", "/test", nil)
			req.Header.Set("X-Request-ID", "test-request-123")
			w := httptest.NewRecorder()

			// Execute the handler
			handler.ServeHTTP(w, req)

			// Check response status
			assert.Equal(t, tt.expectedStatus, w.Code)

			if tt.expectPanic {
				// Verify panic was recovered and logged
				logOutput := logBuffer.String()
				assert.Contains(t, logOutput, tt.expectedLog)
				assert.Contains(t, logOutput, "goroutine") // Stack trace

				// Verify error response structure
				var errorResp middleware.ErrorResponse
				err := json.Unmarshal(w.Body.Bytes(), &errorResp)
				assert.NoError(t, err)
				assert.Equal(t, "internal_error", errorResp.Error)
				assert.Equal(t, "An internal error occurred", errorResp.Message)
				assert.Equal(t, http.StatusInternalServerError, errorResp.StatusCode)
				assert.Equal(t, "test-request-123", errorResp.RequestID)
			} else {
				// No panic, log should be empty
				assert.Empty(t, logBuffer.String())
			}
		})
	}
}

func TestErrorHandler_ConcurrentRequests(t *testing.T) {
	t.Parallel()

	var logBuffer bytes.Buffer
	logger := log.New(&logBuffer, "", 0)

	// Handler that panics every other request
	var requestCount int
	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		requestCount++
		if requestCount%2 == 0 {
			panic("panic on even request")
		}
		w.WriteHeader(http.StatusOK)
	})

	errorHandler := middleware.ErrorHandler(logger)
	handler := errorHandler(baseHandler)

	// Run concurrent requests
	const numRequests = 10
	done := make(chan bool, numRequests)

	for i := 0; i < numRequests; i++ {
		go func(id int) {
			req := httptest.NewRequest("GET", "/test", nil)
			w := httptest.NewRecorder()
			handler.ServeHTTP(w, req)

			// Even requests should get error, odd should be OK
			if id%2 == 0 {
				assert.Equal(t, http.StatusOK, w.Code)
			}
			done <- true
		}(i)
	}

	// Wait for all requests to complete
	for i := 0; i < numRequests; i++ {
		<-done
	}
}

func TestConvertGRPCError(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name           string
		grpcError      error
		expectedStatus int
		expectedCode   string
	}{
		{
			name:           "OK status",
			grpcError:      status.Error(codes.OK, "success"),
			expectedStatus: http.StatusOK,
			expectedCode:   "ok",
		},
		{
			name:           "Canceled",
			grpcError:      status.Error(codes.Canceled, "request canceled"),
			expectedStatus: http.StatusRequestTimeout,
			expectedCode:   "canceled",
		},
		{
			name:           "Unknown",
			grpcError:      status.Error(codes.Unknown, "unknown error"),
			expectedStatus: http.StatusInternalServerError,
			expectedCode:   "unknown_error",
		},
		{
			name:           "InvalidArgument",
			grpcError:      status.Error(codes.InvalidArgument, "invalid argument"),
			expectedStatus: http.StatusBadRequest,
			expectedCode:   "invalid_argument",
		},
		{
			name:           "DeadlineExceeded",
			grpcError:      status.Error(codes.DeadlineExceeded, "deadline exceeded"),
			expectedStatus: http.StatusGatewayTimeout,
			expectedCode:   "deadline_exceeded",
		},
		{
			name:           "NotFound",
			grpcError:      status.Error(codes.NotFound, "not found"),
			expectedStatus: http.StatusNotFound,
			expectedCode:   "not_found",
		},
		{
			name:           "AlreadyExists",
			grpcError:      status.Error(codes.AlreadyExists, "already exists"),
			expectedStatus: http.StatusConflict,
			expectedCode:   "already_exists",
		},
		{
			name:           "PermissionDenied",
			grpcError:      status.Error(codes.PermissionDenied, "permission denied"),
			expectedStatus: http.StatusForbidden,
			expectedCode:   "permission_denied",
		},
		{
			name:           "ResourceExhausted",
			grpcError:      status.Error(codes.ResourceExhausted, "resource exhausted"),
			expectedStatus: http.StatusTooManyRequests,
			expectedCode:   "resource_exhausted",
		},
		{
			name:           "FailedPrecondition",
			grpcError:      status.Error(codes.FailedPrecondition, "failed precondition"),
			expectedStatus: http.StatusPreconditionFailed,
			expectedCode:   "failed_precondition",
		},
		{
			name:           "Aborted",
			grpcError:      status.Error(codes.Aborted, "aborted"),
			expectedStatus: http.StatusConflict,
			expectedCode:   "aborted",
		},
		{
			name:           "OutOfRange",
			grpcError:      status.Error(codes.OutOfRange, "out of range"),
			expectedStatus: http.StatusBadRequest,
			expectedCode:   "out_of_range",
		},
		{
			name:           "Unimplemented",
			grpcError:      status.Error(codes.Unimplemented, "not implemented"),
			expectedStatus: http.StatusNotImplemented,
			expectedCode:   "not_implemented",
		},
		{
			name:           "Internal",
			grpcError:      status.Error(codes.Internal, "internal error"),
			expectedStatus: http.StatusInternalServerError,
			expectedCode:   "internal_error",
		},
		{
			name:           "Unavailable",
			grpcError:      status.Error(codes.Unavailable, "service unavailable"),
			expectedStatus: http.StatusServiceUnavailable,
			expectedCode:   "service_unavailable",
		},
		{
			name:           "DataLoss",
			grpcError:      status.Error(codes.DataLoss, "data loss"),
			expectedStatus: http.StatusInternalServerError,
			expectedCode:   "data_loss",
		},
		{
			name:           "Unauthenticated",
			grpcError:      status.Error(codes.Unauthenticated, "unauthenticated"),
			expectedStatus: http.StatusUnauthorized,
			expectedCode:   "unauthenticated",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			httpStatus, errorResp := middleware.ConvertGRPCError(tt.grpcError)

			assert.Equal(t, tt.expectedStatus, httpStatus)

			// OK status may return nil error response
			if tt.grpcError != nil && status.Code(tt.grpcError) != codes.OK {
				assert.NotNil(t, errorResp)
				assert.Equal(t, tt.expectedCode, errorResp.Error)
				assert.Equal(t, tt.expectedStatus, errorResp.StatusCode)

				// Get message from gRPC status
				st, _ := status.FromError(tt.grpcError)
				assert.Equal(t, st.Message(), errorResp.Message)
			}
		})
	}
}

func TestConvertGRPCError_WithFieldDetails(t *testing.T) {
	t.Parallel()

	// Test error message with field information
	grpcErr := status.Error(codes.InvalidArgument, "validation failed field: email")
	httpStatus, errorResp := middleware.ConvertGRPCError(grpcErr)

	assert.Equal(t, http.StatusBadRequest, httpStatus)
	assert.NotNil(t, errorResp.Details)
	assert.Equal(t, "email", errorResp.Details["field"])
}

func TestValidationError(t *testing.T) {
	t.Parallel()

	errorResp := middleware.ValidationError("email", "invalid email format")

	assert.Equal(t, "validation_error", errorResp.Error)
	assert.Equal(t, "invalid email format", errorResp.Message)
	assert.Equal(t, http.StatusBadRequest, errorResp.StatusCode)
	assert.Equal(t, "email", errorResp.Details["field"])
}

func TestNotFoundError(t *testing.T) {
	t.Parallel()

	errorResp := middleware.NotFoundError("user")

	assert.Equal(t, "not_found", errorResp.Error)
	assert.Equal(t, "user not found", errorResp.Message)
	assert.Equal(t, http.StatusNotFound, errorResp.StatusCode)
	assert.Equal(t, "user", errorResp.Details["resource"])
}

func TestServiceUnavailableError(t *testing.T) {
	t.Parallel()

	errorResp := middleware.ServiceUnavailableError("database")

	assert.Equal(t, "service_unavailable", errorResp.Error)
	assert.Equal(t, "Service temporarily unavailable", errorResp.Message)
	assert.Equal(t, http.StatusServiceUnavailable, errorResp.StatusCode)
	assert.Equal(t, "database", errorResp.Details["service"])
}

func TestErrorHandler_WriteJSON(t *testing.T) {
	t.Parallel()

	var logBuffer bytes.Buffer
	logger := log.New(&logBuffer, "", 0)

	// Handler that panics with JSON serialization
	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		panic("json error")
	})

	errorHandler := middleware.ErrorHandler(logger)
	handler := errorHandler(baseHandler)

	req := httptest.NewRequest("GET", "/test", nil)
	w := httptest.NewRecorder()

	handler.ServeHTTP(w, req)

	// Content-Type should be set by error handler
	assert.Equal(t, "application/json", w.Header().Get("Content-Type"))
}

func TestGRPCErrorHandler(t *testing.T) {
	t.Parallel()

	var logBuffer bytes.Buffer
	logger := log.New(&logBuffer, "", 0)

	// Test that GRPCErrorHandler passes through normal responses
	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("success"))
	})

	grpcErrorMiddleware := middleware.GRPCErrorHandler(logger)
	handler := grpcErrorMiddleware(baseHandler)

	req := httptest.NewRequest("GET", "/test", nil)
	w := httptest.NewRecorder()

	handler.ServeHTTP(w, req)

	// Should pass through normally
	assert.Equal(t, http.StatusOK, w.Code)
	assert.Equal(t, "success", w.Body.String())
}

func TestGRPCErrorHandler_NilLogger(t *testing.T) {
	t.Parallel()

	// Test that nil logger doesn't cause panic
	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("OK"))
	})

	// Should not panic with nil logger
	grpcErrorMiddleware := middleware.GRPCErrorHandler(nil)
	handler := grpcErrorMiddleware(baseHandler)

	req := httptest.NewRequest("GET", "/test", nil)
	w := httptest.NewRecorder()

	// Should handle request gracefully even with nil logger
	assert.NotPanics(t, func() {
		handler.ServeHTTP(w, req)
	})

	assert.Equal(t, http.StatusOK, w.Code)
}

// Benchmark tests
func BenchmarkErrorHandler(b *testing.B) {
	var logBuffer bytes.Buffer
	logger := log.New(&logBuffer, "", 0)

	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
	})

	errorHandler := middleware.ErrorHandler(logger)
	handler := errorHandler(baseHandler)

	req := httptest.NewRequest("GET", "/test", nil)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		w := httptest.NewRecorder()
		handler.ServeHTTP(w, req)
	}
}

func BenchmarkErrorHandler_WithPanic(b *testing.B) {
	var logBuffer bytes.Buffer
	logger := log.New(&logBuffer, "", 0)

	baseHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		panic("benchmark panic")
	})

	errorHandler := middleware.ErrorHandler(logger)
	handler := errorHandler(baseHandler)

	req := httptest.NewRequest("GET", "/test", nil)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		w := httptest.NewRecorder()
		handler.ServeHTTP(w, req)
		logBuffer.Reset()
	}
}

func BenchmarkConvertGRPCError(b *testing.B) {
	grpcErr := status.Error(codes.InvalidArgument, "invalid input")

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		middleware.ConvertGRPCError(grpcErr)
	}
}