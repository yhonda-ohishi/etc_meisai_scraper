package config_test

import (
	"os"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/yhonda-ohishi/etc_meisai/src/config"
)

func TestLoadAccountsFromArrayEnv(t *testing.T) {
	tests := []struct {
		name   string
		setup  func()
		verify func(*testing.T, *config.AccountsConfig)
		errMsg string
	}{
		{
			name: "json array format corporate accounts",
			setup: func() {
				os.Setenv("ETC_CORP_ACCOUNTS", `[{"name":"Corp A","user_id":"user1","password":"pass1","password_corp":"corp1","card_numbers":["1234","5678"]}]`)
			},
			verify: func(t *testing.T, cfg *config.AccountsConfig) {
				assert.Len(t, cfg.Accounts, 1)
				acc := cfg.Accounts[0]
				assert.Equal(t, "Corp A", acc.Name)
				assert.Equal(t, "user1", acc.UserID)
				assert.Equal(t, "pass1", acc.Password)
				assert.Equal(t, "corp1", acc.PasswordCorp)
				assert.Equal(t, config.AccountTypeCorporate, acc.Type)
				assert.True(t, acc.Active)
			},
		},
		{
			name: "json array format personal accounts",
			setup: func() {
				os.Setenv("ETC_PERSONAL_ACCOUNTS", `[{"name":"Personal A","user_id":"user2","password":"pass2","card_numbers":["9012"]}]`)
			},
			verify: func(t *testing.T, cfg *config.AccountsConfig) {
				assert.Len(t, cfg.Accounts, 1)
				acc := cfg.Accounts[0]
				assert.Equal(t, "Personal A", acc.Name)
				assert.Equal(t, "user2", acc.UserID)
				assert.Equal(t, "pass2", acc.Password)
				assert.Empty(t, acc.PasswordCorp)
				assert.Equal(t, config.AccountTypePersonal, acc.Type)
				assert.True(t, acc.Active)
			},
		},
		{
			name: "simple format corporate accounts",
			setup: func() {
				os.Setenv("ETC_CORP_ACCOUNTS", "Corp1:user1:pass1:corp1;Corp2:user2:pass2:corp2")
			},
			verify: func(t *testing.T, cfg *config.AccountsConfig) {
				assert.Len(t, cfg.Accounts, 2)
				assert.Equal(t, "Corp1", cfg.Accounts[0].Name)
				assert.Equal(t, "user1", cfg.Accounts[0].UserID)
				assert.Equal(t, "pass1", cfg.Accounts[0].Password)
				assert.Equal(t, "corp1", cfg.Accounts[0].PasswordCorp)
				assert.Equal(t, config.AccountTypeCorporate, cfg.Accounts[0].Type)
				assert.Equal(t, "Corp2", cfg.Accounts[1].Name)
				assert.Equal(t, "user2", cfg.Accounts[1].UserID)
				assert.Equal(t, "pass2", cfg.Accounts[1].Password)
				assert.Equal(t, "corp2", cfg.Accounts[1].PasswordCorp)
			},
		},
		{
			name: "simple format personal accounts",
			setup: func() {
				os.Setenv("ETC_PERSONAL_ACCOUNTS", "Personal3:user3:pass3;Personal4:user4:pass4")
			},
			verify: func(t *testing.T, cfg *config.AccountsConfig) {
				assert.Len(t, cfg.Accounts, 2)
				assert.Equal(t, "Personal3", cfg.Accounts[0].Name)
				assert.Equal(t, "user3", cfg.Accounts[0].UserID)
				assert.Equal(t, "pass3", cfg.Accounts[0].Password)
				assert.Empty(t, cfg.Accounts[0].PasswordCorp)
				assert.Equal(t, config.AccountTypePersonal, cfg.Accounts[0].Type)
				assert.Equal(t, "Personal4", cfg.Accounts[1].Name)
				assert.Equal(t, "user4", cfg.Accounts[1].UserID)
				assert.Equal(t, "pass4", cfg.Accounts[1].Password)
			},
		},
		{
			name: "delimited format multiple fields",
			setup: func() {
				os.Setenv("ETC_CORP_ACCOUNTS_DELIMITED", "user1|pass1|corp1|name1|1234,5678;user2|pass2|corp2|name2|9012")
				os.Setenv("ETC_ACCOUNTS_DELIMITER", "|")
				os.Setenv("ETC_ACCOUNTS_SEPARATOR", ";")
				os.Setenv("ETC_CARDS_SEPARATOR", ",")
			},
			verify: func(t *testing.T, cfg *config.AccountsConfig) {
				if len(cfg.Accounts) > 0 {
					acc := cfg.Accounts[0]
					assert.Equal(t, "user1", acc.UserID)
					assert.Equal(t, "pass1", acc.Password)
					assert.Equal(t, config.AccountTypeCorporate, acc.Type)
				}
			},
		},
		{
			name: "mixed corporate and personal accounts",
			setup: func() {
				os.Setenv("ETC_CORP_ACCOUNTS", `[{"name":"Corp B","user_id":"corp_user","password":"corp_pass"}]`)
				os.Setenv("ETC_PERSONAL_ACCOUNTS", `[{"name":"Personal B","user_id":"personal_user","password":"personal_pass"}]`)
			},
			verify: func(t *testing.T, cfg *config.AccountsConfig) {
				assert.Len(t, cfg.Accounts, 2)

				// Corporate account comes first
				assert.Equal(t, "Corp B", cfg.Accounts[0].Name)
				assert.Equal(t, config.AccountTypeCorporate, cfg.Accounts[0].Type)

				// Personal account
				assert.Equal(t, "Personal B", cfg.Accounts[1].Name)
				assert.Equal(t, config.AccountTypePersonal, cfg.Accounts[1].Type)
			},
		},
		{
			name: "invalid json falls back to simple format",
			setup: func() {
				os.Setenv("ETC_CORP_ACCOUNTS", `{invalid json but valid simple: user:pass:corp`)
			},
			verify: func(t *testing.T, cfg *config.AccountsConfig) {
				// Should parse as simple format after JSON fails
				// The exact behavior depends on parseSimpleFormat implementation
				assert.NotNil(t, cfg)
			},
		},
		{
			name: "empty environment variables",
			setup: func() {
				// No environment variables set
			},
			verify: func(t *testing.T, cfg *config.AccountsConfig) {
				assert.Len(t, cfg.Accounts, 0)
			},
		},
		{
			name: "multiple accounts in json array",
			setup: func() {
				os.Setenv("ETC_CORP_ACCOUNTS", `[
					{"name":"Corp 1","user_id":"user1","password":"pass1"},
					{"name":"Corp 2","user_id":"user2","password":"pass2"},
					{"name":"Corp 3","user_id":"user3","password":"pass3"}
				]`)
			},
			verify: func(t *testing.T, cfg *config.AccountsConfig) {
				assert.Len(t, cfg.Accounts, 3)
				for i, acc := range cfg.Accounts {
					assert.Equal(t, config.AccountTypeCorporate, acc.Type)
					assert.True(t, acc.Active)
					assert.NotEmpty(t, acc.UserID)
					assert.NotEmpty(t, acc.Password)
					assert.Contains(t, acc.Name, "Corp")
					assert.Equal(t, cfg.Accounts[i].UserID, acc.UserID)
				}
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// Clear environment
			os.Clearenv()

			// Setup test environment
			tt.setup()

			// Load accounts
			accounts, err := config.LoadAccountsFromArrayEnv()

			assert.NoError(t, err)
			assert.NotNil(t, accounts)

			// Verify
			if tt.verify != nil {
				tt.verify(t, accounts)
			}

			// Clear environment again
			os.Clearenv()
		})
	}
}

func TestParseSimpleFormat(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name     string
		input    string
		accType  config.AccountType
		expected []config.ETCAccount
	}{
		{
			name:    "single corporate account",
			input:   "Corp1:user1:pass1:corp1",
			accType: config.AccountTypeCorporate,
			expected: []config.ETCAccount{
				{
					Name:         "Corp1",
					UserID:       "user1",
					Password:     "pass1",
					PasswordCorp: "corp1",
					Type:         config.AccountTypeCorporate,
				},
			},
		},
		{
			name:    "multiple corporate accounts",
			input:   "Corp1:user1:pass1:corp1;Corp2:user2:pass2:corp2",
			accType: config.AccountTypeCorporate,
			expected: []config.ETCAccount{
				{Name: "Corp1", UserID: "user1", Password: "pass1", PasswordCorp: "corp1", Type: config.AccountTypeCorporate},
				{Name: "Corp2", UserID: "user2", Password: "pass2", PasswordCorp: "corp2", Type: config.AccountTypeCorporate},
			},
		},
		{
			name:    "personal accounts without corp password",
			input:   "Personal3:user3:pass3;Personal4:user4:pass4",
			accType: config.AccountTypePersonal,
			expected: []config.ETCAccount{
				{Name: "Personal3", UserID: "user3", Password: "pass3", Type: config.AccountTypePersonal},
				{Name: "Personal4", UserID: "user4", Password: "pass4", Type: config.AccountTypePersonal},
			},
		},
		{
			name:    "with spaces",
			input:   " Corp1 : user1 : pass1 : corp1 ",
			accType: config.AccountTypeCorporate,
			expected: []config.ETCAccount{
				{Name: "Corp1", UserID: "user1", Password: "pass1", PasswordCorp: "corp1", Type: config.AccountTypeCorporate},
			},
		},
		{
			name:     "empty input",
			input:    "",
			accType:  config.AccountTypePersonal,
			expected: []config.ETCAccount{},
		},
		{
			name:     "invalid format",
			input:    "invalid_no_colon",
			accType:  config.AccountTypePersonal,
			expected: []config.ETCAccount{},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// This test assumes parseSimpleFormat is exported or we test it indirectly
			// through LoadAccountsFromArrayEnv

			// Setup environment to test indirectly
			os.Clearenv()
			if tt.accType == config.AccountTypeCorporate {
				os.Setenv("ETC_CORP_ACCOUNTS", tt.input)
			} else {
				os.Setenv("ETC_PERSONAL_ACCOUNTS", tt.input)
			}

			accounts, err := config.LoadAccountsFromArrayEnv()
			assert.NoError(t, err)

			// Verify the accounts match expected (if parseSimpleFormat was called)
			if tt.input != "" && tt.input != "invalid_no_colon" {
				assert.Len(t, accounts.Accounts, len(tt.expected))
				for i, expected := range tt.expected {
					if i < len(accounts.Accounts) {
						actual := accounts.Accounts[i]
						assert.Equal(t, expected.Name, actual.Name)
						assert.Equal(t, expected.UserID, actual.UserID)
						assert.Equal(t, expected.Password, actual.Password)
						if tt.accType == config.AccountTypeCorporate {
							assert.Equal(t, expected.PasswordCorp, actual.PasswordCorp)
						}
						assert.Equal(t, expected.Type, actual.Type)
					}
				}
			}

			os.Clearenv()
		})
	}
}