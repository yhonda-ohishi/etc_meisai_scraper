package config_test

import (
	"encoding/json"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"github.com/yhonda-ohishi/etc_meisai/src/config"
)

// T008-A: Environment variable override testing
func TestT008A_EnvironmentVariableOverrides(t *testing.T) {
	tests := []struct {
		name     string
		envVars  map[string]string
		verify   func(*testing.T, *config.Settings)
		teardown func()
	}{
		{
			name: "database environment overrides",
			envVars: map[string]string{
				"DB_DRIVER":   "postgres",
				"DB_HOST":     "db.example.com",
				"DB_PORT":     "5432",
				"DB_NAME":     "test_database",
				"DB_USER":     "test_user",
				"DB_PASSWORD": "test_password",
				"DB_PATH":     "/custom/path/db.sqlite",
			},
			verify: func(t *testing.T, s *config.Settings) {
				assert.Equal(t, "postgres", s.Database.Driver)
				assert.Equal(t, "db.example.com", s.Database.Host)
				assert.Equal(t, 5432, s.Database.Port)
				assert.Equal(t, "test_database", s.Database.Database)
				assert.Equal(t, "test_user", s.Database.Username)
				assert.Equal(t, "test_password", s.Database.Password)
				assert.Equal(t, "/custom/path/db.sqlite", s.Database.Path)
			},
		},
		{
			name: "grpc environment overrides",
			envVars: map[string]string{
				"GRPC_DB_SERVICE_ADDRESS": "grpc.example.com:50052",
				"GRPC_TIMEOUT":            "60s",
				"GRPC_MAX_RETRIES":        "5",
				"GRPC_ENABLE_TLS":         "true",
				"GRPC_CERT_FILE":          "/certs/client.crt",
				"GRPC_KEY_FILE":           "/certs/client.key",
				"GRPC_CA_FILE":            "/certs/ca.crt",
			},
			verify: func(t *testing.T, s *config.Settings) {
				assert.Equal(t, "grpc.example.com:50052", s.GRPC.DBServiceAddress)
				assert.Equal(t, 60*time.Second, s.GRPC.Timeout)
				assert.Equal(t, 5, s.GRPC.MaxRetries)
				assert.True(t, s.GRPC.EnableTLS)
				assert.Equal(t, "/certs/client.crt", s.GRPC.CertFile)
				assert.Equal(t, "/certs/client.key", s.GRPC.KeyFile)
				assert.Equal(t, "/certs/ca.crt", s.GRPC.CAFile)
			},
		},
		{
			name: "server environment overrides",
			envVars: map[string]string{
				"SERVER_HOST": "api.example.com",
				"SERVER_PORT": "9000",
			},
			verify: func(t *testing.T, s *config.Settings) {
				assert.Equal(t, "api.example.com", s.Server.Host)
				assert.Equal(t, 9000, s.Server.Port)
			},
		},
		{
			name: "scraping environment overrides",
			envVars: map[string]string{
				"SCRAPING_MAX_WORKERS": "10",
				"SCRAPING_HEADLESS":    "false",
			},
			verify: func(t *testing.T, s *config.Settings) {
				assert.Equal(t, 10, s.Scraping.MaxWorkers)
				assert.False(t, s.Scraping.HeadlessBrowser)
			},
		},
		{
			name: "import environment overrides",
			envVars: map[string]string{
				"IMPORT_BATCH_SIZE": "2000",
				"IMPORT_TEMP_DIR":   "/custom/temp",
			},
			verify: func(t *testing.T, s *config.Settings) {
				assert.Equal(t, 2000, s.Import.BatchSize)
				assert.Equal(t, "/custom/temp", s.Import.TempDir)
			},
		},
		{
			name: "logging environment overrides",
			envVars: map[string]string{
				"LOG_LEVEL": "debug",
				"LOG_PATH":  "/var/log/custom",
				"LOG_JSON":  "false",
			},
			verify: func(t *testing.T, s *config.Settings) {
				assert.Equal(t, "debug", s.Logging.Level)
				assert.Equal(t, "/var/log/custom", s.Logging.OutputPath)
				assert.False(t, s.Logging.EnableJSON)
			},
		},
		{
			name: "partial overrides preserve defaults",
			envVars: map[string]string{
				"DB_HOST":     "custom-host",
				"SERVER_PORT": "9090",
			},
			verify: func(t *testing.T, s *config.Settings) {
				// Overridden values
				assert.Equal(t, "custom-host", s.Database.Host)
				assert.Equal(t, 9090, s.Server.Port)
				// Preserved defaults
				assert.Equal(t, "gorm", s.Database.Driver)
				assert.Equal(t, 3306, s.Database.Port)
				assert.Equal(t, "0.0.0.0", s.Server.Host)
				assert.Equal(t, "localhost:50051", s.GRPC.DBServiceAddress)
			},
		},
		{
			name: "invalid values fall back to defaults",
			envVars: map[string]string{
				"DB_PORT":              "invalid_port",
				"SERVER_PORT":          "not_a_number",
				"GRPC_TIMEOUT":         "invalid_duration",
				"GRPC_MAX_RETRIES":     "not_int",
				"SCRAPING_MAX_WORKERS": "invalid",
				"IMPORT_BATCH_SIZE":    "invalid",
			},
			verify: func(t *testing.T, s *config.Settings) {
				// Should use defaults when parsing fails
				assert.Equal(t, 3306, s.Database.Port)
				assert.Equal(t, 8080, s.Server.Port)
				assert.Equal(t, 30*time.Second, s.GRPC.Timeout)
				assert.Equal(t, 3, s.GRPC.MaxRetries)
				assert.Equal(t, 5, s.Scraping.MaxWorkers)
				assert.Equal(t, 1000, s.Import.BatchSize)
			},
		},
		{
			name: "boolean environment variables",
			envVars: map[string]string{
				"GRPC_ENABLE_TLS":    "TRUE",
				"SCRAPING_HEADLESS":  "False",
				"LOG_JSON":           "true",
			},
			verify: func(t *testing.T, s *config.Settings) {
				assert.True(t, s.GRPC.EnableTLS)
				assert.False(t, s.Scraping.HeadlessBrowser)
				assert.True(t, s.Logging.EnableJSON)
			},
		},
		{
			name: "environment override priority",
			envVars: map[string]string{
				"DB_HOST":        "env-host",
				"DB_PORT":        "5432",
				"SERVER_HOST":    "env-server",
				"LOG_LEVEL":      "error",
			},
			verify: func(t *testing.T, s *config.Settings) {
				// Environment should override defaults
				assert.Equal(t, "env-host", s.Database.Host)
				assert.Equal(t, 5432, s.Database.Port)
				assert.Equal(t, "env-server", s.Server.Host)
				assert.Equal(t, "error", s.Logging.Level)
				// Unset values should remain defaults
				assert.Equal(t, "gorm", s.Database.Driver)
				assert.Equal(t, 8080, s.Server.Port)
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// Clear environment
			clearEnv()

			// Set test environment variables
			for key, value := range tt.envVars {
				os.Setenv(key, value)
			}

			// Load settings
			settings := config.LoadFromEnv()

			// Verify results
			tt.verify(t, settings)

			// Cleanup
			clearEnv()
			if tt.teardown != nil {
				tt.teardown()
			}
		})
	}
}

// T008-B: Configuration file validation testing with malformed JSON/YAML
func TestT008B_ConfigurationFileValidation(t *testing.T) {
	tests := []struct {
		name    string
		content string
		wantErr bool
		errMsg  string
		verify  func(*testing.T, *config.Settings)
	}{
		{
			name: "valid complete JSON config",
			content: `{
				"database": {
					"driver": "postgres",
					"host": "localhost",
					"port": 5432,
					"database": "test_db",
					"username": "user",
					"password": "pass",
					"max_connections": 50,
					"max_idle_connections": 10,
					"connection_timeout": 60,
					"path": "/data/test.db"
				},
				"server": {
					"host": "0.0.0.0",
					"port": 9000,
					"read_timeout": 45,
					"write_timeout": 45,
					"max_body_size": 67108864
				},
				"grpc": {
					"db_service_address": "grpc.example.com:50051",
					"timeout": 45000000000,
					"max_retries": 5,
					"retry_delay": 2000000000,
					"enable_tls": true,
					"cert_file": "/certs/client.crt",
					"key_file": "/certs/client.key",
					"ca_file": "/certs/ca.crt"
				},
				"scraping": {
					"max_workers": 10,
					"retry_count": 5,
					"retry_delay": 10000000000,
					"request_timeout": 60000000000,
					"headless_browser": false
				},
				"import": {
					"batch_size": 2000,
					"max_file_size": 209715200,
					"temp_directory": "/tmp/custom",
					"allowed_formats": [".csv", ".xlsx", ".json"],
					"duplicate_check": false
				},
				"logging": {
					"level": "debug",
					"output_path": "/logs/custom",
					"max_size_mb": 200,
					"max_backups": 14,
					"max_age_days": 60,
					"enable_console": false,
					"enable_json": true
				}
			}`,
			wantErr: false,
			verify: func(t *testing.T, s *config.Settings) {
				assert.Equal(t, "postgres", s.Database.Driver)
				assert.Equal(t, "localhost", s.Database.Host)
				assert.Equal(t, 5432, s.Database.Port)
				assert.Equal(t, "test_db", s.Database.Database)
				assert.Equal(t, 9000, s.Server.Port)
				assert.Equal(t, 45, s.Server.ReadTimeout)
				assert.Equal(t, "grpc.example.com:50051", s.GRPC.DBServiceAddress)
				assert.Equal(t, 45*time.Second, s.GRPC.Timeout)
				assert.True(t, s.GRPC.EnableTLS)
				assert.Equal(t, 10, s.Scraping.MaxWorkers)
				assert.False(t, s.Scraping.HeadlessBrowser)
				assert.Equal(t, 2000, s.Import.BatchSize)
				assert.Contains(t, s.Import.AllowedFormats, ".json")
				assert.Equal(t, "debug", s.Logging.Level)
				assert.False(t, s.Logging.EnableConsole)
			},
		},
		{
			name: "malformed JSON - missing braces",
			content: `{
				"database": {
					"driver": "mysql",
					"host": "localhost"
				// Missing closing brace
			`,
			wantErr: true,
			errMsg:  "failed to decode config file",
		},
		{
			name: "malformed JSON - invalid syntax",
			content: `{
				"database": {
					"driver": "mysql",
					"host": "localhost",
					"port": "invalid_json_syntax",,
				}
			}`,
			wantErr: true,
			errMsg:  "failed to decode config file",
		},
		{
			name: "malformed JSON - unquoted keys",
			content: `{
				database: {
					driver: "mysql",
					host: "localhost"
				}
			}`,
			wantErr: true,
			errMsg:  "failed to decode config file",
		},
		{
			name: "malformed JSON - trailing commas",
			content: `{
				"database": {
					"driver": "mysql",
					"host": "localhost",
				},
			}`,
			wantErr: true,
			errMsg:  "failed to decode config file",
		},
		{
			name: "malformed JSON - mixed quotes",
			content: `{
				"database": {
					'driver': "mysql",
					"host": "localhost"
				}
			}`,
			wantErr: true,
			errMsg:  "failed to decode config file",
		},
		{
			name: "invalid data types",
			content: `{
				"database": {
					"driver": "mysql",
					"host": "localhost",
					"port": "should_be_number"
				},
				"server": {
					"host": 12345,
					"port": "should_be_number"
				}
			}`,
			wantErr: true,
			errMsg:  "failed to decode config file",
		},
		{
			name: "partial config with defaults",
			content: `{
				"database": {
					"driver": "mysql",
					"host": "localhost"
				},
				"logging": {
					"level": "warn"
				}
			}`,
			wantErr: false,
			verify: func(t *testing.T, s *config.Settings) {
				// Specified values
				assert.Equal(t, "mysql", s.Database.Driver)
				assert.Equal(t, "localhost", s.Database.Host)
				assert.Equal(t, "warn", s.Logging.Level)
				// Defaults for unspecified values
				assert.Equal(t, 3306, s.Database.Port)
				assert.Equal(t, 8080, s.Server.Port)
				assert.Equal(t, "localhost:50051", s.GRPC.DBServiceAddress)
				assert.Equal(t, 5, s.Scraping.MaxWorkers)
				assert.Equal(t, 1000, s.Import.BatchSize)
			},
		},
		{
			name:    "empty JSON object",
			content: `{}`,
			wantErr: false,
			verify: func(t *testing.T, s *config.Settings) {
				// Should have all defaults
				assert.Equal(t, "gorm", s.Database.Driver)
				assert.Equal(t, "localhost", s.Database.Host)
				assert.Equal(t, 8080, s.Server.Port)
				assert.Equal(t, "localhost:50051", s.GRPC.DBServiceAddress)
				assert.Equal(t, "info", s.Logging.Level)
			},
		},
		{
			name:    "empty file",
			content: ``,
			wantErr: true,
			errMsg:  "failed to decode config file",
		},
		{
			name:    "null JSON",
			content: `null`,
			wantErr: true,
			errMsg:  "failed to decode config file",
		},
		{
			name: "array instead of object",
			content: `[
				{"database": {"driver": "mysql"}},
				{"server": {"port": 9000}}
			]`,
			wantErr: true,
			errMsg:  "failed to decode config file",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// Create temp directory and file
			tmpDir, err := os.MkdirTemp("", "config_test_*")
			require.NoError(t, err)
			defer os.RemoveAll(tmpDir)

			configFile := filepath.Join(tmpDir, "test_config.json")
			err = os.WriteFile(configFile, []byte(tt.content), 0644)
			require.NoError(t, err)

			// Test LoadFromFile
			settings, err := config.LoadFromFile(configFile)

			if tt.wantErr {
				assert.Error(t, err)
				if tt.errMsg != "" {
					assert.Contains(t, err.Error(), tt.errMsg)
				}
			} else {
				assert.NoError(t, err)
				assert.NotNil(t, settings)
				if tt.verify != nil {
					tt.verify(t, settings)
				}

				// Test validation passes for valid configs
				err = settings.Validate()
				assert.NoError(t, err)
			}
		})
	}

	// Test non-existent file
	t.Run("non-existent file", func(t *testing.T) {
		_, err := config.LoadFromFile("/non/existent/config.json")
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "failed to open config file")
	})

	// Test permission denied
	t.Run("permission denied", func(t *testing.T) {
		if os.Geteuid() == 0 {
			t.Skip("Skipping permission test when running as root")
		}

		tmpDir, err := os.MkdirTemp("", "config_test_*")
		require.NoError(t, err)
		defer os.RemoveAll(tmpDir)

		configFile := filepath.Join(tmpDir, "no_read_config.json")
		err = os.WriteFile(configFile, []byte(`{"database": {"driver": "mysql"}}`), 0644)
		require.NoError(t, err)

		// Remove read permissions
		err = os.Chmod(configFile, 0000)
		require.NoError(t, err)

		_, err = config.LoadFromFile(configFile)
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "failed to open config file")
	})
}

// T008-C: Default value fallback testing when configs are missing
func TestT008C_DefaultValueFallback(t *testing.T) {
	t.Run("new settings has all defaults", func(t *testing.T) {
		settings := config.NewSettings()

		// Database defaults
		assert.Equal(t, "gorm", settings.Database.Driver)
		assert.Equal(t, "localhost", settings.Database.Host)
		assert.Equal(t, 3306, settings.Database.Port)
		assert.Equal(t, 25, settings.Database.MaxConn)
		assert.Equal(t, 5, settings.Database.MaxIdleConn)
		assert.Equal(t, 30, settings.Database.ConnTimeout)
		assert.Equal(t, "./data/etc_meisai.db", settings.Database.Path)

		// Server defaults
		assert.Equal(t, "0.0.0.0", settings.Server.Host)
		assert.Equal(t, 8080, settings.Server.Port)
		assert.Equal(t, 30, settings.Server.ReadTimeout)
		assert.Equal(t, 30, settings.Server.WriteTimeout)
		assert.Equal(t, int64(32<<20), settings.Server.MaxBodySize)

		// gRPC defaults
		assert.Equal(t, "localhost:50051", settings.GRPC.DBServiceAddress)
		assert.Equal(t, 30*time.Second, settings.GRPC.Timeout)
		assert.Equal(t, 3, settings.GRPC.MaxRetries)
		assert.Equal(t, 1*time.Second, settings.GRPC.RetryDelay)
		assert.False(t, settings.GRPC.EnableTLS)

		// Scraping defaults
		assert.Equal(t, 5, settings.Scraping.MaxWorkers)
		assert.Equal(t, 3, settings.Scraping.RetryCount)
		assert.Equal(t, 5*time.Second, settings.Scraping.RetryDelay)
		assert.Equal(t, 30*time.Second, settings.Scraping.RequestTimeout)
		assert.True(t, settings.Scraping.HeadlessBrowser)

		// Import defaults
		assert.Equal(t, 1000, settings.Import.BatchSize)
		assert.Equal(t, int64(100<<20), settings.Import.MaxFileSize)
		assert.Equal(t, "./temp", settings.Import.TempDir)
		assert.Equal(t, []string{".csv", ".xlsx"}, settings.Import.AllowedFormats)
		assert.True(t, settings.Import.DuplicateCheck)

		// Logging defaults
		assert.Equal(t, "info", settings.Logging.Level)
		assert.Equal(t, "./logs", settings.Logging.OutputPath)
		assert.Equal(t, 100, settings.Logging.MaxSize)
		assert.Equal(t, 7, settings.Logging.MaxBackups)
		assert.Equal(t, 30, settings.Logging.MaxAge)
		assert.True(t, settings.Logging.EnableConsole)
		assert.True(t, settings.Logging.EnableJSON)
	})

	t.Run("load from env with no vars preserves defaults", func(t *testing.T) {
		clearEnv()
		settings := config.LoadFromEnv()

		// Should be identical to NewSettings()
		expected := config.NewSettings()

		assert.Equal(t, expected.Database.Driver, settings.Database.Driver)
		assert.Equal(t, expected.Database.Host, settings.Database.Host)
		assert.Equal(t, expected.Database.Port, settings.Database.Port)
		assert.Equal(t, expected.Server.Host, settings.Server.Host)
		assert.Equal(t, expected.Server.Port, settings.Server.Port)
		assert.Equal(t, expected.GRPC.DBServiceAddress, settings.GRPC.DBServiceAddress)
		assert.Equal(t, expected.GRPC.Timeout, settings.GRPC.Timeout)
		assert.Equal(t, expected.Scraping.MaxWorkers, settings.Scraping.MaxWorkers)
		assert.Equal(t, expected.Import.BatchSize, settings.Import.BatchSize)
		assert.Equal(t, expected.Logging.Level, settings.Logging.Level)
	})

	t.Run("partial env vars keep unspecified defaults", func(t *testing.T) {
		clearEnv()

		// Set only a few environment variables
		os.Setenv("DB_HOST", "custom-host")
		os.Setenv("SERVER_PORT", "9090")
		os.Setenv("LOG_LEVEL", "debug")
		defer clearEnv()

		settings := config.LoadFromEnv()

		// Changed values
		assert.Equal(t, "custom-host", settings.Database.Host)
		assert.Equal(t, 9090, settings.Server.Port)
		assert.Equal(t, "debug", settings.Logging.Level)

		// Unchanged defaults
		assert.Equal(t, "gorm", settings.Database.Driver)
		assert.Equal(t, 3306, settings.Database.Port)
		assert.Equal(t, "0.0.0.0", settings.Server.Host)
		assert.Equal(t, "localhost:50051", settings.GRPC.DBServiceAddress)
		assert.Equal(t, 30*time.Second, settings.GRPC.Timeout)
		assert.Equal(t, 5, settings.Scraping.MaxWorkers)
		assert.Equal(t, 1000, settings.Import.BatchSize)
	})

	t.Run("missing config file falls back to env then defaults", func(t *testing.T) {
		clearEnv()

		// Ensure no config.json exists
		if _, err := os.Stat("config.json"); err == nil {
			os.Rename("config.json", "config.json.backup")
			defer os.Rename("config.json.backup", "config.json")
		}

		// Set some env vars
		os.Setenv("DB_DRIVER", "mysql")
		os.Setenv("DB_HOST", "localhost")
		os.Setenv("GRPC_DB_SERVICE_ADDRESS", "localhost:50051")
		defer clearEnv()

		// Save original GlobalSettings
		originalSettings := config.GlobalSettings
		defer func() {
			config.GlobalSettings = originalSettings
		}()

		err := config.InitSettings()
		assert.NoError(t, err)
		assert.NotNil(t, config.GlobalSettings)

		// Should use env vars where set, defaults elsewhere
		assert.Equal(t, "mysql", config.GlobalSettings.Database.Driver)
		assert.Equal(t, "localhost", config.GlobalSettings.Database.Host)
		assert.Equal(t, 3306, config.GlobalSettings.Database.Port) // default
		assert.Equal(t, 8080, config.GlobalSettings.Server.Port)   // default
		assert.Equal(t, "info", config.GlobalSettings.Logging.Level) // default
	})

	t.Run("auto-correction uses sensible defaults", func(t *testing.T) {
		settings := config.NewSettings()

		// Set invalid values that should be auto-corrected
		settings.Server.ReadTimeout = 0
		settings.Server.WriteTimeout = -10
		settings.GRPC.Timeout = 0
		settings.GRPC.MaxRetries = -5
		settings.GRPC.RetryDelay = 0
		settings.Scraping.MaxWorkers = 0
		settings.Scraping.RetryCount = -1
		settings.Import.BatchSize = 0
		settings.Import.MaxFileSize = 0
		settings.Import.TempDir = ""

		err := settings.Validate()
		assert.NoError(t, err)

		// Check auto-corrected defaults
		assert.Equal(t, 30, settings.Server.ReadTimeout)
		assert.Equal(t, 30, settings.Server.WriteTimeout)
		assert.Equal(t, 30*time.Second, settings.GRPC.Timeout)
		assert.Equal(t, 0, settings.GRPC.MaxRetries)
		assert.Equal(t, 1*time.Second, settings.GRPC.RetryDelay)
		assert.Equal(t, 1, settings.Scraping.MaxWorkers)
		assert.Equal(t, 0, settings.Scraping.RetryCount)
		assert.Equal(t, 100, settings.Import.BatchSize)
		assert.Equal(t, int64(10<<20), settings.Import.MaxFileSize)
		assert.Equal(t, "./temp", settings.Import.TempDir)
	})

	t.Run("defaults are immutable between instances", func(t *testing.T) {
		settings1 := config.NewSettings()
		settings2 := config.NewSettings()

		// Modify settings1
		settings1.Database.Host = "modified-host"
		settings1.Server.Port = 9999
		settings1.Import.AllowedFormats = append(settings1.Import.AllowedFormats, ".txt")

		// settings2 should be unaffected
		assert.Equal(t, "localhost", settings2.Database.Host)
		assert.Equal(t, 8080, settings2.Server.Port)
		assert.Equal(t, []string{".csv", ".xlsx"}, settings2.Import.AllowedFormats)
	})
}

// T008-D: Configuration hot reload testing without service restart
func TestT008D_ConfigurationHotReload(t *testing.T) {
	t.Run("hot reload from file changes", func(t *testing.T) {
		tmpDir, err := os.MkdirTemp("", "hot_reload_test_*")
		require.NoError(t, err)
		defer os.RemoveAll(tmpDir)

		configFile := filepath.Join(tmpDir, "dynamic_config.json")

		// Initial config
		initialConfig := `{
			"database": {"driver": "mysql", "host": "localhost", "port": 3306},
			"server": {"host": "0.0.0.0", "port": 8080},
			"logging": {"level": "info"}
		}`
		err = os.WriteFile(configFile, []byte(initialConfig), 0644)
		require.NoError(t, err)

		// Load initial settings
		settings1, err := config.LoadFromFile(configFile)
		require.NoError(t, err)
		assert.Equal(t, "mysql", settings1.Database.Driver)
		assert.Equal(t, "localhost", settings1.Database.Host)
		assert.Equal(t, 3306, settings1.Database.Port)
		assert.Equal(t, 8080, settings1.Server.Port)
		assert.Equal(t, "info", settings1.Logging.Level)

		// Simulate file change
		time.Sleep(10 * time.Millisecond) // Ensure file timestamp changes
		updatedConfig := `{
			"database": {"driver": "postgres", "host": "db.example.com", "port": 5432},
			"server": {"host": "127.0.0.1", "port": 9090},
			"logging": {"level": "debug"}
		}`
		err = os.WriteFile(configFile, []byte(updatedConfig), 0644)
		require.NoError(t, err)

		// Reload settings (simulating hot reload)
		settings2, err := config.LoadFromFile(configFile)
		require.NoError(t, err)
		assert.Equal(t, "postgres", settings2.Database.Driver)
		assert.Equal(t, "db.example.com", settings2.Database.Host)
		assert.Equal(t, 5432, settings2.Database.Port)
		assert.Equal(t, 9090, settings2.Server.Port)
		assert.Equal(t, "debug", settings2.Logging.Level)

		// Verify original settings unchanged (immutable)
		assert.Equal(t, "mysql", settings1.Database.Driver)
		assert.Equal(t, "localhost", settings1.Database.Host)
		assert.Equal(t, 8080, settings1.Server.Port)
	})

	t.Run("hot reload from environment changes", func(t *testing.T) {
		clearEnv()

		// Initial environment
		os.Setenv("DB_DRIVER", "mysql")
		os.Setenv("DB_HOST", "localhost")
		os.Setenv("SERVER_PORT", "8080")
		os.Setenv("LOG_LEVEL", "info")

		settings1 := config.LoadFromEnv()
		assert.Equal(t, "mysql", settings1.Database.Driver)
		assert.Equal(t, "localhost", settings1.Database.Host)
		assert.Equal(t, 8080, settings1.Server.Port)
		assert.Equal(t, "info", settings1.Logging.Level)

		// Change environment (simulating external config change)
		os.Setenv("DB_DRIVER", "postgres")
		os.Setenv("DB_HOST", "db.example.com")
		os.Setenv("SERVER_PORT", "9090")
		os.Setenv("LOG_LEVEL", "debug")

		// Reload from environment
		settings2 := config.LoadFromEnv()
		assert.Equal(t, "postgres", settings2.Database.Driver)
		assert.Equal(t, "db.example.com", settings2.Database.Host)
		assert.Equal(t, 9090, settings2.Server.Port)
		assert.Equal(t, "debug", settings2.Logging.Level)

		// Original settings unchanged
		assert.Equal(t, "mysql", settings1.Database.Driver)
		assert.Equal(t, "localhost", settings1.Database.Host)
		assert.Equal(t, 8080, settings1.Server.Port)
		assert.Equal(t, "info", settings1.Logging.Level)

		clearEnv()
	})

	t.Run("concurrent hot reload safety", func(t *testing.T) {
		tmpDir, err := os.MkdirTemp("", "concurrent_reload_test_*")
		require.NoError(t, err)
		defer os.RemoveAll(tmpDir)

		configFile := filepath.Join(tmpDir, "concurrent_config.json")
		initialConfig := `{"database": {"driver": "mysql", "host": "localhost"}, "server": {"port": 8080}}`
		err = os.WriteFile(configFile, []byte(initialConfig), 0644)
		require.NoError(t, err)

		var wg sync.WaitGroup
		const numRoutines = 10
		results := make([]string, numRoutines)

		// Launch multiple goroutines to reload config concurrently
		for i := 0; i < numRoutines; i++ {
			wg.Add(1)
			go func(index int) {
				defer wg.Done()

				// Simulate some load and reload
				for j := 0; j < 5; j++ {
					settings, err := config.LoadFromFile(configFile)
					if err == nil {
						results[index] = settings.Database.Driver
					}
					time.Sleep(time.Millisecond)
				}
			}(i)
		}

		// Change config during concurrent access
		time.Sleep(5 * time.Millisecond)
		updatedConfig := `{"database": {"driver": "postgres", "host": "localhost"}, "server": {"port": 8080}}`
		os.WriteFile(configFile, []byte(updatedConfig), 0644)

		wg.Wait()

		// All results should be valid (either "mysql" or "postgres")
		for i, result := range results {
			assert.True(t, result == "mysql" || result == "postgres",
				"Result %d should be either 'mysql' or 'postgres', got: %s", i, result)
		}
	})

	t.Run("reload with validation", func(t *testing.T) {
		tmpDir, err := os.MkdirTemp("", "reload_validation_test_*")
		require.NoError(t, err)
		defer os.RemoveAll(tmpDir)

		configFile := filepath.Join(tmpDir, "validation_config.json")

		// Test valid reload
		validConfig := `{
			"database": {"driver": "mysql", "host": "localhost", "port": 3306},
			"server": {"host": "0.0.0.0", "port": 8080},
			"grpc": {"db_service_address": "localhost:50051"},
			"logging": {"level": "info"}
		}`
		err = os.WriteFile(configFile, []byte(validConfig), 0644)
		require.NoError(t, err)

		settings, err := config.LoadFromFile(configFile)
		require.NoError(t, err)
		err = settings.Validate()
		assert.NoError(t, err)

		// Test invalid reload (should be detectable)
		invalidConfig := `{
			"database": {"driver": "", "host": "", "port": 0},
			"server": {"host": "0.0.0.0", "port": -1},
			"grpc": {"db_service_address": ""},
			"logging": {"level": "invalid_level"}
		}`
		err = os.WriteFile(configFile, []byte(invalidConfig), 0644)
		require.NoError(t, err)

		settings, err = config.LoadFromFile(configFile)
		require.NoError(t, err)
		err = settings.Validate()
		assert.Error(t, err, "Invalid config should fail validation")
	})

	t.Run("global settings hot reload", func(t *testing.T) {
		// Save original settings
		originalSettings := config.GlobalSettings
		defer func() {
			config.GlobalSettings = originalSettings
		}()

		clearEnv()

		// Set initial environment
		os.Setenv("DB_DRIVER", "mysql")
		os.Setenv("DB_HOST", "localhost")
		os.Setenv("GRPC_DB_SERVICE_ADDRESS", "localhost:50051")
		defer clearEnv()

		// Initialize global settings
		err := config.InitSettings()
		require.NoError(t, err)
		assert.Equal(t, "mysql", config.GlobalSettings.Database.Driver)
		assert.Equal(t, "localhost", config.GlobalSettings.Database.Host)

		// Change environment and reinitialize (simulating hot reload)
		os.Setenv("DB_DRIVER", "postgres")
		os.Setenv("DB_HOST", "db.example.com")

		err = config.InitSettings()
		require.NoError(t, err)
		assert.Equal(t, "postgres", config.GlobalSettings.Database.Driver)
		assert.Equal(t, "db.example.com", config.GlobalSettings.Database.Host)
	})
}

// T008-E: Sensitive data masking testing in configuration logging
func TestT008E_SensitiveDataMasking(t *testing.T) {
	t.Run("database password masking", func(t *testing.T) {
		settings := config.NewSettings()
		settings.Database.Username = "testuser"
		settings.Database.Password = "supersecret123"
		settings.GRPC.CertFile = "/path/to/secret.crt"
		settings.GRPC.KeyFile = "/path/to/secret.key"

		// Test JSON marshaling masks sensitive fields
		data, err := json.Marshal(settings)
		require.NoError(t, err)

		jsonStr := string(data)

		// Password should be masked or not present in logs
		assert.NotContains(t, jsonStr, "supersecret123",
			"Database password should not appear in JSON output")

		// Username should be present (not sensitive)
		assert.Contains(t, jsonStr, "testuser",
			"Username should appear in JSON output")
	})

	t.Run("GetDSN masks password in logs", func(t *testing.T) {
		tests := []struct {
			name     string
			settings config.DatabaseSettings
			wantMask bool
		}{
			{
				name: "mysql DSN with password",
				settings: config.DatabaseSettings{
					Driver:   "mysql",
					Host:     "localhost",
					Port:     3306,
					Database: "testdb",
					Username: "user",
					Password: "secret123",
				},
				wantMask: true,
			},
			{
				name: "postgres DSN with password",
				settings: config.DatabaseSettings{
					Driver:   "postgres",
					Host:     "localhost",
					Port:     5432,
					Database: "testdb",
					Username: "user",
					Password: "secret123",
				},
				wantMask: true,
			},
			{
				name: "unknown driver returns empty",
				settings: config.DatabaseSettings{
					Driver:   "unknown",
					Password: "secret123",
				},
				wantMask: false,
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				dsn := tt.settings.GetDSN()

				if tt.wantMask && dsn != "" {
					// In a real implementation, DSN should mask password for logging
					// For now, we're testing that the function returns a DSN
					assert.NotEmpty(t, dsn)

					// The actual password should still be in the DSN for functionality
					// But in logs, it should be masked (this would be in logging middleware)
					if tt.settings.Driver == "mysql" {
						assert.Contains(t, dsn, tt.settings.Password)
						// In production, log output would mask this
					}
				}
			})
		}
	})

	t.Run("configuration logging with masking", func(t *testing.T) {
		// Simulate configuration logging
		var logOutput strings.Builder

		settings := config.NewSettings()
		settings.Database.Username = "testuser"
		settings.Database.Password = "topsecret456"
		settings.GRPC.CertFile = "/certs/secret.crt"
		settings.GRPC.KeyFile = "/certs/secret.key"
		settings.GRPC.CAFile = "/certs/ca.crt"

		// Simulate masked logging (in real impl, this would be in logging middleware)
		maskedConfig := maskSensitiveData(settings)

		// Write masked config to simulated log
		err := json.NewEncoder(&logOutput).Encode(maskedConfig)
		require.NoError(t, err)

		logContent := logOutput.String()

		// Sensitive data should be masked
		assert.NotContains(t, logContent, "topsecret456",
			"Password should be masked in logs")
		assert.NotContains(t, logContent, "/certs/secret.crt",
			"Cert file path should be masked in logs")
		assert.NotContains(t, logContent, "/certs/secret.key",
			"Key file path should be masked in logs")

		// Non-sensitive data should remain
		assert.Contains(t, logContent, "testuser",
			"Username should not be masked")
		assert.Contains(t, logContent, "localhost",
			"Host should not be masked")
	})

	t.Run("environment variable masking", func(t *testing.T) {
		clearEnv()

		sensitiveEnvVars := map[string]string{
			"DB_PASSWORD":     "supersecret",
			"GRPC_CERT_FILE":  "/path/to/cert.pem",
			"GRPC_KEY_FILE":   "/path/to/key.pem",
			"GRPC_CA_FILE":    "/path/to/ca.pem",
			"DB_USER":         "testuser", // Not sensitive
			"DB_HOST":         "localhost", // Not sensitive
		}

		for key, value := range sensitiveEnvVars {
			os.Setenv(key, value)
		}
		defer clearEnv()

		settings := config.LoadFromEnv()

		// Verify sensitive data is loaded correctly (functionality)
		assert.Equal(t, "supersecret", settings.Database.Password)
		assert.Equal(t, "/path/to/cert.pem", settings.GRPC.CertFile)
		assert.Equal(t, "/path/to/key.pem", settings.GRPC.KeyFile)
		assert.Equal(t, "/path/to/ca.pem", settings.GRPC.CAFile)

		// For logging, these would be masked
		logSafeConfig := maskSensitiveData(settings)
		data, err := json.Marshal(logSafeConfig)
		require.NoError(t, err)

		logContent := string(data)
		assert.NotContains(t, logContent, "supersecret")
		assert.NotContains(t, logContent, "/path/to/cert.pem")
		assert.NotContains(t, logContent, "/path/to/key.pem")
	})

	t.Run("regex pattern sensitive data detection", func(t *testing.T) {
		testStrings := []struct {
			input     string
			sensitive bool
			desc      string
		}{
			{"password123", true, "simple password"},
			{"supersecretkey", true, "secret key"},
			{"token_abc123def", true, "token pattern"},
			{"cert.pem", true, "certificate file"},
			{"private.key", true, "private key file"},
			{"api_key_12345", true, "API key pattern"},
			{"localhost", false, "hostname"},
			{"username", false, "username"},
			{"database_name", false, "database name"},
			{"8080", false, "port number"},
		}

		// Patterns for sensitive data detection
		sensitivePatterns := []*regexp.Regexp{
			regexp.MustCompile(`(?i)password`),
			regexp.MustCompile(`(?i)secret`),
			regexp.MustCompile(`(?i)token`),
			regexp.MustCompile(`(?i)key`),
			regexp.MustCompile(`\.pem$`),
			regexp.MustCompile(`\.crt$`),
			regexp.MustCompile(`api[_-]?key`),
		}

		for _, test := range testStrings {
			t.Run(test.desc, func(t *testing.T) {
				isSensitive := false
				for _, pattern := range sensitivePatterns {
					if pattern.MatchString(test.input) {
						isSensitive = true
						break
					}
				}

				assert.Equal(t, test.sensitive, isSensitive,
					"String '%s' sensitivity detection failed", test.input)
			})
		}
	})
}

// Helper functions

func clearEnv() {
	envVars := []string{
		"DB_DRIVER", "DB_HOST", "DB_PORT", "DB_NAME", "DB_USER", "DB_PASSWORD", "DB_PATH",
		"GRPC_DB_SERVICE_ADDRESS", "GRPC_TIMEOUT", "GRPC_MAX_RETRIES", "GRPC_ENABLE_TLS",
		"GRPC_CERT_FILE", "GRPC_KEY_FILE", "GRPC_CA_FILE",
		"SERVER_HOST", "SERVER_PORT",
		"SCRAPING_MAX_WORKERS", "SCRAPING_HEADLESS",
		"IMPORT_BATCH_SIZE", "IMPORT_TEMP_DIR",
		"LOG_LEVEL", "LOG_PATH", "LOG_JSON",
	}

	for _, env := range envVars {
		os.Unsetenv(env)
	}
}

// maskSensitiveData creates a copy of settings with sensitive data masked
// In a real implementation, this would be part of the logging middleware
func maskSensitiveData(settings *config.Settings) map[string]interface{} {
	masked := map[string]interface{}{
		"database": map[string]interface{}{
			"driver":               settings.Database.Driver,
			"host":                 settings.Database.Host,
			"port":                 settings.Database.Port,
			"database":             settings.Database.Database,
			"username":             settings.Database.Username,
			"password":             "***MASKED***",
			"max_connections":      settings.Database.MaxConn,
			"max_idle_connections": settings.Database.MaxIdleConn,
			"connection_timeout":   settings.Database.ConnTimeout,
			"path":                 maskIfSensitive(settings.Database.Path),
		},
		"server": map[string]interface{}{
			"host":          settings.Server.Host,
			"port":          settings.Server.Port,
			"read_timeout":  settings.Server.ReadTimeout,
			"write_timeout": settings.Server.WriteTimeout,
			"max_body_size": settings.Server.MaxBodySize,
		},
		"grpc": map[string]interface{}{
			"db_service_address": settings.GRPC.DBServiceAddress,
			"timeout":            settings.GRPC.Timeout,
			"max_retries":        settings.GRPC.MaxRetries,
			"retry_delay":        settings.GRPC.RetryDelay,
			"enable_tls":         settings.GRPC.EnableTLS,
			"cert_file":          maskIfSensitive(settings.GRPC.CertFile),
			"key_file":           maskIfSensitive(settings.GRPC.KeyFile),
			"ca_file":            maskIfSensitive(settings.GRPC.CAFile),
		},
		"scraping": map[string]interface{}{
			"max_workers":      settings.Scraping.MaxWorkers,
			"retry_count":      settings.Scraping.RetryCount,
			"retry_delay":      settings.Scraping.RetryDelay,
			"request_timeout":  settings.Scraping.RequestTimeout,
			"headless_browser": settings.Scraping.HeadlessBrowser,
		},
		"import": map[string]interface{}{
			"batch_size":       settings.Import.BatchSize,
			"max_file_size":    settings.Import.MaxFileSize,
			"temp_directory":   settings.Import.TempDir,
			"allowed_formats":  settings.Import.AllowedFormats,
			"duplicate_check":  settings.Import.DuplicateCheck,
		},
		"logging": map[string]interface{}{
			"level":          settings.Logging.Level,
			"output_path":    settings.Logging.OutputPath,
			"max_size_mb":    settings.Logging.MaxSize,
			"max_backups":    settings.Logging.MaxBackups,
			"max_age_days":   settings.Logging.MaxAge,
			"enable_console": settings.Logging.EnableConsole,
			"enable_json":    settings.Logging.EnableJSON,
		},
	}

	return masked
}

func maskIfSensitive(value string) string {
	if value == "" {
		return value
	}

	sensitivePatterns := []*regexp.Regexp{
		regexp.MustCompile(`(?i)\.pem$`),
		regexp.MustCompile(`(?i)\.crt$`),
		regexp.MustCompile(`(?i)\.key$`),
		regexp.MustCompile(`(?i)password`),
		regexp.MustCompile(`(?i)secret`),
		regexp.MustCompile(`(?i)token`),
	}

	for _, pattern := range sensitivePatterns {
		if pattern.MatchString(value) {
			return "***MASKED***"
		}
	}

	return value
}

// Additional coverage tests for uncovered functions
func TestAdditionalCoverage_AccountsFromEnv(t *testing.T) {
	t.Run("load accounts from environment", func(t *testing.T) {
		clearEnv()

		// Set up test accounts
		os.Setenv("ETC_CORP_USER_1", "corp_user_1")
		os.Setenv("ETC_CORP_PASS_1", "corp_pass_1")
		os.Setenv("ETC_CORP_PASS2_1", "corp_pass2_1")
		os.Setenv("ETC_CORP_NAME_1", "Corporation A")
		os.Setenv("ETC_CORP_CARDS_1", "1111-2222, 3333-4444")

		os.Setenv("ETC_PERSONAL_USER_1", "personal_user_1")
		os.Setenv("ETC_PERSONAL_PASS_1", "personal_pass_1")
		os.Setenv("ETC_PERSONAL_NAME_1", "Personal User")
		os.Setenv("ETC_PERSONAL_CARDS_1", "5555-6666")
		defer clearEnv()

		accounts, err := config.LoadAccountsFromEnv()
		assert.NoError(t, err)
		assert.NotNil(t, accounts)
		assert.Len(t, accounts.Accounts, 2)

		// Test corporate account
		corpAccount := accounts.Accounts[0]
		assert.Equal(t, "Corporation A", corpAccount.Name)
		assert.Equal(t, "corp_user_1", corpAccount.UserID)
		assert.Equal(t, "corp_pass_1", corpAccount.Password)
		assert.Equal(t, "corp_pass2_1", corpAccount.PasswordCorp)
		assert.Equal(t, config.AccountTypeCorporate, corpAccount.Type)
		assert.True(t, corpAccount.Active)
		assert.Len(t, corpAccount.CardNumbers, 2)

		// Test personal account
		personalAccount := accounts.Accounts[1]
		assert.Equal(t, "Personal User", personalAccount.Name)
		assert.Equal(t, "personal_user_1", personalAccount.UserID)
		assert.Equal(t, "personal_pass_1", personalAccount.Password)
		assert.Equal(t, config.AccountTypePersonal, personalAccount.Type)
		assert.True(t, personalAccount.Active)
		assert.Len(t, personalAccount.CardNumbers, 1)

		// Test filtering methods
		activeAccounts := accounts.GetActiveAccounts()
		assert.Len(t, activeAccounts, 2)

		corpAccounts := accounts.GetCorporateAccounts()
		assert.Len(t, corpAccounts, 1)
		assert.Equal(t, config.AccountTypeCorporate, corpAccounts[0].Type)

		personalAccounts := accounts.GetPersonalAccounts()
		assert.Len(t, personalAccounts, 1)
		assert.Equal(t, config.AccountTypePersonal, personalAccounts[0].Type)
	})

	t.Run("fallback to simple account", func(t *testing.T) {
		clearEnv()

		os.Setenv("ETC_USER_ID", "simple_user")
		os.Setenv("ETC_PASSWORD", "simple_pass")
		defer clearEnv()

		accounts, err := config.LoadAccountsFromEnv()
		assert.NoError(t, err)
		assert.Len(t, accounts.Accounts, 1)

		account := accounts.Accounts[0]
		assert.Equal(t, "Default Account", account.Name)
		assert.Equal(t, "simple_user", account.UserID)
		assert.Equal(t, "simple_pass", account.Password)
		assert.Equal(t, config.AccountTypePersonal, account.Type)
		assert.True(t, account.Active)
	})
}

func TestAdditionalCoverage_SimpleAccounts(t *testing.T) {
	t.Run("load corporate accounts from env", func(t *testing.T) {
		clearEnv()

		os.Setenv("ETC_CORP_ACCOUNTS", `["user1:pass1", "user2:pass2"]`)
		defer clearEnv()

		accounts, err := config.LoadCorporateAccountsFromEnv()
		assert.NoError(t, err)
		assert.Len(t, accounts, 2)
		assert.Equal(t, "user1", accounts[0].UserID)
		assert.Equal(t, "pass1", accounts[0].Password)
		assert.Equal(t, "user2", accounts[1].UserID)
		assert.Equal(t, "pass2", accounts[1].Password)
	})

	t.Run("load corporate accounts simple format", func(t *testing.T) {
		clearEnv()

		os.Setenv("ETC_CORP_ACCOUNTS", "user1:pass1,user2:pass2")
		defer clearEnv()

		accounts, err := config.LoadCorporateAccountsFromEnv()
		assert.NoError(t, err)
		assert.Len(t, accounts, 2)
	})

	t.Run("load personal accounts from env", func(t *testing.T) {
		clearEnv()

		os.Setenv("ETC_PERSONAL_ACCOUNTS", `["user3:pass3", "user4:pass4"]`)
		defer clearEnv()

		accounts, err := config.LoadPersonalAccountsFromEnv()
		assert.NoError(t, err)
		assert.Len(t, accounts, 2)
		assert.Equal(t, "user3", accounts[0].UserID)
		assert.Equal(t, "pass3", accounts[0].Password)
	})

	t.Run("error cases", func(t *testing.T) {
		clearEnv()

		// Test missing environment
		_, err := config.LoadCorporateAccountsFromEnv()
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "ETC_CORP_ACCOUNTS not set")

		_, err = config.LoadPersonalAccountsFromEnv()
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "ETC_PERSONAL_ACCOUNTS not set")

		// Test invalid format
		os.Setenv("ETC_CORP_ACCOUNTS", "invalid_format")
		_, err = config.LoadCorporateAccountsFromEnv()
		assert.Error(t, err)
	})
}

func TestAdditionalCoverage_ArrayAccounts(t *testing.T) {
	t.Run("load accounts from array env", func(t *testing.T) {
		clearEnv()

		corpJSON := `[{"name":"Corp A","user_id":"corp1","password":"pass1","password_corp":"corp_pass1"}]`
		personalJSON := `[{"name":"Personal A","user_id":"user1","password":"pass1"}]`

		os.Setenv("ETC_CORP_ACCOUNTS", corpJSON)
		os.Setenv("ETC_PERSONAL_ACCOUNTS", personalJSON)
		defer clearEnv()

		accounts, err := config.LoadAccountsFromArrayEnv()
		assert.NoError(t, err)
		assert.Len(t, accounts.Accounts, 2)

		// Check corporate account
		corpAcc := accounts.Accounts[0]
		assert.Equal(t, "Corp A", corpAcc.Name)
		assert.Equal(t, config.AccountTypeCorporate, corpAcc.Type)
		assert.True(t, corpAcc.Active)

		// Check personal account
		personalAcc := accounts.Accounts[1]
		assert.Equal(t, "Personal A", personalAcc.Name)
		assert.Equal(t, config.AccountTypePersonal, personalAcc.Type)
		assert.True(t, personalAcc.Active)
	})

	t.Run("generate env example", func(t *testing.T) {
		example := config.GenerateEnvExample()
		assert.NotEmpty(t, example)
		assert.Contains(t, example, "ETC_CORP_ACCOUNTS")
		assert.Contains(t, example, "ETC_PERSONAL_ACCOUNTS")
		assert.Contains(t, example, "JSON Array Format")
	})
}

// Test coverage for utility functions
func TestAdditionalCoverage_UtilityFunctions(t *testing.T) {
	t.Run("database DSN generation", func(t *testing.T) {
		tests := []struct {
			name     string
			settings config.DatabaseSettings
			expected string
		}{
			{
				name: "mysql DSN",
				settings: config.DatabaseSettings{
					Driver:   "mysql",
					Host:     "localhost",
					Port:     3306,
					Database: "testdb",
					Username: "user",
					Password: "pass",
				},
				expected: "user:pass@tcp(localhost:3306)/testdb?charset=utf8mb4&parseTime=true&loc=Local",
			},
			{
				name: "postgres DSN",
				settings: config.DatabaseSettings{
					Driver:   "postgres",
					Host:     "localhost",
					Port:     5432,
					Database: "testdb",
					Username: "user",
					Password: "pass",
				},
				expected: "host=localhost port=5432 user=user password=pass dbname=testdb sslmode=disable",
			},
			{
				name: "sqlite/gorm DSN",
				settings: config.DatabaseSettings{
					Driver: "sqlite",
				},
				expected: "",
			},
		}

		for _, tt := range tests {
			t.Run(tt.name, func(t *testing.T) {
				dsn := tt.settings.GetDSN()
				assert.Equal(t, tt.expected, dsn)
			})
		}
	})

	t.Run("server address generation", func(t *testing.T) {
		settings := config.ServerSettings{
			Host: "127.0.0.1",
			Port: 9090,
		}
		addr := settings.GetServerAddress()
		assert.Equal(t, "127.0.0.1:9090", addr)
	})

	t.Run("grpc settings methods", func(t *testing.T) {
		settings := config.GRPCSettings{
			DBServiceAddress: "grpc.example.com:50051",
			Timeout:          45 * time.Second,
			EnableTLS:        true,
		}

		assert.Equal(t, "grpc.example.com:50051", settings.GetDBServiceAddress())
		assert.Equal(t, 45*time.Second, settings.GetConnectionTimeout())
		assert.True(t, settings.IsSecure())
	})
}

func TestInitSettings_Coverage(t *testing.T) {
	// Save original GlobalSettings
	originalSettings := config.GlobalSettings
	defer func() {
		config.GlobalSettings = originalSettings
	}()

	t.Run("init from config file", func(t *testing.T) {
		tmpDir, err := os.MkdirTemp("", "init_test_*")
		require.NoError(t, err)
		defer os.RemoveAll(tmpDir)

		// Change to temp directory to create config.json
		oldWd, err := os.Getwd()
		require.NoError(t, err)
		defer os.Chdir(oldWd)

		err = os.Chdir(tmpDir)
		require.NoError(t, err)

		configContent := `{
			"database": {"driver": "postgres", "host": "localhost", "port": 5432},
			"server": {"host": "0.0.0.0", "port": 8080},
			"grpc": {"db_service_address": "localhost:50051"}
		}`
		err = os.WriteFile("config.json", []byte(configContent), 0644)
		require.NoError(t, err)

		err = config.InitSettings()
		assert.NoError(t, err)
		assert.NotNil(t, config.GlobalSettings)
		assert.Equal(t, "postgres", config.GlobalSettings.Database.Driver)
		assert.Equal(t, 5432, config.GlobalSettings.Database.Port)
	})

	t.Run("init with invalid config file", func(t *testing.T) {
		tmpDir, err := os.MkdirTemp("", "init_invalid_test_*")
		require.NoError(t, err)
		defer os.RemoveAll(tmpDir)

		oldWd, err := os.Getwd()
		require.NoError(t, err)
		defer os.Chdir(oldWd)

		err = os.Chdir(tmpDir)
		require.NoError(t, err)

		// Create invalid JSON config
		err = os.WriteFile("config.json", []byte("{invalid json}"), 0644)
		require.NoError(t, err)

		err = config.InitSettings()
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "failed to load config file")
	})
}