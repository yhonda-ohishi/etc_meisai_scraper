package config_test

import (
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/yhonda-ohishi/etc_meisai/src/config"
)

func TestValidation_DatabaseSettings(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		setup   func() *config.Settings
		wantErr bool
		errMsg  string
	}{
		{
			name: "valid database configuration",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.Database.Driver = "mysql"
				s.Database.Host = "localhost"
				s.Database.Port = 3306
				return s
			},
			wantErr: false,
		},
		{
			name: "empty driver",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.Database.Driver = ""
				return s
			},
			wantErr: true,
			errMsg:  "database driver is required",
		},
		{
			name: "empty host",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.Database.Host = ""
				return s
			},
			wantErr: true,
			errMsg:  "database host is required",
		},
		{
			name: "port zero",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.Database.Port = 0
				return s
			},
			wantErr: true,
			errMsg:  "invalid database port: 0",
		},
		{
			name: "port negative",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.Database.Port = -1
				return s
			},
			wantErr: true,
			errMsg:  "invalid database port: -1",
		},
		{
			name: "port too high",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.Database.Port = 65536
				return s
			},
			wantErr: true,
			errMsg:  "invalid database port: 65536",
		},
		{
			name: "port max valid",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.Database.Port = 65535
				return s
			},
			wantErr: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			settings := tt.setup()
			err := settings.Validate()

			if tt.wantErr {
				assert.Error(t, err)
				if tt.errMsg != "" {
					assert.Contains(t, err.Error(), tt.errMsg)
				}
			} else {
				assert.NoError(t, err)
			}
		})
	}
}

func TestValidation_ServerSettings(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		setup   func() *config.Settings
		wantErr bool
		errMsg  string
	}{
		{
			name: "valid server configuration",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.Server.Port = 8080
				s.Server.ReadTimeout = 30
				s.Server.WriteTimeout = 30
				return s
			},
			wantErr: false,
		},
		{
			name: "invalid server port zero",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.Server.Port = 0
				return s
			},
			wantErr: true,
			errMsg:  "invalid server port: 0",
		},
		{
			name: "invalid server port negative",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.Server.Port = -8080
				return s
			},
			wantErr: true,
			errMsg:  "invalid server port: -8080",
		},
		{
			name: "invalid server port too high",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.Server.Port = 100000
				return s
			},
			wantErr: true,
			errMsg:  "invalid server port: 100000",
		},
		{
			name: "auto-fix zero read timeout",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.Server.ReadTimeout = 0
				return s
			},
			wantErr: false,
		},
		{
			name: "auto-fix zero write timeout",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.Server.WriteTimeout = 0
				return s
			},
			wantErr: false,
		},
		{
			name: "auto-fix negative timeouts",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.Server.ReadTimeout = -10
				s.Server.WriteTimeout = -10
				return s
			},
			wantErr: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			settings := tt.setup()
			err := settings.Validate()

			if tt.wantErr {
				assert.Error(t, err)
				if tt.errMsg != "" {
					assert.Contains(t, err.Error(), tt.errMsg)
				}
			} else {
				assert.NoError(t, err)

				// Check auto-fixed values
				if tt.name == "auto-fix zero read timeout" {
					assert.Equal(t, 30, settings.Server.ReadTimeout)
				}
				if tt.name == "auto-fix zero write timeout" {
					assert.Equal(t, 30, settings.Server.WriteTimeout)
				}
				if tt.name == "auto-fix negative timeouts" {
					assert.Equal(t, 30, settings.Server.ReadTimeout)
					assert.Equal(t, 30, settings.Server.WriteTimeout)
				}
			}
		})
	}
}

func TestValidation_GRPCSettings(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		setup   func() *config.Settings
		wantErr bool
		errMsg  string
		verify  func(*testing.T, *config.Settings)
	}{
		{
			name: "valid gRPC configuration",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.GRPC.DBServiceAddress = "localhost:50051"
				s.GRPC.Timeout = 30 * time.Second
				return s
			},
			wantErr: false,
		},
		{
			name: "missing gRPC address",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.GRPC.DBServiceAddress = ""
				return s
			},
			wantErr: true,
			errMsg:  "gRPC db_service address is required",
		},
		{
			name: "auto-fix zero timeout",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.GRPC.Timeout = 0
				return s
			},
			wantErr: false,
			verify: func(t *testing.T, s *config.Settings) {
				assert.Equal(t, 30*time.Second, s.GRPC.Timeout)
			},
		},
		{
			name: "auto-fix negative timeout",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.GRPC.Timeout = -5 * time.Second
				return s
			},
			wantErr: false,
			verify: func(t *testing.T, s *config.Settings) {
				assert.Equal(t, 30*time.Second, s.GRPC.Timeout)
			},
		},
		{
			name: "auto-fix negative max retries",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.GRPC.MaxRetries = -3
				return s
			},
			wantErr: false,
			verify: func(t *testing.T, s *config.Settings) {
				assert.Equal(t, 0, s.GRPC.MaxRetries)
			},
		},
		{
			name: "auto-fix zero retry delay",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.GRPC.RetryDelay = 0
				return s
			},
			wantErr: false,
			verify: func(t *testing.T, s *config.Settings) {
				assert.Equal(t, 1*time.Second, s.GRPC.RetryDelay)
			},
		},
		{
			name: "TLS enabled without cert",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.GRPC.EnableTLS = true
				s.GRPC.CertFile = ""
				s.GRPC.KeyFile = "key.pem"
				return s
			},
			wantErr: true,
			errMsg:  "TLS cert_file and key_file are required when TLS is enabled",
		},
		{
			name: "TLS enabled without key",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.GRPC.EnableTLS = true
				s.GRPC.CertFile = "cert.pem"
				s.GRPC.KeyFile = ""
				return s
			},
			wantErr: true,
			errMsg:  "TLS cert_file and key_file are required when TLS is enabled",
		},
		{
			name: "TLS enabled with both files",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.GRPC.EnableTLS = true
				s.GRPC.CertFile = "cert.pem"
				s.GRPC.KeyFile = "key.pem"
				s.GRPC.CAFile = "ca.pem"
				return s
			},
			wantErr: false,
		},
		{
			name: "TLS disabled without files",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.GRPC.EnableTLS = false
				s.GRPC.CertFile = ""
				s.GRPC.KeyFile = ""
				return s
			},
			wantErr: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			settings := tt.setup()
			err := settings.Validate()

			if tt.wantErr {
				assert.Error(t, err)
				if tt.errMsg != "" {
					assert.Contains(t, err.Error(), tt.errMsg)
				}
			} else {
				assert.NoError(t, err)
				if tt.verify != nil {
					tt.verify(t, settings)
				}
			}
		})
	}
}

func TestValidation_ScrapingSettings(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		setup   func() *config.Settings
		wantErr bool
		verify  func(*testing.T, *config.Settings)
	}{
		{
			name: "valid scraping configuration",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.Scraping.MaxWorkers = 5
				s.Scraping.RetryCount = 3
				return s
			},
			wantErr: false,
		},
		{
			name: "auto-fix zero workers",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.Scraping.MaxWorkers = 0
				return s
			},
			wantErr: false,
			verify: func(t *testing.T, s *config.Settings) {
				assert.Equal(t, 1, s.Scraping.MaxWorkers)
			},
		},
		{
			name: "auto-fix negative workers",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.Scraping.MaxWorkers = -5
				return s
			},
			wantErr: false,
			verify: func(t *testing.T, s *config.Settings) {
				assert.Equal(t, 1, s.Scraping.MaxWorkers)
			},
		},
		{
			name: "auto-fix negative retry count",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.Scraping.RetryCount = -1
				return s
			},
			wantErr: false,
			verify: func(t *testing.T, s *config.Settings) {
				assert.Equal(t, 0, s.Scraping.RetryCount)
			},
		},
		{
			name: "valid zero retry count",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.Scraping.RetryCount = 0
				return s
			},
			wantErr: false,
			verify: func(t *testing.T, s *config.Settings) {
				assert.Equal(t, 0, s.Scraping.RetryCount)
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			settings := tt.setup()
			err := settings.Validate()

			if tt.wantErr {
				assert.Error(t, err)
			} else {
				assert.NoError(t, err)
				if tt.verify != nil {
					tt.verify(t, settings)
				}
			}
		})
	}
}

func TestValidation_ImportSettings(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		setup   func() *config.Settings
		wantErr bool
		verify  func(*testing.T, *config.Settings)
	}{
		{
			name: "valid import configuration",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.Import.BatchSize = 1000
				s.Import.MaxFileSize = 100 << 20
				s.Import.TempDir = "/tmp"
				return s
			},
			wantErr: false,
		},
		{
			name: "auto-fix zero batch size",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.Import.BatchSize = 0
				return s
			},
			wantErr: false,
			verify: func(t *testing.T, s *config.Settings) {
				assert.Equal(t, 100, s.Import.BatchSize)
			},
		},
		{
			name: "auto-fix negative batch size",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.Import.BatchSize = -100
				return s
			},
			wantErr: false,
			verify: func(t *testing.T, s *config.Settings) {
				assert.Equal(t, 100, s.Import.BatchSize)
			},
		},
		{
			name: "auto-fix zero max file size",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.Import.MaxFileSize = 0
				return s
			},
			wantErr: false,
			verify: func(t *testing.T, s *config.Settings) {
				assert.Equal(t, int64(10<<20), s.Import.MaxFileSize)
			},
		},
		{
			name: "auto-fix negative max file size",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.Import.MaxFileSize = -1024
				return s
			},
			wantErr: false,
			verify: func(t *testing.T, s *config.Settings) {
				assert.Equal(t, int64(10<<20), s.Import.MaxFileSize)
			},
		},
		{
			name: "auto-fix empty temp dir",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.Import.TempDir = ""
				return s
			},
			wantErr: false,
			verify: func(t *testing.T, s *config.Settings) {
				assert.Equal(t, "./temp", s.Import.TempDir)
			},
		},
		{
			name: "preserve custom temp dir",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.Import.TempDir = "/custom/temp"
				return s
			},
			wantErr: false,
			verify: func(t *testing.T, s *config.Settings) {
				assert.Equal(t, "/custom/temp", s.Import.TempDir)
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			settings := tt.setup()
			err := settings.Validate()

			if tt.wantErr {
				assert.Error(t, err)
			} else {
				assert.NoError(t, err)
				if tt.verify != nil {
					tt.verify(t, settings)
				}
			}
		})
	}
}

func TestValidation_LoggingSettings(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		setup   func() *config.Settings
		wantErr bool
		errMsg  string
	}{
		{
			name: "valid log level debug",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.Logging.Level = "debug"
				return s
			},
			wantErr: false,
		},
		{
			name: "valid log level info",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.Logging.Level = "info"
				return s
			},
			wantErr: false,
		},
		{
			name: "valid log level warn",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.Logging.Level = "warn"
				return s
			},
			wantErr: false,
		},
		{
			name: "valid log level error",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.Logging.Level = "error"
				return s
			},
			wantErr: false,
		},
		{
			name: "valid log level fatal",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.Logging.Level = "fatal"
				return s
			},
			wantErr: false,
		},
		{
			name: "invalid log level",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.Logging.Level = "invalid"
				return s
			},
			wantErr: true,
			errMsg:  "invalid log level: invalid",
		},
		{
			name: "log level case insensitive",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.Logging.Level = "DEBUG"
				return s
			},
			wantErr: false,
		},
		{
			name: "log level mixed case",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.Logging.Level = "Info"
				return s
			},
			wantErr: false,
		},
		{
			name: "empty log level",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.Logging.Level = ""
				return s
			},
			wantErr: true,
			errMsg:  "invalid log level: ",
		},
		{
			name: "log level with spaces",
			setup: func() *config.Settings {
				s := config.NewSettings()
				s.Logging.Level = "  info  "
				return s
			},
			wantErr: true,
			errMsg:  "invalid log level: ",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			settings := tt.setup()
			err := settings.Validate()

			if tt.wantErr {
				assert.Error(t, err)
				if tt.errMsg != "" {
					assert.Contains(t, err.Error(), tt.errMsg)
				}
			} else {
				assert.NoError(t, err)
			}
		})
	}
}

func TestValidation_EdgeCases(t *testing.T) {
	t.Parallel()

	t.Run("all defaults valid", func(t *testing.T) {
		settings := config.NewSettings()
		err := settings.Validate()
		assert.NoError(t, err)
	})

	t.Run("multiple errors", func(t *testing.T) {
		settings := config.NewSettings()
		settings.Database.Driver = ""
		settings.Database.Host = ""
		settings.Server.Port = -1

		err := settings.Validate()
		assert.Error(t, err)
		// Should fail on first error
		assert.Contains(t, err.Error(), "database driver is required")
	})

	t.Run("fix multiple auto-corrections", func(t *testing.T) {
		settings := config.NewSettings()
		settings.Server.ReadTimeout = 0
		settings.Server.WriteTimeout = -1
		settings.GRPC.Timeout = 0
		settings.GRPC.MaxRetries = -1
		settings.GRPC.RetryDelay = 0
		settings.Scraping.MaxWorkers = 0
		settings.Scraping.RetryCount = -1
		settings.Import.BatchSize = 0
		settings.Import.MaxFileSize = 0
		settings.Import.TempDir = ""

		err := settings.Validate()
		assert.NoError(t, err)

		// Verify all auto-corrections
		assert.Equal(t, 30, settings.Server.ReadTimeout)
		assert.Equal(t, 30, settings.Server.WriteTimeout)
		assert.Equal(t, 30*time.Second, settings.GRPC.Timeout)
		assert.Equal(t, 0, settings.GRPC.MaxRetries)
		assert.Equal(t, 1*time.Second, settings.GRPC.RetryDelay)
		assert.Equal(t, 1, settings.Scraping.MaxWorkers)
		assert.Equal(t, 0, settings.Scraping.RetryCount)
		assert.Equal(t, 100, settings.Import.BatchSize)
		assert.Equal(t, int64(10<<20), settings.Import.MaxFileSize)
		assert.Equal(t, "./temp", settings.Import.TempDir)
	})

	t.Run("boundary values", func(t *testing.T) {
		settings := config.NewSettings()

		// Test port boundaries
		settings.Database.Port = 1
		settings.Server.Port = 65535
		err := settings.Validate()
		assert.NoError(t, err)

		settings.Database.Port = 65535
		settings.Server.Port = 1
		err = settings.Validate()
		assert.NoError(t, err)
	})
}