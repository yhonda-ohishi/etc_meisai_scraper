package config_test

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"github.com/yhonda-ohishi/etc_meisai/src/config"
)

func TestAccountType(t *testing.T) {
	t.Parallel()

	assert.Equal(t, config.AccountType("corporate"), config.AccountTypeCorporate)
	assert.Equal(t, config.AccountType("personal"), config.AccountTypePersonal)
}

func TestETCAccount(t *testing.T) {
	t.Parallel()

	account := config.ETCAccount{
		Name:         "Test Account",
		UserID:       "test123",
		Password:     "pass123",
		PasswordCorp: "corp123",
		Type:         config.AccountTypeCorporate,
		CardNumbers:  []string{"1234-5678", "9012-3456"},
		Active:       true,
	}

	assert.Equal(t, "Test Account", account.Name)
	assert.Equal(t, "test123", account.UserID)
	assert.Equal(t, "pass123", account.Password)
	assert.Equal(t, "corp123", account.PasswordCorp)
	assert.Equal(t, config.AccountTypeCorporate, account.Type)
	assert.Len(t, account.CardNumbers, 2)
	assert.True(t, account.Active)
}

func TestLoadAccountsFromEnv(t *testing.T) {
	tests := []struct {
		name   string
		setup  func()
		verify func(*testing.T, *config.AccountsConfig)
	}{
		{
			name: "single corporate account",
			setup: func() {
				os.Setenv("ETC_CORP_USER_1", "corp_user_1")
				os.Setenv("ETC_CORP_PASS_1", "corp_pass_1")
				os.Setenv("ETC_CORP_PASS2_1", "corp_pass2_1")
				os.Setenv("ETC_CORP_NAME_1", "Corporation A")
				os.Setenv("ETC_CORP_CARDS_1", "1111-2222, 3333-4444")
			},
			verify: func(t *testing.T, cfg *config.AccountsConfig) {
				assert.Len(t, cfg.Accounts, 1)
				acc := cfg.Accounts[0]
				assert.Equal(t, "Corporation A", acc.Name)
				assert.Equal(t, "corp_user_1", acc.UserID)
				assert.Equal(t, "corp_pass_1", acc.Password)
				assert.Equal(t, "corp_pass2_1", acc.PasswordCorp)
				assert.Equal(t, config.AccountTypeCorporate, acc.Type)
				assert.True(t, acc.Active)
				assert.Len(t, acc.CardNumbers, 2)
				assert.Equal(t, "1111-2222", acc.CardNumbers[0])
				assert.Equal(t, "3333-4444", acc.CardNumbers[1])
			},
		},
		{
			name: "multiple corporate accounts",
			setup: func() {
				os.Setenv("ETC_CORP_USER_1", "corp_user_1")
				os.Setenv("ETC_CORP_PASS_1", "corp_pass_1")
				os.Setenv("ETC_CORP_USER_2", "corp_user_2")
				os.Setenv("ETC_CORP_PASS_2", "corp_pass_2")
				os.Setenv("ETC_CORP_USER_3", "corp_user_3")
				os.Setenv("ETC_CORP_PASS_3", "corp_pass_3")
			},
			verify: func(t *testing.T, cfg *config.AccountsConfig) {
				assert.Len(t, cfg.Accounts, 3)
				for i, acc := range cfg.Accounts {
					assert.Equal(t, config.AccountTypeCorporate, acc.Type)
					assert.True(t, acc.Active)
					assert.Equal(t, cfg.Accounts[i].UserID, acc.UserID)
				}
			},
		},
		{
			name: "single personal account",
			setup: func() {
				os.Setenv("ETC_PERSONAL_USER_1", "personal_user_1")
				os.Setenv("ETC_PERSONAL_PASS_1", "personal_pass_1")
				os.Setenv("ETC_PERSONAL_NAME_1", "John Doe")
				os.Setenv("ETC_PERSONAL_CARDS_1", "5555-6666")
			},
			verify: func(t *testing.T, cfg *config.AccountsConfig) {
				assert.Len(t, cfg.Accounts, 1)
				acc := cfg.Accounts[0]
				assert.Equal(t, "John Doe", acc.Name)
				assert.Equal(t, "personal_user_1", acc.UserID)
				assert.Equal(t, "personal_pass_1", acc.Password)
				assert.Empty(t, acc.PasswordCorp)
				assert.Equal(t, config.AccountTypePersonal, acc.Type)
				assert.True(t, acc.Active)
				assert.Len(t, acc.CardNumbers, 1)
				assert.Equal(t, "5555-6666", acc.CardNumbers[0])
			},
		},
		{
			name: "mixed corporate and personal accounts",
			setup: func() {
				os.Setenv("ETC_CORP_USER_1", "corp_user_1")
				os.Setenv("ETC_CORP_PASS_1", "corp_pass_1")
				os.Setenv("ETC_PERSONAL_USER_1", "personal_user_1")
				os.Setenv("ETC_PERSONAL_PASS_1", "personal_pass_1")
				os.Setenv("ETC_PERSONAL_USER_2", "personal_user_2")
				os.Setenv("ETC_PERSONAL_PASS_2", "personal_pass_2")
			},
			verify: func(t *testing.T, cfg *config.AccountsConfig) {
				assert.Len(t, cfg.Accounts, 3)

				// Corporate accounts come first
				corpCount := 0
				personalCount := 0
				for _, acc := range cfg.Accounts {
					if acc.Type == config.AccountTypeCorporate {
						corpCount++
					} else {
						personalCount++
					}
				}
				assert.Equal(t, 1, corpCount)
				assert.Equal(t, 2, personalCount)
			},
		},
		{
			name: "account with no name uses default",
			setup: func() {
				os.Setenv("ETC_CORP_USER_1", "corp_user_1")
				os.Setenv("ETC_CORP_PASS_1", "corp_pass_1")
				// No name set
				os.Setenv("ETC_PERSONAL_USER_1", "personal_user_1")
				os.Setenv("ETC_PERSONAL_PASS_1", "personal_pass_1")
				// No name set
			},
			verify: func(t *testing.T, cfg *config.AccountsConfig) {
				assert.Len(t, cfg.Accounts, 2)
				assert.Equal(t, "Corporate Account 1", cfg.Accounts[0].Name)
				assert.Equal(t, "Personal Account 1", cfg.Accounts[1].Name)
			},
		},
		{
			name: "cards with spaces and special handling",
			setup: func() {
				os.Setenv("ETC_CORP_USER_1", "corp_user_1")
				os.Setenv("ETC_CORP_PASS_1", "corp_pass_1")
				os.Setenv("ETC_CORP_CARDS_1", "  1111-2222  , 3333-4444,5555-6666  ")
			},
			verify: func(t *testing.T, cfg *config.AccountsConfig) {
				assert.Len(t, cfg.Accounts, 1)
				acc := cfg.Accounts[0]
				assert.Len(t, acc.CardNumbers, 3)
				assert.Equal(t, "1111-2222", acc.CardNumbers[0])
				assert.Equal(t, "3333-4444", acc.CardNumbers[1])
				assert.Equal(t, "5555-6666", acc.CardNumbers[2])
			},
		},
		{
			name: "skip accounts with missing user ID",
			setup: func() {
				// No user ID for account 1
				os.Setenv("ETC_CORP_PASS_1", "corp_pass_1")
				os.Setenv("ETC_CORP_NAME_1", "Should not appear")

				// Valid account 2
				os.Setenv("ETC_CORP_USER_2", "corp_user_2")
				os.Setenv("ETC_CORP_PASS_2", "corp_pass_2")

				// No user ID for account 3
				os.Setenv("ETC_CORP_PASS_3", "corp_pass_3")

				// Valid personal account
				os.Setenv("ETC_PERSONAL_USER_1", "personal_user_1")
				os.Setenv("ETC_PERSONAL_PASS_1", "personal_pass_1")
			},
			verify: func(t *testing.T, cfg *config.AccountsConfig) {
				assert.Len(t, cfg.Accounts, 2)
				assert.Equal(t, "corp_user_2", cfg.Accounts[0].UserID)
				assert.Equal(t, "personal_user_1", cfg.Accounts[1].UserID)
			},
		},
		{
			name: "backward compatibility with simple account",
			setup: func() {
				os.Setenv("ETC_USER_ID", "simple_user")
				os.Setenv("ETC_PASSWORD", "simple_pass")
			},
			verify: func(t *testing.T, cfg *config.AccountsConfig) {
				assert.Len(t, cfg.Accounts, 1)
				acc := cfg.Accounts[0]
				assert.Equal(t, "Default Account", acc.Name)
				assert.Equal(t, "simple_user", acc.UserID)
				assert.Equal(t, "simple_pass", acc.Password)
				assert.Equal(t, config.AccountTypePersonal, acc.Type)
				assert.True(t, acc.Active)
				assert.Empty(t, acc.CardNumbers)
			},
		},
		{
			name: "new format takes precedence over simple format",
			setup: func() {
				// New format
				os.Setenv("ETC_CORP_USER_1", "corp_user_1")
				os.Setenv("ETC_CORP_PASS_1", "corp_pass_1")

				// Old format (should be ignored)
				os.Setenv("ETC_USER_ID", "simple_user")
				os.Setenv("ETC_PASSWORD", "simple_pass")
			},
			verify: func(t *testing.T, cfg *config.AccountsConfig) {
				assert.Len(t, cfg.Accounts, 1)
				acc := cfg.Accounts[0]
				assert.Equal(t, "corp_user_1", acc.UserID)
				assert.Equal(t, config.AccountTypeCorporate, acc.Type)
			},
		},
		{
			name: "all 10 slots for corporate and personal",
			setup: func() {
				// Fill all 10 corporate slots
				for i := 1; i <= 10; i++ {
					os.Setenv(fmt.Sprintf("ETC_CORP_USER_%d", i), fmt.Sprintf("corp_user_%d", i))
					os.Setenv(fmt.Sprintf("ETC_CORP_PASS_%d", i), fmt.Sprintf("corp_pass_%d", i))
				}
				// Fill all 10 personal slots
				for i := 1; i <= 10; i++ {
					os.Setenv(fmt.Sprintf("ETC_PERSONAL_USER_%d", i), fmt.Sprintf("personal_user_%d", i))
					os.Setenv(fmt.Sprintf("ETC_PERSONAL_PASS_%d", i), fmt.Sprintf("personal_pass_%d", i))
				}
			},
			verify: func(t *testing.T, cfg *config.AccountsConfig) {
				assert.Len(t, cfg.Accounts, 20)

				// First 10 should be corporate
				for i := 0; i < 10; i++ {
					assert.Equal(t, config.AccountTypeCorporate, cfg.Accounts[i].Type)
					assert.Equal(t, fmt.Sprintf("corp_user_%d", i+1), cfg.Accounts[i].UserID)
				}

				// Next 10 should be personal
				for i := 10; i < 20; i++ {
					assert.Equal(t, config.AccountTypePersonal, cfg.Accounts[i].Type)
					assert.Equal(t, fmt.Sprintf("personal_user_%d", i-9), cfg.Accounts[i].UserID)
				}
			},
		},
		{
			name: "no accounts configured",
			setup: func() {
				// Don't set any environment variables
			},
			verify: func(t *testing.T, cfg *config.AccountsConfig) {
				assert.Len(t, cfg.Accounts, 0)
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// Clear environment
			os.Clearenv()

			// Setup test environment
			tt.setup()

			// Load accounts
			accounts, err := config.LoadAccountsFromEnv()
			assert.NoError(t, err)
			assert.NotNil(t, accounts)

			// Verify
			tt.verify(t, accounts)

			// Clear environment again
			os.Clearenv()
		})
	}
}

func TestLoadAccountsFromFile(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		content string
		verify  func(*testing.T, *config.AccountsConfig)
		wantErr bool
		errMsg  string
	}{
		{
			name: "valid accounts file",
			content: `{
				"accounts": [
					{
						"name": "Test Corp",
						"user_id": "corp123",
						"password": "pass123",
						"password_corp": "corp_pass",
						"type": "corporate",
						"card_numbers": ["1234-5678", "9012-3456"],
						"active": true
					},
					{
						"name": "Test Personal",
						"user_id": "personal456",
						"password": "pass456",
						"type": "personal",
						"card_numbers": ["7890-1234"],
						"active": false
					}
				]
			}`,
			verify: func(t *testing.T, cfg *config.AccountsConfig) {
				assert.Len(t, cfg.Accounts, 2)

				// First account
				acc1 := cfg.Accounts[0]
				assert.Equal(t, "Test Corp", acc1.Name)
				assert.Equal(t, "corp123", acc1.UserID)
				assert.Equal(t, "pass123", acc1.Password)
				assert.Equal(t, "corp_pass", acc1.PasswordCorp)
				assert.Equal(t, config.AccountType("corporate"), acc1.Type)
				assert.Len(t, acc1.CardNumbers, 2)
				assert.True(t, acc1.Active)

				// Second account
				acc2 := cfg.Accounts[1]
				assert.Equal(t, "Test Personal", acc2.Name)
				assert.Equal(t, "personal456", acc2.UserID)
				assert.Equal(t, "pass456", acc2.Password)
				assert.Empty(t, acc2.PasswordCorp)
				assert.Equal(t, config.AccountType("personal"), acc2.Type)
				assert.Len(t, acc2.CardNumbers, 1)
				assert.False(t, acc2.Active)
			},
		},
		{
			name: "empty accounts array",
			content: `{
				"accounts": []
			}`,
			verify: func(t *testing.T, cfg *config.AccountsConfig) {
				assert.Len(t, cfg.Accounts, 0)
			},
		},
		{
			name: "partial account data",
			content: `{
				"accounts": [
					{
						"user_id": "minimal_user",
						"password": "minimal_pass"
					}
				]
			}`,
			verify: func(t *testing.T, cfg *config.AccountsConfig) {
				assert.Len(t, cfg.Accounts, 1)
				acc := cfg.Accounts[0]
				assert.Empty(t, acc.Name)
				assert.Equal(t, "minimal_user", acc.UserID)
				assert.Equal(t, "minimal_pass", acc.Password)
				assert.Empty(t, acc.PasswordCorp)
				assert.Empty(t, acc.Type)
				assert.Nil(t, acc.CardNumbers)
				assert.False(t, acc.Active)
			},
		},
		{
			name:    "invalid json",
			content: `{invalid json}`,
			wantErr: true,
			errMsg:  "failed to decode accounts file",
		},
		{
			name:    "not json object",
			content: `["not", "an", "object"]`,
			wantErr: false, // JSON decoding succeeds but results in empty accounts
			verify: func(t *testing.T, cfg *config.AccountsConfig) {
				assert.Len(t, cfg.Accounts, 0)
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// Create temp file
			tmpDir := t.TempDir()
			accountsFile := filepath.Join(tmpDir, "accounts.json")
			err := os.WriteFile(accountsFile, []byte(tt.content), 0644)
			require.NoError(t, err)

			// Load accounts
			accounts, err := config.LoadAccountsFromFile(accountsFile)

			if tt.wantErr {
				assert.Error(t, err)
				if tt.errMsg != "" {
					assert.Contains(t, err.Error(), tt.errMsg)
				}
			} else {
				assert.NoError(t, err)
				assert.NotNil(t, accounts)
				if tt.verify != nil {
					tt.verify(t, accounts)
				}
			}
		})
	}

	// Test non-existent file
	t.Run("non-existent file", func(t *testing.T) {
		_, err := config.LoadAccountsFromFile("/non/existent/file.json")
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "failed to open accounts file")
	})
}

func TestAccountsConfig_GetActiveAccounts(t *testing.T) {
	t.Parallel()

	config := &config.AccountsConfig{
		Accounts: []config.ETCAccount{
			{UserID: "user1", Active: true},
			{UserID: "user2", Active: false},
			{UserID: "user3", Active: true},
			{UserID: "user4", Active: false},
			{UserID: "user5", Active: true},
		},
	}

	active := config.GetActiveAccounts()
	assert.Len(t, active, 3)

	// Verify only active accounts are returned
	for _, acc := range active {
		assert.True(t, acc.Active)
	}

	// Verify correct accounts
	assert.Equal(t, "user1", active[0].UserID)
	assert.Equal(t, "user3", active[1].UserID)
	assert.Equal(t, "user5", active[2].UserID)
}

func TestAccountsConfig_GetCorporateAccounts(t *testing.T) {
	t.Parallel()

	cfg := &config.AccountsConfig{
		Accounts: []config.ETCAccount{
			{UserID: "corp1", Type: config.AccountTypeCorporate, Active: true},
			{UserID: "personal1", Type: config.AccountTypePersonal, Active: true},
			{UserID: "corp2", Type: config.AccountTypeCorporate, Active: false}, // inactive
			{UserID: "corp3", Type: config.AccountTypeCorporate, Active: true},
			{UserID: "personal2", Type: config.AccountTypePersonal, Active: true},
		},
	}

	corp := cfg.GetCorporateAccounts()
	assert.Len(t, corp, 2) // Only active corporate accounts

	// Verify only active corporate accounts are returned
	for _, acc := range corp {
		assert.Equal(t, config.AccountTypeCorporate, acc.Type)
		assert.True(t, acc.Active)
	}

	// Verify correct accounts
	assert.Equal(t, "corp1", corp[0].UserID)
	assert.Equal(t, "corp3", corp[1].UserID)
}

func TestAccountsConfig_GetPersonalAccounts(t *testing.T) {
	t.Parallel()

	cfg := &config.AccountsConfig{
		Accounts: []config.ETCAccount{
			{UserID: "corp1", Type: config.AccountTypeCorporate, Active: true},
			{UserID: "personal1", Type: config.AccountTypePersonal, Active: true},
			{UserID: "personal2", Type: config.AccountTypePersonal, Active: false}, // inactive
			{UserID: "corp2", Type: config.AccountTypeCorporate, Active: true},
			{UserID: "personal3", Type: config.AccountTypePersonal, Active: true},
		},
	}

	personal := cfg.GetPersonalAccounts()
	assert.Len(t, personal, 2) // Only active personal accounts

	// Verify only active personal accounts are returned
	for _, acc := range personal {
		assert.Equal(t, config.AccountTypePersonal, acc.Type)
		assert.True(t, acc.Active)
	}

	// Verify correct accounts
	assert.Equal(t, "personal1", personal[0].UserID)
	assert.Equal(t, "personal3", personal[1].UserID)
}

func TestAccountsConfig_EmptyConfig(t *testing.T) {
	t.Parallel()

	// Test with nil accounts
	cfg := &config.AccountsConfig{}

	assert.Len(t, cfg.GetActiveAccounts(), 0)
	assert.Len(t, cfg.GetCorporateAccounts(), 0)
	assert.Len(t, cfg.GetPersonalAccounts(), 0)

	// Test with empty slice
	cfg.Accounts = []config.ETCAccount{}

	assert.Len(t, cfg.GetActiveAccounts(), 0)
	assert.Len(t, cfg.GetCorporateAccounts(), 0)
	assert.Len(t, cfg.GetPersonalAccounts(), 0)
}

func TestAccountsJSON(t *testing.T) {
	t.Parallel()

	// Test JSON marshalling/unmarshalling
	original := &config.AccountsConfig{
		Accounts: []config.ETCAccount{
			{
				Name:         "Test Account",
				UserID:       "test123",
				Password:     "pass123",
				PasswordCorp: "corp123",
				Type:         config.AccountTypeCorporate,
				CardNumbers:  []string{"1234", "5678"},
				Active:       true,
			},
		},
	}

	// Marshal to JSON
	data, err := json.Marshal(original)
	assert.NoError(t, err)

	// Unmarshal back
	var decoded config.AccountsConfig
	err = json.Unmarshal(data, &decoded)
	assert.NoError(t, err)

	// Verify
	assert.Len(t, decoded.Accounts, 1)
	acc := decoded.Accounts[0]
	assert.Equal(t, "Test Account", acc.Name)
	assert.Equal(t, "test123", acc.UserID)
	assert.Equal(t, "pass123", acc.Password)
	assert.Equal(t, "corp123", acc.PasswordCorp)
	assert.Equal(t, config.AccountTypeCorporate, acc.Type)
	assert.Len(t, acc.CardNumbers, 2)
	assert.True(t, acc.Active)
}