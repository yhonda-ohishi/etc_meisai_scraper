package config_test

import (
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/yhonda-ohishi/etc_meisai/src/config"
)

func TestDefaults_DatabaseSettings(t *testing.T) {
	t.Parallel()

	settings := config.NewSettings()

	assert.Equal(t, "gorm", settings.Database.Driver)
	assert.Equal(t, "localhost", settings.Database.Host)
	assert.Equal(t, 3306, settings.Database.Port)
	assert.Equal(t, 25, settings.Database.MaxConn)
	assert.Equal(t, 5, settings.Database.MaxIdleConn)
	assert.Equal(t, 30, settings.Database.ConnTimeout)
	assert.Equal(t, "./data/etc_meisai.db", settings.Database.Path)
	assert.Empty(t, settings.Database.Database)
	assert.Empty(t, settings.Database.Username)
	assert.Empty(t, settings.Database.Password)
}

func TestDefaults_ServerSettings(t *testing.T) {
	t.Parallel()

	settings := config.NewSettings()

	assert.Equal(t, "0.0.0.0", settings.Server.Host)
	assert.Equal(t, 8080, settings.Server.Port)
	assert.Equal(t, 30, settings.Server.ReadTimeout)
	assert.Equal(t, 30, settings.Server.WriteTimeout)
	assert.Equal(t, int64(32<<20), settings.Server.MaxBodySize) // 32MB
}

func TestDefaults_GRPCSettings(t *testing.T) {
	t.Parallel()

	settings := config.NewSettings()

	assert.Equal(t, "localhost:50051", settings.GRPC.DBServiceAddress)
	assert.Equal(t, 30*time.Second, settings.GRPC.Timeout)
	assert.Equal(t, 3, settings.GRPC.MaxRetries)
	assert.Equal(t, 1*time.Second, settings.GRPC.RetryDelay)
	assert.False(t, settings.GRPC.EnableTLS)
	assert.Empty(t, settings.GRPC.CertFile)
	assert.Empty(t, settings.GRPC.KeyFile)
	assert.Empty(t, settings.GRPC.CAFile)
}

func TestDefaults_ScrapingSettings(t *testing.T) {
	t.Parallel()

	settings := config.NewSettings()

	assert.Equal(t, 5, settings.Scraping.MaxWorkers)
	assert.Equal(t, 3, settings.Scraping.RetryCount)
	assert.Equal(t, 5*time.Second, settings.Scraping.RetryDelay)
	assert.Equal(t, 30*time.Second, settings.Scraping.RequestTimeout)
	assert.True(t, settings.Scraping.HeadlessBrowser)
}

func TestDefaults_ImportSettings(t *testing.T) {
	t.Parallel()

	settings := config.NewSettings()

	assert.Equal(t, 1000, settings.Import.BatchSize)
	assert.Equal(t, int64(100<<20), settings.Import.MaxFileSize) // 100MB
	assert.Equal(t, "./temp", settings.Import.TempDir)
	assert.Equal(t, []string{".csv", ".xlsx"}, settings.Import.AllowedFormats)
	assert.True(t, settings.Import.DuplicateCheck)
}

func TestDefaults_LoggingSettings(t *testing.T) {
	t.Parallel()

	settings := config.NewSettings()

	assert.Equal(t, "info", settings.Logging.Level)
	assert.Equal(t, "./logs", settings.Logging.OutputPath)
	assert.Equal(t, 100, settings.Logging.MaxSize)
	assert.Equal(t, 7, settings.Logging.MaxBackups)
	assert.Equal(t, 30, settings.Logging.MaxAge)
	assert.True(t, settings.Logging.EnableConsole)
	assert.True(t, settings.Logging.EnableJSON)
}

func TestDefaults_AllSettingsStructure(t *testing.T) {
	t.Parallel()

	settings := config.NewSettings()

	// Verify top-level structure
	assert.NotNil(t, settings)
	assert.NotNil(t, settings.Database)
	assert.NotNil(t, settings.Server)
	assert.NotNil(t, settings.GRPC)
	assert.NotNil(t, settings.Scraping)
	assert.NotNil(t, settings.Import)
	assert.NotNil(t, settings.Logging)

	// Verify defaults make sense
	assert.Greater(t, settings.Database.MaxConn, settings.Database.MaxIdleConn, "MaxConn should be greater than MaxIdleConn")
	assert.Greater(t, settings.Database.ConnTimeout, 0, "ConnTimeout should be positive")
	assert.Greater(t, settings.Server.ReadTimeout, 0, "ReadTimeout should be positive")
	assert.Greater(t, settings.Server.WriteTimeout, 0, "WriteTimeout should be positive")
	assert.Greater(t, settings.GRPC.Timeout.Seconds(), float64(0), "GRPC Timeout should be positive")
	assert.GreaterOrEqual(t, settings.GRPC.MaxRetries, 0, "MaxRetries should not be negative")
	assert.Greater(t, settings.Scraping.MaxWorkers, 0, "MaxWorkers should be positive")
	assert.GreaterOrEqual(t, settings.Scraping.RetryCount, 0, "RetryCount should not be negative")
	assert.Greater(t, settings.Import.BatchSize, 0, "BatchSize should be positive")
	assert.Greater(t, settings.Import.MaxFileSize, int64(0), "MaxFileSize should be positive")
	assert.NotEmpty(t, settings.Import.TempDir, "TempDir should not be empty")
	assert.NotEmpty(t, settings.Import.AllowedFormats, "AllowedFormats should have defaults")
	assert.NotEmpty(t, settings.Logging.Level, "LogLevel should have default")
	assert.NotEmpty(t, settings.Logging.OutputPath, "OutputPath should have default")
}

func TestDefaults_ByteSizeCalculations(t *testing.T) {
	t.Parallel()

	settings := config.NewSettings()

	// Verify byte size calculations are correct
	assert.Equal(t, int64(33554432), settings.Server.MaxBodySize, "32MB = 32 * 1024 * 1024")
	assert.Equal(t, int64(104857600), settings.Import.MaxFileSize, "100MB = 100 * 1024 * 1024")
}

func TestDefaults_TimeoutConsistency(t *testing.T) {
	t.Parallel()

	settings := config.NewSettings()

	// Verify timeouts are consistent
	assert.Equal(t, settings.Server.ReadTimeout, settings.Server.WriteTimeout, "Read and Write timeouts should match by default")
	assert.Equal(t, int(settings.GRPC.Timeout.Seconds()), settings.Server.ReadTimeout, "GRPC and Server timeouts should be aligned")
	assert.Equal(t, int(settings.Scraping.RequestTimeout.Seconds()), settings.Server.ReadTimeout, "Scraping and Server timeouts should be aligned")
}

func TestDefaults_ValidationPasses(t *testing.T) {
	t.Parallel()

	settings := config.NewSettings()

	// Default settings should always pass validation
	err := settings.Validate()
	assert.NoError(t, err, "Default settings should be valid")
}

func TestDefaults_LoadFromEnvPreservesDefaults(t *testing.T) {
	t.Parallel()

	// Don't set any environment variables
	settings := config.LoadFromEnv()

	// Should have all defaults
	assert.Equal(t, "gorm", settings.Database.Driver)
	assert.Equal(t, "localhost", settings.Database.Host)
	assert.Equal(t, 3306, settings.Database.Port)
	assert.Equal(t, "0.0.0.0", settings.Server.Host)
	assert.Equal(t, 8080, settings.Server.Port)
	assert.Equal(t, "localhost:50051", settings.GRPC.DBServiceAddress)
	assert.Equal(t, 30*time.Second, settings.GRPC.Timeout)
	assert.Equal(t, 5, settings.Scraping.MaxWorkers)
	assert.Equal(t, 1000, settings.Import.BatchSize)
	assert.Equal(t, "info", settings.Logging.Level)
}

func TestDefaults_ZeroValues(t *testing.T) {
	t.Parallel()

	// Test that zero values are handled properly
	t.Run("DatabaseSettings zero value", func(t *testing.T) {
		var db config.DatabaseSettings
		assert.Empty(t, db.Driver)
		assert.Empty(t, db.Host)
		assert.Zero(t, db.Port)
		assert.Zero(t, db.MaxConn)
		assert.Zero(t, db.MaxIdleConn)
		assert.Zero(t, db.ConnTimeout)
		assert.Empty(t, db.Path)
		assert.Empty(t, db.GetDSN()) // Should return empty for zero value
	})

	t.Run("ServerSettings zero value", func(t *testing.T) {
		var srv config.ServerSettings
		assert.Empty(t, srv.Host)
		assert.Zero(t, srv.Port)
		assert.Zero(t, srv.ReadTimeout)
		assert.Zero(t, srv.WriteTimeout)
		assert.Zero(t, srv.MaxBodySize)
		assert.Equal(t, ":0", srv.GetServerAddress()) // Should handle zero value
	})

	t.Run("GRPCSettings zero value", func(t *testing.T) {
		var grpc config.GRPCSettings
		assert.Empty(t, grpc.DBServiceAddress)
		assert.Zero(t, grpc.Timeout)
		assert.Zero(t, grpc.MaxRetries)
		assert.Zero(t, grpc.RetryDelay)
		assert.False(t, grpc.EnableTLS)
		assert.Empty(t, grpc.CertFile)
		assert.Empty(t, grpc.KeyFile)
		assert.Empty(t, grpc.CAFile)
		assert.Empty(t, grpc.GetDBServiceAddress())
		assert.False(t, grpc.IsSecure())
		assert.Zero(t, grpc.GetConnectionTimeout())
	})

	t.Run("ScrapingSettings zero value", func(t *testing.T) {
		var scraping config.ScrapingSettings
		assert.Zero(t, scraping.MaxWorkers)
		assert.Zero(t, scraping.RetryCount)
		assert.Zero(t, scraping.RetryDelay)
		assert.Zero(t, scraping.RequestTimeout)
		assert.False(t, scraping.HeadlessBrowser)
	})

	t.Run("ImportSettings zero value", func(t *testing.T) {
		var imp config.ImportSettings
		assert.Zero(t, imp.BatchSize)
		assert.Zero(t, imp.MaxFileSize)
		assert.Empty(t, imp.TempDir)
		assert.Nil(t, imp.AllowedFormats)
		assert.False(t, imp.DuplicateCheck)
	})

	t.Run("LoggingSettings zero value", func(t *testing.T) {
		var log config.LoggingSettings
		assert.Empty(t, log.Level)
		assert.Empty(t, log.OutputPath)
		assert.Zero(t, log.MaxSize)
		assert.Zero(t, log.MaxBackups)
		assert.Zero(t, log.MaxAge)
		assert.False(t, log.EnableConsole)
		assert.False(t, log.EnableJSON)
	})
}

func TestDefaults_ModifyingDefaults(t *testing.T) {
	t.Parallel()

	// Test that modifying one default doesn't affect others
	t.Run("modify database keeps other defaults", func(t *testing.T) {
		settings := config.NewSettings()
		settings.Database.Host = "custom-host"
		settings.Database.Port = 5432

		// Other database defaults should remain
		assert.Equal(t, "gorm", settings.Database.Driver)
		assert.Equal(t, 25, settings.Database.MaxConn)
		assert.Equal(t, 5, settings.Database.MaxIdleConn)

		// Other sections should be unaffected
		assert.Equal(t, "0.0.0.0", settings.Server.Host)
		assert.Equal(t, 8080, settings.Server.Port)
		assert.Equal(t, "localhost:50051", settings.GRPC.DBServiceAddress)
		assert.Equal(t, 5, settings.Scraping.MaxWorkers)
		assert.Equal(t, 1000, settings.Import.BatchSize)
		assert.Equal(t, "info", settings.Logging.Level)
	})

	t.Run("modify server keeps other defaults", func(t *testing.T) {
		settings := config.NewSettings()
		settings.Server.Port = 9090
		settings.Server.ReadTimeout = 60

		// Other server defaults should remain
		assert.Equal(t, "0.0.0.0", settings.Server.Host)
		assert.Equal(t, 30, settings.Server.WriteTimeout)
		assert.Equal(t, int64(32<<20), settings.Server.MaxBodySize)

		// Other sections should be unaffected
		assert.Equal(t, "gorm", settings.Database.Driver)
		assert.Equal(t, "localhost:50051", settings.GRPC.DBServiceAddress)
	})
}

func TestDefaults_ListDefaults(t *testing.T) {
	t.Parallel()

	// Test list/array defaults
	settings := config.NewSettings()

	t.Run("allowed formats", func(t *testing.T) {
		assert.Len(t, settings.Import.AllowedFormats, 2)
		assert.Contains(t, settings.Import.AllowedFormats, ".csv")
		assert.Contains(t, settings.Import.AllowedFormats, ".xlsx")
	})

	t.Run("allowed formats are mutable", func(t *testing.T) {
		// Verify we can modify the slice
		settings.Import.AllowedFormats = append(settings.Import.AllowedFormats, ".txt")
		assert.Len(t, settings.Import.AllowedFormats, 3)
		assert.Contains(t, settings.Import.AllowedFormats, ".txt")
	})
}

func TestDefaults_GlobalSettings(t *testing.T) {
	// Save original GlobalSettings
	original := config.GlobalSettings
	defer func() {
		config.GlobalSettings = original
	}()

	t.Run("GlobalSettings initially nil", func(t *testing.T) {
		config.GlobalSettings = nil
		assert.Nil(t, config.GlobalSettings)
	})

	t.Run("GlobalSettings after InitSettings", func(t *testing.T) {
		config.GlobalSettings = nil

		// Set minimal required values for validation
		t.Setenv("DB_DRIVER", "mysql")
		t.Setenv("DB_HOST", "localhost")
		t.Setenv("GRPC_DB_SERVICE_ADDRESS", "localhost:50051")

		err := config.InitSettings()
		assert.NoError(t, err)
		assert.NotNil(t, config.GlobalSettings)

		// Should have both env values and defaults
		assert.Equal(t, "mysql", config.GlobalSettings.Database.Driver)
		assert.Equal(t, "localhost", config.GlobalSettings.Database.Host)
		assert.Equal(t, 3306, config.GlobalSettings.Database.Port) // default
		assert.Equal(t, "localhost:50051", config.GlobalSettings.GRPC.DBServiceAddress)
		assert.Equal(t, 30*time.Second, config.GlobalSettings.GRPC.Timeout) // default
		assert.Equal(t, 5, config.GlobalSettings.Scraping.MaxWorkers)        // default
		assert.Equal(t, "info", config.GlobalSettings.Logging.Level)         // default
	})
}