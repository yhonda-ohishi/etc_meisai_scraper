package config_test

import (
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"github.com/yhonda-ohishi/etc_meisai/src/config"
)

func TestNewSettings(t *testing.T) {
	t.Parallel()

	settings := config.NewSettings()

	assert.NotNil(t, settings)
	assert.Equal(t, "gorm", settings.Database.Driver)
	assert.Equal(t, "localhost", settings.Database.Host)
	assert.Equal(t, 3306, settings.Database.Port)
	assert.Equal(t, 25, settings.Database.MaxConn)
	assert.Equal(t, 5, settings.Database.MaxIdleConn)
	assert.Equal(t, 30, settings.Database.ConnTimeout)
	assert.Equal(t, "./data/etc_meisai.db", settings.Database.Path)

	assert.Equal(t, "0.0.0.0", settings.Server.Host)
	assert.Equal(t, 8080, settings.Server.Port)
	assert.Equal(t, 30, settings.Server.ReadTimeout)
	assert.Equal(t, 30, settings.Server.WriteTimeout)
	assert.Equal(t, int64(32<<20), settings.Server.MaxBodySize)

	assert.Equal(t, "localhost:50051", settings.GRPC.DBServiceAddress)
	assert.Equal(t, 30*time.Second, settings.GRPC.Timeout)
	assert.Equal(t, 3, settings.GRPC.MaxRetries)
	assert.Equal(t, 1*time.Second, settings.GRPC.RetryDelay)
	assert.False(t, settings.GRPC.EnableTLS)

	assert.Equal(t, 5, settings.Scraping.MaxWorkers)
	assert.Equal(t, 3, settings.Scraping.RetryCount)
	assert.Equal(t, 5*time.Second, settings.Scraping.RetryDelay)
	assert.Equal(t, 30*time.Second, settings.Scraping.RequestTimeout)
	assert.True(t, settings.Scraping.HeadlessBrowser)

	assert.Equal(t, 1000, settings.Import.BatchSize)
	assert.Equal(t, int64(100<<20), settings.Import.MaxFileSize)
	assert.Equal(t, "./temp", settings.Import.TempDir)
	assert.Equal(t, []string{".csv", ".xlsx"}, settings.Import.AllowedFormats)
	assert.True(t, settings.Import.DuplicateCheck)

	assert.Equal(t, "info", settings.Logging.Level)
	assert.Equal(t, "./logs", settings.Logging.OutputPath)
	assert.Equal(t, 100, settings.Logging.MaxSize)
	assert.Equal(t, 7, settings.Logging.MaxBackups)
	assert.Equal(t, 30, settings.Logging.MaxAge)
	assert.True(t, settings.Logging.EnableConsole)
	assert.True(t, settings.Logging.EnableJSON)
}

func TestLoadFromEnv(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name   string
		setup  func()
		verify func(*testing.T, *config.Settings)
	}{
		{
			name: "database settings",
			setup: func() {
				os.Setenv("DB_DRIVER", "mysql")
				os.Setenv("DB_HOST", "db.example.com")
				os.Setenv("DB_PORT", "3307")
				os.Setenv("DB_NAME", "test_db")
				os.Setenv("DB_USER", "testuser")
				os.Setenv("DB_PASSWORD", "testpass")
				os.Setenv("DB_PATH", "/data/test.db")
			},
			verify: func(t *testing.T, s *config.Settings) {
				assert.Equal(t, "mysql", s.Database.Driver)
				assert.Equal(t, "db.example.com", s.Database.Host)
				assert.Equal(t, 3307, s.Database.Port)
				assert.Equal(t, "test_db", s.Database.Database)
				assert.Equal(t, "testuser", s.Database.Username)
				assert.Equal(t, "testpass", s.Database.Password)
				assert.Equal(t, "/data/test.db", s.Database.Path)
			},
		},
		{
			name: "grpc settings",
			setup: func() {
				os.Setenv("GRPC_DB_SERVICE_ADDRESS", "grpc.example.com:50052")
				os.Setenv("GRPC_TIMEOUT", "45s")
				os.Setenv("GRPC_MAX_RETRIES", "5")
				os.Setenv("GRPC_ENABLE_TLS", "true")
				os.Setenv("GRPC_CERT_FILE", "/certs/client.crt")
				os.Setenv("GRPC_KEY_FILE", "/certs/client.key")
				os.Setenv("GRPC_CA_FILE", "/certs/ca.crt")
			},
			verify: func(t *testing.T, s *config.Settings) {
				assert.Equal(t, "grpc.example.com:50052", s.GRPC.DBServiceAddress)
				assert.Equal(t, 45*time.Second, s.GRPC.Timeout)
				assert.Equal(t, 5, s.GRPC.MaxRetries)
				assert.True(t, s.GRPC.EnableTLS)
				assert.Equal(t, "/certs/client.crt", s.GRPC.CertFile)
				assert.Equal(t, "/certs/client.key", s.GRPC.KeyFile)
				assert.Equal(t, "/certs/ca.crt", s.GRPC.CAFile)
			},
		},
		{
			name: "server settings",
			setup: func() {
				os.Setenv("SERVER_HOST", "127.0.0.1")
				os.Setenv("SERVER_PORT", "9090")
			},
			verify: func(t *testing.T, s *config.Settings) {
				assert.Equal(t, "127.0.0.1", s.Server.Host)
				assert.Equal(t, 9090, s.Server.Port)
			},
		},
		{
			name: "scraping settings",
			setup: func() {
				os.Setenv("SCRAPING_MAX_WORKERS", "10")
				os.Setenv("SCRAPING_HEADLESS", "false")
			},
			verify: func(t *testing.T, s *config.Settings) {
				assert.Equal(t, 10, s.Scraping.MaxWorkers)
				assert.False(t, s.Scraping.HeadlessBrowser)
			},
		},
		{
			name: "import settings",
			setup: func() {
				os.Setenv("IMPORT_BATCH_SIZE", "2000")
				os.Setenv("IMPORT_TEMP_DIR", "/tmp/imports")
			},
			verify: func(t *testing.T, s *config.Settings) {
				assert.Equal(t, 2000, s.Import.BatchSize)
				assert.Equal(t, "/tmp/imports", s.Import.TempDir)
			},
		},
		{
			name: "logging settings",
			setup: func() {
				os.Setenv("LOG_LEVEL", "debug")
				os.Setenv("LOG_PATH", "/var/log/app")
				os.Setenv("LOG_JSON", "false")
			},
			verify: func(t *testing.T, s *config.Settings) {
				assert.Equal(t, "debug", s.Logging.Level)
				assert.Equal(t, "/var/log/app", s.Logging.OutputPath)
				assert.False(t, s.Logging.EnableJSON)
			},
		},
		{
			name: "invalid port values",
			setup: func() {
				os.Setenv("DB_PORT", "invalid")
				os.Setenv("SERVER_PORT", "not_a_number")
				os.Setenv("GRPC_TIMEOUT", "invalid_duration")
				os.Setenv("GRPC_MAX_RETRIES", "not_int")
				os.Setenv("SCRAPING_MAX_WORKERS", "invalid")
				os.Setenv("IMPORT_BATCH_SIZE", "invalid")
			},
			verify: func(t *testing.T, s *config.Settings) {
				// Should use defaults when parsing fails
				assert.Equal(t, 3306, s.Database.Port)
				assert.Equal(t, 8080, s.Server.Port)
				assert.Equal(t, 30*time.Second, s.GRPC.Timeout)
				assert.Equal(t, 3, s.GRPC.MaxRetries)
				assert.Equal(t, 5, s.Scraping.MaxWorkers)
				assert.Equal(t, 1000, s.Import.BatchSize)
			},
		},
		{
			name: "boolean parsing",
			setup: func() {
				os.Setenv("GRPC_ENABLE_TLS", "TRUE")
				os.Setenv("SCRAPING_HEADLESS", "True")
				os.Setenv("LOG_JSON", "1")
			},
			verify: func(t *testing.T, s *config.Settings) {
				assert.True(t, s.GRPC.EnableTLS)
				assert.True(t, s.Scraping.HeadlessBrowser)
				assert.False(t, s.Logging.EnableJSON) // "1" is not "true"
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// Clear environment
			os.Clearenv()

			// Setup test environment
			tt.setup()

			// Load settings
			settings := config.LoadFromEnv()

			// Verify
			tt.verify(t, settings)

			// Clear environment again
			os.Clearenv()
		})
	}
}

func TestLoadFromFile(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		content string
		verify  func(*testing.T, *config.Settings)
		wantErr bool
		errMsg  string
	}{
		{
			name: "valid json config",
			content: `{
				"database": {
					"driver": "postgres",
					"host": "pg.example.com",
					"port": 5432,
					"database": "mydb",
					"username": "user",
					"password": "pass"
				},
				"server": {
					"host": "0.0.0.0",
					"port": 9000
				},
				"grpc": {
					"db_service_address": "grpc:50051",
					"timeout": 60000000000,
					"max_retries": 5,
					"enable_tls": true,
					"cert_file": "/certs/client.crt",
					"key_file": "/certs/client.key"
				},
				"scraping": {
					"max_workers": 10
				},
				"import": {
					"batch_size": 2000,
					"temp_directory": "/tmp/import"
				},
				"logging": {
					"level": "debug",
					"output_path": "/logs"
				}
			}`,
			verify: func(t *testing.T, s *config.Settings) {
				assert.Equal(t, "postgres", s.Database.Driver)
				assert.Equal(t, "pg.example.com", s.Database.Host)
				assert.Equal(t, 5432, s.Database.Port)
				assert.Equal(t, "mydb", s.Database.Database)
				assert.Equal(t, "user", s.Database.Username)
				assert.Equal(t, "pass", s.Database.Password)
				assert.Equal(t, 9000, s.Server.Port)
				assert.Equal(t, "grpc:50051", s.GRPC.DBServiceAddress)
				assert.Equal(t, 60*time.Second, s.GRPC.Timeout)
				assert.Equal(t, 5, s.GRPC.MaxRetries)
				assert.True(t, s.GRPC.EnableTLS)
				assert.Equal(t, 10, s.Scraping.MaxWorkers)
				assert.Equal(t, 2000, s.Import.BatchSize)
				assert.Equal(t, "/tmp/import", s.Import.TempDir)
				assert.Equal(t, "debug", s.Logging.Level)
				assert.Equal(t, "/logs", s.Logging.OutputPath)
			},
		},
		{
			name: "partial config uses defaults",
			content: `{
				"database": {
					"driver": "mysql",
					"host": "localhost"
				}
			}`,
			verify: func(t *testing.T, s *config.Settings) {
				assert.Equal(t, "mysql", s.Database.Driver)
				assert.Equal(t, "localhost", s.Database.Host)
				// Check defaults are preserved
				assert.Equal(t, 8080, s.Server.Port)
				assert.Equal(t, "localhost:50051", s.GRPC.DBServiceAddress)
				assert.Equal(t, 1000, s.Import.BatchSize)
			},
		},
		{
			name:    "invalid json",
			content: `{invalid json}`,
			wantErr: true,
			errMsg:  "failed to decode config file",
		},
		{
			name:    "empty file",
			content: `{}`,
			verify: func(t *testing.T, s *config.Settings) {
				// Should have all defaults
				assert.Equal(t, "gorm", s.Database.Driver)
				assert.Equal(t, "localhost", s.Database.Host)
				assert.Equal(t, 8080, s.Server.Port)
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// Create temp file
			tmpDir := t.TempDir()
			configFile := filepath.Join(tmpDir, "config.json")
			err := os.WriteFile(configFile, []byte(tt.content), 0644)
			require.NoError(t, err)

			// Load settings
			settings, err := config.LoadFromFile(configFile)

			if tt.wantErr {
				assert.Error(t, err)
				if tt.errMsg != "" {
					assert.Contains(t, err.Error(), tt.errMsg)
				}
			} else {
				assert.NoError(t, err)
				assert.NotNil(t, settings)
				if tt.verify != nil {
					tt.verify(t, settings)
				}
			}
		})
	}

	// Test non-existent file
	t.Run("non-existent file", func(t *testing.T) {
		_, err := config.LoadFromFile("/non/existent/file.json")
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "failed to open config file")
	})
}

func TestSettings_Validate(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		setup   func(*config.Settings)
		wantErr bool
		errMsg  string
	}{
		{
			name: "valid settings",
			setup: func(s *config.Settings) {
				// Default settings are valid
			},
			wantErr: false,
		},
		{
			name: "missing database driver",
			setup: func(s *config.Settings) {
				s.Database.Driver = ""
			},
			wantErr: true,
			errMsg:  "database driver is required",
		},
		{
			name: "missing database host",
			setup: func(s *config.Settings) {
				s.Database.Host = ""
			},
			wantErr: true,
			errMsg:  "database host is required",
		},
		{
			name: "invalid database port",
			setup: func(s *config.Settings) {
				s.Database.Port = 0
			},
			wantErr: true,
			errMsg:  "invalid database port: 0",
		},
		{
			name: "database port too high",
			setup: func(s *config.Settings) {
				s.Database.Port = 70000
			},
			wantErr: true,
			errMsg:  "invalid database port: 70000",
		},
		{
			name: "invalid server port",
			setup: func(s *config.Settings) {
				s.Server.Port = -1
			},
			wantErr: true,
			errMsg:  "invalid server port: -1",
		},
		{
			name: "missing grpc address",
			setup: func(s *config.Settings) {
				s.GRPC.DBServiceAddress = ""
			},
			wantErr: true,
			errMsg:  "gRPC db_service address is required",
		},
		{
			name: "tls enabled without cert",
			setup: func(s *config.Settings) {
				s.GRPC.EnableTLS = true
				s.GRPC.CertFile = ""
				s.GRPC.KeyFile = "key.pem"
			},
			wantErr: true,
			errMsg:  "TLS cert_file and key_file are required when TLS is enabled",
		},
		{
			name: "tls enabled without key",
			setup: func(s *config.Settings) {
				s.GRPC.EnableTLS = true
				s.GRPC.CertFile = "cert.pem"
				s.GRPC.KeyFile = ""
			},
			wantErr: true,
			errMsg:  "TLS cert_file and key_file are required when TLS is enabled",
		},
		{
			name: "tls enabled with both files",
			setup: func(s *config.Settings) {
				s.GRPC.EnableTLS = true
				s.GRPC.CertFile = "cert.pem"
				s.GRPC.KeyFile = "key.pem"
			},
			wantErr: false,
		},
		{
			name: "invalid log level",
			setup: func(s *config.Settings) {
				s.Logging.Level = "invalid"
			},
			wantErr: true,
			errMsg:  "invalid log level: invalid",
		},
		{
			name: "valid log levels",
			setup: func(s *config.Settings) {
				// Test each valid level
				levels := []string{"debug", "info", "warn", "error", "fatal"}
				for _, level := range levels {
					s.Logging.Level = level
					err := s.Validate()
					assert.NoError(t, err, "level %s should be valid", level)
				}
			},
			wantErr: false,
		},
		{
			name: "auto-fix zero timeouts",
			setup: func(s *config.Settings) {
				s.Server.ReadTimeout = 0
				s.Server.WriteTimeout = 0
				s.GRPC.Timeout = 0
				s.GRPC.RetryDelay = 0
			},
			wantErr: false,
		},
		{
			name: "auto-fix negative values",
			setup: func(s *config.Settings) {
				s.GRPC.MaxRetries = -5
				s.Scraping.MaxWorkers = 0
				s.Scraping.RetryCount = -1
				s.Import.BatchSize = 0
				s.Import.MaxFileSize = 0
				s.Import.TempDir = ""
			},
			wantErr: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			settings := config.NewSettings()
			if tt.setup != nil {
				tt.setup(settings)
			}

			err := settings.Validate()

			if tt.wantErr {
				assert.Error(t, err)
				if tt.errMsg != "" {
					assert.Contains(t, err.Error(), tt.errMsg)
				}
			} else {
				assert.NoError(t, err)

				// Check auto-fixed values
				if settings.Server.ReadTimeout == 0 {
					settings.Server.ReadTimeout = 30
				}
				if settings.Server.WriteTimeout == 0 {
					settings.Server.WriteTimeout = 30
				}
				if settings.GRPC.Timeout <= 0 {
					assert.Equal(t, 30*time.Second, settings.GRPC.Timeout)
				}
				if settings.GRPC.MaxRetries < 0 {
					assert.Equal(t, 0, settings.GRPC.MaxRetries)
				}
				if settings.GRPC.RetryDelay <= 0 {
					assert.Equal(t, 1*time.Second, settings.GRPC.RetryDelay)
				}
				if settings.Scraping.MaxWorkers <= 0 {
					assert.Equal(t, 1, settings.Scraping.MaxWorkers)
				}
				if settings.Scraping.RetryCount < 0 {
					assert.Equal(t, 0, settings.Scraping.RetryCount)
				}
				if settings.Import.BatchSize <= 0 {
					assert.Equal(t, 100, settings.Import.BatchSize)
				}
				if settings.Import.MaxFileSize <= 0 {
					assert.Equal(t, int64(10<<20), settings.Import.MaxFileSize)
				}
				if settings.Import.TempDir == "" {
					assert.Equal(t, "./temp", settings.Import.TempDir)
				}
			}
		})
	}
}

func TestDatabaseSettings_GetDSN(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name     string
		settings config.DatabaseSettings
		expected string
	}{
		{
			name: "mysql dsn",
			settings: config.DatabaseSettings{
				Driver:   "mysql",
				Host:     "localhost",
				Port:     3306,
				Database: "testdb",
				Username: "user",
				Password: "pass",
			},
			expected: "user:pass@tcp(localhost:3306)/testdb?charset=utf8mb4&parseTime=true&loc=Local",
		},
		{
			name: "postgres dsn",
			settings: config.DatabaseSettings{
				Driver:   "postgres",
				Host:     "localhost",
				Port:     5432,
				Database: "testdb",
				Username: "user",
				Password: "pass",
			},
			expected: "host=localhost port=5432 user=user password=pass dbname=testdb sslmode=disable",
		},
		{
			name: "unknown driver",
			settings: config.DatabaseSettings{
				Driver: "unknown",
			},
			expected: "",
		},
		{
			name: "gorm driver",
			settings: config.DatabaseSettings{
				Driver: "gorm",
			},
			expected: "",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			dsn := tt.settings.GetDSN()
			assert.Equal(t, tt.expected, dsn)
		})
	}
}

func TestServerSettings_GetServerAddress(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name     string
		settings config.ServerSettings
		expected string
	}{
		{
			name: "default address",
			settings: config.ServerSettings{
				Host: "0.0.0.0",
				Port: 8080,
			},
			expected: "0.0.0.0:8080",
		},
		{
			name: "custom address",
			settings: config.ServerSettings{
				Host: "127.0.0.1",
				Port: 9090,
			},
			expected: "127.0.0.1:9090",
		},
		{
			name: "hostname",
			settings: config.ServerSettings{
				Host: "api.example.com",
				Port: 443,
			},
			expected: "api.example.com:443",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			addr := tt.settings.GetServerAddress()
			assert.Equal(t, tt.expected, addr)
		})
	}
}

func TestGRPCSettings_Methods(t *testing.T) {
	t.Parallel()

	t.Run("GetDBServiceAddress", func(t *testing.T) {
		settings := config.GRPCSettings{
			DBServiceAddress: "grpc.example.com:50051",
		}
		assert.Equal(t, "grpc.example.com:50051", settings.GetDBServiceAddress())
	})

	t.Run("IsSecure", func(t *testing.T) {
		settings := config.GRPCSettings{
			EnableTLS: false,
		}
		assert.False(t, settings.IsSecure())

		settings.EnableTLS = true
		assert.True(t, settings.IsSecure())
	})

	t.Run("GetConnectionTimeout", func(t *testing.T) {
		settings := config.GRPCSettings{
			Timeout: 45 * time.Second,
		}
		assert.Equal(t, 45*time.Second, settings.GetConnectionTimeout())
	})
}

func TestInitSettings(t *testing.T) {
	// Save original GlobalSettings
	originalSettings := config.GlobalSettings
	defer func() {
		config.GlobalSettings = originalSettings
	}()

	t.Run("init from environment", func(t *testing.T) {
		// Clear any existing config file
		os.Remove("config.json")

		// Set required environment variables
		os.Setenv("DB_DRIVER", "mysql")
		os.Setenv("DB_HOST", "localhost")
		os.Setenv("GRPC_DB_SERVICE_ADDRESS", "localhost:50051")
		defer os.Clearenv()

		err := config.InitSettings()
		assert.NoError(t, err)
		assert.NotNil(t, config.GlobalSettings)
		assert.Equal(t, "mysql", config.GlobalSettings.Database.Driver)
	})

	t.Run("init from config file", func(t *testing.T) {
		// Create a valid config file
		configContent := `{
			"database": {"driver": "postgres", "host": "localhost", "port": 5432},
			"server": {"host": "0.0.0.0", "port": 8080},
			"grpc": {"db_service_address": "localhost:50051"}
		}`
		err := os.WriteFile("config.json", []byte(configContent), 0644)
		require.NoError(t, err)
		defer os.Remove("config.json")

		err = config.InitSettings()
		assert.NoError(t, err)
		assert.NotNil(t, config.GlobalSettings)
		assert.Equal(t, "postgres", config.GlobalSettings.Database.Driver)
	})

	t.Run("init with invalid config", func(t *testing.T) {
		// Clear config file
		os.Remove("config.json")
		config.GlobalSettings = nil

		// Set invalid environment - invalid log level
		os.Setenv("DB_DRIVER", "mysql")
		os.Setenv("DB_HOST", "localhost")
		os.Setenv("GRPC_DB_SERVICE_ADDRESS", "localhost:50051")
		os.Setenv("LOG_LEVEL", "invalid_level") // Invalid log level
		defer os.Clearenv()

		err := config.InitSettings()
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "invalid log level")
	})

	t.Run("init with invalid config file", func(t *testing.T) {
		// Create an invalid config file
		err := os.WriteFile("config.json", []byte("{invalid json}"), 0644)
		require.NoError(t, err)
		defer os.Remove("config.json")

		err = config.InitSettings()
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "failed to load config file")
	})
}

func TestSettingsJSONMarshalling(t *testing.T) {
	t.Parallel()

	settings := config.NewSettings()

	// Marshal to JSON
	data, err := json.Marshal(settings)
	assert.NoError(t, err)
	assert.NotEmpty(t, data)

	// Unmarshal back
	var decoded config.Settings
	err = json.Unmarshal(data, &decoded)
	assert.NoError(t, err)

	// Verify fields
	assert.Equal(t, settings.Database.Driver, decoded.Database.Driver)
	assert.Equal(t, settings.Server.Port, decoded.Server.Port)
	assert.Equal(t, settings.GRPC.DBServiceAddress, decoded.GRPC.DBServiceAddress)
	assert.Equal(t, settings.Import.BatchSize, decoded.Import.BatchSize)
	assert.Equal(t, settings.Logging.Level, decoded.Logging.Level)
}