package grpc

import (
	"context"
	"errors"
	"io"
	"log"
	"os"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"

	"github.com/yhonda-ohishi/etc_meisai/src/models"
	"github.com/yhonda-ohishi/etc_meisai/src/pb"
	"github.com/yhonda-ohishi/etc_meisai/src/services"
)

// Mock implementations

type MockETCMeisaiService struct {
	mock.Mock
}

func (m *MockETCMeisaiService) CreateRecord(ctx context.Context, params *services.CreateRecordParams) (*models.ETCMeisaiRecord, error) {
	args := m.Called(ctx, params)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*models.ETCMeisaiRecord), args.Error(1)
}

func (m *MockETCMeisaiService) GetRecord(ctx context.Context, id int64) (*models.ETCMeisaiRecord, error) {
	args := m.Called(ctx, id)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*models.ETCMeisaiRecord), args.Error(1)
}

func (m *MockETCMeisaiService) ListRecords(ctx context.Context, params *services.ListRecordsParams) (*services.ListRecordsResponse, error) {
	args := m.Called(ctx, params)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*services.ListRecordsResponse), args.Error(1)
}

func (m *MockETCMeisaiService) UpdateRecord(ctx context.Context, id int64, params *services.CreateRecordParams) (*models.ETCMeisaiRecord, error) {
	args := m.Called(ctx, id, params)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*models.ETCMeisaiRecord), args.Error(1)
}

func (m *MockETCMeisaiService) DeleteRecord(ctx context.Context, id int64) error {
	args := m.Called(ctx, id)
	return args.Error(0)
}

func (m *MockETCMeisaiService) HealthCheck(ctx context.Context) error {
	args := m.Called(ctx)
	return args.Error(0)
}

type MockETCMappingService struct {
	mock.Mock
}

func (m *MockETCMappingService) CreateMapping(ctx context.Context, params *services.CreateMappingParams) (*models.ETCMapping, error) {
	args := m.Called(ctx, params)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*models.ETCMapping), args.Error(1)
}

func (m *MockETCMappingService) GetMapping(ctx context.Context, id int64) (*models.ETCMapping, error) {
	args := m.Called(ctx, id)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*models.ETCMapping), args.Error(1)
}

func (m *MockETCMappingService) ListMappings(ctx context.Context, params *services.ListMappingsParams) (*services.ListMappingsResponse, error) {
	args := m.Called(ctx, params)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*services.ListMappingsResponse), args.Error(1)
}

func (m *MockETCMappingService) UpdateMapping(ctx context.Context, id int64, params *services.UpdateMappingParams) (*models.ETCMapping, error) {
	args := m.Called(ctx, id, params)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*models.ETCMapping), args.Error(1)
}

func (m *MockETCMappingService) DeleteMapping(ctx context.Context, id int64) error {
	args := m.Called(ctx, id)
	return args.Error(0)
}

func (m *MockETCMappingService) UpdateStatus(ctx context.Context, id int64, status string) error {
	args := m.Called(ctx, id, status)
	return args.Error(0)
}

func (m *MockETCMappingService) HealthCheck(ctx context.Context) error {
	args := m.Called(ctx)
	return args.Error(0)
}

type MockImportService struct {
	mock.Mock
}

func (m *MockImportService) ImportCSV(ctx context.Context, params *services.ImportCSVParams, reader io.Reader) (*services.ImportCSVResult, error) {
	args := m.Called(ctx, params, reader)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*services.ImportCSVResult), args.Error(1)
}

func (m *MockImportService) GetImportSession(ctx context.Context, sessionID string) (*models.ImportSession, error) {
	args := m.Called(ctx, sessionID)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*models.ImportSession), args.Error(1)
}

func (m *MockImportService) ListImportSessions(ctx context.Context, params *services.ListImportSessionsParams) (*services.ListImportSessionsResponse, error) {
	args := m.Called(ctx, params)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*services.ListImportSessionsResponse), args.Error(1)
}

func (m *MockImportService) ImportCSVStream(ctx context.Context, params *services.ImportCSVStreamParams) (*services.ImportCSVResult, error) {
	args := m.Called(ctx, params)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*services.ImportCSVResult), args.Error(1)
}

func (m *MockImportService) ProcessCSV(ctx context.Context, rows []*services.CSVRow, options *services.BulkProcessOptions) (*services.BulkProcessResult, error) {
	args := m.Called(ctx, rows, options)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*services.BulkProcessResult), args.Error(1)
}

func (m *MockImportService) ProcessCSVRow(ctx context.Context, row *services.CSVRow) (*models.ETCMeisaiRecord, error) {
	args := m.Called(ctx, row)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*models.ETCMeisaiRecord), args.Error(1)
}

func (m *MockImportService) HandleDuplicates(ctx context.Context, records []*models.ETCMeisaiRecord) ([]*services.DuplicateResult, error) {
	args := m.Called(ctx, records)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).([]*services.DuplicateResult), args.Error(1)
}

func (m *MockImportService) CancelImportSession(ctx context.Context, sessionID string) error {
	args := m.Called(ctx, sessionID)
	return args.Error(0)
}

func (m *MockImportService) HealthCheck(ctx context.Context) error {
	args := m.Called(ctx)
	return args.Error(0)
}

type MockStatisticsService struct {
	mock.Mock
}

func (m *MockStatisticsService) GetGeneralStatistics(ctx context.Context, filter *services.StatisticsFilter) (*services.GeneralStatistics, error) {
	args := m.Called(ctx, filter)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*services.GeneralStatistics), args.Error(1)
}

func (m *MockStatisticsService) GetDailyStatistics(ctx context.Context, filter *services.StatisticsFilter) (*services.DailyStatisticsResponse, error) {
	args := m.Called(ctx, filter)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*services.DailyStatisticsResponse), args.Error(1)
}

func (m *MockStatisticsService) GetMonthlyStatistics(ctx context.Context, filter *services.StatisticsFilter) (*services.MonthlyStatisticsResponse, error) {
	args := m.Called(ctx, filter)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*services.MonthlyStatisticsResponse), args.Error(1)
}

func (m *MockStatisticsService) GetVehicleStatistics(ctx context.Context, carNumbers []string, filter *services.StatisticsFilter) (*services.VehicleStatisticsResponse, error) {
	args := m.Called(ctx, carNumbers, filter)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*services.VehicleStatisticsResponse), args.Error(1)
}

func (m *MockStatisticsService) GetMappingStatistics(ctx context.Context, filter *services.StatisticsFilter) (*services.MappingStatisticsResponse, error) {
	args := m.Called(ctx, filter)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*services.MappingStatisticsResponse), args.Error(1)
}

func (m *MockStatisticsService) HealthCheck(ctx context.Context) error {
	args := m.Called(ctx)
	return args.Error(0)
}

// Comprehensive tests for 100% coverage

func TestTestableETCMeisaiServer_CreateRecord_Complete(t *testing.T) {
	logger := log.New(os.Stderr, "[TEST] ", log.LstdFlags)

	t.Run("successful creation", func(t *testing.T) {
		mockService := new(MockETCMeisaiService)
		server := NewTestableETCMeisaiServer(mockService, nil, nil, nil, logger)

		expectedRecord := &models.ETCMeisaiRecord{
			ID:            1,
			Date:          time.Date(2025, 1, 1, 0, 0, 0, 0, time.UTC),
			Time:          "10:30:00",
			EntranceIC:    "Tokyo IC",
			ExitIC:        "Yokohama IC",
			TollAmount:    1000,
			CarNumber:     "123-45",
			ETCCardNumber: "1234567890",
		}

		mockService.On("CreateRecord", mock.Anything, mock.Anything).Return(expectedRecord, nil)

		req := &pb.CreateRecordRequest{
			Record: &pb.ETCMeisaiRecord{
				Date:          "2025-01-01",
				Time:          "10:30:00",
				EntranceIc:    "Tokyo IC",
				ExitIc:        "Yokohama IC",
				TollAmount:    1000,
				CarNumber:     "123-45",
				EtcCardNumber: "1234567890",
			},
		}

		resp, err := server.CreateRecord(context.Background(), req)

		assert.NoError(t, err)
		assert.NotNil(t, resp)
		assert.NotNil(t, resp.Record)
		mockService.AssertExpectations(t)
	})

	t.Run("proto conversion error via nil record", func(t *testing.T) {
		mockService := new(MockETCMeisaiService)
		server := NewTestableETCMeisaiServer(mockService, nil, nil, nil, logger)

		// Return nil record to force adapter error
		mockService.On("CreateRecord", mock.Anything, mock.Anything).Return((*models.ETCMeisaiRecord)(nil), nil)

		req := &pb.CreateRecordRequest{
			Record: &pb.ETCMeisaiRecord{
				Date:          "2025-01-01",
				Time:          "10:30:00",
				EntranceIc:    "Tokyo IC",
				ExitIc:        "Yokohama IC",
				TollAmount:    1000,
				CarNumber:     "123-45",
				EtcCardNumber: "1234567890",
			},
		}

		_, err := server.CreateRecord(context.Background(), req)

		assert.Error(t, err)
		st, ok := status.FromError(err)
		assert.True(t, ok)
		assert.Equal(t, codes.Internal, st.Code())
		assert.Contains(t, st.Message(), "failed to convert response")
		mockService.AssertExpectations(t)
	})

	t.Run("invalid date format in request", func(t *testing.T) {
		mockService := new(MockETCMeisaiService)
		server := NewTestableETCMeisaiServer(mockService, nil, nil, nil, logger)

		req := &pb.CreateRecordRequest{
			Record: &pb.ETCMeisaiRecord{
				Date:          "invalid-date-format",
				Time:          "10:30:00",
				EntranceIc:    "Tokyo IC",
				ExitIc:        "Yokohama IC",
				TollAmount:    1000,
				CarNumber:     "123-45",
				EtcCardNumber: "1234567890",
			},
		}

		_, err := server.CreateRecord(context.Background(), req)

		assert.Error(t, err)
		st, ok := status.FromError(err)
		assert.True(t, ok)
		assert.Equal(t, codes.InvalidArgument, st.Code())
		assert.Contains(t, st.Message(), "invalid record data")
	})
}

func TestTestableETCMeisaiServer_GetRecord_Complete(t *testing.T) {
	logger := log.New(os.Stderr, "[TEST] ", log.LstdFlags)

	t.Run("adapter conversion error", func(t *testing.T) {
		mockService := new(MockETCMeisaiService)
		server := NewTestableETCMeisaiServer(mockService, nil, nil, nil, logger)

		// Return nil record to force adapter error
		mockService.On("GetRecord", mock.Anything, int64(1)).Return((*models.ETCMeisaiRecord)(nil), nil)

		req := &pb.GetRecordRequest{Id: 1}
		_, err := server.GetRecord(context.Background(), req)

		assert.Error(t, err)
		st, ok := status.FromError(err)
		assert.True(t, ok)
		assert.Equal(t, codes.Internal, st.Code())
		assert.Contains(t, st.Message(), "failed to convert response")
		mockService.AssertExpectations(t)
	})
}

func TestTestableETCMeisaiServer_UpdateRecord_Complete(t *testing.T) {
	logger := log.New(os.Stderr, "[TEST] ", log.LstdFlags)

	t.Run("adapter conversion error", func(t *testing.T) {
		mockService := new(MockETCMeisaiService)
		server := NewTestableETCMeisaiServer(mockService, nil, nil, nil, logger)

		// Return nil record to force adapter error
		mockService.On("UpdateRecord", mock.Anything, int64(1), mock.Anything).Return((*models.ETCMeisaiRecord)(nil), nil)

		req := &pb.UpdateRecordRequest{
			Id: 1,
			Record: &pb.ETCMeisaiRecord{
				Date:          "2025-01-01",
				Time:          "10:30:00",
				EntranceIc:    "Tokyo IC",
				ExitIc:        "Yokohama IC",
				TollAmount:    1500,
				CarNumber:     "123-45",
				EtcCardNumber: "1234567890",
			},
		}

		_, err := server.UpdateRecord(context.Background(), req)

		assert.Error(t, err)
		st, ok := status.FromError(err)
		assert.True(t, ok)
		assert.Equal(t, codes.Internal, st.Code())
		assert.Contains(t, st.Message(), "failed to convert response")
		mockService.AssertExpectations(t)
	})

	t.Run("invalid date format in request", func(t *testing.T) {
		mockService := new(MockETCMeisaiService)
		server := NewTestableETCMeisaiServer(mockService, nil, nil, nil, logger)

		req := &pb.UpdateRecordRequest{
			Id: 1,
			Record: &pb.ETCMeisaiRecord{
				Date:          "invalid-date",
				Time:          "10:30:00",
				EntranceIc:    "Tokyo IC",
				ExitIc:        "Yokohama IC",
				TollAmount:    1500,
				CarNumber:     "123-45",
				EtcCardNumber: "1234567890",
			},
		}

		_, err := server.UpdateRecord(context.Background(), req)

		assert.Error(t, err)
		st, ok := status.FromError(err)
		assert.True(t, ok)
		assert.Equal(t, codes.InvalidArgument, st.Code())
		assert.Contains(t, st.Message(), "invalid record data")
	})

	t.Run("nil service", func(t *testing.T) {
		server := NewTestableETCMeisaiServer(nil, nil, nil, nil, logger)

		req := &pb.UpdateRecordRequest{
			Id: 1,
			Record: &pb.ETCMeisaiRecord{
				Date:          "2025-01-01",
				Time:          "10:30:00",
				EntranceIc:    "Tokyo IC",
				ExitIc:        "Yokohama IC",
				TollAmount:    1500,
				CarNumber:     "123-45",
				EtcCardNumber: "1234567890",
			},
		}

		_, err := server.UpdateRecord(context.Background(), req)

		assert.Error(t, err)
		st, ok := status.FromError(err)
		assert.True(t, ok)
		assert.Equal(t, codes.Internal, st.Code())
		assert.Contains(t, st.Message(), "service not available")
	})
}

func TestTestableETCMeisaiServer_ListRecords_Complete(t *testing.T) {
	logger := log.New(os.Stderr, "[TEST] ", log.LstdFlags)

	t.Run("adapter conversion error in list", func(t *testing.T) {
		mockService := new(MockETCMeisaiService)
		server := NewTestableETCMeisaiServer(mockService, nil, nil, nil, logger)

		// Return a list with a nil record to force adapter error
		expectedRecords := []*models.ETCMeisaiRecord{nil}

		mockService.On("ListRecords", mock.Anything, mock.Anything).Return(&services.ListRecordsResponse{
			Records:    expectedRecords,
			TotalCount: 1,
		}, nil)

		req := &pb.ListRecordsRequest{
			Page:     1,
			PageSize: 50,
		}

		_, err := server.ListRecords(context.Background(), req)

		assert.Error(t, err)
		st, ok := status.FromError(err)
		assert.True(t, ok)
		assert.Equal(t, codes.Internal, st.Code())
		assert.Contains(t, st.Message(), "failed to convert records")
		mockService.AssertExpectations(t)
	})

	t.Run("invalid date format in filters", func(t *testing.T) {
		mockService := new(MockETCMeisaiService)
		server := NewTestableETCMeisaiServer(mockService, nil, nil, nil, logger)

		invalidDateFrom := "invalid-date"
		req := &pb.ListRecordsRequest{
			Page:     1,
			PageSize: 50,
			DateFrom: &invalidDateFrom,
		}

		_, err := server.ListRecords(context.Background(), req)

		assert.Error(t, err)
		st, ok := status.FromError(err)
		assert.True(t, ok)
		assert.Equal(t, codes.InvalidArgument, st.Code())
	})
}

func TestTestableETCMeisaiServer_ImportCSV_Complete(t *testing.T) {
	logger := log.New(os.Stderr, "[TEST] ", log.LstdFlags)

	t.Run("adapter conversion error", func(t *testing.T) {
		mockService := new(MockImportService)
		server := NewTestableETCMeisaiServer(nil, nil, mockService, nil, logger)

		// Return result with nil session to force adapter error
		expectedResult := &services.ImportCSVResult{
			Session:        nil,
			SuccessCount:   0,
			ErrorCount:     0,
			DuplicateCount: 0,
		}

		mockService.On("ImportCSV", mock.Anything, mock.Anything, mock.Anything).Return(expectedResult, nil)

		req := &pb.ImportCSVRequest{
			AccountType: "corporate",
			AccountId:   "acc123",
			FileName:    "test.csv",
			FileContent: []byte("test,data"),
		}

		_, err := server.ImportCSV(context.Background(), req)

		assert.Error(t, err)
		st, ok := status.FromError(err)
		assert.True(t, ok)
		assert.Equal(t, codes.Internal, st.Code())
		assert.Contains(t, st.Message(), "failed to convert response")
		mockService.AssertExpectations(t)
	})

	t.Run("nil service", func(t *testing.T) {
		server := NewTestableETCMeisaiServer(nil, nil, nil, nil, logger)

		req := &pb.ImportCSVRequest{
			AccountType: "corporate",
			AccountId:   "acc123",
			FileName:    "test.csv",
			FileContent: []byte("test,data"),
		}

		_, err := server.ImportCSV(context.Background(), req)

		assert.Error(t, err)
		st, ok := status.FromError(err)
		assert.True(t, ok)
		assert.Equal(t, codes.Internal, st.Code())
		assert.Contains(t, st.Message(), "service not available")
	})
}

// Tests for mapping functionality with adapter conversion errors
func TestTestableETCMeisaiServer_GetMapping_Complete(t *testing.T) {
	logger := log.New(os.Stderr, "[TEST] ", log.LstdFlags)

	t.Run("adapter conversion error", func(t *testing.T) {
		mockService := new(MockETCMappingService)
		server := NewTestableETCMeisaiServer(nil, mockService, nil, nil, logger)

		// Return nil mapping to force adapter error
		mockService.On("GetMapping", mock.Anything, int64(1)).Return((*models.ETCMapping)(nil), nil)

		req := &pb.GetMappingRequest{Id: 1}
		_, err := server.GetMapping(context.Background(), req)

		assert.Error(t, err)
		st, ok := status.FromError(err)
		assert.True(t, ok)
		assert.Equal(t, codes.Internal, st.Code())
		assert.Contains(t, st.Message(), "failed to convert response")
		mockService.AssertExpectations(t)
	})

	t.Run("nil service", func(t *testing.T) {
		server := NewTestableETCMeisaiServer(nil, nil, nil, nil, logger)

		req := &pb.GetMappingRequest{Id: 1}
		_, err := server.GetMapping(context.Background(), req)

		assert.Error(t, err)
		st, ok := status.FromError(err)
		assert.True(t, ok)
		assert.Equal(t, codes.Internal, st.Code())
		assert.Contains(t, st.Message(), "service not available")
	})
}

func TestTestableETCMeisaiServer_UpdateMapping_Complete(t *testing.T) {
	logger := log.New(os.Stderr, "[TEST] ", log.LstdFlags)

	t.Run("adapter conversion error", func(t *testing.T) {
		mockService := new(MockETCMappingService)
		server := NewTestableETCMeisaiServer(nil, mockService, nil, nil, logger)

		// Return nil mapping to force adapter error
		mockService.On("UpdateMapping", mock.Anything, int64(1), mock.Anything).Return((*models.ETCMapping)(nil), nil)

		req := &pb.UpdateMappingRequest{
			Id: 1,
			Mapping: &pb.ETCMapping{
				EtcRecordId:      1,
				MappingType:      "auto",
				MappedEntityId:   123,
				MappedEntityType: "vehicle",
				Confidence:       0.95,
				Status:           pb.MappingStatus_MAPPING_STATUS_ACTIVE,
			},
		}

		_, err := server.UpdateMapping(context.Background(), req)

		assert.Error(t, err)
		st, ok := status.FromError(err)
		assert.True(t, ok)
		assert.Equal(t, codes.Internal, st.Code())
		assert.Contains(t, st.Message(), "failed to convert response")
		mockService.AssertExpectations(t)
	})

	t.Run("validation error - invalid confidence", func(t *testing.T) {
		mockService := new(MockETCMappingService)
		server := NewTestableETCMeisaiServer(nil, mockService, nil, nil, logger)

		req := &pb.UpdateMappingRequest{
			Id: 1,
			Mapping: &pb.ETCMapping{
				EtcRecordId:      1,
				MappingType:      "auto",
				MappedEntityId:   123,
				MappedEntityType: "vehicle",
				Confidence:       1.5, // Invalid confidence > 1
				Status:           pb.MappingStatus_MAPPING_STATUS_ACTIVE,
			},
		}

		_, err := server.UpdateMapping(context.Background(), req)

		assert.Error(t, err)
		st, ok := status.FromError(err)
		assert.True(t, ok)
		assert.Equal(t, codes.InvalidArgument, st.Code())
		assert.Contains(t, st.Message(), "confidence must be between 0 and 1")
	})

	t.Run("nil service", func(t *testing.T) {
		server := NewTestableETCMeisaiServer(nil, nil, nil, nil, logger)

		req := &pb.UpdateMappingRequest{
			Id: 1,
			Mapping: &pb.ETCMapping{
				EtcRecordId:      1,
				MappingType:      "auto",
				MappedEntityId:   123,
				MappedEntityType: "vehicle",
				Confidence:       0.95,
				Status:           pb.MappingStatus_MAPPING_STATUS_ACTIVE,
			},
		}

		_, err := server.UpdateMapping(context.Background(), req)

		assert.Error(t, err)
		st, ok := status.FromError(err)
		assert.True(t, ok)
		assert.Equal(t, codes.Internal, st.Code())
		assert.Contains(t, st.Message(), "service not available")
	})
}

func TestTestableETCMeisaiServer_ListMappings_Complete(t *testing.T) {
	logger := log.New(os.Stderr, "[TEST] ", log.LstdFlags)

	t.Run("adapter conversion error in list", func(t *testing.T) {
		mockService := new(MockETCMappingService)
		server := NewTestableETCMeisaiServer(nil, mockService, nil, nil, logger)

		// Return a list with a nil mapping to force adapter error
		expectedMappings := []*models.ETCMapping{nil}

		mockService.On("ListMappings", mock.Anything, mock.Anything).Return(&services.ListMappingsResponse{
			Mappings:   expectedMappings,
			TotalCount: 1,
		}, nil)

		req := &pb.ListMappingsRequest{
			Page:     1,
			PageSize: 50,
		}

		_, err := server.ListMappings(context.Background(), req)

		assert.Error(t, err)
		st, ok := status.FromError(err)
		assert.True(t, ok)
		assert.Equal(t, codes.Internal, st.Code())
		assert.Contains(t, st.Message(), "failed to convert mappings")
		mockService.AssertExpectations(t)
	})

	t.Run("nil service", func(t *testing.T) {
		server := NewTestableETCMeisaiServer(nil, nil, nil, nil, logger)

		req := &pb.ListMappingsRequest{
			Page:     1,
			PageSize: 50,
		}

		_, err := server.ListMappings(context.Background(), req)

		assert.Error(t, err)
		st, ok := status.FromError(err)
		assert.True(t, ok)
		assert.Equal(t, codes.Internal, st.Code())
		assert.Contains(t, st.Message(), "service not available")
	})
}

func TestTestableETCMeisaiServer_CreateMapping_Complete(t *testing.T) {
	logger := log.New(os.Stderr, "[TEST] ", log.LstdFlags)

	t.Run("adapter conversion error", func(t *testing.T) {
		mockService := new(MockETCMappingService)
		server := NewTestableETCMeisaiServer(nil, mockService, nil, nil, logger)

		// Return nil mapping to force adapter error
		mockService.On("CreateMapping", mock.Anything, mock.Anything).Return((*models.ETCMapping)(nil), nil)

		req := &pb.CreateMappingRequest{
			Mapping: &pb.ETCMapping{
				EtcRecordId:      1,
				MappingType:      "auto",
				MappedEntityId:   123,
				MappedEntityType: "vehicle",
				Confidence:       0.95,
				Status:           pb.MappingStatus_MAPPING_STATUS_ACTIVE,
			},
		}

		_, err := server.CreateMapping(context.Background(), req)

		assert.Error(t, err)
		st, ok := status.FromError(err)
		assert.True(t, ok)
		assert.Equal(t, codes.Internal, st.Code())
		assert.Contains(t, st.Message(), "failed to convert response")
		mockService.AssertExpectations(t)
	})

	t.Run("nil service", func(t *testing.T) {
		server := NewTestableETCMeisaiServer(nil, nil, nil, nil, logger)

		req := &pb.CreateMappingRequest{
			Mapping: &pb.ETCMapping{
				EtcRecordId:      1,
				MappingType:      "auto",
				MappedEntityId:   123,
				MappedEntityType: "vehicle",
				Confidence:       0.95,
				Status:           pb.MappingStatus_MAPPING_STATUS_ACTIVE,
			},
		}

		_, err := server.CreateMapping(context.Background(), req)

		assert.Error(t, err)
		st, ok := status.FromError(err)
		assert.True(t, ok)
		assert.Equal(t, codes.Internal, st.Code())
		assert.Contains(t, st.Message(), "service not available")
	})
}

// Tests for import session methods with adapter conversion errors
func TestTestableETCMeisaiServer_GetImportSession_Complete(t *testing.T) {
	logger := log.New(os.Stderr, "[TEST] ", log.LstdFlags)

	t.Run("adapter conversion error", func(t *testing.T) {
		mockService := new(MockImportService)
		server := NewTestableETCMeisaiServer(nil, nil, mockService, nil, logger)

		// Return nil session to force adapter error
		mockService.On("GetImportSession", mock.Anything, "session-123").Return((*models.ImportSession)(nil), nil)

		req := &pb.GetImportSessionRequest{SessionId: "session-123"}
		_, err := server.GetImportSession(context.Background(), req)

		assert.Error(t, err)
		st, ok := status.FromError(err)
		assert.True(t, ok)
		assert.Equal(t, codes.Internal, st.Code())
		assert.Contains(t, st.Message(), "failed to convert response")
		mockService.AssertExpectations(t)
	})

	t.Run("nil service", func(t *testing.T) {
		server := NewTestableETCMeisaiServer(nil, nil, nil, nil, logger)

		req := &pb.GetImportSessionRequest{SessionId: "session-123"}
		_, err := server.GetImportSession(context.Background(), req)

		assert.Error(t, err)
		st, ok := status.FromError(err)
		assert.True(t, ok)
		assert.Equal(t, codes.Internal, st.Code())
		assert.Contains(t, st.Message(), "service not available")
	})
}

func TestTestableETCMeisaiServer_ListImportSessions_Complete(t *testing.T) {
	logger := log.New(os.Stderr, "[TEST] ", log.LstdFlags)

	t.Run("adapter conversion error in list", func(t *testing.T) {
		mockService := new(MockImportService)
		server := NewTestableETCMeisaiServer(nil, nil, mockService, nil, logger)

		// Return a list with a nil session to force adapter error
		expectedSessions := []*models.ImportSession{nil}

		mockService.On("ListImportSessions", mock.Anything, mock.Anything).Return(&services.ListImportSessionsResponse{
			Sessions:   expectedSessions,
			TotalCount: 1,
		}, nil)

		req := &pb.ListImportSessionsRequest{
			Page:     1,
			PageSize: 50,
		}

		_, err := server.ListImportSessions(context.Background(), req)

		assert.Error(t, err)
		st, ok := status.FromError(err)
		assert.True(t, ok)
		assert.Equal(t, codes.Internal, st.Code())
		assert.Contains(t, st.Message(), "failed to convert sessions")
		mockService.AssertExpectations(t)
	})

	t.Run("nil service", func(t *testing.T) {
		server := NewTestableETCMeisaiServer(nil, nil, nil, nil, logger)

		req := &pb.ListImportSessionsRequest{
			Page:     1,
			PageSize: 50,
		}

		_, err := server.ListImportSessions(context.Background(), req)

		assert.Error(t, err)
		st, ok := status.FromError(err)
		assert.True(t, ok)
		assert.Equal(t, codes.Internal, st.Code())
		assert.Contains(t, st.Message(), "service not available")
	})
}

// Tests for missing methods with 0% coverage
func TestTestableETCMeisaiServer_DeleteMapping_Complete(t *testing.T) {
	logger := log.New(os.Stderr, "[TEST] ", log.LstdFlags)

	t.Run("successful deletion", func(t *testing.T) {
		mockService := new(MockETCMappingService)
		server := NewTestableETCMeisaiServer(nil, mockService, nil, nil, logger)

		mockService.On("DeleteMapping", mock.Anything, int64(1)).Return(nil)

		req := &pb.DeleteMappingRequest{Id: 1}
		_, err := server.DeleteMapping(context.Background(), req)

		assert.NoError(t, err)
		mockService.AssertExpectations(t)
	})

	t.Run("not found error", func(t *testing.T) {
		mockService := new(MockETCMappingService)
		server := NewTestableETCMeisaiServer(nil, mockService, nil, nil, logger)

		mockService.On("DeleteMapping", mock.Anything, int64(999)).Return(errors.New("mapping not found"))

		req := &pb.DeleteMappingRequest{Id: 999}
		_, err := server.DeleteMapping(context.Background(), req)

		assert.Error(t, err)
		st, ok := status.FromError(err)
		assert.True(t, ok)
		assert.Equal(t, codes.NotFound, st.Code())
		mockService.AssertExpectations(t)
	})

	t.Run("nil service", func(t *testing.T) {
		server := NewTestableETCMeisaiServer(nil, nil, nil, nil, logger)

		req := &pb.DeleteMappingRequest{Id: 1}
		_, err := server.DeleteMapping(context.Background(), req)

		assert.Error(t, err)
		st, ok := status.FromError(err)
		assert.True(t, ok)
		assert.Equal(t, codes.Internal, st.Code())
		assert.Contains(t, st.Message(), "service not available")
	})

	t.Run("invalid ID", func(t *testing.T) {
		mockService := new(MockETCMappingService)
		server := NewTestableETCMeisaiServer(nil, mockService, nil, nil, logger)

		req := &pb.DeleteMappingRequest{Id: 0} // Invalid ID
		_, err := server.DeleteMapping(context.Background(), req)

		assert.Error(t, err)
		st, ok := status.FromError(err)
		assert.True(t, ok)
		assert.Equal(t, codes.InvalidArgument, st.Code())
		assert.Contains(t, st.Message(), "invalid mapping ID")
	})
}