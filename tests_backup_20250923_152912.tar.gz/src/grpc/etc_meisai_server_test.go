package grpc

import (
	"context"
	"errors"
	"io"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/metadata"
	"google.golang.org/grpc/status"
	"google.golang.org/protobuf/types/known/structpb"

	"github.com/yhonda-ohishi/etc_meisai/src/mocks"
	"github.com/yhonda-ohishi/etc_meisai/src/models"
	"github.com/yhonda-ohishi/etc_meisai/src/pb"
	"github.com/yhonda-ohishi/etc_meisai/src/services"
)

func TestNewETCMeisaiServer(t *testing.T) {
	tests := []struct {
		name                  string
		etcMeisaiService      ETCMeisaiServiceInterface
		etcMappingService     ETCMappingServiceInterface
		importService         ImportServiceInterface
		statisticsService     StatisticsServiceInterface
		logger                LoggerInterface
		expectPanic           bool
		expectedPanicMessage  string
	}{
		{
			name:                 "Valid services with logger",
			etcMeisaiService:     &mocks.MockETCMeisaiService{},
			etcMappingService:    &mocks.MockETCMappingService{},
			importService:        &mocks.MockImportService{},
			statisticsService:    &mocks.MockStatisticsService{},
			logger:               &mocks.MockLogger{},
			expectPanic:          false,
		},
		{
			name:                 "Valid services without logger (should create default)",
			etcMeisaiService:     &mocks.MockETCMeisaiService{},
			etcMappingService:    &mocks.MockETCMappingService{},
			importService:        &mocks.MockImportService{},
			statisticsService:    &mocks.MockStatisticsService{},
			logger:               nil,
			expectPanic:          false,
		},
		{
			name:                 "Nil etcMeisaiService",
			etcMeisaiService:     nil,
			etcMappingService:    &mocks.MockETCMappingService{},
			importService:        &mocks.MockImportService{},
			statisticsService:    &mocks.MockStatisticsService{},
			logger:               &mocks.MockLogger{},
			expectPanic:          true,
			expectedPanicMessage: "etcMeisaiService cannot be nil",
		},
		{
			name:                 "Nil etcMappingService",
			etcMeisaiService:     &mocks.MockETCMeisaiService{},
			etcMappingService:    nil,
			importService:        &mocks.MockImportService{},
			statisticsService:    &mocks.MockStatisticsService{},
			logger:               &mocks.MockLogger{},
			expectPanic:          true,
			expectedPanicMessage: "etcMappingService cannot be nil",
		},
		{
			name:                 "Nil importService",
			etcMeisaiService:     &mocks.MockETCMeisaiService{},
			etcMappingService:    &mocks.MockETCMappingService{},
			importService:        nil,
			statisticsService:    &mocks.MockStatisticsService{},
			logger:               &mocks.MockLogger{},
			expectPanic:          true,
			expectedPanicMessage: "importService cannot be nil",
		},
		{
			name:                 "Nil statisticsService",
			etcMeisaiService:     &mocks.MockETCMeisaiService{},
			etcMappingService:    &mocks.MockETCMappingService{},
			importService:        &mocks.MockImportService{},
			statisticsService:    nil,
			logger:               &mocks.MockLogger{},
			expectPanic:          true,
			expectedPanicMessage: "statisticsService cannot be nil",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if tt.expectPanic {
				assert.PanicsWithValue(t, tt.expectedPanicMessage, func() {
					NewETCMeisaiServer(tt.etcMeisaiService, tt.etcMappingService, tt.importService, tt.statisticsService, tt.logger)
				})
			} else {
				server := NewETCMeisaiServer(tt.etcMeisaiService, tt.etcMappingService, tt.importService, tt.statisticsService, tt.logger)
				assert.NotNil(t, server)
				assert.NotNil(t, server.logger) // Should have logger even if nil was passed
			}
		})
	}
}

func TestETCMeisaiServer_CreateRecord(t *testing.T) {
	tests := []struct {
		name          string
		req           *pb.CreateRecordRequest
		setupMocks    func(*mocks.MockETCMeisaiService, *mocks.MockLogger)
		expectedError codes.Code
		expectedMsg   string
	}{
		{
			name: "Success",
			req: &pb.CreateRecordRequest{
				Record: &pb.ETCMeisaiRecord{
					Date:          "2023-01-01",
					Time:          "10:30:00",
					EntranceIc:    "Test Entrance",
					ExitIc:        "Test Exit",
					CarNumber:     "1234",
					EtcCardNumber: "1234567890123456",
					TollAmount:    1000,
				},
			},
			setupMocks: func(service *mocks.MockETCMeisaiService, logger *mocks.MockLogger) {
				service.On("CreateRecord", mock.Anything, mock.AnythingOfType("*services.CreateRecordParams")).Return(
					&models.ETCMeisaiRecord{
						ID:            1,
						Hash:          "testhash",
						Date:          time.Date(2023, 1, 1, 0, 0, 0, 0, time.UTC),
						Time:          "10:30:00",
						EntranceIC:    "Test Entrance",
						ExitIC:        "Test Exit",
						CarNumber:     "1234",
						ETCCardNumber: "1234567890123456",
						TollAmount:    1000,
						CreatedAt:     time.Now(),
					}, nil)
			},
			expectedError: codes.OK,
		},
		{
			name:          "Nil request",
			req:           nil,
			setupMocks:    func(*mocks.MockETCMeisaiService, *mocks.MockLogger) {},
			expectedError: codes.InvalidArgument,
			expectedMsg:   "request and record cannot be nil",
		},
		{
			name: "Nil record",
			req: &pb.CreateRecordRequest{
				Record: nil,
			},
			setupMocks:    func(*mocks.MockETCMeisaiService, *mocks.MockLogger) {},
			expectedError: codes.InvalidArgument,
			expectedMsg:   "request and record cannot be nil",
		},
		{
			name: "Missing date",
			req: &pb.CreateRecordRequest{
				Record: &pb.ETCMeisaiRecord{
					Date:          "",
					Time:          "10:30:00",
					EntranceIc:    "Test Entrance",
					ExitIc:        "Test Exit",
					CarNumber:     "1234",
					EtcCardNumber: "1234567890123456",
					TollAmount:    1000,
				},
			},
			setupMocks:    func(*mocks.MockETCMeisaiService, *mocks.MockLogger) {},
			expectedError: codes.InvalidArgument,
			expectedMsg:   "date is required",
		},
		{
			name: "Missing time",
			req: &pb.CreateRecordRequest{
				Record: &pb.ETCMeisaiRecord{
					Date:          "2023-01-01",
					Time:          "",
					EntranceIc:    "Test Entrance",
					ExitIc:        "Test Exit",
					CarNumber:     "1234",
					EtcCardNumber: "1234567890123456",
					TollAmount:    1000,
				},
			},
			setupMocks:    func(*mocks.MockETCMeisaiService, *mocks.MockLogger) {},
			expectedError: codes.InvalidArgument,
			expectedMsg:   "time is required",
		},
		{
			name: "Invalid date format",
			req: &pb.CreateRecordRequest{
				Record: &pb.ETCMeisaiRecord{
					Date:          "invalid-date",
					Time:          "10:30:00",
					EntranceIc:    "Test Entrance",
					ExitIc:        "Test Exit",
					CarNumber:     "1234",
					EtcCardNumber: "1234567890123456",
					TollAmount:    1000,
				},
			},
			setupMocks: func(service *mocks.MockETCMeisaiService, logger *mocks.MockLogger) {
				logger.On("Printf", mock.AnythingOfType("string"), mock.Anything).Return()
			},
			expectedError: codes.InvalidArgument,
			expectedMsg:   "invalid record data",
		},
		{
			name: "Service error",
			req: &pb.CreateRecordRequest{
				Record: &pb.ETCMeisaiRecord{
					Date:          "2023-01-01",
					Time:          "10:30:00",
					EntranceIc:    "Test Entrance",
					ExitIc:        "Test Exit",
					CarNumber:     "1234",
					EtcCardNumber: "1234567890123456",
					TollAmount:    1000,
				},
			},
			setupMocks: func(service *mocks.MockETCMeisaiService, logger *mocks.MockLogger) {
				service.On("CreateRecord", mock.Anything, mock.AnythingOfType("*services.CreateRecordParams")).Return(
					(*models.ETCMeisaiRecord)(nil), errors.New("service error"))
				logger.On("Printf", mock.AnythingOfType("string"), mock.Anything).Return()
			},
			expectedError: codes.Internal,
			expectedMsg:   "failed to create record",
		},
		{
			name: "Negative toll amount",
			req: &pb.CreateRecordRequest{
				Record: &pb.ETCMeisaiRecord{
					Date:          "2023-01-01",
					Time:          "10:30:00",
					EntranceIc:    "Test Entrance",
					ExitIc:        "Test Exit",
					CarNumber:     "1234",
					EtcCardNumber: "1234567890123456",
					TollAmount:    -100,
				},
			},
			setupMocks:    func(*mocks.MockETCMeisaiService, *mocks.MockLogger) {},
			expectedError: codes.InvalidArgument,
			expectedMsg:   "toll_amount must be non-negative",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockService := &mocks.MockETCMeisaiService{}
			mockMappingService := &mocks.MockETCMappingService{}
			mockImportService := &mocks.MockImportService{}
			mockStatsService := &mocks.MockStatisticsService{}
			mockLogger := &mocks.MockLogger{}

			tt.setupMocks(mockService, mockLogger)

			server := NewETCMeisaiServer(mockService, mockMappingService, mockImportService, mockStatsService, mockLogger)

			resp, err := server.CreateRecord(context.Background(), tt.req)

			if tt.expectedError == codes.OK {
				assert.NoError(t, err)
				assert.NotNil(t, resp)
				assert.NotNil(t, resp.Record)
			} else {
				assert.Error(t, err)
				assert.Nil(t, resp)
				st, ok := status.FromError(err)
				assert.True(t, ok)
				assert.Equal(t, tt.expectedError, st.Code())
				if tt.expectedMsg != "" {
					assert.Contains(t, st.Message(), tt.expectedMsg)
				}
			}

			mockService.AssertExpectations(t)
			mockLogger.AssertExpectations(t)
		})
	}
}

func TestETCMeisaiServer_GetRecord(t *testing.T) {
	tests := []struct {
		name          string
		req           *pb.GetRecordRequest
		setupMocks    func(*mocks.MockETCMeisaiService, *mocks.MockLogger)
		expectedError codes.Code
		expectedMsg   string
	}{
		{
			name: "Success",
			req: &pb.GetRecordRequest{
				Id: 1,
			},
			setupMocks: func(service *mocks.MockETCMeisaiService, logger *mocks.MockLogger) {
				service.On("GetRecord", mock.Anything, int64(1)).Return(
					&models.ETCMeisaiRecord{
						ID:            1,
						Hash:          "testhash",
						Date:          time.Date(2023, 1, 1, 0, 0, 0, 0, time.UTC),
						Time:          "10:30:00",
						EntranceIC:    "Test Entrance",
						ExitIC:        "Test Exit",
						CarNumber:     "1234",
						ETCCardNumber: "1234567890123456",
						TollAmount:    1000,
						CreatedAt:     time.Now(),
					}, nil)
			},
			expectedError: codes.OK,
		},
		{
			name:          "Nil request",
			req:           nil,
			setupMocks:    func(*mocks.MockETCMeisaiService, *mocks.MockLogger) {},
			expectedError: codes.InvalidArgument,
			expectedMsg:   "invalid record ID",
		},
		{
			name: "Invalid ID (zero)",
			req: &pb.GetRecordRequest{
				Id: 0,
			},
			setupMocks:    func(*mocks.MockETCMeisaiService, *mocks.MockLogger) {},
			expectedError: codes.InvalidArgument,
			expectedMsg:   "invalid record ID",
		},
		{
			name: "Invalid ID (negative)",
			req: &pb.GetRecordRequest{
				Id: -1,
			},
			setupMocks:    func(*mocks.MockETCMeisaiService, *mocks.MockLogger) {},
			expectedError: codes.InvalidArgument,
			expectedMsg:   "invalid record ID",
		},
		{
			name: "Record not found",
			req: &pb.GetRecordRequest{
				Id: 999,
			},
			setupMocks: func(service *mocks.MockETCMeisaiService, logger *mocks.MockLogger) {
				service.On("GetRecord", mock.Anything, int64(999)).Return(
					(*models.ETCMeisaiRecord)(nil), errors.New("record not found"))
				logger.On("Printf", mock.AnythingOfType("string"), mock.Anything).Return()
			},
			expectedError: codes.NotFound,
			expectedMsg:   "record not found",
		},
		{
			name: "Service error",
			req: &pb.GetRecordRequest{
				Id: 1,
			},
			setupMocks: func(service *mocks.MockETCMeisaiService, logger *mocks.MockLogger) {
				service.On("GetRecord", mock.Anything, int64(1)).Return(
					(*models.ETCMeisaiRecord)(nil), errors.New("database error"))
				logger.On("Printf", mock.AnythingOfType("string"), mock.Anything).Return()
			},
			expectedError: codes.Internal,
			expectedMsg:   "failed to get record",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockService := &mocks.MockETCMeisaiService{}
			mockMappingService := &mocks.MockETCMappingService{}
			mockImportService := &mocks.MockImportService{}
			mockStatsService := &mocks.MockStatisticsService{}
			mockLogger := &mocks.MockLogger{}

			tt.setupMocks(mockService, mockLogger)

			server := NewETCMeisaiServer(mockService, mockMappingService, mockImportService, mockStatsService, mockLogger)

			resp, err := server.GetRecord(context.Background(), tt.req)

			if tt.expectedError == codes.OK {
				assert.NoError(t, err)
				assert.NotNil(t, resp)
				assert.NotNil(t, resp.Record)
			} else {
				assert.Error(t, err)
				assert.Nil(t, resp)
				st, ok := status.FromError(err)
				assert.True(t, ok)
				assert.Equal(t, tt.expectedError, st.Code())
				if tt.expectedMsg != "" {
					assert.Contains(t, st.Message(), tt.expectedMsg)
				}
			}

			mockService.AssertExpectations(t)
			mockLogger.AssertExpectations(t)
		})
	}
}

func TestETCMeisaiServer_ListRecords(t *testing.T) {
	tests := []struct {
		name          string
		req           *pb.ListRecordsRequest
		setupMocks    func(*mocks.MockETCMeisaiService, *mocks.MockLogger)
		expectedError codes.Code
		expectedMsg   string
	}{
		{
			name: "Success with default pagination",
			req:  &pb.ListRecordsRequest{},
			setupMocks: func(service *mocks.MockETCMeisaiService, logger *mocks.MockLogger) {
				service.On("ListRecords", mock.Anything, mock.AnythingOfType("*services.ListRecordsParams")).Return(
					&services.ListRecordsResponse{
						Records: []*models.ETCMeisaiRecord{
							{
								ID:            1,
								Hash:          "testhash",
								Date:          time.Date(2023, 1, 1, 0, 0, 0, 0, time.UTC),
								Time:          "10:30:00",
								EntranceIC:    "Test Entrance",
								ExitIC:        "Test Exit",
								CarNumber:     "1234",
								ETCCardNumber: "1234567890123456",
								TollAmount:    1000,
								CreatedAt:     time.Now(),
									},
						},
						TotalCount: 1,
					}, nil)
			},
			expectedError: codes.OK,
		},
		{
			name: "Success with custom pagination",
			req: &pb.ListRecordsRequest{
				Page:     2,
				PageSize: 25,
			},
			setupMocks: func(service *mocks.MockETCMeisaiService, logger *mocks.MockLogger) {
				service.On("ListRecords", mock.Anything, mock.MatchedBy(func(params *services.ListRecordsParams) bool {
					return params.Page == 2 && params.PageSize == 25
				})).Return(
					&services.ListRecordsResponse{
						Records:    []*models.ETCMeisaiRecord{},
						TotalCount: 0,
					}, nil)
			},
			expectedError: codes.OK,
		},
		{
			name: "Success with large page size (should be capped)",
			req: &pb.ListRecordsRequest{
				Page:     1,
				PageSize: 2000,
			},
			setupMocks: func(service *mocks.MockETCMeisaiService, logger *mocks.MockLogger) {
				service.On("ListRecords", mock.Anything, mock.MatchedBy(func(params *services.ListRecordsParams) bool {
					return params.PageSize == 1000 // Should be capped at 1000
				})).Return(
					&services.ListRecordsResponse{
						Records:    []*models.ETCMeisaiRecord{},
						TotalCount: 0,
					}, nil)
			},
			expectedError: codes.OK,
		},
		{
			name: "Success with filters",
			req: &pb.ListRecordsRequest{
				Page:           1,
				PageSize:       50,
				DateFrom:       stringPtr("2023-01-01"),
				DateTo:         stringPtr("2023-12-31"),
				CarNumber:      stringPtr("1234"),
				EtcCardNumber:  stringPtr("1234567890123456"),
				SortBy:         "date",
				SortOrder:      pb.SortOrder_SORT_ORDER_DESC,
			},
			setupMocks: func(service *mocks.MockETCMeisaiService, logger *mocks.MockLogger) {
				service.On("ListRecords", mock.Anything, mock.MatchedBy(func(params *services.ListRecordsParams) bool {
					return params.SortBy == "date" && params.SortOrder == "desc" &&
						   params.CarNumber != nil && *params.CarNumber == "1234"
				})).Return(
					&services.ListRecordsResponse{
						Records:    []*models.ETCMeisaiRecord{},
						TotalCount: 0,
					}, nil)
			},
			expectedError: codes.OK,
		},
		{
			name:          "Nil request",
			req:           nil,
			setupMocks:    func(*mocks.MockETCMeisaiService, *mocks.MockLogger) {},
			expectedError: codes.InvalidArgument,
			expectedMsg:   "request cannot be nil",
		},
		{
			name: "Invalid date format",
			req: &pb.ListRecordsRequest{
				DateFrom: stringPtr("invalid-date"),
			},
			setupMocks:    func(*mocks.MockETCMeisaiService, *mocks.MockLogger) {},
			expectedError: codes.InvalidArgument,
		},
		{
			name: "Service error",
			req:  &pb.ListRecordsRequest{},
			setupMocks: func(service *mocks.MockETCMeisaiService, logger *mocks.MockLogger) {
				service.On("ListRecords", mock.Anything, mock.AnythingOfType("*services.ListRecordsParams")).Return(
					(*services.ListRecordsResponse)(nil), errors.New("database error"))
				logger.On("Printf", mock.AnythingOfType("string"), mock.Anything).Return()
			},
			expectedError: codes.Internal,
			expectedMsg:   "failed to list records",
		},
		// Note: Adapter conversion error test removed - zero time doesn't actually cause conversion errors
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockService := &mocks.MockETCMeisaiService{}
			mockMappingService := &mocks.MockETCMappingService{}
			mockImportService := &mocks.MockImportService{}
			mockStatsService := &mocks.MockStatisticsService{}
			mockLogger := &mocks.MockLogger{}

			tt.setupMocks(mockService, mockLogger)

			server := NewETCMeisaiServer(mockService, mockMappingService, mockImportService, mockStatsService, mockLogger)

			resp, err := server.ListRecords(context.Background(), tt.req)

			if tt.expectedError == codes.OK {
				assert.NoError(t, err)
				assert.NotNil(t, resp)
				assert.NotNil(t, resp.Records)
			} else {
				assert.Error(t, err)
				assert.Nil(t, resp)
				st, ok := status.FromError(err)
				assert.True(t, ok)
				assert.Equal(t, tt.expectedError, st.Code())
				if tt.expectedMsg != "" {
					assert.Contains(t, st.Message(), tt.expectedMsg)
				}
			}

			mockService.AssertExpectations(t)
			mockLogger.AssertExpectations(t)
		})
	}
}

func TestETCMeisaiServer_UpdateRecord(t *testing.T) {
	tests := []struct {
		name          string
		req           *pb.UpdateRecordRequest
		setupMocks    func(*mocks.MockETCMeisaiService, *mocks.MockLogger)
		expectedError codes.Code
		expectedMsg   string
	}{
		{
			name: "Success",
			req: &pb.UpdateRecordRequest{
				Id: 1,
				Record: &pb.ETCMeisaiRecord{
					Date:          "2023-01-01",
					Time:          "10:30:00",
					EntranceIc:    "Test Entrance",
					ExitIc:        "Test Exit",
					CarNumber:     "1234",
					EtcCardNumber: "1234567890123456",
					TollAmount:    1000,
				},
			},
			setupMocks: func(service *mocks.MockETCMeisaiService, logger *mocks.MockLogger) {
				service.On("UpdateRecord", mock.Anything, int64(1), mock.AnythingOfType("*services.CreateRecordParams")).Return(
					&models.ETCMeisaiRecord{
						ID:            1,
						Hash:          "testhash",
						Date:          time.Date(2023, 1, 1, 0, 0, 0, 0, time.UTC),
						Time:          "10:30:00",
						EntranceIC:    "Test Entrance",
						ExitIC:        "Test Exit",
						CarNumber:     "1234",
						ETCCardNumber: "1234567890123456",
						TollAmount:    1000,
						CreatedAt:     time.Now(),
					}, nil)
			},
			expectedError: codes.OK,
		},
		{
			name:          "Nil request",
			req:           nil,
			setupMocks:    func(*mocks.MockETCMeisaiService, *mocks.MockLogger) {},
			expectedError: codes.InvalidArgument,
			expectedMsg:   "invalid request or record ID",
		},
		{
			name: "Invalid ID",
			req: &pb.UpdateRecordRequest{
				Id: 0,
				Record: &pb.ETCMeisaiRecord{
					Date:          "2023-01-01",
					Time:          "10:30:00",
					EntranceIc:    "Test Entrance",
					ExitIc:        "Test Exit",
					CarNumber:     "1234",
					EtcCardNumber: "1234567890123456",
					TollAmount:    1000,
				},
			},
			setupMocks:    func(*mocks.MockETCMeisaiService, *mocks.MockLogger) {},
			expectedError: codes.InvalidArgument,
			expectedMsg:   "invalid request or record ID",
		},
		{
			name: "Nil record",
			req: &pb.UpdateRecordRequest{
				Id:     1,
				Record: nil,
			},
			setupMocks:    func(*mocks.MockETCMeisaiService, *mocks.MockLogger) {},
			expectedError: codes.InvalidArgument,
			expectedMsg:   "invalid request or record ID",
		},
		{
			name: "Record not found",
			req: &pb.UpdateRecordRequest{
				Id: 999,
				Record: &pb.ETCMeisaiRecord{
					Date:          "2023-01-01",
					Time:          "10:30:00",
					EntranceIc:    "Test Entrance",
					ExitIc:        "Test Exit",
					CarNumber:     "1234",
					EtcCardNumber: "1234567890123456",
					TollAmount:    1000,
				},
			},
			setupMocks: func(service *mocks.MockETCMeisaiService, logger *mocks.MockLogger) {
				service.On("UpdateRecord", mock.Anything, int64(999), mock.AnythingOfType("*services.CreateRecordParams")).Return(
					(*models.ETCMeisaiRecord)(nil), errors.New("record not found"))
				logger.On("Printf", mock.AnythingOfType("string"), mock.Anything).Return()
			},
			expectedError: codes.NotFound,
			expectedMsg:   "record not found",
		},
		{
			name: "Service error",
			req: &pb.UpdateRecordRequest{
				Id: 1,
				Record: &pb.ETCMeisaiRecord{
					Date:          "2023-01-01",
					Time:          "10:30:00",
					EntranceIc:    "Test Entrance",
					ExitIc:        "Test Exit",
					CarNumber:     "1234",
					EtcCardNumber: "1234567890123456",
					TollAmount:    1000,
				},
			},
			setupMocks: func(service *mocks.MockETCMeisaiService, logger *mocks.MockLogger) {
				service.On("UpdateRecord", mock.Anything, int64(1), mock.AnythingOfType("*services.CreateRecordParams")).Return(
					(*models.ETCMeisaiRecord)(nil), errors.New("database error"))
				logger.On("Printf", mock.AnythingOfType("string"), mock.Anything).Return()
			},
			expectedError: codes.Internal,
			expectedMsg:   "failed to update record",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockService := &mocks.MockETCMeisaiService{}
			mockMappingService := &mocks.MockETCMappingService{}
			mockImportService := &mocks.MockImportService{}
			mockStatsService := &mocks.MockStatisticsService{}
			mockLogger := &mocks.MockLogger{}

			tt.setupMocks(mockService, mockLogger)

			server := NewETCMeisaiServer(mockService, mockMappingService, mockImportService, mockStatsService, mockLogger)

			resp, err := server.UpdateRecord(context.Background(), tt.req)

			if tt.expectedError == codes.OK {
				assert.NoError(t, err)
				assert.NotNil(t, resp)
				assert.NotNil(t, resp.Record)
			} else {
				assert.Error(t, err)
				assert.Nil(t, resp)
				st, ok := status.FromError(err)
				assert.True(t, ok)
				assert.Equal(t, tt.expectedError, st.Code())
				if tt.expectedMsg != "" {
					assert.Contains(t, st.Message(), tt.expectedMsg)
				}
			}

			mockService.AssertExpectations(t)
			mockLogger.AssertExpectations(t)
		})
	}
}

func TestETCMeisaiServer_DeleteRecord(t *testing.T) {
	tests := []struct {
		name          string
		req           *pb.DeleteRecordRequest
		setupMocks    func(*mocks.MockETCMeisaiService, *mocks.MockLogger)
		expectedError codes.Code
		expectedMsg   string
	}{
		{
			name: "Success",
			req: &pb.DeleteRecordRequest{
				Id: 1,
			},
			setupMocks: func(service *mocks.MockETCMeisaiService, logger *mocks.MockLogger) {
				service.On("DeleteRecord", mock.Anything, int64(1)).Return(nil)
			},
			expectedError: codes.OK,
		},
		{
			name:          "Nil request",
			req:           nil,
			setupMocks:    func(*mocks.MockETCMeisaiService, *mocks.MockLogger) {},
			expectedError: codes.InvalidArgument,
			expectedMsg:   "invalid record ID",
		},
		{
			name: "Invalid ID",
			req: &pb.DeleteRecordRequest{
				Id: 0,
			},
			setupMocks:    func(*mocks.MockETCMeisaiService, *mocks.MockLogger) {},
			expectedError: codes.InvalidArgument,
			expectedMsg:   "invalid record ID",
		},
		{
			name: "Record not found",
			req: &pb.DeleteRecordRequest{
				Id: 999,
			},
			setupMocks: func(service *mocks.MockETCMeisaiService, logger *mocks.MockLogger) {
				service.On("DeleteRecord", mock.Anything, int64(999)).Return(errors.New("record not found"))
				logger.On("Printf", mock.AnythingOfType("string"), mock.Anything).Return()
			},
			expectedError: codes.NotFound,
			expectedMsg:   "record not found",
		},
		{
			name: "Service error",
			req: &pb.DeleteRecordRequest{
				Id: 1,
			},
			setupMocks: func(service *mocks.MockETCMeisaiService, logger *mocks.MockLogger) {
				service.On("DeleteRecord", mock.Anything, int64(1)).Return(errors.New("database error"))
				logger.On("Printf", mock.AnythingOfType("string"), mock.Anything).Return()
			},
			expectedError: codes.Internal,
			expectedMsg:   "failed to delete record",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockService := &mocks.MockETCMeisaiService{}
			mockMappingService := &mocks.MockETCMappingService{}
			mockImportService := &mocks.MockImportService{}
			mockStatsService := &mocks.MockStatisticsService{}
			mockLogger := &mocks.MockLogger{}

			tt.setupMocks(mockService, mockLogger)

			server := NewETCMeisaiServer(mockService, mockMappingService, mockImportService, mockStatsService, mockLogger)

			resp, err := server.DeleteRecord(context.Background(), tt.req)

			if tt.expectedError == codes.OK {
				assert.NoError(t, err)
				assert.NotNil(t, resp)
			} else {
				assert.Error(t, err)
				assert.Nil(t, resp)
				st, ok := status.FromError(err)
				assert.True(t, ok)
				assert.Equal(t, tt.expectedError, st.Code())
				if tt.expectedMsg != "" {
					assert.Contains(t, st.Message(), tt.expectedMsg)
				}
			}

			mockService.AssertExpectations(t)
			mockLogger.AssertExpectations(t)
		})
	}
}

func TestETCMeisaiServer_ImportCSV(t *testing.T) {
	tests := []struct {
		name          string
		req           *pb.ImportCSVRequest
		setupMocks    func(*mocks.MockImportService, *mocks.MockLogger)
		expectedError codes.Code
		expectedMsg   string
	}{
		{
			name: "Success",
			req: &pb.ImportCSVRequest{
				AccountType: "corporate",
				AccountId:   "test_account",
				FileName:    "test.csv",
				FileContent: []byte("Date,Time,Entrance,Exit,Amount,Car,Card\n2023-01-01,10:30:00,A,B,1000,1234,1234567890123456"),
			},
			setupMocks: func(service *mocks.MockImportService, logger *mocks.MockLogger) {
				service.On("ImportCSV", mock.Anything, mock.AnythingOfType("*services.ImportCSVParams"), mock.AnythingOfType("*strings.Reader")).Return(
					&services.ImportCSVResult{
						Session: &models.ImportSession{
							ID:           "test_session",
							FileName:     "test.csv",
							Status:       "completed",
							ProcessedRows: 1,
							CreatedAt:    time.Now(),
						},
						SuccessCount:   1,
						ErrorCount:     0,
						DuplicateCount: 0,
					}, nil)
			},
			expectedError: codes.OK,
		},
		{
			name:          "Nil request",
			req:           nil,
			setupMocks:    func(*mocks.MockImportService, *mocks.MockLogger) {},
			expectedError: codes.InvalidArgument,
			expectedMsg:   "request cannot be nil",
		},
		{
			name: "Missing account type",
			req: &pb.ImportCSVRequest{
				AccountType: "",
				AccountId:   "test_account",
				FileName:    "test.csv",
				FileContent: []byte("content"),
			},
			setupMocks:    func(*mocks.MockImportService, *mocks.MockLogger) {},
			expectedError: codes.InvalidArgument,
			expectedMsg:   "account_type, account_id, and file_name are required",
		},
		{
			name: "Missing account ID",
			req: &pb.ImportCSVRequest{
				AccountType: "corporate",
				AccountId:   "",
				FileName:    "test.csv",
				FileContent: []byte("content"),
			},
			setupMocks:    func(*mocks.MockImportService, *mocks.MockLogger) {},
			expectedError: codes.InvalidArgument,
			expectedMsg:   "account_type, account_id, and file_name are required",
		},
		{
			name: "Missing file name",
			req: &pb.ImportCSVRequest{
				AccountType: "corporate",
				AccountId:   "test_account",
				FileName:    "",
				FileContent: []byte("content"),
			},
			setupMocks:    func(*mocks.MockImportService, *mocks.MockLogger) {},
			expectedError: codes.InvalidArgument,
			expectedMsg:   "account_type, account_id, and file_name are required",
		},
		{
			name: "Empty file content",
			req: &pb.ImportCSVRequest{
				AccountType: "corporate",
				AccountId:   "test_account",
				FileName:    "test.csv",
				FileContent: []byte{},
			},
			setupMocks:    func(*mocks.MockImportService, *mocks.MockLogger) {},
			expectedError: codes.InvalidArgument,
			expectedMsg:   "file_content cannot be empty",
		},
		{
			name: "Service error",
			req: &pb.ImportCSVRequest{
				AccountType: "corporate",
				AccountId:   "test_account",
				FileName:    "test.csv",
				FileContent: []byte("content"),
			},
			setupMocks: func(service *mocks.MockImportService, logger *mocks.MockLogger) {
				service.On("ImportCSV", mock.Anything, mock.AnythingOfType("*services.ImportCSVParams"), mock.AnythingOfType("*strings.Reader")).Return(
					(*services.ImportCSVResult)(nil), errors.New("import error"))
				logger.On("Printf", mock.AnythingOfType("string"), mock.Anything).Return()
			},
			expectedError: codes.Internal,
			expectedMsg:   "failed to import CSV",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockService := &mocks.MockETCMeisaiService{}
			mockMappingService := &mocks.MockETCMappingService{}
			mockImportService := &mocks.MockImportService{}
			mockStatsService := &mocks.MockStatisticsService{}
			mockLogger := &mocks.MockLogger{}

			tt.setupMocks(mockImportService, mockLogger)

			server := NewETCMeisaiServer(mockService, mockMappingService, mockImportService, mockStatsService, mockLogger)

			resp, err := server.ImportCSV(context.Background(), tt.req)

			if tt.expectedError == codes.OK {
				assert.NoError(t, err)
				assert.NotNil(t, resp)
				assert.NotNil(t, resp.Session)
			} else {
				assert.Error(t, err)
				assert.Nil(t, resp)
				st, ok := status.FromError(err)
				assert.True(t, ok)
				assert.Equal(t, tt.expectedError, st.Code())
				if tt.expectedMsg != "" {
					assert.Contains(t, st.Message(), tt.expectedMsg)
				}
			}

			mockImportService.AssertExpectations(t)
			mockLogger.AssertExpectations(t)
		})
	}
}

// Mock stream for testing ImportCSVStream
type mockImportStream struct {
	chunks   []*pb.ImportCSVChunk
	progress []*pb.ImportProgress
	index    int
	sent     []*pb.ImportProgress
}

func (m *mockImportStream) Send(progress *pb.ImportProgress) error {
	m.sent = append(m.sent, progress)
	return nil
}

func (m *mockImportStream) Recv() (*pb.ImportCSVChunk, error) {
	if m.index >= len(m.chunks) {
		return nil, io.EOF
	}
	chunk := m.chunks[m.index]
	m.index++
	return chunk, nil
}

func (m *mockImportStream) Context() context.Context {
	return context.Background()
}

func (m *mockImportStream) SendMsg(msg any) error {
	return nil
}

func (m *mockImportStream) RecvMsg(msg any) error {
	return nil
}

func (m *mockImportStream) SendHeader(md metadata.MD) error {
	return nil
}

func (m *mockImportStream) SetTrailer(md metadata.MD) {
}

func (m *mockImportStream) SetHeader(md metadata.MD) error {
	return nil
}

func TestETCMeisaiServer_ImportCSVStream(t *testing.T) {
	tests := []struct {
		name       string
		chunks     []*pb.ImportCSVChunk
		setupMocks func(*mocks.MockImportService, *mocks.MockLogger)
		expectErr  bool
	}{
		{
			name: "Success with single chunk",
			chunks: []*pb.ImportCSVChunk{
				{
					SessionId: "test_session",
					Data:      []byte("Date,Time,Entrance,Exit,Amount,Car,Card\n2023-01-01,10:30:00,A,B,1000,1234,1234567890123456"),
					IsLast:    true,
				},
			},
			setupMocks: func(service *mocks.MockImportService, logger *mocks.MockLogger) {
				service.On("ImportCSV", mock.Anything, mock.AnythingOfType("*services.ImportCSVParams"), mock.AnythingOfType("*strings.Reader")).Return(
					&services.ImportCSVResult{
						Session: &models.ImportSession{
							ID:           "test_session",
							ProcessedRows: 1,
						},
						SuccessCount:   1,
						ErrorCount:     0,
						DuplicateCount: 0,
					}, nil)
			},
			expectErr: false,
		},
		{
			name: "Success with multiple chunks",
			chunks: []*pb.ImportCSVChunk{
				{
					SessionId: "test_session",
					Data:      []byte("Date,Time,Entrance,Exit"),
					IsLast:    false,
				},
				{
					SessionId: "test_session",
					Data:      []byte(",Amount,Car,Card\n2023-01-01,10:30:00,A,B,1000,1234,1234567890123456"),
					IsLast:    true,
				},
			},
			setupMocks: func(service *mocks.MockImportService, logger *mocks.MockLogger) {
				service.On("ImportCSV", mock.Anything, mock.AnythingOfType("*services.ImportCSVParams"), mock.AnythingOfType("*strings.Reader")).Return(
					&services.ImportCSVResult{
						Session: &models.ImportSession{
							ID:           "test_session",
							ProcessedRows: 1,
						},
						SuccessCount:   1,
						ErrorCount:     0,
						DuplicateCount: 0,
					}, nil)
			},
			expectErr: false,
		},
		{
			name: "Session ID mismatch",
			chunks: []*pb.ImportCSVChunk{
				{
					SessionId: "session1",
					Data:      []byte("data1"),
					IsLast:    false,
				},
				{
					SessionId: "session2",
					Data:      []byte("data2"),
					IsLast:    true,
				},
			},
			setupMocks: func(*mocks.MockImportService, *mocks.MockLogger) {},
			expectErr:  true,
		},
		{
			name: "Import service error",
			chunks: []*pb.ImportCSVChunk{
				{
					SessionId: "test_session",
					Data:      []byte("invalid data"),
					IsLast:    true,
				},
			},
			setupMocks: func(service *mocks.MockImportService, logger *mocks.MockLogger) {
				service.On("ImportCSV", mock.Anything, mock.AnythingOfType("*services.ImportCSVParams"), mock.AnythingOfType("*strings.Reader")).Return(
					(*services.ImportCSVResult)(nil), errors.New("import failed"))
				logger.On("Printf", mock.AnythingOfType("string"), mock.Anything).Return()
			},
			expectErr: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockService := &mocks.MockETCMeisaiService{}
			mockMappingService := &mocks.MockETCMappingService{}
			mockImportService := &mocks.MockImportService{}
			mockStatsService := &mocks.MockStatisticsService{}
			mockLogger := &mocks.MockLogger{}

			tt.setupMocks(mockImportService, mockLogger)

			server := NewETCMeisaiServer(mockService, mockMappingService, mockImportService, mockStatsService, mockLogger)

			stream := &mockImportStream{
				chunks: tt.chunks,
				index:  0,
			}

			err := server.ImportCSVStream(stream)

			if tt.expectErr {
				assert.Error(t, err)
			} else {
				assert.NoError(t, err)
				// Verify progress messages were sent
				assert.NotEmpty(t, stream.sent)
			}

			mockImportService.AssertExpectations(t)
			mockLogger.AssertExpectations(t)
		})
	}
}

func TestETCMeisaiServer_GetImportSession(t *testing.T) {
	tests := []struct {
		name          string
		req           *pb.GetImportSessionRequest
		setupMocks    func(*mocks.MockImportService, *mocks.MockLogger)
		expectedError codes.Code
		expectedMsg   string
	}{
		{
			name: "Success",
			req: &pb.GetImportSessionRequest{
				SessionId: "test_session",
			},
			setupMocks: func(service *mocks.MockImportService, logger *mocks.MockLogger) {
				service.On("GetImportSession", mock.Anything, "test_session").Return(
					&models.ImportSession{
						ID:           "test_session",
						FileName:     "test.csv",
						Status:       "completed",
						ProcessedRows: 1,
						CreatedAt:    time.Now(),
					}, nil)
			},
			expectedError: codes.OK,
		},
		{
			name:          "Nil request",
			req:           nil,
			setupMocks:    func(*mocks.MockImportService, *mocks.MockLogger) {},
			expectedError: codes.InvalidArgument,
			expectedMsg:   "session_id is required",
		},
		{
			name: "Empty session ID",
			req: &pb.GetImportSessionRequest{
				SessionId: "",
			},
			setupMocks:    func(*mocks.MockImportService, *mocks.MockLogger) {},
			expectedError: codes.InvalidArgument,
			expectedMsg:   "session_id is required",
		},
		{
			name: "Session not found",
			req: &pb.GetImportSessionRequest{
				SessionId: "nonexistent",
			},
			setupMocks: func(service *mocks.MockImportService, logger *mocks.MockLogger) {
				service.On("GetImportSession", mock.Anything, "nonexistent").Return(
					(*models.ImportSession)(nil), errors.New("session not found"))
				logger.On("Printf", mock.AnythingOfType("string"), mock.Anything).Return()
			},
			expectedError: codes.NotFound,
			expectedMsg:   "session not found",
		},
		{
			name: "Service error",
			req: &pb.GetImportSessionRequest{
				SessionId: "test_session",
			},
			setupMocks: func(service *mocks.MockImportService, logger *mocks.MockLogger) {
				service.On("GetImportSession", mock.Anything, "test_session").Return(
					(*models.ImportSession)(nil), errors.New("database error"))
				logger.On("Printf", mock.AnythingOfType("string"), mock.Anything).Return()
			},
			expectedError: codes.Internal,
			expectedMsg:   "failed to get session",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockService := &mocks.MockETCMeisaiService{}
			mockMappingService := &mocks.MockETCMappingService{}
			mockImportService := &mocks.MockImportService{}
			mockStatsService := &mocks.MockStatisticsService{}
			mockLogger := &mocks.MockLogger{}

			tt.setupMocks(mockImportService, mockLogger)

			server := NewETCMeisaiServer(mockService, mockMappingService, mockImportService, mockStatsService, mockLogger)

			resp, err := server.GetImportSession(context.Background(), tt.req)

			if tt.expectedError == codes.OK {
				assert.NoError(t, err)
				assert.NotNil(t, resp)
				assert.NotNil(t, resp.Session)
			} else {
				assert.Error(t, err)
				assert.Nil(t, resp)
				st, ok := status.FromError(err)
				assert.True(t, ok)
				assert.Equal(t, tt.expectedError, st.Code())
				if tt.expectedMsg != "" {
					assert.Contains(t, st.Message(), tt.expectedMsg)
				}
			}

			mockImportService.AssertExpectations(t)
			mockLogger.AssertExpectations(t)
		})
	}
}

func TestETCMeisaiServer_ListImportSessions(t *testing.T) {
	tests := []struct {
		name          string
		req           *pb.ListImportSessionsRequest
		setupMocks    func(*mocks.MockImportService, *mocks.MockLogger)
		expectedError codes.Code
		expectedMsg   string
	}{
		{
			name: "Success",
			req:  &pb.ListImportSessionsRequest{},
			setupMocks: func(service *mocks.MockImportService, logger *mocks.MockLogger) {
				service.On("ListImportSessions", mock.Anything, mock.AnythingOfType("*services.ListImportSessionsParams")).Return(
					&services.ListImportSessionsResponse{
						Sessions: []*models.ImportSession{
							{
								ID:           "session1",
								FileName:     "test.csv",
								Status:       "completed",
								ProcessedRows: 1,
								CreatedAt:    time.Now(),
								},
						},
						TotalCount: 1,
					}, nil)
			},
			expectedError: codes.OK,
		},
		{
			name:          "Nil request",
			req:           nil,
			setupMocks:    func(*mocks.MockImportService, *mocks.MockLogger) {},
			expectedError: codes.InvalidArgument,
			expectedMsg:   "request cannot be nil",
		},
		{
			name: "Service error",
			req:  &pb.ListImportSessionsRequest{},
			setupMocks: func(service *mocks.MockImportService, logger *mocks.MockLogger) {
				service.On("ListImportSessions", mock.Anything, mock.AnythingOfType("*services.ListImportSessionsParams")).Return(
					(*services.ListImportSessionsResponse)(nil), errors.New("database error"))
				logger.On("Printf", mock.AnythingOfType("string"), mock.Anything).Return()
			},
			expectedError: codes.Internal,
			expectedMsg:   "failed to list sessions",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockService := &mocks.MockETCMeisaiService{}
			mockMappingService := &mocks.MockETCMappingService{}
			mockImportService := &mocks.MockImportService{}
			mockStatsService := &mocks.MockStatisticsService{}
			mockLogger := &mocks.MockLogger{}

			tt.setupMocks(mockImportService, mockLogger)

			server := NewETCMeisaiServer(mockService, mockMappingService, mockImportService, mockStatsService, mockLogger)

			resp, err := server.ListImportSessions(context.Background(), tt.req)

			if tt.expectedError == codes.OK {
				assert.NoError(t, err)
				assert.NotNil(t, resp)
				assert.NotNil(t, resp.Sessions)
			} else {
				assert.Error(t, err)
				assert.Nil(t, resp)
				st, ok := status.FromError(err)
				assert.True(t, ok)
				assert.Equal(t, tt.expectedError, st.Code())
				if tt.expectedMsg != "" {
					assert.Contains(t, st.Message(), tt.expectedMsg)
				}
			}

			mockImportService.AssertExpectations(t)
			mockLogger.AssertExpectations(t)
		})
	}
}

func TestETCMeisaiServer_CreateMapping(t *testing.T) {
	tests := []struct {
		name          string
		req           *pb.CreateMappingRequest
		setupMocks    func(*mocks.MockETCMappingService, *mocks.MockLogger)
		expectedError codes.Code
		expectedMsg   string
	}{
		{
			name: "Success",
			req: &pb.CreateMappingRequest{
				Mapping: &pb.ETCMapping{
					EtcRecordId:      1,
					MappingType:      "dtako",
					MappedEntityId:   100,
					MappedEntityType: "dtako_record",
					Confidence:       0.95,
					Status:           pb.MappingStatus_MAPPING_STATUS_ACTIVE,
					CreatedBy:        "test_user",
				},
			},
			setupMocks: func(service *mocks.MockETCMappingService, logger *mocks.MockLogger) {
				service.On("CreateMapping", mock.Anything, mock.AnythingOfType("*services.CreateMappingParams")).Return(
					&models.ETCMapping{
						ID:               1,
						ETCRecordID:      1,
						MappingType:      "dtako",
						MappedEntityID:   100,
						MappedEntityType: "dtako_record",
						Confidence:       0.95,
						Status:           "active",
						CreatedBy:        "test_user",
						CreatedAt:        time.Now(),
						UpdatedAt:        time.Now(),
					}, nil)
			},
			expectedError: codes.OK,
		},
		{
			name:          "Nil request",
			req:           nil,
			setupMocks:    func(*mocks.MockETCMappingService, *mocks.MockLogger) {},
			expectedError: codes.InvalidArgument,
			expectedMsg:   "request and mapping cannot be nil",
		},
		{
			name: "Nil mapping",
			req: &pb.CreateMappingRequest{
				Mapping: nil,
			},
			setupMocks:    func(*mocks.MockETCMappingService, *mocks.MockLogger) {},
			expectedError: codes.InvalidArgument,
			expectedMsg:   "request and mapping cannot be nil",
		},
		{
			name: "Invalid ETC record ID",
			req: &pb.CreateMappingRequest{
				Mapping: &pb.ETCMapping{
					EtcRecordId:      0,
					MappingType:      "dtako",
					MappedEntityId:   100,
					MappedEntityType: "dtako_record",
					Confidence:       0.95,
				},
			},
			setupMocks:    func(*mocks.MockETCMappingService, *mocks.MockLogger) {},
			expectedError: codes.InvalidArgument,
			expectedMsg:   "etc_record_id is required",
		},
		{
			name: "Invalid confidence range",
			req: &pb.CreateMappingRequest{
				Mapping: &pb.ETCMapping{
					EtcRecordId:      1,
					MappingType:      "dtako",
					MappedEntityId:   100,
					MappedEntityType: "dtako_record",
					Confidence:       1.5,
				},
			},
			setupMocks:    func(*mocks.MockETCMappingService, *mocks.MockLogger) {},
			expectedError: codes.InvalidArgument,
			expectedMsg:   "confidence must be between 0 and 1",
		},
		{
			name: "Service error",
			req: &pb.CreateMappingRequest{
				Mapping: &pb.ETCMapping{
					EtcRecordId:      1,
					MappingType:      "dtako",
					MappedEntityId:   100,
					MappedEntityType: "dtako_record",
					Confidence:       0.95,
				},
			},
			setupMocks: func(service *mocks.MockETCMappingService, logger *mocks.MockLogger) {
				service.On("CreateMapping", mock.Anything, mock.AnythingOfType("*services.CreateMappingParams")).Return(
					(*models.ETCMapping)(nil), errors.New("database error"))
				logger.On("Printf", mock.AnythingOfType("string"), mock.Anything).Return()
			},
			expectedError: codes.Internal,
			expectedMsg:   "failed to create mapping",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockService := &mocks.MockETCMeisaiService{}
			mockMappingService := &mocks.MockETCMappingService{}
			mockImportService := &mocks.MockImportService{}
			mockStatsService := &mocks.MockStatisticsService{}
			mockLogger := &mocks.MockLogger{}

			tt.setupMocks(mockMappingService, mockLogger)

			server := NewETCMeisaiServer(mockService, mockMappingService, mockImportService, mockStatsService, mockLogger)

			resp, err := server.CreateMapping(context.Background(), tt.req)

			if tt.expectedError == codes.OK {
				assert.NoError(t, err)
				assert.NotNil(t, resp)
				assert.NotNil(t, resp.Mapping)
			} else {
				assert.Error(t, err)
				assert.Nil(t, resp)
				st, ok := status.FromError(err)
				assert.True(t, ok)
				assert.Equal(t, tt.expectedError, st.Code())
				if tt.expectedMsg != "" {
					assert.Contains(t, st.Message(), tt.expectedMsg)
				}
			}

			mockMappingService.AssertExpectations(t)
			mockLogger.AssertExpectations(t)
		})
	}
}

func TestETCMeisaiServer_GetMapping(t *testing.T) {
	tests := []struct {
		name          string
		req           *pb.GetMappingRequest
		setupMocks    func(*mocks.MockETCMappingService, *mocks.MockLogger)
		expectedError codes.Code
		expectedMsg   string
	}{
		{
			name: "Success",
			req: &pb.GetMappingRequest{
				Id: 1,
			},
			setupMocks: func(service *mocks.MockETCMappingService, logger *mocks.MockLogger) {
				service.On("GetMapping", mock.Anything, int64(1)).Return(
					&models.ETCMapping{
						ID:               1,
						ETCRecordID:      1,
						MappingType:      "dtako",
						MappedEntityID:   100,
						MappedEntityType: "dtako_record",
						Confidence:       0.95,
						Status:           "active",
						CreatedAt:        time.Now(),
						UpdatedAt:        time.Now(),
					}, nil)
			},
			expectedError: codes.OK,
		},
		{
			name:          "Nil request",
			req:           nil,
			setupMocks:    func(*mocks.MockETCMappingService, *mocks.MockLogger) {},
			expectedError: codes.InvalidArgument,
			expectedMsg:   "invalid mapping ID",
		},
		{
			name: "Invalid ID",
			req: &pb.GetMappingRequest{
				Id: 0,
			},
			setupMocks:    func(*mocks.MockETCMappingService, *mocks.MockLogger) {},
			expectedError: codes.InvalidArgument,
			expectedMsg:   "invalid mapping ID",
		},
		{
			name: "Mapping not found",
			req: &pb.GetMappingRequest{
				Id: 999,
			},
			setupMocks: func(service *mocks.MockETCMappingService, logger *mocks.MockLogger) {
				service.On("GetMapping", mock.Anything, int64(999)).Return(
					(*models.ETCMapping)(nil), errors.New("mapping not found"))
				logger.On("Printf", mock.AnythingOfType("string"), mock.Anything).Return()
			},
			expectedError: codes.NotFound,
			expectedMsg:   "mapping not found",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockService := &mocks.MockETCMeisaiService{}
			mockMappingService := &mocks.MockETCMappingService{}
			mockImportService := &mocks.MockImportService{}
			mockStatsService := &mocks.MockStatisticsService{}
			mockLogger := &mocks.MockLogger{}

			tt.setupMocks(mockMappingService, mockLogger)

			server := NewETCMeisaiServer(mockService, mockMappingService, mockImportService, mockStatsService, mockLogger)

			resp, err := server.GetMapping(context.Background(), tt.req)

			if tt.expectedError == codes.OK {
				assert.NoError(t, err)
				assert.NotNil(t, resp)
				assert.NotNil(t, resp.Mapping)
			} else {
				assert.Error(t, err)
				assert.Nil(t, resp)
				st, ok := status.FromError(err)
				assert.True(t, ok)
				assert.Equal(t, tt.expectedError, st.Code())
				if tt.expectedMsg != "" {
					assert.Contains(t, st.Message(), tt.expectedMsg)
				}
			}

			mockMappingService.AssertExpectations(t)
			mockLogger.AssertExpectations(t)
		})
	}
}

func TestETCMeisaiServer_ListMappings(t *testing.T) {
	tests := []struct {
		name          string
		req           *pb.ListMappingsRequest
		setupMocks    func(*mocks.MockETCMappingService, *mocks.MockLogger)
		expectedError codes.Code
		expectedMsg   string
	}{
		{
			name: "Success",
			req:  &pb.ListMappingsRequest{},
			setupMocks: func(service *mocks.MockETCMappingService, logger *mocks.MockLogger) {
				service.On("ListMappings", mock.Anything, mock.AnythingOfType("*services.ListMappingsParams")).Return(
					&services.ListMappingsResponse{
						Mappings: []*models.ETCMapping{
							{
								ID:               1,
								ETCRecordID:      1,
								MappingType:      "dtako",
								MappedEntityID:   100,
								MappedEntityType: "dtako_record",
								Confidence:       0.95,
								Status:           "active",
								CreatedAt:        time.Now(),
							},
						},
						TotalCount: 1,
					}, nil)
			},
			expectedError: codes.OK,
		},
		{
			name:          "Nil request",
			req:           nil,
			setupMocks:    func(*mocks.MockETCMappingService, *mocks.MockLogger) {},
			expectedError: codes.InvalidArgument,
			expectedMsg:   "request cannot be nil",
		},
		{
			name: "Service error",
			req:  &pb.ListMappingsRequest{},
			setupMocks: func(service *mocks.MockETCMappingService, logger *mocks.MockLogger) {
				service.On("ListMappings", mock.Anything, mock.AnythingOfType("*services.ListMappingsParams")).Return(
					(*services.ListMappingsResponse)(nil), errors.New("database error"))
				logger.On("Printf", mock.AnythingOfType("string"), mock.Anything).Return()
			},
			expectedError: codes.Internal,
			expectedMsg:   "failed to list mappings",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockService := &mocks.MockETCMeisaiService{}
			mockMappingService := &mocks.MockETCMappingService{}
			mockImportService := &mocks.MockImportService{}
			mockStatsService := &mocks.MockStatisticsService{}
			mockLogger := &mocks.MockLogger{}

			tt.setupMocks(mockMappingService, mockLogger)

			server := NewETCMeisaiServer(mockService, mockMappingService, mockImportService, mockStatsService, mockLogger)

			resp, err := server.ListMappings(context.Background(), tt.req)

			if tt.expectedError == codes.OK {
				assert.NoError(t, err)
				assert.NotNil(t, resp)
				assert.NotNil(t, resp.Mappings)
			} else {
				assert.Error(t, err)
				assert.Nil(t, resp)
				st, ok := status.FromError(err)
				assert.True(t, ok)
				assert.Equal(t, tt.expectedError, st.Code())
				if tt.expectedMsg != "" {
					assert.Contains(t, st.Message(), tt.expectedMsg)
				}
			}

			mockMappingService.AssertExpectations(t)
			mockLogger.AssertExpectations(t)
		})
	}
}

func TestETCMeisaiServer_UpdateMapping(t *testing.T) {
	tests := []struct {
		name          string
		req           *pb.UpdateMappingRequest
		setupMocks    func(*mocks.MockETCMappingService, *mocks.MockLogger)
		expectedError codes.Code
		expectedMsg   string
	}{
		{
			name: "Success",
			req: &pb.UpdateMappingRequest{
				Id: 1,
				Mapping: &pb.ETCMapping{
					EtcRecordId:      1,
					MappingType:      "dtako",
					MappedEntityId:   100,
					MappedEntityType: "dtako_record",
					Confidence:       0.90,
					Status:           pb.MappingStatus_MAPPING_STATUS_ACTIVE,
				},
			},
			setupMocks: func(service *mocks.MockETCMappingService, logger *mocks.MockLogger) {
				service.On("UpdateMapping", mock.Anything, int64(1), mock.AnythingOfType("*services.UpdateMappingParams")).Return(
					&models.ETCMapping{
						ID:               1,
						ETCRecordID:      1,
						MappingType:      "dtako",
						MappedEntityID:   100,
						MappedEntityType: "dtako_record",
						Confidence:       0.90,
						Status:           "active",
						CreatedAt:        time.Now(),
						UpdatedAt:        time.Now(),
					}, nil)
			},
			expectedError: codes.OK,
		},
		{
			name:          "Nil request",
			req:           nil,
			setupMocks:    func(*mocks.MockETCMappingService, *mocks.MockLogger) {},
			expectedError: codes.InvalidArgument,
			expectedMsg:   "invalid request or mapping ID",
		},
		{
			name: "Invalid ID",
			req: &pb.UpdateMappingRequest{
				Id: 0,
				Mapping: &pb.ETCMapping{
					EtcRecordId:      1,
					MappingType:      "dtako",
					MappedEntityId:   100,
					MappedEntityType: "dtako_record",
					Confidence:       0.90,
				},
			},
			setupMocks:    func(*mocks.MockETCMappingService, *mocks.MockLogger) {},
			expectedError: codes.InvalidArgument,
			expectedMsg:   "invalid request or mapping ID",
		},
		{
			name: "Mapping not found",
			req: &pb.UpdateMappingRequest{
				Id: 999,
				Mapping: &pb.ETCMapping{
					EtcRecordId:      1,
					MappingType:      "dtako",
					MappedEntityId:   100,
					MappedEntityType: "dtako_record",
					Confidence:       0.90,
				},
			},
			setupMocks: func(service *mocks.MockETCMappingService, logger *mocks.MockLogger) {
				service.On("UpdateMapping", mock.Anything, int64(999), mock.AnythingOfType("*services.UpdateMappingParams")).Return(
					(*models.ETCMapping)(nil), errors.New("mapping not found"))
				logger.On("Printf", mock.AnythingOfType("string"), mock.Anything).Return()
			},
			expectedError: codes.NotFound,
			expectedMsg:   "mapping not found",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockService := &mocks.MockETCMeisaiService{}
			mockMappingService := &mocks.MockETCMappingService{}
			mockImportService := &mocks.MockImportService{}
			mockStatsService := &mocks.MockStatisticsService{}
			mockLogger := &mocks.MockLogger{}

			tt.setupMocks(mockMappingService, mockLogger)

			server := NewETCMeisaiServer(mockService, mockMappingService, mockImportService, mockStatsService, mockLogger)

			resp, err := server.UpdateMapping(context.Background(), tt.req)

			if tt.expectedError == codes.OK {
				assert.NoError(t, err)
				assert.NotNil(t, resp)
				assert.NotNil(t, resp.Mapping)
			} else {
				assert.Error(t, err)
				assert.Nil(t, resp)
				st, ok := status.FromError(err)
				assert.True(t, ok)
				assert.Equal(t, tt.expectedError, st.Code())
				if tt.expectedMsg != "" {
					assert.Contains(t, st.Message(), tt.expectedMsg)
				}
			}

			mockMappingService.AssertExpectations(t)
			mockLogger.AssertExpectations(t)
		})
	}
}

func TestETCMeisaiServer_DeleteMapping(t *testing.T) {
	tests := []struct {
		name          string
		req           *pb.DeleteMappingRequest
		setupMocks    func(*mocks.MockETCMappingService, *mocks.MockLogger)
		expectedError codes.Code
		expectedMsg   string
	}{
		{
			name: "Success",
			req: &pb.DeleteMappingRequest{
				Id: 1,
			},
			setupMocks: func(service *mocks.MockETCMappingService, logger *mocks.MockLogger) {
				service.On("DeleteMapping", mock.Anything, int64(1)).Return(nil)
			},
			expectedError: codes.OK,
		},
		{
			name:          "Nil request",
			req:           nil,
			setupMocks:    func(*mocks.MockETCMappingService, *mocks.MockLogger) {},
			expectedError: codes.InvalidArgument,
			expectedMsg:   "invalid mapping ID",
		},
		{
			name: "Invalid ID",
			req: &pb.DeleteMappingRequest{
				Id: 0,
			},
			setupMocks:    func(*mocks.MockETCMappingService, *mocks.MockLogger) {},
			expectedError: codes.InvalidArgument,
			expectedMsg:   "invalid mapping ID",
		},
		{
			name: "Mapping not found",
			req: &pb.DeleteMappingRequest{
				Id: 999,
			},
			setupMocks: func(service *mocks.MockETCMappingService, logger *mocks.MockLogger) {
				service.On("DeleteMapping", mock.Anything, int64(999)).Return(errors.New("mapping not found"))
				logger.On("Printf", mock.AnythingOfType("string"), mock.Anything).Return()
			},
			expectedError: codes.NotFound,
			expectedMsg:   "mapping not found",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockService := &mocks.MockETCMeisaiService{}
			mockMappingService := &mocks.MockETCMappingService{}
			mockImportService := &mocks.MockImportService{}
			mockStatsService := &mocks.MockStatisticsService{}
			mockLogger := &mocks.MockLogger{}

			tt.setupMocks(mockMappingService, mockLogger)

			server := NewETCMeisaiServer(mockService, mockMappingService, mockImportService, mockStatsService, mockLogger)

			resp, err := server.DeleteMapping(context.Background(), tt.req)

			if tt.expectedError == codes.OK {
				assert.NoError(t, err)
				assert.NotNil(t, resp)
			} else {
				assert.Error(t, err)
				assert.Nil(t, resp)
				st, ok := status.FromError(err)
				assert.True(t, ok)
				assert.Equal(t, tt.expectedError, st.Code())
				if tt.expectedMsg != "" {
					assert.Contains(t, st.Message(), tt.expectedMsg)
				}
			}

			mockMappingService.AssertExpectations(t)
			mockLogger.AssertExpectations(t)
		})
	}
}

func TestETCMeisaiServer_GetStatistics(t *testing.T) {
	tests := []struct {
		name          string
		req           *pb.GetStatisticsRequest
		setupMocks    func(*mocks.MockStatisticsService, *mocks.MockLogger)
		expectedError codes.Code
		expectedMsg   string
	}{
		{
			name: "Success",
			req:  &pb.GetStatisticsRequest{},
			setupMocks: func(service *mocks.MockStatisticsService, logger *mocks.MockLogger) {
				service.On("GetGeneralStatistics", mock.Anything, mock.AnythingOfType("*services.StatisticsFilter")).Return(
					&services.GeneralStatistics{
						TotalRecords:   100,
						TotalAmount:    50000,
						UniqueVehicles: 5,
						UniqueCards:    3,
					}, nil)
			},
			expectedError: codes.OK,
		},
		{
			name: "Success with filters",
			req: &pb.GetStatisticsRequest{
				DateFrom:      stringPtr("2023-01-01"),
				DateTo:        stringPtr("2023-12-31"),
				CarNumber:     stringPtr("1234"),
				EtcCardNumber: stringPtr("1234567890123456"),
			},
			setupMocks: func(service *mocks.MockStatisticsService, logger *mocks.MockLogger) {
				service.On("GetGeneralStatistics", mock.Anything, mock.MatchedBy(func(filter *services.StatisticsFilter) bool {
					return filter.DateFrom != nil && filter.DateTo != nil &&
						   len(filter.CarNumbers) > 0 && len(filter.ETCNumbers) > 0
				})).Return(
					&services.GeneralStatistics{
						TotalRecords:   10,
						TotalAmount:    5000,
						UniqueVehicles: 1,
						UniqueCards:    1,
					}, nil)
			},
			expectedError: codes.OK,
		},
		{
			name:          "Nil request",
			req:           nil,
			setupMocks:    func(*mocks.MockStatisticsService, *mocks.MockLogger) {},
			expectedError: codes.InvalidArgument,
			expectedMsg:   "request cannot be nil",
		},
		{
			name: "Invalid date format",
			req: &pb.GetStatisticsRequest{
				DateFrom: stringPtr("invalid-date"),
			},
			setupMocks:    func(*mocks.MockStatisticsService, *mocks.MockLogger) {},
			expectedError: codes.InvalidArgument,
		},
		{
			name: "Service error",
			req:  &pb.GetStatisticsRequest{},
			setupMocks: func(service *mocks.MockStatisticsService, logger *mocks.MockLogger) {
				service.On("GetGeneralStatistics", mock.Anything, mock.AnythingOfType("*services.StatisticsFilter")).Return(
					(*services.GeneralStatistics)(nil), errors.New("database error"))
				logger.On("Printf", mock.AnythingOfType("string"), mock.Anything).Return()
			},
			expectedError: codes.Internal,
			expectedMsg:   "failed to get statistics",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockService := &mocks.MockETCMeisaiService{}
			mockMappingService := &mocks.MockETCMappingService{}
			mockImportService := &mocks.MockImportService{}
			mockStatsService := &mocks.MockStatisticsService{}
			mockLogger := &mocks.MockLogger{}

			tt.setupMocks(mockStatsService, mockLogger)

			server := NewETCMeisaiServer(mockService, mockMappingService, mockImportService, mockStatsService, mockLogger)

			resp, err := server.GetStatistics(context.Background(), tt.req)

			if tt.expectedError == codes.OK {
				assert.NoError(t, err)
				assert.NotNil(t, resp)
				assert.GreaterOrEqual(t, resp.TotalRecords, int64(0))
			} else {
				assert.Error(t, err)
				assert.Nil(t, resp)
				st, ok := status.FromError(err)
				assert.True(t, ok)
				assert.Equal(t, tt.expectedError, st.Code())
				if tt.expectedMsg != "" {
					assert.Contains(t, st.Message(), tt.expectedMsg)
				}
			}

			mockStatsService.AssertExpectations(t)
			mockLogger.AssertExpectations(t)
		})
	}
}

// Test helper functions
func TestETCMeisaiServer_validateETCRecord(t *testing.T) {
	server := &ETCMeisaiServer{}

	tests := []struct {
		name      string
		record    *pb.ETCMeisaiRecord
		expectErr bool
		errMsg    string
	}{
		{
			name: "Valid record",
			record: &pb.ETCMeisaiRecord{
				Date:          "2023-01-01",
				Time:          "10:30:00",
				EntranceIc:    "Test Entrance",
				ExitIc:        "Test Exit",
				CarNumber:     "1234",
				EtcCardNumber: "1234567890123456",
				TollAmount:    1000,
			},
			expectErr: false,
		},
		{
			name: "Missing date",
			record: &pb.ETCMeisaiRecord{
				Date:          "",
				Time:          "10:30:00",
				EntranceIc:    "Test Entrance",
				ExitIc:        "Test Exit",
				CarNumber:     "1234",
				EtcCardNumber: "1234567890123456",
				TollAmount:    1000,
			},
			expectErr: true,
			errMsg:    "date is required",
		},
		{
			name: "Missing time",
			record: &pb.ETCMeisaiRecord{
				Date:          "2023-01-01",
				Time:          "",
				EntranceIc:    "Test Entrance",
				ExitIc:        "Test Exit",
				CarNumber:     "1234",
				EtcCardNumber: "1234567890123456",
				TollAmount:    1000,
			},
			expectErr: true,
			errMsg:    "time is required",
		},
		{
			name: "Missing entrance IC",
			record: &pb.ETCMeisaiRecord{
				Date:          "2023-01-01",
				Time:          "10:30:00",
				EntranceIc:    "",
				ExitIc:        "Test Exit",
				CarNumber:     "1234",
				EtcCardNumber: "1234567890123456",
				TollAmount:    1000,
			},
			expectErr: true,
			errMsg:    "entrance_ic is required",
		},
		{
			name: "Missing exit IC",
			record: &pb.ETCMeisaiRecord{
				Date:          "2023-01-01",
				Time:          "10:30:00",
				EntranceIc:    "Test Entrance",
				ExitIc:        "",
				CarNumber:     "1234",
				EtcCardNumber: "1234567890123456",
				TollAmount:    1000,
			},
			expectErr: true,
			errMsg:    "exit_ic is required",
		},
		{
			name: "Missing car number",
			record: &pb.ETCMeisaiRecord{
				Date:          "2023-01-01",
				Time:          "10:30:00",
				EntranceIc:    "Test Entrance",
				ExitIc:        "Test Exit",
				CarNumber:     "",
				EtcCardNumber: "1234567890123456",
				TollAmount:    1000,
			},
			expectErr: true,
			errMsg:    "car_number is required",
		},
		{
			name: "Missing ETC card number",
			record: &pb.ETCMeisaiRecord{
				Date:          "2023-01-01",
				Time:          "10:30:00",
				EntranceIc:    "Test Entrance",
				ExitIc:        "Test Exit",
				CarNumber:     "1234",
				EtcCardNumber: "",
				TollAmount:    1000,
			},
			expectErr: true,
			errMsg:    "etc_card_number is required",
		},
		{
			name: "Negative toll amount",
			record: &pb.ETCMeisaiRecord{
				Date:          "2023-01-01",
				Time:          "10:30:00",
				EntranceIc:    "Test Entrance",
				ExitIc:        "Test Exit",
				CarNumber:     "1234",
				EtcCardNumber: "1234567890123456",
				TollAmount:    -100,
			},
			expectErr: true,
			errMsg:    "toll_amount must be non-negative",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			err := server.validateETCRecord(tt.record)
			if tt.expectErr {
				assert.Error(t, err)
				assert.Contains(t, err.Error(), tt.errMsg)
			} else {
				assert.NoError(t, err)
			}
		})
	}
}

func TestETCMeisaiServer_validateETCMapping(t *testing.T) {
	server := &ETCMeisaiServer{}

	tests := []struct {
		name      string
		mapping   *pb.ETCMapping
		expectErr bool
		errMsg    string
	}{
		{
			name: "Valid mapping",
			mapping: &pb.ETCMapping{
				EtcRecordId:      1,
				MappingType:      "dtako",
				MappedEntityId:   100,
				MappedEntityType: "dtako_record",
				Confidence:       0.95,
			},
			expectErr: false,
		},
		{
			name: "Invalid ETC record ID",
			mapping: &pb.ETCMapping{
				EtcRecordId:      0,
				MappingType:      "dtako",
				MappedEntityId:   100,
				MappedEntityType: "dtako_record",
				Confidence:       0.95,
			},
			expectErr: true,
			errMsg:    "etc_record_id is required",
		},
		{
			name: "Missing mapping type",
			mapping: &pb.ETCMapping{
				EtcRecordId:      1,
				MappingType:      "",
				MappedEntityId:   100,
				MappedEntityType: "dtako_record",
				Confidence:       0.95,
			},
			expectErr: true,
			errMsg:    "mapping_type is required",
		},
		{
			name: "Invalid mapped entity ID",
			mapping: &pb.ETCMapping{
				EtcRecordId:      1,
				MappingType:      "dtako",
				MappedEntityId:   0,
				MappedEntityType: "dtako_record",
				Confidence:       0.95,
			},
			expectErr: true,
			errMsg:    "mapped_entity_id is required",
		},
		{
			name: "Missing mapped entity type",
			mapping: &pb.ETCMapping{
				EtcRecordId:      1,
				MappingType:      "dtako",
				MappedEntityId:   100,
				MappedEntityType: "",
				Confidence:       0.95,
			},
			expectErr: true,
			errMsg:    "mapped_entity_type is required",
		},
		{
			name: "Invalid confidence range (too low)",
			mapping: &pb.ETCMapping{
				EtcRecordId:      1,
				MappingType:      "dtako",
				MappedEntityId:   100,
				MappedEntityType: "dtako_record",
				Confidence:       -0.1,
			},
			expectErr: true,
			errMsg:    "confidence must be between 0 and 1",
		},
		{
			name: "Invalid confidence range (too high)",
			mapping: &pb.ETCMapping{
				EtcRecordId:      1,
				MappingType:      "dtako",
				MappedEntityId:   100,
				MappedEntityType: "dtako_record",
				Confidence:       1.5,
			},
			expectErr: true,
			errMsg:    "confidence must be between 0 and 1",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			err := server.validateETCMapping(tt.mapping)
			if tt.expectErr {
				assert.Error(t, err)
				assert.Contains(t, err.Error(), tt.errMsg)
			} else {
				assert.NoError(t, err)
			}
		})
	}
}

func TestETCMeisaiServer_protoToCreateRecordParams(t *testing.T) {
	server := &ETCMeisaiServer{}

	tests := []struct {
		name      string
		record    *pb.ETCMeisaiRecord
		expectErr bool
	}{
		{
			name: "Valid conversion",
			record: &pb.ETCMeisaiRecord{
				Date:          "2023-01-01",
				Time:          "10:30:00",
				EntranceIc:    "Test Entrance",
				ExitIc:        "Test Exit",
				CarNumber:     "1234",
				EtcCardNumber: "1234567890123456",
				TollAmount:    1000,
			},
			expectErr: false,
		},
		{
			name: "Valid conversion with optional fields",
			record: &pb.ETCMeisaiRecord{
				Date:          "2023-01-01",
				Time:          "10:30:00",
				EntranceIc:    "Test Entrance",
				ExitIc:        "Test Exit",
				CarNumber:     "1234",
				EtcCardNumber: "1234567890123456",
				TollAmount:    1000,
				EtcNum:        stringPtr("ETC123"),
				DtakoRowId:    int64Ptr(456),
			},
			expectErr: false,
		},
		{
			name: "Invalid date format",
			record: &pb.ETCMeisaiRecord{
				Date:          "invalid-date",
				Time:          "10:30:00",
				EntranceIc:    "Test Entrance",
				ExitIc:        "Test Exit",
				CarNumber:     "1234",
				EtcCardNumber: "1234567890123456",
				TollAmount:    1000,
			},
			expectErr: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			params, err := server.protoToCreateRecordParams(tt.record)
			if tt.expectErr {
				assert.Error(t, err)
				assert.Nil(t, params)
			} else {
				assert.NoError(t, err)
				assert.NotNil(t, params)
				assert.Equal(t, tt.record.CarNumber, params.CarNumber)
				assert.Equal(t, tt.record.EtcCardNumber, params.ETCCardNumber)
				if tt.record.EtcNum != nil {
					assert.Equal(t, tt.record.EtcNum, params.ETCNum)
				}
				if tt.record.DtakoRowId != nil {
					assert.Equal(t, tt.record.DtakoRowId, params.DtakoRowID)
				}
			}
		})
	}
}

func TestETCMeisaiServer_protoToListRecordsParams(t *testing.T) {
	server := &ETCMeisaiServer{}

	tests := []struct {
		name      string
		req       *pb.ListRecordsRequest
		expectErr bool
	}{
		{
			name: "Valid conversion",
			req: &pb.ListRecordsRequest{
				Page:     1,
				PageSize: 50,
				SortBy:   "date",
				SortOrder: pb.SortOrder_SORT_ORDER_DESC,
			},
			expectErr: false,
		},
		{
			name: "Valid conversion with filters",
			req: &pb.ListRecordsRequest{
				Page:           1,
				PageSize:       50,
				DateFrom:       stringPtr("2023-01-01"),
				DateTo:         stringPtr("2023-12-31"),
				CarNumber:      stringPtr("1234"),
				EtcCardNumber:  stringPtr("1234567890123456"),
				SortBy:         "date",
				SortOrder:      pb.SortOrder_SORT_ORDER_ASC,
			},
			expectErr: false,
		},
		{
			name: "Invalid date format",
			req: &pb.ListRecordsRequest{
				DateFrom: stringPtr("invalid-date"),
			},
			expectErr: true,
		},
		{
			name: "Invalid date to format",
			req: &pb.ListRecordsRequest{
				DateTo: stringPtr("invalid-date"),
			},
			expectErr: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			params, err := server.protoToListRecordsParams(tt.req)
			if tt.expectErr {
				assert.Error(t, err)
				assert.Nil(t, params)
			} else {
				assert.NoError(t, err)
				assert.NotNil(t, params)
			}
		})
	}
}

func TestETCMeisaiServer_protoToCreateMappingParams(t *testing.T) {
	server := &ETCMeisaiServer{}

	validMapping := &pb.ETCMapping{
		EtcRecordId:      1,
		MappingType:      "dtako",
		MappedEntityId:   100,
		MappedEntityType: "dtako_record",
		Confidence:       0.95,
		Status:           pb.MappingStatus_MAPPING_STATUS_ACTIVE,
		CreatedBy:        "test_user",
	}

	params, err := server.protoToCreateMappingParams(validMapping)
	assert.NoError(t, err)
	assert.NotNil(t, params)
	assert.Equal(t, int64(1), params.ETCRecordID)
	assert.Equal(t, "dtako", params.MappingType)
	assert.Equal(t, int64(100), params.MappedEntityID)
	assert.Equal(t, "dtako_record", params.MappedEntityType)
	assert.Equal(t, float32(0.95), params.Confidence)
	assert.Equal(t, "active", params.Status)
	assert.Equal(t, "test_user", params.CreatedBy)

	// Test with metadata
	metadata, _ := structpb.NewStruct(map[string]interface{}{
		"test": "value",
	})
	validMapping.Metadata = metadata
	params, err = server.protoToCreateMappingParams(validMapping)
	assert.NoError(t, err)
	assert.NotNil(t, params)
	assert.NotNil(t, params.Metadata)
}

func TestETCMeisaiServer_protoToUpdateMappingParams(t *testing.T) {
	server := &ETCMeisaiServer{}

	validMapping := &pb.ETCMapping{
		EtcRecordId:      1,
		MappingType:      "dtako",
		MappedEntityId:   100,
		MappedEntityType: "dtako_record",
		Confidence:       0.90,
		Status:           pb.MappingStatus_MAPPING_STATUS_INACTIVE,
	}

	params, err := server.protoToUpdateMappingParams(1, validMapping)
	assert.NoError(t, err)
	assert.NotNil(t, params)
	assert.Equal(t, "dtako", *params.MappingType)
	assert.Equal(t, int64(100), *params.MappedEntityID)
	assert.Equal(t, "dtako_record", *params.MappedEntityType)
	assert.Equal(t, float32(0.90), *params.Confidence)
	assert.Equal(t, "inactive", *params.Status)
}

func TestETCMeisaiServer_protoToListMappingsParams(t *testing.T) {
	server := &ETCMeisaiServer{}

	req := &pb.ListMappingsRequest{
		Page:             1,
		PageSize:         50,
		EtcRecordId:      int64Ptr(1),
		MappingType:      stringPtr("dtako"),
		MappedEntityId:   int64Ptr(100),
		MappedEntityType: stringPtr("dtako_record"),
		Status:           mappingStatusPtr(pb.MappingStatus_MAPPING_STATUS_ACTIVE),
	}

	params, err := server.protoToListMappingsParams(req)
	assert.NoError(t, err)
	assert.NotNil(t, params)
	assert.Equal(t, 1, params.Page)
	assert.Equal(t, 50, params.PageSize)
	assert.Equal(t, int64Ptr(1), params.ETCRecordID)
	assert.Equal(t, stringPtr("dtako"), params.MappingType)
	assert.Equal(t, int64Ptr(100), params.MappedEntityID)
	assert.Equal(t, stringPtr("dtako_record"), params.MappedEntityType)
	assert.Equal(t, stringPtr("active"), params.Status)
}

func TestETCMeisaiServer_protoToStatisticsFilter(t *testing.T) {
	server := &ETCMeisaiServer{}

	tests := []struct {
		name      string
		req       *pb.GetStatisticsRequest
		expectErr bool
	}{
		{
			name: "Valid filter",
			req: &pb.GetStatisticsRequest{
				DateFrom:      stringPtr("2023-01-01"),
				DateTo:        stringPtr("2023-12-31"),
				CarNumber:     stringPtr("1234"),
				EtcCardNumber: stringPtr("1234567890123456"),
			},
			expectErr: false,
		},
		{
			name: "Empty filter",
			req:  &pb.GetStatisticsRequest{},
			expectErr: false,
		},
		{
			name: "Invalid date from format",
			req: &pb.GetStatisticsRequest{
				DateFrom: stringPtr("invalid-date"),
			},
			expectErr: true,
		},
		{
			name: "Invalid date to format",
			req: &pb.GetStatisticsRequest{
				DateTo: stringPtr("invalid-date"),
			},
			expectErr: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			filter, err := server.protoToStatisticsFilter(tt.req)
			if tt.expectErr {
				assert.Error(t, err)
				assert.Nil(t, filter)
			} else {
				assert.NoError(t, err)
				assert.NotNil(t, filter)
			}
		})
	}
}

// Helper functions for test cases
func stringPtr(s string) *string {
	return &s
}

func int64Ptr(i int64) *int64 {
	return &i
}

func mappingStatusPtr(status pb.MappingStatus) *pb.MappingStatus {
	return &status
}