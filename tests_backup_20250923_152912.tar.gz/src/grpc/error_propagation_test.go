package grpc_test

import (
	"context"
	"errors"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"

	pb "github.com/yhonda-ohishi/etc_meisai/src/pb"
	"github.com/yhonda-ohishi/etc_meisai/src/grpc"
	"github.com/yhonda-ohishi/etc_meisai/src/models"
)

// TestErrorPropagation_CreateETCMeisaiRecord tests error propagation for Create method
func TestErrorPropagation_CreateETCMeisaiRecord(t *testing.T) {
	tests := []struct {
		name          string
		setupMock     func(*MockETCMeisaiService)
		request       *pb.CreateETCMeisaiRecordRequest
		expectedCode  codes.Code
		expectedError string
	}{
		{
			name: "validation error propagation",
			setupMock: func(m *MockETCMeisaiService) {
				m.On("CreateRecord", mock.Anything, mock.AnythingOfType("*models.ETCMeisaiRecord")).
					Return(nil, errors.New("validation failed: invalid ETC card number"))
			},
			request: &pb.CreateETCMeisaiRecordRequest{
				Record: &pb.ETCMeisaiRecord{
					Date:          "2025-01-01",
					Time:          "10:30:00",
					EntranceIc:    "東京IC",
					ExitIc:        "横浜IC",
					TollAmount:    1500,
					CarNumber:     "123-45",
					EtcCardNumber: "invalid",
				},
			},
			expectedCode:  codes.InvalidArgument,
			expectedError: "validation failed",
		},
		{
			name: "database error propagation",
			setupMock: func(m *MockETCMeisaiService) {
				m.On("CreateRecord", mock.Anything, mock.AnythingOfType("*models.ETCMeisaiRecord")).
					Return(nil, errors.New("database connection failed"))
			},
			request: &pb.CreateETCMeisaiRecordRequest{
				Record: &pb.ETCMeisaiRecord{
					Date:          "2025-01-01",
					Time:          "10:30:00",
					EntranceIc:    "東京IC",
					ExitIc:        "横浜IC",
					TollAmount:    1500,
					CarNumber:     "123-45",
					EtcCardNumber: "1234567890123456",
				},
			},
			expectedCode:  codes.Internal,
			expectedError: "database connection failed",
		},
		{
			name: "duplicate record error",
			setupMock: func(m *MockETCMeisaiService) {
				m.On("CreateRecord", mock.Anything, mock.AnythingOfType("*models.ETCMeisaiRecord")).
					Return(nil, errors.New("duplicate record found"))
			},
			request: &pb.CreateETCMeisaiRecordRequest{
				Record: &pb.ETCMeisaiRecord{
					Date:          "2025-01-01",
					Time:          "10:30:00",
					EntranceIc:    "東京IC",
					ExitIc:        "横浜IC",
					TollAmount:    1500,
					CarNumber:     "123-45",
					EtcCardNumber: "1234567890123456",
				},
			},
			expectedCode:  codes.AlreadyExists,
			expectedError: "duplicate record",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockService := new(MockETCMeisaiService)
			tt.setupMock(mockService)

			server := grpc.NewETCMeisaiServer(mockService, nil, nil, nil)
			ctx := context.Background()

			_, err := server.CreateETCMeisaiRecord(ctx, tt.request)
			assert.Error(t, err)

			st, ok := status.FromError(err)
			assert.True(t, ok)
			assert.Equal(t, tt.expectedCode, st.Code())
			assert.Contains(t, st.Message(), tt.expectedError)

			mockService.AssertExpectations(t)
		})
	}
}

// TestErrorPropagation_GetETCMeisaiRecord tests error propagation for Get method
func TestErrorPropagation_GetETCMeisaiRecord(t *testing.T) {
	tests := []struct {
		name          string
		setupMock     func(*MockETCMeisaiService)
		request       *pb.GetETCMeisaiRecordRequest
		expectedCode  codes.Code
		expectedError string
	}{
		{
			name: "record not found",
			setupMock: func(m *MockETCMeisaiService) {
				m.On("GetRecord", mock.Anything, int64(999)).
					Return(nil, errors.New("record not found"))
			},
			request:       &pb.GetETCMeisaiRecordRequest{Id: 999},
			expectedCode:  codes.NotFound,
			expectedError: "record not found",
		},
		{
			name: "invalid ID",
			setupMock: func(m *MockETCMeisaiService) {
				// No mock setup needed - validation happens before service call
			},
			request:       &pb.GetETCMeisaiRecordRequest{Id: -1},
			expectedCode:  codes.InvalidArgument,
			expectedError: "invalid ID",
		},
		{
			name: "database timeout",
			setupMock: func(m *MockETCMeisaiService) {
				m.On("GetRecord", mock.Anything, int64(1)).
					Return(nil, errors.New("context deadline exceeded"))
			},
			request:       &pb.GetETCMeisaiRecordRequest{Id: 1},
			expectedCode:  codes.DeadlineExceeded,
			expectedError: "deadline exceeded",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockService := new(MockETCMeisaiService)
			tt.setupMock(mockService)

			server := grpc.NewETCMeisaiServer(mockService, nil, nil, nil)
			ctx := context.Background()

			_, err := server.GetETCMeisaiRecord(ctx, tt.request)
			assert.Error(t, err)

			st, ok := status.FromError(err)
			assert.True(t, ok)
			assert.Equal(t, tt.expectedCode, st.Code())
			assert.Contains(t, st.Message(), tt.expectedError)
		})
	}
}

// TestErrorPropagation_ListETCMeisaiRecords tests error propagation for List method
func TestErrorPropagation_ListETCMeisaiRecords(t *testing.T) {
	tests := []struct {
		name          string
		setupMock     func(*MockETCMeisaiService)
		request       *pb.ListETCMeisaiRecordsRequest
		expectedCode  codes.Code
		expectedError string
	}{
		{
			name: "invalid pagination parameters",
			setupMock: func(m *MockETCMeisaiService) {
				// No mock setup needed - validation happens before service call
			},
			request: &pb.ListETCMeisaiRecordsRequest{
				Page:     -1,
				PageSize: 0,
			},
			expectedCode:  codes.InvalidArgument,
			expectedError: "invalid pagination",
		},
		{
			name: "database query error",
			setupMock: func(m *MockETCMeisaiService) {
				m.On("ListRecords", mock.Anything, mock.AnythingOfType("*services.ListRecordsParams")).
					Return(nil, errors.New("query execution failed"))
			},
			request: &pb.ListETCMeisaiRecordsRequest{
				Page:     1,
				PageSize: 10,
			},
			expectedCode:  codes.Internal,
			expectedError: "query execution failed",
		},
		{
			name: "permission denied",
			setupMock: func(m *MockETCMeisaiService) {
				m.On("ListRecords", mock.Anything, mock.AnythingOfType("*services.ListRecordsParams")).
					Return(nil, errors.New("permission denied"))
			},
			request: &pb.ListETCMeisaiRecordsRequest{
				Page:     1,
				PageSize: 10,
			},
			expectedCode:  codes.PermissionDenied,
			expectedError: "permission denied",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockService := new(MockETCMeisaiService)
			tt.setupMock(mockService)

			server := grpc.NewETCMeisaiServer(mockService, nil, nil, nil)
			ctx := context.Background()

			_, err := server.ListETCMeisaiRecords(ctx, tt.request)
			assert.Error(t, err)

			st, ok := status.FromError(err)
			assert.True(t, ok)
			assert.Equal(t, tt.expectedCode, st.Code())
			assert.Contains(t, st.Message(), tt.expectedError)
		})
	}
}

// TestErrorPropagation_ImportCSV tests error propagation for import operations
func TestErrorPropagation_ImportCSV(t *testing.T) {
	tests := []struct {
		name          string
		setupMock     func(*MockImportService)
		request       *pb.ImportCSVRequest
		expectedCode  codes.Code
		expectedError string
	}{
		{
			name: "file size exceeded",
			setupMock: func(m *MockImportService) {
				// No mock setup needed - validation happens before service call
			},
			request: &pb.ImportCSVRequest{
				AccountType: "corporate",
				AccountId:   "corp-001",
				FileName:    "large.csv",
				FileSize:    100 * 1024 * 1024, // 100MB
			},
			expectedCode:  codes.InvalidArgument,
			expectedError: "file size exceeds limit",
		},
		{
			name: "invalid CSV format",
			setupMock: func(m *MockImportService) {
				m.On("ImportCSV", mock.Anything, mock.AnythingOfType("*services.ImportCSVParams"), mock.Anything).
					Return(nil, errors.New("CSV parsing failed: invalid format"))
			},
			request: &pb.ImportCSVRequest{
				AccountType: "corporate",
				AccountId:   "corp-001",
				FileName:    "invalid.csv",
				FileSize:    1024,
				Data:        []byte("invalid,csv,data"),
			},
			expectedCode:  codes.InvalidArgument,
			expectedError: "CSV parsing failed",
		},
		{
			name: "concurrent import limit exceeded",
			setupMock: func(m *MockImportService) {
				m.On("ImportCSV", mock.Anything, mock.AnythingOfType("*services.ImportCSVParams"), mock.Anything).
					Return(nil, errors.New("concurrent import limit exceeded"))
			},
			request: &pb.ImportCSVRequest{
				AccountType: "corporate",
				AccountId:   "corp-001",
				FileName:    "test.csv",
				FileSize:    1024,
			},
			expectedCode:  codes.ResourceExhausted,
			expectedError: "concurrent import limit",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockService := new(MockImportService)
			tt.setupMock(mockService)

			server := grpc.NewETCMeisaiServer(nil, nil, mockService, nil)
			ctx := context.Background()

			_, err := server.ImportCSV(ctx, tt.request)
			assert.Error(t, err)

			st, ok := status.FromError(err)
			assert.True(t, ok)
			assert.Equal(t, tt.expectedCode, st.Code())
			assert.Contains(t, st.Message(), tt.expectedError)
		})
	}
}

// TestErrorPropagation_StreamingImport tests error propagation for streaming operations
func TestErrorPropagation_StreamingImport(t *testing.T) {
	t.Run("stream send error", func(t *testing.T) {
		mockService := new(MockImportService)
		server := grpc.NewETCMeisaiServer(nil, nil, mockService, nil)

		// Create a mock stream
		mockStream := new(MockImportCSVStream)

		// First receive succeeds
		mockStream.On("Recv").Return(&pb.ImportCSVStreamRequest{
			Data: &pb.ImportCSVStreamRequest_Metadata_{
				Metadata: &pb.ImportCSVStreamRequest_Metadata{
					AccountType: "corporate",
					AccountId:   "corp-001",
					FileName:    "stream.csv",
				},
			},
		}, nil).Once()

		// Second receive fails
		mockStream.On("Recv").Return(nil, errors.New("stream broken")).Once()

		err := server.ImportCSVStream(mockStream)
		assert.Error(t, err)

		st, ok := status.FromError(err)
		assert.True(t, ok)
		assert.Equal(t, codes.Internal, st.Code())
		assert.Contains(t, st.Message(), "stream broken")
	})

	t.Run("invalid stream metadata", func(t *testing.T) {
		mockService := new(MockImportService)
		server := grpc.NewETCMeisaiServer(nil, nil, mockService, nil)

		mockStream := new(MockImportCSVStream)

		// Send invalid metadata
		mockStream.On("Recv").Return(&pb.ImportCSVStreamRequest{
			Data: &pb.ImportCSVStreamRequest_Metadata_{
				Metadata: &pb.ImportCSVStreamRequest_Metadata{
					AccountType: "",  // Invalid
					AccountId:   "",  // Invalid
					FileName:    "",  // Invalid
				},
			},
		}, nil)

		err := server.ImportCSVStream(mockStream)
		assert.Error(t, err)

		st, ok := status.FromError(err)
		assert.True(t, ok)
		assert.Equal(t, codes.InvalidArgument, st.Code())
	})
}

// TestErrorPropagation_CascadingErrors tests cascading error scenarios
func TestErrorPropagation_CascadingErrors(t *testing.T) {
	t.Run("transaction rollback on error", func(t *testing.T) {
		mockService := new(MockETCMeisaiService)

		// First operation succeeds
		mockService.On("CreateRecord", mock.Anything, mock.AnythingOfType("*models.ETCMeisaiRecord")).
			Return(&models.ETCMeisaiRecord{ID: 1}, nil).Once()

		// Second operation fails, should trigger rollback
		mockService.On("CreateRecord", mock.Anything, mock.AnythingOfType("*models.ETCMeisaiRecord")).
			Return(nil, errors.New("constraint violation")).Once()

		server := grpc.NewETCMeisaiServer(mockService, nil, nil, nil)
		ctx := context.Background()

		// Simulate batch operation
		req1 := &pb.CreateETCMeisaiRecordRequest{
			Record: &pb.ETCMeisaiRecord{
				Date:          "2025-01-01",
				Time:          "10:30:00",
				EntranceIc:    "東京IC",
				ExitIc:        "横浜IC",
				TollAmount:    1500,
				CarNumber:     "123-45",
				EtcCardNumber: "1234567890123456",
			},
		}

		req2 := &pb.CreateETCMeisaiRecordRequest{
			Record: &pb.ETCMeisaiRecord{
				Date:          "2025-01-01",
				Time:          "10:30:00",
				EntranceIc:    "東京IC",
				ExitIc:        "横浜IC",
				TollAmount:    1500,
				CarNumber:     "123-45",
				EtcCardNumber: "1234567890123456", // Duplicate
			},
		}

		// First should succeed
		resp1, err1 := server.CreateETCMeisaiRecord(ctx, req1)
		assert.NoError(t, err1)
		assert.NotNil(t, resp1)

		// Second should fail
		_, err2 := server.CreateETCMeisaiRecord(ctx, req2)
		assert.Error(t, err2)

		st, ok := status.FromError(err2)
		assert.True(t, ok)
		assert.Equal(t, codes.Internal, st.Code())
		assert.Contains(t, st.Message(), "constraint violation")
	})
}

// TestErrorPropagation_ContextCancellation tests context cancellation handling
func TestErrorPropagation_ContextCancellation(t *testing.T) {
	mockService := new(MockETCMeisaiService)

	// Simulate long-running operation
	mockService.On("ListRecords", mock.Anything, mock.AnythingOfType("*services.ListRecordsParams")).
		Return(nil, context.Canceled)

	server := grpc.NewETCMeisaiServer(mockService, nil, nil, nil)

	ctx, cancel := context.WithCancel(context.Background())
	cancel() // Cancel immediately

	_, err := server.ListETCMeisaiRecords(ctx, &pb.ListETCMeisaiRecordsRequest{
		Page:     1,
		PageSize: 100,
	})

	assert.Error(t, err)
	st, ok := status.FromError(err)
	assert.True(t, ok)
	assert.Equal(t, codes.Canceled, st.Code())
}

// TestErrorPropagation_ValidationChain tests validation error chain
func TestErrorPropagation_ValidationChain(t *testing.T) {
	tests := []struct {
		name          string
		request       *pb.CreateETCMeisaiRecordRequest
		expectedCode  codes.Code
		expectedError string
	}{
		{
			name: "missing required fields",
			request: &pb.CreateETCMeisaiRecordRequest{
				Record: &pb.ETCMeisaiRecord{},
			},
			expectedCode:  codes.InvalidArgument,
			expectedError: "required field",
		},
		{
			name: "invalid date format",
			request: &pb.CreateETCMeisaiRecordRequest{
				Record: &pb.ETCMeisaiRecord{
					Date:          "invalid-date",
					Time:          "10:30:00",
					EntranceIc:    "東京IC",
					ExitIc:        "横浜IC",
					TollAmount:    1500,
					CarNumber:     "123-45",
					EtcCardNumber: "1234567890123456",
				},
			},
			expectedCode:  codes.InvalidArgument,
			expectedError: "invalid date format",
		},
		{
			name: "negative toll amount",
			request: &pb.CreateETCMeisaiRecordRequest{
				Record: &pb.ETCMeisaiRecord{
					Date:          "2025-01-01",
					Time:          "10:30:00",
					EntranceIc:    "東京IC",
					ExitIc:        "横浜IC",
					TollAmount:    -1500,
					CarNumber:     "123-45",
					EtcCardNumber: "1234567890123456",
				},
			},
			expectedCode:  codes.InvalidArgument,
			expectedError: "toll amount must be positive",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockService := new(MockETCMeisaiService)
			server := grpc.NewETCMeisaiServer(mockService, nil, nil, nil)
			ctx := context.Background()

			_, err := server.CreateETCMeisaiRecord(ctx, tt.request)
			assert.Error(t, err)

			st, ok := status.FromError(err)
			assert.True(t, ok)
			assert.Equal(t, tt.expectedCode, st.Code())
			assert.Contains(t, st.Message(), tt.expectedError)
		})
	}
}