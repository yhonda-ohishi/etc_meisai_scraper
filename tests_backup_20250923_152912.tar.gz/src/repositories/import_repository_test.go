package repositories_test

import (
	"context"
	"errors"
	"fmt"
	"sync"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"
	"github.com/yhonda-ohishi/etc_meisai/src/models"
	"github.com/yhonda-ohishi/etc_meisai/src/repositories"
)

// MockImportRepository is a mock implementation for testing
type MockImportRepository struct {
	mock.Mock
}

func (m *MockImportRepository) CreateSession(ctx context.Context, session *models.ImportSession) error {
	args := m.Called(ctx, session)
	return args.Error(0)
}

func (m *MockImportRepository) GetSession(ctx context.Context, sessionID string) (*models.ImportSession, error) {
	args := m.Called(ctx, sessionID)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*models.ImportSession), args.Error(1)
}

func (m *MockImportRepository) UpdateSession(ctx context.Context, session *models.ImportSession) error {
	args := m.Called(ctx, session)
	return args.Error(0)
}

func (m *MockImportRepository) ListSessions(ctx context.Context, params repositories.ListImportSessionsParams) ([]*models.ImportSession, int64, error) {
	args := m.Called(ctx, params)
	if args.Get(0) == nil {
		return nil, args.Get(1).(int64), args.Error(2)
	}
	return args.Get(0).([]*models.ImportSession), args.Get(1).(int64), args.Error(2)
}

func (m *MockImportRepository) CancelSession(ctx context.Context, sessionID string) error {
	args := m.Called(ctx, sessionID)
	return args.Error(0)
}

func (m *MockImportRepository) CreateRecord(ctx context.Context, record *models.ETCMeisaiRecord) error {
	args := m.Called(ctx, record)
	return args.Error(0)
}

func (m *MockImportRepository) CreateRecordsBatch(ctx context.Context, records []*models.ETCMeisaiRecord) error {
	args := m.Called(ctx, records)
	return args.Error(0)
}

func (m *MockImportRepository) FindRecordByHash(ctx context.Context, hash string) (*models.ETCMeisaiRecord, error) {
	args := m.Called(ctx, hash)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*models.ETCMeisaiRecord), args.Error(1)
}

func (m *MockImportRepository) FindDuplicateRecords(ctx context.Context, hashes []string) ([]*models.ETCMeisaiRecord, error) {
	args := m.Called(ctx, hashes)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).([]*models.ETCMeisaiRecord), args.Error(1)
}

func (m *MockImportRepository) BeginTx(ctx context.Context) (repositories.ImportRepository, error) {
	args := m.Called(ctx)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(repositories.ImportRepository), args.Error(1)
}

func (m *MockImportRepository) CommitTx() error {
	args := m.Called()
	return args.Error(0)
}

func (m *MockImportRepository) RollbackTx() error {
	args := m.Called()
	return args.Error(0)
}

func (m *MockImportRepository) Ping(ctx context.Context) error {
	args := m.Called(ctx)
	return args.Error(0)
}

// Test data helpers
func createTestImportSession() *models.ImportSession {
	return &models.ImportSession{
		ID:          "session_123",
		AccountType: "corporate",
		AccountID:   "corp_001",
		FileName:    "test.csv",
		FileSize:    1024,
		Status:      "processing",
		TotalRows:   100,
		StartedAt:   time.Now(),
		CreatedBy:   "user_001",
		CreatedAt:   time.Now(),
	}
}

func createTestETCMeisaiRecord2() *models.ETCMeisaiRecord {
	return &models.ETCMeisaiRecord{
		ID:            1,
		Hash:          "abc123",
		Date:          time.Date(2024, 1, 15, 0, 0, 0, 0, time.UTC),
		Time:          "14:30:00",
		EntranceIC:    "東京IC",
		ExitIC:        "横浜IC",
		TollAmount:    500,
		CarNumber:     "品川500あ1234",
		ETCCardNumber: "1234567890123456",
		CreatedAt:     time.Now(),
		UpdatedAt:     time.Now(),
	}
}

// T006-A: Error path testing for ImportRepository with database connection failures
func TestImportRepository_T006A_DatabaseConnectionFailures(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name      string
		operation string
		setupMock func(*MockImportRepository)
		testFunc  func(repositories.ImportRepository) error
		errorMsg  string
	}{
		{
			name:      "CreateSession with connection failure",
			operation: "CreateSession",
			setupMock: func(m *MockImportRepository) {
				m.On("CreateSession", mock.Anything, mock.Anything).Return(errors.New("connection refused"))
			},
			testFunc: func(repo repositories.ImportRepository) error {
				return repo.CreateSession(context.Background(), createTestImportSession())
			},
			errorMsg: "connection refused",
		},
		{
			name:      "GetSession with timeout",
			operation: "GetSession",
			setupMock: func(m *MockImportRepository) {
				m.On("GetSession", mock.Anything, mock.Anything).Return(nil, errors.New("context deadline exceeded"))
			},
			testFunc: func(repo repositories.ImportRepository) error {
				_, err := repo.GetSession(context.Background(), "session_123")
				return err
			},
			errorMsg: "context deadline exceeded",
		},
		{
			name:      "CreateRecordsBatch with database lock",
			operation: "CreateRecordsBatch",
			setupMock: func(m *MockImportRepository) {
				m.On("CreateRecordsBatch", mock.Anything, mock.Anything).Return(errors.New("database is locked"))
			},
			testFunc: func(repo repositories.ImportRepository) error {
				records := []*models.ETCMeisaiRecord{createTestETCMeisaiRecord2()}
				return repo.CreateRecordsBatch(context.Background(), records)
			},
			errorMsg: "database is locked",
		},
		{
			name:      "ListSessions with SQL error",
			operation: "ListSessions",
			setupMock: func(m *MockImportRepository) {
				m.On("ListSessions", mock.Anything, mock.Anything).Return(nil, int64(0), errors.New("SQL syntax error"))
			},
			testFunc: func(repo repositories.ImportRepository) error {
				_, _, err := repo.ListSessions(context.Background(), repositories.ListImportSessionsParams{})
				return err
			},
			errorMsg: "SQL syntax error",
		},
		{
			name:      "FindDuplicateRecords with connection lost",
			operation: "FindDuplicateRecords",
			setupMock: func(m *MockImportRepository) {
				m.On("FindDuplicateRecords", mock.Anything, mock.Anything).Return(nil, errors.New("connection lost"))
			},
			testFunc: func(repo repositories.ImportRepository) error {
				_, err := repo.FindDuplicateRecords(context.Background(), []string{"hash1", "hash2"})
				return err
			},
			errorMsg: "connection lost",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			mockRepo := new(MockImportRepository)
			tt.setupMock(mockRepo)

			err := tt.testFunc(mockRepo)

			assert.Error(t, err)
			assert.Contains(t, err.Error(), tt.errorMsg)
			mockRepo.AssertExpectations(t)
		})
	}
}

// T006-B: Transaction testing for batch import with rollback scenarios
func TestImportRepository_T006B_BatchImportTransactionRollback(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name      string
		setupMock func(*MockImportRepository, *MockImportRepository)
		scenario  string
	}{
		{
			name: "BeginTx fails",
			setupMock: func(mainRepo, txRepo *MockImportRepository) {
				mainRepo.On("BeginTx", mock.Anything).Return(nil, errors.New("failed to begin transaction"))
			},
			scenario: "transaction_begin_failure",
		},
		{
			name: "CreateRecordsBatch fails, rollback succeeds",
			setupMock: func(mainRepo, txRepo *MockImportRepository) {
				mainRepo.On("BeginTx", mock.Anything).Return(txRepo, nil)
				txRepo.On("CreateRecordsBatch", mock.Anything, mock.Anything).Return(errors.New("constraint violation"))
				txRepo.On("RollbackTx").Return(nil)
			},
			scenario: "batch_create_failure_rollback_success",
		},
		{
			name: "CreateRecordsBatch fails, rollback also fails",
			setupMock: func(mainRepo, txRepo *MockImportRepository) {
				mainRepo.On("BeginTx", mock.Anything).Return(txRepo, nil)
				txRepo.On("CreateRecordsBatch", mock.Anything, mock.Anything).Return(errors.New("constraint violation"))
				txRepo.On("RollbackTx").Return(errors.New("rollback failed"))
			},
			scenario: "batch_create_failure_rollback_failure",
		},
		{
			name: "Batch succeeds, session update fails, rollback succeeds",
			setupMock: func(mainRepo, txRepo *MockImportRepository) {
				mainRepo.On("BeginTx", mock.Anything).Return(txRepo, nil)
				txRepo.On("CreateRecordsBatch", mock.Anything, mock.Anything).Return(nil)
				txRepo.On("UpdateSession", mock.Anything, mock.Anything).Return(errors.New("session update failed"))
				txRepo.On("RollbackTx").Return(nil)
			},
			scenario: "session_update_failure_rollback_success",
		},
		{
			name: "All operations succeed, commit fails",
			setupMock: func(mainRepo, txRepo *MockImportRepository) {
				mainRepo.On("BeginTx", mock.Anything).Return(txRepo, nil)
				txRepo.On("CreateRecordsBatch", mock.Anything, mock.Anything).Return(nil)
				txRepo.On("UpdateSession", mock.Anything, mock.Anything).Return(nil)
				txRepo.On("CommitTx").Return(errors.New("commit failed"))
				txRepo.On("RollbackTx").Return(nil)
			},
			scenario: "commit_failure_rollback_success",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			mainRepo := new(MockImportRepository)
			txRepo := new(MockImportRepository)
			tt.setupMock(mainRepo, txRepo)

			ctx := context.Background()

			switch tt.scenario {
			case "transaction_begin_failure":
				_, err := mainRepo.BeginTx(ctx)
				assert.Error(t, err)
				assert.Contains(t, err.Error(), "failed to begin transaction")

			case "batch_create_failure_rollback_success":
				tx, err := mainRepo.BeginTx(ctx)
				require.NoError(t, err)
				require.NotNil(t, tx)

				records := []*models.ETCMeisaiRecord{createTestETCMeisaiRecord2()}
				err = tx.CreateRecordsBatch(ctx, records)
				assert.Error(t, err)

				rollbackErr := tx.RollbackTx()
				assert.NoError(t, rollbackErr)

			case "batch_create_failure_rollback_failure":
				tx, err := mainRepo.BeginTx(ctx)
				require.NoError(t, err)
				require.NotNil(t, tx)

				records := []*models.ETCMeisaiRecord{createTestETCMeisaiRecord2()}
				err = tx.CreateRecordsBatch(ctx, records)
				assert.Error(t, err)

				rollbackErr := tx.RollbackTx()
				assert.Error(t, rollbackErr)

			case "session_update_failure_rollback_success":
				tx, err := mainRepo.BeginTx(ctx)
				require.NoError(t, err)
				require.NotNil(t, tx)

				records := []*models.ETCMeisaiRecord{createTestETCMeisaiRecord2()}
				err = tx.CreateRecordsBatch(ctx, records)
				assert.NoError(t, err)

				session := createTestImportSession()
				session.Status = "completed"
				err = tx.UpdateSession(ctx, session)
				assert.Error(t, err)

				rollbackErr := tx.RollbackTx()
				assert.NoError(t, rollbackErr)

			case "commit_failure_rollback_success":
				tx, err := mainRepo.BeginTx(ctx)
				require.NoError(t, err)
				require.NotNil(t, tx)

				records := []*models.ETCMeisaiRecord{createTestETCMeisaiRecord2()}
				err = tx.CreateRecordsBatch(ctx, records)
				assert.NoError(t, err)

				session := createTestImportSession()
				session.Status = "completed"
				err = tx.UpdateSession(ctx, session)
				assert.NoError(t, err)

				commitErr := tx.CommitTx()
				assert.Error(t, commitErr)

				rollbackErr := tx.RollbackTx()
				assert.NoError(t, rollbackErr)
			}

			mainRepo.AssertExpectations(t)
			txRepo.AssertExpectations(t)
		})
	}
}

// T006-C: Concurrent access testing for import operations
func TestImportRepository_T006C_ConcurrentAccess(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name        string
		concurrency int
		operation   string
	}{
		{
			name:        "Concurrent CreateSession operations",
			concurrency: 10,
			operation:   "create_session",
		},
		{
			name:        "Concurrent GetSession operations",
			concurrency: 15,
			operation:   "get_session",
		},
		{
			name:        "Concurrent CreateRecord operations",
			concurrency: 20,
			operation:   "create_record",
		},
		{
			name:        "Mixed concurrent operations",
			concurrency: 18,
			operation:   "mixed",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			mockRepo := new(MockImportRepository)

			// Setup mock expectations for concurrent operations
			switch tt.operation {
			case "create_session":
				mockRepo.On("CreateSession", mock.Anything, mock.Anything).Return(nil).Times(tt.concurrency)
			case "get_session":
				testSession := createTestImportSession()
				mockRepo.On("GetSession", mock.Anything, mock.Anything).Return(testSession, nil).Times(tt.concurrency)
			case "create_record":
				mockRepo.On("CreateRecord", mock.Anything, mock.Anything).Return(nil).Times(tt.concurrency)
			case "mixed":
				sessionOps := tt.concurrency / 3
				getOps := tt.concurrency / 3
				recordOps := tt.concurrency - sessionOps - getOps

				mockRepo.On("CreateSession", mock.Anything, mock.Anything).Return(nil).Times(sessionOps)
				testSession := createTestImportSession()
				mockRepo.On("GetSession", mock.Anything, mock.Anything).Return(testSession, nil).Times(getOps)
				mockRepo.On("CreateRecord", mock.Anything, mock.Anything).Return(nil).Times(recordOps)
			}

			var wg sync.WaitGroup
			errChan := make(chan error, tt.concurrency)
			ctx := context.Background()

			// Launch concurrent operations
			for i := 0; i < tt.concurrency; i++ {
				wg.Add(1)
				go func(id int) {
					defer wg.Done()

					switch tt.operation {
					case "create_session":
						session := createTestImportSession()
						session.ID = fmt.Sprintf("session_%d", id)
						err := mockRepo.CreateSession(ctx, session)
						if err != nil {
							errChan <- err
						}
					case "get_session":
						_, err := mockRepo.GetSession(ctx, fmt.Sprintf("session_%d", id))
						if err != nil {
							errChan <- err
						}
					case "create_record":
						record := createTestETCMeisaiRecord2()
						record.ID = int64(id + 1)
						record.Hash = fmt.Sprintf("hash_%d", id)
						err := mockRepo.CreateRecord(ctx, record)
						if err != nil {
							errChan <- err
						}
					case "mixed":
						operation := id % 3
						switch operation {
						case 0: // CreateSession
							session := createTestImportSession()
							session.ID = fmt.Sprintf("session_%d", id)
							err := mockRepo.CreateSession(ctx, session)
							if err != nil {
								errChan <- err
							}
						case 1: // GetSession
							_, err := mockRepo.GetSession(ctx, fmt.Sprintf("session_%d", id))
							if err != nil {
								errChan <- err
							}
						case 2: // CreateRecord
							record := createTestETCMeisaiRecord2()
							record.ID = int64(id + 1)
							record.Hash = fmt.Sprintf("hash_%d", id)
							err := mockRepo.CreateRecord(ctx, record)
							if err != nil {
								errChan <- err
							}
						}
					}
				}(i)
			}

			// Wait for all operations to complete
			wg.Wait()
			close(errChan)

			// Check for errors
			var errors []error
			for err := range errChan {
				errors = append(errors, err)
			}

			assert.Empty(t, errors, "No errors should occur during concurrent operations")
			mockRepo.AssertExpectations(t)
		})
	}
}

// T006-D: Database constraint violation testing
func TestImportRepository_T006D_ConstraintViolations(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name           string
		setupMock      func(*MockImportRepository)
		operation      func(repositories.ImportRepository) error
		constraintType string
	}{
		{
			name: "CreateSession with unique constraint violation on session ID",
			setupMock: func(m *MockImportRepository) {
				m.On("CreateSession", mock.Anything, mock.Anything).Return(errors.New("UNIQUE constraint failed: import_sessions.id"))
			},
			operation: func(repo repositories.ImportRepository) error {
				session := createTestImportSession()
				session.ID = "existing_session_id"
				return repo.CreateSession(context.Background(), session)
			},
			constraintType: "unique",
		},
		{
			name: "CreateRecord with unique constraint violation on hash",
			setupMock: func(m *MockImportRepository) {
				m.On("CreateRecord", mock.Anything, mock.Anything).Return(errors.New("UNIQUE constraint failed: etc_meisai_records.hash"))
			},
			operation: func(repo repositories.ImportRepository) error {
				record := createTestETCMeisaiRecord2()
				record.Hash = "existing_hash"
				return repo.CreateRecord(context.Background(), record)
			},
			constraintType: "unique",
		},
		{
			name: "CreateSession with not null constraint violation",
			setupMock: func(m *MockImportRepository) {
				m.On("CreateSession", mock.Anything, mock.Anything).Return(errors.New("NOT NULL constraint failed: import_sessions.account_type"))
			},
			operation: func(repo repositories.ImportRepository) error {
				session := createTestImportSession()
				session.AccountType = "" // Missing required field
				return repo.CreateSession(context.Background(), session)
			},
			constraintType: "not_null",
		},
		{
			name: "CreateRecord with foreign key constraint violation",
			setupMock: func(m *MockImportRepository) {
				m.On("CreateRecord", mock.Anything, mock.Anything).Return(errors.New("FOREIGN KEY constraint failed: etc_meisai_records.session_id"))
			},
			operation: func(repo repositories.ImportRepository) error {
				record := createTestETCMeisaiRecord2()
				// Simulate invalid session reference
				return repo.CreateRecord(context.Background(), record)
			},
			constraintType: "foreign_key",
		},
		{
			name: "CreateRecordsBatch with constraint violations in batch",
			setupMock: func(m *MockImportRepository) {
				m.On("CreateRecordsBatch", mock.Anything, mock.Anything).Return(errors.New("UNIQUE constraint failed during batch insert: hash duplicate at record 2"))
			},
			operation: func(repo repositories.ImportRepository) error {
				records := []*models.ETCMeisaiRecord{
					createTestETCMeisaiRecord2(),
					createTestETCMeisaiRecord2(), // Same hash - should cause unique constraint violation
				}
				return repo.CreateRecordsBatch(context.Background(), records)
			},
			constraintType: "batch_unique",
		},
		{
			name: "UpdateSession with check constraint violation on status",
			setupMock: func(m *MockImportRepository) {
				m.On("UpdateSession", mock.Anything, mock.Anything).Return(errors.New("CHECK constraint failed: status IN ('pending', 'processing', 'completed', 'failed', 'cancelled')"))
			},
			operation: func(repo repositories.ImportRepository) error {
				session := createTestImportSession()
				session.Status = "invalid_status"
				return repo.UpdateSession(context.Background(), session)
			},
			constraintType: "check",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			mockRepo := new(MockImportRepository)
			tt.setupMock(mockRepo)

			err := tt.operation(mockRepo)

			assert.Error(t, err)

			switch tt.constraintType {
			case "unique", "batch_unique":
				assert.Contains(t, err.Error(), "UNIQUE constraint")
			case "not_null":
				assert.Contains(t, err.Error(), "NOT NULL constraint")
			case "foreign_key":
				assert.Contains(t, err.Error(), "FOREIGN KEY constraint")
			case "check":
				assert.Contains(t, err.Error(), "CHECK constraint")
			}

			mockRepo.AssertExpectations(t)
		})
	}
}

// T006-E: Pagination edge case testing for ListSessions
func TestImportRepository_T006E_PaginationEdgeCases(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name           string
		params         repositories.ListImportSessionsParams
		mockResponse   []*models.ImportSession
		mockTotal      int64
		mockError      error
		expectedResult string
	}{
		{
			name: "Empty results - no sessions found",
			params: repositories.ListImportSessionsParams{
				Page:     1,
				PageSize: 10,
			},
			mockResponse:   []*models.ImportSession{},
			mockTotal:      0,
			mockError:      nil,
			expectedResult: "empty",
		},
		{
			name: "Single page with exact page size",
			params: repositories.ListImportSessionsParams{
				Page:     1,
				PageSize: 3,
			},
			mockResponse: []*models.ImportSession{
				createTestImportSession(),
				createTestImportSession(),
				createTestImportSession(),
			},
			mockTotal:      3,
			mockError:      nil,
			expectedResult: "exact_page",
		},
		{
			name: "Last page with partial results",
			params: repositories.ListImportSessionsParams{
				Page:     3,
				PageSize: 5,
			},
			mockResponse: []*models.ImportSession{
				createTestImportSession(),
				createTestImportSession(),
			},
			mockTotal:      12, // Total 12, page 3 with size 5 = 2 remaining
			mockError:      nil,
			expectedResult: "partial_last_page",
		},
		{
			name: "Page beyond available data",
			params: repositories.ListImportSessionsParams{
				Page:     10,
				PageSize: 5,
			},
			mockResponse:   []*models.ImportSession{},
			mockTotal:      20, // Only 20 total sessions, page 10 is beyond available data
			mockError:      nil,
			expectedResult: "beyond_data",
		},
		{
			name: "Filter by account type with results",
			params: repositories.ListImportSessionsParams{
				Page:        1,
				PageSize:    10,
				AccountType: func() *string { s := "corporate"; return &s }(),
			},
			mockResponse: []*models.ImportSession{createTestImportSession()},
			mockTotal:    1,
			mockError:    nil,
			expectedResult: "filtered_results",
		},
		{
			name: "Filter by status with no results",
			params: repositories.ListImportSessionsParams{
				Page:     1,
				PageSize: 10,
				Status:   func() *string { s := "archived"; return &s }(),
			},
			mockResponse:   []*models.ImportSession{},
			mockTotal:      0,
			mockError:      nil,
			expectedResult: "filtered_empty",
		},
		{
			name: "Invalid page number (negative)",
			params: repositories.ListImportSessionsParams{
				Page:     -1,
				PageSize: 10,
			},
			mockResponse:   nil,
			mockTotal:      0,
			mockError:      errors.New("invalid page number: must be positive"),
			expectedResult: "invalid_page",
		},
		{
			name: "Invalid page size (zero)",
			params: repositories.ListImportSessionsParams{
				Page:     1,
				PageSize: 0,
			},
			mockResponse:   nil,
			mockTotal:      0,
			mockError:      errors.New("invalid page size: must be positive"),
			expectedResult: "invalid_page_size",
		},
		{
			name: "Very large page size",
			params: repositories.ListImportSessionsParams{
				Page:     1,
				PageSize: 10000,
			},
			mockResponse: func() []*models.ImportSession {
				// Create 100 test sessions
				sessions := make([]*models.ImportSession, 100)
				for i := 0; i < 100; i++ {
					session := createTestImportSession()
					session.ID = fmt.Sprintf("session_%d", i)
					sessions[i] = session
				}
				return sessions
			}(),
			mockTotal:      100,
			mockError:      nil,
			expectedResult: "large_page_size",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			mockRepo := new(MockImportRepository)
			mockRepo.On("ListSessions", mock.Anything, tt.params).Return(tt.mockResponse, tt.mockTotal, tt.mockError)

			ctx := context.Background()
			result, total, err := mockRepo.ListSessions(ctx, tt.params)

			switch tt.expectedResult {
			case "empty":
				assert.NoError(t, err)
				assert.Empty(t, result)
				assert.Equal(t, int64(0), total)

			case "exact_page":
				assert.NoError(t, err)
				assert.Len(t, result, tt.params.PageSize)
				assert.Equal(t, int64(3), total)

			case "partial_last_page":
				assert.NoError(t, err)
				assert.Len(t, result, 2)
				assert.Equal(t, int64(12), total)

			case "beyond_data":
				assert.NoError(t, err)
				assert.Empty(t, result)
				assert.Equal(t, int64(20), total)

			case "filtered_results":
				assert.NoError(t, err)
				assert.Len(t, result, 1)
				assert.Equal(t, int64(1), total)

			case "filtered_empty":
				assert.NoError(t, err)
				assert.Empty(t, result)
				assert.Equal(t, int64(0), total)

			case "invalid_page":
				assert.Error(t, err)
				assert.Contains(t, err.Error(), "invalid page number")

			case "invalid_page_size":
				assert.Error(t, err)
				assert.Contains(t, err.Error(), "invalid page size")

			case "large_page_size":
				assert.NoError(t, err)
				assert.Len(t, result, 100)
				assert.Equal(t, int64(100), total)
			}

			mockRepo.AssertExpectations(t)
		})
	}
}

// Benchmark tests for import operations
func BenchmarkImportRepository_CreateSession(b *testing.B) {
	mockRepo := new(MockImportRepository)
	mockRepo.On("CreateSession", mock.Anything, mock.Anything).Return(nil)

	ctx := context.Background()
	session := createTestImportSession()

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		session.ID = fmt.Sprintf("session_%d", i)
		_ = mockRepo.CreateSession(ctx, session)
	}
}

func BenchmarkImportRepository_CreateRecordsBatch(b *testing.B) {
	mockRepo := new(MockImportRepository)
	mockRepo.On("CreateRecordsBatch", mock.Anything, mock.Anything).Return(nil)

	ctx := context.Background()

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		records := make([]*models.ETCMeisaiRecord, 100)
		for j := 0; j < 100; j++ {
			record := createTestETCMeisaiRecord2()
			record.ID = int64(i*100 + j + 1)
			record.Hash = fmt.Sprintf("hash_%d_%d", i, j)
			records[j] = record
		}
		_ = mockRepo.CreateRecordsBatch(ctx, records)
	}
}

func BenchmarkImportRepository_FindDuplicateRecords(b *testing.B) {
	mockRepo := new(MockImportRepository)
	duplicates := []*models.ETCMeisaiRecord{createTestETCMeisaiRecord2()}
	mockRepo.On("FindDuplicateRecords", mock.Anything, mock.Anything).Return(duplicates, nil)

	ctx := context.Background()

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		hashes := make([]string, 50)
		for j := 0; j < 50; j++ {
			hashes[j] = fmt.Sprintf("hash_%d_%d", i, j)
		}
		_, _ = mockRepo.FindDuplicateRecords(ctx, hashes)
	}
}

// Comprehensive integration-style test
func TestImportRepository_ComprehensiveWorkflow(t *testing.T) {
	t.Parallel()

	t.Run("Complete import session lifecycle", func(t *testing.T) {
		t.Parallel()

		mockRepo := new(MockImportRepository)
		ctx := context.Background()
		session := createTestImportSession()

		// Setup expectations for complete lifecycle
		mockRepo.On("CreateSession", ctx, session).Return(nil).Once()
		mockRepo.On("GetSession", ctx, session.ID).Return(session, nil).Once()

		// Update session to processing
		processingSession := *session
		processingSession.Status = "processing"
		mockRepo.On("UpdateSession", ctx, &processingSession).Return(nil).Once()

		// Create some records
		records := []*models.ETCMeisaiRecord{
			createTestETCMeisaiRecord2(),
			{
				ID:            2,
				Hash:          "def456",
				Date:          time.Date(2024, 1, 16, 0, 0, 0, 0, time.UTC),
				Time:          "10:15:00",
				EntranceIC:    "横浜IC",
				ExitIC:        "静岡IC",
				TollAmount:    600,
				CarNumber:     "横浜500い5678",
				ETCCardNumber: "2345678901234567",
			},
		}
		mockRepo.On("CreateRecordsBatch", ctx, records).Return(nil).Once()

		// Update session to completed
		completedSession := processingSession
		completedSession.Status = "completed"
		mockRepo.On("UpdateSession", ctx, &completedSession).Return(nil).Once()

		mockRepo.On("GetSession", ctx, session.ID).Return(&completedSession, nil).Once()

		// Execute lifecycle
		// 1. Create session
		err := mockRepo.CreateSession(ctx, session)
		assert.NoError(t, err)

		// 2. Retrieve session
		retrieved, err := mockRepo.GetSession(ctx, session.ID)
		assert.NoError(t, err)
		assert.Equal(t, session.ID, retrieved.ID)

		// 3. Update to processing
		err = mockRepo.UpdateSession(ctx, &processingSession)
		assert.NoError(t, err)

		// 4. Create records in batch
		err = mockRepo.CreateRecordsBatch(ctx, records)
		assert.NoError(t, err)

		// 5. Complete session
		err = mockRepo.UpdateSession(ctx, &completedSession)
		assert.NoError(t, err)

		// 6. Verify final state
		final, err := mockRepo.GetSession(ctx, session.ID)
		assert.NoError(t, err)
		assert.Equal(t, "completed", final.Status)

		mockRepo.AssertExpectations(t)
	})

	t.Run("Import with duplicate detection", func(t *testing.T) {
		t.Parallel()

		mockRepo := new(MockImportRepository)
		ctx := context.Background()

		// Setup for duplicate detection workflow
		hashes := []string{"hash1", "hash2", "hash3"}
		existingRecords := []*models.ETCMeisaiRecord{
			{ID: 1, Hash: "hash1"},
		}
		mockRepo.On("FindDuplicateRecords", ctx, hashes).Return(existingRecords, nil).Once()

		// New records to import (excluding duplicates)
		newRecords := []*models.ETCMeisaiRecord{
			{ID: 2, Hash: "hash2"},
			{ID: 3, Hash: "hash3"},
		}
		mockRepo.On("CreateRecordsBatch", ctx, newRecords).Return(nil).Once()

		// Execute duplicate detection workflow
		duplicates, err := mockRepo.FindDuplicateRecords(ctx, hashes)
		assert.NoError(t, err)
		assert.Len(t, duplicates, 1)
		assert.Equal(t, "hash1", duplicates[0].Hash)

		// Import only new records
		err = mockRepo.CreateRecordsBatch(ctx, newRecords)
		assert.NoError(t, err)

		mockRepo.AssertExpectations(t)
	})
}