package repositories_test

import (
	"context"
	"errors"
	"fmt"
	"sync"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.com/yhonda-ohishi/etc_meisai/src/repositories"
)

// MockStatisticsRepository is a mock implementation for testing
type MockStatisticsRepository struct {
	mock.Mock
}

func (m *MockStatisticsRepository) CountRecords(ctx context.Context, filter repositories.StatisticsFilter) (int64, error) {
	args := m.Called(ctx, filter)
	return args.Get(0).(int64), args.Error(1)
}

func (m *MockStatisticsRepository) CountUniqueVehicles(ctx context.Context, filter repositories.StatisticsFilter) (int64, error) {
	args := m.Called(ctx, filter)
	return args.Get(0).(int64), args.Error(1)
}

func (m *MockStatisticsRepository) CountUniqueCards(ctx context.Context, filter repositories.StatisticsFilter) (int64, error) {
	args := m.Called(ctx, filter)
	return args.Get(0).(int64), args.Error(1)
}

func (m *MockStatisticsRepository) CountUniqueEntranceICs(ctx context.Context, filter repositories.StatisticsFilter) (int64, error) {
	args := m.Called(ctx, filter)
	return args.Get(0).(int64), args.Error(1)
}

func (m *MockStatisticsRepository) CountUniqueExitICs(ctx context.Context, filter repositories.StatisticsFilter) (int64, error) {
	args := m.Called(ctx, filter)
	return args.Get(0).(int64), args.Error(1)
}

func (m *MockStatisticsRepository) SumTollAmount(ctx context.Context, filter repositories.StatisticsFilter) (int64, error) {
	args := m.Called(ctx, filter)
	return args.Get(0).(int64), args.Error(1)
}

func (m *MockStatisticsRepository) AverageTollAmount(ctx context.Context, filter repositories.StatisticsFilter) (float64, error) {
	args := m.Called(ctx, filter)
	return args.Get(0).(float64), args.Error(1)
}

func (m *MockStatisticsRepository) GetTopRoutes(ctx context.Context, filter repositories.StatisticsFilter, limit int) ([]repositories.RouteStatistic, error) {
	args := m.Called(ctx, filter, limit)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).([]repositories.RouteStatistic), args.Error(1)
}

func (m *MockStatisticsRepository) GetTopVehicles(ctx context.Context, filter repositories.StatisticsFilter, limit int) ([]repositories.VehicleStatistic, error) {
	args := m.Called(ctx, filter, limit)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).([]repositories.VehicleStatistic), args.Error(1)
}

func (m *MockStatisticsRepository) GetTopCards(ctx context.Context, filter repositories.StatisticsFilter, limit int) ([]repositories.CardStatistic, error) {
	args := m.Called(ctx, filter, limit)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).([]repositories.CardStatistic), args.Error(1)
}

func (m *MockStatisticsRepository) GetHourlyDistribution(ctx context.Context, filter repositories.StatisticsFilter) ([]repositories.HourlyStatistic, error) {
	args := m.Called(ctx, filter)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).([]repositories.HourlyStatistic), args.Error(1)
}

func (m *MockStatisticsRepository) GetDailyDistribution(ctx context.Context, filter repositories.StatisticsFilter) ([]repositories.DailyStatistic, error) {
	args := m.Called(ctx, filter)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).([]repositories.DailyStatistic), args.Error(1)
}

func (m *MockStatisticsRepository) GetMonthlyDistribution(ctx context.Context, filter repositories.StatisticsFilter) ([]repositories.MonthlyStatistic, error) {
	args := m.Called(ctx, filter)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).([]repositories.MonthlyStatistic), args.Error(1)
}

func (m *MockStatisticsRepository) CountMappedRecords(ctx context.Context, filter repositories.StatisticsFilter) (int64, error) {
	args := m.Called(ctx, filter)
	return args.Get(0).(int64), args.Error(1)
}

func (m *MockStatisticsRepository) CountUnmappedRecords(ctx context.Context, filter repositories.StatisticsFilter) (int64, error) {
	args := m.Called(ctx, filter)
	return args.Get(0).(int64), args.Error(1)
}

func (m *MockStatisticsRepository) GetMappingStatistics(ctx context.Context, filter repositories.StatisticsFilter) (*repositories.MappingStatistics, error) {
	args := m.Called(ctx, filter)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*repositories.MappingStatistics), args.Error(1)
}

func (m *MockStatisticsRepository) Ping(ctx context.Context) error {
	args := m.Called(ctx)
	return args.Error(0)
}

// Test data helpers
func createTestStatisticsFilter() repositories.StatisticsFilter {
	dateFrom := time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC)
	dateTo := time.Date(2024, 1, 31, 23, 59, 59, 0, time.UTC)
	minAmount := 100
	maxAmount := 10000

	return repositories.StatisticsFilter{
		DateFrom:      &dateFrom,
		DateTo:        &dateTo,
		CarNumbers:    []string{"品川500あ1234", "横浜500い5678"},
		ETCNumbers:    []string{"1234567890123456", "2345678901234567"},
		EntranceICs:   []string{"東京IC", "横浜IC"},
		ExitICs:       []string{"静岡IC", "名古屋IC"},
		MinTollAmount: &minAmount,
		MaxTollAmount: &maxAmount,
	}
}

// T006-A: Error path testing for StatisticsRepository with database connection failures
func TestStatisticsRepository_T006A_DatabaseConnectionFailures(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name      string
		operation string
		setupMock func(*MockStatisticsRepository)
		testFunc  func(repositories.StatisticsRepository) error
		errorMsg  string
	}{
		{
			name:      "CountRecords with connection failure",
			operation: "CountRecords",
			setupMock: func(m *MockStatisticsRepository) {
				m.On("CountRecords", mock.Anything, mock.Anything).Return(int64(0), errors.New("connection refused"))
			},
			testFunc: func(repo repositories.StatisticsRepository) error {
				_, err := repo.CountRecords(context.Background(), createTestStatisticsFilter())
				return err
			},
			errorMsg: "connection refused",
		},
		{
			name:      "GetTopRoutes with timeout",
			operation: "GetTopRoutes",
			setupMock: func(m *MockStatisticsRepository) {
				m.On("GetTopRoutes", mock.Anything, mock.Anything, mock.Anything).Return(nil, errors.New("context deadline exceeded"))
			},
			testFunc: func(repo repositories.StatisticsRepository) error {
				_, err := repo.GetTopRoutes(context.Background(), createTestStatisticsFilter(), 10)
				return err
			},
			errorMsg: "context deadline exceeded",
		},
		{
			name:      "GetMappingStatistics with SQL error",
			operation: "GetMappingStatistics",
			setupMock: func(m *MockStatisticsRepository) {
				m.On("GetMappingStatistics", mock.Anything, mock.Anything).Return(nil, errors.New("SQL syntax error"))
			},
			testFunc: func(repo repositories.StatisticsRepository) error {
				_, err := repo.GetMappingStatistics(context.Background(), createTestStatisticsFilter())
				return err
			},
			errorMsg: "SQL syntax error",
		},
		{
			name:      "SumTollAmount with database lock",
			operation: "SumTollAmount",
			setupMock: func(m *MockStatisticsRepository) {
				m.On("SumTollAmount", mock.Anything, mock.Anything).Return(int64(0), errors.New("database is locked"))
			},
			testFunc: func(repo repositories.StatisticsRepository) error {
				_, err := repo.SumTollAmount(context.Background(), createTestStatisticsFilter())
				return err
			},
			errorMsg: "database is locked",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			mockRepo := new(MockStatisticsRepository)
			tt.setupMock(mockRepo)

			err := tt.testFunc(mockRepo)

			assert.Error(t, err)
			assert.Contains(t, err.Error(), tt.errorMsg)
			mockRepo.AssertExpectations(t)
		})
	}
}

// T006-C: Concurrent access testing for statistics operations
func TestStatisticsRepository_T006C_ConcurrentAccess(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name        string
		concurrency int
		operation   string
	}{
		{
			name:        "Concurrent CountRecords operations",
			concurrency: 10,
			operation:   "count_records",
		},
		{
			name:        "Concurrent GetTopRoutes operations",
			concurrency: 8,
			operation:   "top_routes",
		},
		{
			name:        "Concurrent distribution queries",
			concurrency: 12,
			operation:   "distributions",
		},
		{
			name:        "Mixed concurrent operations",
			concurrency: 15,
			operation:   "mixed",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			mockRepo := new(MockStatisticsRepository)

			// Setup mock expectations for concurrent operations
			switch tt.operation {
			case "count_records":
				mockRepo.On("CountRecords", mock.Anything, mock.Anything).Return(int64(100), nil).Times(tt.concurrency)
			case "top_routes":
				routes := []repositories.RouteStatistic{
					{EntranceIC: "東京IC", ExitIC: "横浜IC", Count: 50, TotalAmount: 5000, AvgAmount: 100.0},
				}
				mockRepo.On("GetTopRoutes", mock.Anything, mock.Anything, mock.Anything).Return(routes, nil).Times(tt.concurrency)
			case "distributions":
				hourly := []repositories.HourlyStatistic{
					{Hour: 8, Count: 10, TotalAmount: 1000, AvgAmount: 100.0},
				}
				mockRepo.On("GetHourlyDistribution", mock.Anything, mock.Anything).Return(hourly, nil).Times(tt.concurrency)
			case "mixed":
				countOps := tt.concurrency / 3
				routesOps := tt.concurrency / 3
				distributionOps := tt.concurrency - countOps - routesOps

				mockRepo.On("CountRecords", mock.Anything, mock.Anything).Return(int64(100), nil).Times(countOps)
				routes := []repositories.RouteStatistic{
					{EntranceIC: "東京IC", ExitIC: "横浜IC", Count: 50, TotalAmount: 5000, AvgAmount: 100.0},
				}
				mockRepo.On("GetTopRoutes", mock.Anything, mock.Anything, mock.Anything).Return(routes, nil).Times(routesOps)
				hourly := []repositories.HourlyStatistic{
					{Hour: 8, Count: 10, TotalAmount: 1000, AvgAmount: 100.0},
				}
				mockRepo.On("GetHourlyDistribution", mock.Anything, mock.Anything).Return(hourly, nil).Times(distributionOps)
			}

			var wg sync.WaitGroup
			errChan := make(chan error, tt.concurrency)
			ctx := context.Background()
			filter := createTestStatisticsFilter()

			// Launch concurrent operations
			for i := 0; i < tt.concurrency; i++ {
				wg.Add(1)
				go func(id int) {
					defer wg.Done()

					switch tt.operation {
					case "count_records":
						_, err := mockRepo.CountRecords(ctx, filter)
						if err != nil {
							errChan <- err
						}
					case "top_routes":
						_, err := mockRepo.GetTopRoutes(ctx, filter, 10)
						if err != nil {
							errChan <- err
						}
					case "distributions":
						_, err := mockRepo.GetHourlyDistribution(ctx, filter)
						if err != nil {
							errChan <- err
						}
					case "mixed":
						operation := id % 3
						switch operation {
						case 0:
							_, err := mockRepo.CountRecords(ctx, filter)
							if err != nil {
								errChan <- err
							}
						case 1:
							_, err := mockRepo.GetTopRoutes(ctx, filter, 10)
							if err != nil {
								errChan <- err
							}
						case 2:
							_, err := mockRepo.GetHourlyDistribution(ctx, filter)
							if err != nil {
								errChan <- err
							}
						}
					}
				}(i)
			}

			// Wait for all operations to complete
			wg.Wait()
			close(errChan)

			// Check for errors
			var errors []error
			for err := range errChan {
				errors = append(errors, err)
			}

			assert.Empty(t, errors, "No errors should occur during concurrent operations")
			mockRepo.AssertExpectations(t)
		})
	}
}

// T006-D: Database constraint violation testing
func TestStatisticsRepository_T006D_ConstraintViolations(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name           string
		setupMock      func(*MockStatisticsRepository)
		operation      func(repositories.StatisticsRepository) error
		constraintType string
	}{
		{
			name: "Invalid date range filter",
			setupMock: func(m *MockStatisticsRepository) {
				m.On("CountRecords", mock.Anything, mock.Anything).Return(int64(0), errors.New("CHECK constraint failed: date_from <= date_to"))
			},
			operation: func(repo repositories.StatisticsRepository) error {
				// Invalid filter with date_from > date_to
				filter := repositories.StatisticsFilter{
					DateFrom: func() *time.Time { t := time.Date(2024, 12, 31, 0, 0, 0, 0, time.UTC); return &t }(),
					DateTo:   func() *time.Time { t := time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC); return &t }(),
				}
				_, err := repo.CountRecords(context.Background(), filter)
				return err
			},
			constraintType: "check",
		},
		{
			name: "Invalid amount range filter",
			setupMock: func(m *MockStatisticsRepository) {
				m.On("SumTollAmount", mock.Anything, mock.Anything).Return(int64(0), errors.New("CHECK constraint failed: min_amount <= max_amount"))
			},
			operation: func(repo repositories.StatisticsRepository) error {
				// Invalid filter with min_amount > max_amount
				filter := repositories.StatisticsFilter{
					MinTollAmount: func() *int { i := 1000; return &i }(),
					MaxTollAmount: func() *int { i := 100; return &i }(),
				}
				_, err := repo.SumTollAmount(context.Background(), filter)
				return err
			},
			constraintType: "check",
		},
		{
			name: "Invalid limit parameter",
			setupMock: func(m *MockStatisticsRepository) {
				m.On("GetTopRoutes", mock.Anything, mock.Anything, mock.Anything).Return(nil, errors.New("CHECK constraint failed: limit > 0"))
			},
			operation: func(repo repositories.StatisticsRepository) error {
				_, err := repo.GetTopRoutes(context.Background(), createTestStatisticsFilter(), -1)
				return err
			},
			constraintType: "check",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			mockRepo := new(MockStatisticsRepository)
			tt.setupMock(mockRepo)

			err := tt.operation(mockRepo)

			assert.Error(t, err)
			assert.Contains(t, err.Error(), "CHECK constraint")
			mockRepo.AssertExpectations(t)
		})
	}
}

// T006-E: Pagination and edge case testing for statistics operations
func TestStatisticsRepository_T006E_EdgeCases(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name           string
		setupMock      func(*MockStatisticsRepository)
		operation      func(repositories.StatisticsRepository) (interface{}, error)
		expectedResult string
	}{
		{
			name: "Empty results - no matching records",
			setupMock: func(m *MockStatisticsRepository) {
				m.On("CountRecords", mock.Anything, mock.Anything).Return(int64(0), nil)
			},
			operation: func(repo repositories.StatisticsRepository) (interface{}, error) {
				return repo.CountRecords(context.Background(), createTestStatisticsFilter())
			},
			expectedResult: "zero_count",
		},
		{
			name: "GetTopRoutes with zero limit",
			setupMock: func(m *MockStatisticsRepository) {
				m.On("GetTopRoutes", mock.Anything, mock.Anything, mock.Anything).Return([]repositories.RouteStatistic{}, nil)
			},
			operation: func(repo repositories.StatisticsRepository) (interface{}, error) {
				return repo.GetTopRoutes(context.Background(), createTestStatisticsFilter(), 0)
			},
			expectedResult: "empty_routes",
		},
		{
			name: "Very large limit for top statistics",
			setupMock: func(m *MockStatisticsRepository) {
				routes := make([]repositories.RouteStatistic, 1000)
				for i := 0; i < 1000; i++ {
					routes[i] = repositories.RouteStatistic{
						EntranceIC:  fmt.Sprintf("IC_%d", i),
						ExitIC:      fmt.Sprintf("IC_%d", i+1),
						Count:       int64(100 - i),
						TotalAmount: int64((100 - i) * 500),
						AvgAmount:   500.0,
					}
				}
				m.On("GetTopRoutes", mock.Anything, mock.Anything, mock.Anything).Return(routes, nil)
			},
			operation: func(repo repositories.StatisticsRepository) (interface{}, error) {
				return repo.GetTopRoutes(context.Background(), createTestStatisticsFilter(), 100000)
			},
			expectedResult: "large_result_set",
		},
		{
			name: "GetMappingStatistics with perfect mapping rate",
			setupMock: func(m *MockStatisticsRepository) {
				stats := &repositories.MappingStatistics{
					TotalRecords:    1000,
					MappedRecords:   1000,
					UnmappedRecords: 0,
					MappingRate:     1.0,
				}
				m.On("GetMappingStatistics", mock.Anything, mock.Anything).Return(stats, nil)
			},
			operation: func(repo repositories.StatisticsRepository) (interface{}, error) {
				return repo.GetMappingStatistics(context.Background(), createTestStatisticsFilter())
			},
			expectedResult: "perfect_mapping",
		},
		{
			name: "GetMappingStatistics with zero mapping rate",
			setupMock: func(m *MockStatisticsRepository) {
				stats := &repositories.MappingStatistics{
					TotalRecords:    1000,
					MappedRecords:   0,
					UnmappedRecords: 1000,
					MappingRate:     0.0,
				}
				m.On("GetMappingStatistics", mock.Anything, mock.Anything).Return(stats, nil)
			},
			operation: func(repo repositories.StatisticsRepository) (interface{}, error) {
				return repo.GetMappingStatistics(context.Background(), createTestStatisticsFilter())
			},
			expectedResult: "zero_mapping",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			mockRepo := new(MockStatisticsRepository)
			tt.setupMock(mockRepo)

			result, err := tt.operation(mockRepo)

			assert.NoError(t, err)

			switch tt.expectedResult {
			case "zero_count":
				count := result.(int64)
				assert.Equal(t, int64(0), count)

			case "empty_routes":
				routes := result.([]repositories.RouteStatistic)
				assert.Empty(t, routes)

			case "large_result_set":
				routes := result.([]repositories.RouteStatistic)
				assert.Len(t, routes, 1000)

			case "perfect_mapping":
				stats := result.(*repositories.MappingStatistics)
				assert.Equal(t, float64(1.0), stats.MappingRate)
				assert.Equal(t, int64(0), stats.UnmappedRecords)

			case "zero_mapping":
				stats := result.(*repositories.MappingStatistics)
				assert.Equal(t, float64(0.0), stats.MappingRate)
				assert.Equal(t, int64(0), stats.MappedRecords)
			}

			mockRepo.AssertExpectations(t)
		})
	}
}

// Benchmark tests for statistics operations
func BenchmarkStatisticsRepository_CountRecords(b *testing.B) {
	mockRepo := new(MockStatisticsRepository)
	mockRepo.On("CountRecords", mock.Anything, mock.Anything).Return(int64(1000), nil)

	ctx := context.Background()
	filter := createTestStatisticsFilter()

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, _ = mockRepo.CountRecords(ctx, filter)
	}
}

func BenchmarkStatisticsRepository_GetTopRoutes(b *testing.B) {
	mockRepo := new(MockStatisticsRepository)
	routes := []repositories.RouteStatistic{
		{EntranceIC: "東京IC", ExitIC: "横浜IC", Count: 50, TotalAmount: 5000, AvgAmount: 100.0},
	}
	mockRepo.On("GetTopRoutes", mock.Anything, mock.Anything, mock.Anything).Return(routes, nil)

	ctx := context.Background()
	filter := createTestStatisticsFilter()

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, _ = mockRepo.GetTopRoutes(ctx, filter, 10)
	}
}

func BenchmarkStatisticsRepository_GetMappingStatistics(b *testing.B) {
	mockRepo := new(MockStatisticsRepository)
	stats := &repositories.MappingStatistics{
		TotalRecords:    1000,
		MappedRecords:   800,
		UnmappedRecords: 200,
		MappingRate:     0.8,
	}
	mockRepo.On("GetMappingStatistics", mock.Anything, mock.Anything).Return(stats, nil)

	ctx := context.Background()
	filter := createTestStatisticsFilter()

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, _ = mockRepo.GetMappingStatistics(ctx, filter)
	}
}

// Comprehensive integration-style test
func TestStatisticsRepository_ComprehensiveWorkflow(t *testing.T) {
	t.Parallel()

	mockRepo := new(MockStatisticsRepository)
	ctx := context.Background()
	filter := createTestStatisticsFilter()

	// Setup expectations for complete workflow
	mockRepo.On("CountRecords", ctx, filter).Return(int64(1000), nil).Once()
	mockRepo.On("CountUniqueVehicles", ctx, filter).Return(int64(50), nil).Once()
	mockRepo.On("SumTollAmount", ctx, filter).Return(int64(500000), nil).Once()
	mockRepo.On("AverageTollAmount", ctx, filter).Return(float64(500.0), nil).Once()

	routes := []repositories.RouteStatistic{
		{EntranceIC: "東京IC", ExitIC: "横浜IC", Count: 100, TotalAmount: 10000, AvgAmount: 100.0},
		{EntranceIC: "横浜IC", ExitIC: "静岡IC", Count: 80, TotalAmount: 12000, AvgAmount: 150.0},
	}
	mockRepo.On("GetTopRoutes", ctx, filter, 10).Return(routes, nil).Once()

	mappingStats := &repositories.MappingStatistics{
		TotalRecords:    1000,
		MappedRecords:   800,
		UnmappedRecords: 200,
		MappingRate:     0.8,
	}
	mockRepo.On("GetMappingStatistics", ctx, filter).Return(mappingStats, nil).Once()

	// Execute comprehensive workflow
	// 1. Basic counts
	recordCount, err := mockRepo.CountRecords(ctx, filter)
	assert.NoError(t, err)
	assert.Equal(t, int64(1000), recordCount)

	vehicleCount, err := mockRepo.CountUniqueVehicles(ctx, filter)
	assert.NoError(t, err)
	assert.Equal(t, int64(50), vehicleCount)

	// 2. Amount calculations
	totalAmount, err := mockRepo.SumTollAmount(ctx, filter)
	assert.NoError(t, err)
	assert.Equal(t, int64(500000), totalAmount)

	avgAmount, err := mockRepo.AverageTollAmount(ctx, filter)
	assert.NoError(t, err)
	assert.Equal(t, float64(500.0), avgAmount)

	// 3. Top statistics
	topRoutes, err := mockRepo.GetTopRoutes(ctx, filter, 10)
	assert.NoError(t, err)
	assert.Len(t, topRoutes, 2)
	assert.Equal(t, "東京IC", topRoutes[0].EntranceIC)

	// 4. Mapping statistics
	mappingResult, err := mockRepo.GetMappingStatistics(ctx, filter)
	assert.NoError(t, err)
	assert.Equal(t, float64(0.8), mappingResult.MappingRate)

	mockRepo.AssertExpectations(t)
}