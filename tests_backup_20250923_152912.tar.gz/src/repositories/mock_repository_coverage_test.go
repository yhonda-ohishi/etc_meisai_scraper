package repositories_test

import (
	"context"
	"errors"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.com/yhonda-ohishi/etc_meisai/src/models"
	"github.com/yhonda-ohishi/etc_meisai/src/repositories"
)

// TestMockETCMappingRepository_ErrorPaths tests error return paths for mock repository methods (T011-T016)
func TestMockETCMappingRepository_ErrorPaths(t *testing.T) {
	t.Parallel()

	ctx := context.Background()

	t.Run("GetByID returns nil", func(t *testing.T) {
		// T011: Test GetByID error path when returning nil
		mockRepo := new(repositories.MockETCMappingRepository)
		mockRepo.On("GetByID", ctx, int64(1)).Return(nil, errors.New("not found"))

		result, err := mockRepo.GetByID(ctx, 1)
		assert.Nil(t, result)
		assert.Error(t, err)
		assert.Equal(t, "not found", err.Error())
		mockRepo.AssertExpectations(t)
	})

	t.Run("GetByETCRecordID returns nil", func(t *testing.T) {
		// T012: Test GetByETCRecordID error path when returning nil
		mockRepo := new(repositories.MockETCMappingRepository)
		mockRepo.On("GetByETCRecordID", ctx, int64(123)).Return(nil, errors.New("database error"))

		result, err := mockRepo.GetByETCRecordID(ctx, 123)
		assert.Nil(t, result)
		assert.Error(t, err)
		assert.Equal(t, "database error", err.Error())
		mockRepo.AssertExpectations(t)
	})

	t.Run("GetByMappedEntity returns nil", func(t *testing.T) {
		// T013: Test GetByMappedEntity error path when returning nil
		mockRepo := new(repositories.MockETCMappingRepository)
		mockRepo.On("GetByMappedEntity", ctx, "dtako", int64(456)).Return(nil, errors.New("connection failed"))

		result, err := mockRepo.GetByMappedEntity(ctx, "dtako", 456)
		assert.Nil(t, result)
		assert.Error(t, err)
		assert.Equal(t, "connection failed", err.Error())
		mockRepo.AssertExpectations(t)
	})

	t.Run("GetActiveMapping returns nil", func(t *testing.T) {
		// T014: Test GetActiveMapping error path when returning nil
		mockRepo := new(repositories.MockETCMappingRepository)
		mockRepo.On("GetActiveMapping", ctx, int64(789)).Return(nil, errors.New("no active mapping"))

		result, err := mockRepo.GetActiveMapping(ctx, 789)
		assert.Nil(t, result)
		assert.Error(t, err)
		assert.Equal(t, "no active mapping", err.Error())
		mockRepo.AssertExpectations(t)
	})

	t.Run("List returns nil", func(t *testing.T) {
		// T015: Test List error path when returning nil
		mockRepo := new(repositories.MockETCMappingRepository)
		params := repositories.ListMappingsParams{
			Page:     1,
			PageSize: 10,
		}
		mockRepo.On("List", ctx, params).Return(nil, int64(0), errors.New("query timeout"))

		result, count, err := mockRepo.List(ctx, params)
		assert.Nil(t, result)
		assert.Equal(t, int64(0), count)
		assert.Error(t, err)
		assert.Equal(t, "query timeout", err.Error())
		mockRepo.AssertExpectations(t)
	})

	t.Run("BeginTx returns nil", func(t *testing.T) {
		// T016: Test BeginTx error path when returning nil
		mockRepo := new(repositories.MockETCMappingRepository)
		mockRepo.On("BeginTx", ctx).Return(nil, errors.New("transaction failed"))

		result, err := mockRepo.BeginTx(ctx)
		assert.Nil(t, result)
		assert.Error(t, err)
		assert.Equal(t, "transaction failed", err.Error())
		mockRepo.AssertExpectations(t)
	})
}

// TestMockETCMeisaiRecordRepository_ErrorPaths tests error return paths for ETC meisai record repository (T017-T019)
func TestMockETCMeisaiRecordRepository_ErrorPaths(t *testing.T) {
	t.Parallel()

	ctx := context.Background()

	t.Run("GetByHash returns nil", func(t *testing.T) {
		// T017: Test GetByHash error path when returning nil
		mockRepo := new(repositories.MockETCMeisaiRecordRepository)
		mockRepo.On("GetByHash", ctx, "abc123").Return(nil, errors.New("hash not found"))

		result, err := mockRepo.GetByHash(ctx, "abc123")
		assert.Nil(t, result)
		assert.Error(t, err)
		assert.Equal(t, "hash not found", err.Error())
		mockRepo.AssertExpectations(t)
	})

	t.Run("List returns nil", func(t *testing.T) {
		// T018: Test List error path when returning nil
		mockRepo := new(repositories.MockETCMeisaiRecordRepository)
		params := repositories.ListRecordsParams{
			Page:     1,
			PageSize: 20,
		}
		mockRepo.On("List", ctx, params).Return(nil, int64(0), errors.New("database unavailable"))

		result, count, err := mockRepo.List(ctx, params)
		assert.Nil(t, result)
		assert.Equal(t, int64(0), count)
		assert.Error(t, err)
		assert.Equal(t, "database unavailable", err.Error())
		mockRepo.AssertExpectations(t)
	})

	t.Run("BeginTx returns nil", func(t *testing.T) {
		// T019: Test BeginTx error path when returning nil
		mockRepo := new(repositories.MockETCMeisaiRecordRepository)
		mockRepo.On("BeginTx", ctx).Return(nil, errors.New("cannot start transaction"))

		result, err := mockRepo.BeginTx(ctx)
		assert.Nil(t, result)
		assert.Error(t, err)
		assert.Equal(t, "cannot start transaction", err.Error())
		mockRepo.AssertExpectations(t)
	})
}

// TestMockRepository_ComplexScenarios tests complex error scenarios for mock repositories
func TestMockRepository_ComplexScenarios(t *testing.T) {
	t.Parallel()

	ctx := context.Background()

	t.Run("Multiple method calls with mixed results", func(t *testing.T) {
		mockRepo := new(repositories.MockETCMappingRepository)

		// Setup expectations for multiple calls
		mockRepo.On("GetByID", ctx, int64(1)).Return(&models.ETCMapping{ID: 1}, nil).Once()
		mockRepo.On("GetByID", ctx, int64(2)).Return(nil, errors.New("not found")).Once()
		mockRepo.On("GetByID", ctx, int64(3)).Return(&models.ETCMapping{ID: 3}, nil).Once()

		// First call succeeds
		result1, err1 := mockRepo.GetByID(ctx, 1)
		assert.NotNil(t, result1)
		assert.NoError(t, err1)
		assert.Equal(t, int64(1), result1.ID)

		// Second call fails
		result2, err2 := mockRepo.GetByID(ctx, 2)
		assert.Nil(t, result2)
		assert.Error(t, err2)

		// Third call succeeds
		result3, err3 := mockRepo.GetByID(ctx, 3)
		assert.NotNil(t, result3)
		assert.NoError(t, err3)
		assert.Equal(t, int64(3), result3.ID)

		mockRepo.AssertExpectations(t)
	})

	t.Run("Transaction rollback scenario", func(t *testing.T) {
		mockRepo := new(repositories.MockETCMappingRepository)
		txMock := new(repositories.MockETCMappingRepository)

		// Setup transaction expectations
		mockRepo.On("BeginTx", ctx).Return(txMock, nil)
		txMock.On("Create", ctx, mock.Anything).Return(errors.New("constraint violation"))
		txMock.On("RollbackTx").Return(nil)

		// Begin transaction
		tx, err := mockRepo.BeginTx(ctx)
		assert.NotNil(t, tx)
		assert.NoError(t, err)

		// Try to create, which fails
		err = tx.Create(ctx, &models.ETCMapping{})
		assert.Error(t, err)

		// Rollback due to error
		err = tx.RollbackTx()
		assert.NoError(t, err)

		mockRepo.AssertExpectations(t)
		txMock.AssertExpectations(t)
	})

	t.Run("Concurrent access simulation", func(t *testing.T) {
		mockRepo := new(repositories.MockETCMappingRepository)

		// Setup for concurrent access
		mockRepo.On("GetByID", ctx, int64(1)).Return(&models.ETCMapping{ID: 1}, nil).Maybe()

		// Simulate concurrent access
		done := make(chan bool, 3)
		for i := 0; i < 3; i++ {
			go func() {
				result, err := mockRepo.GetByID(ctx, 1)
				if err == nil {
					assert.NotNil(t, result)
					assert.Equal(t, int64(1), result.ID)
				}
				done <- true
			}()
		}

		// Wait for all goroutines
		for i := 0; i < 3; i++ {
			<-done
		}
	})

	t.Run("Pagination edge cases", func(t *testing.T) {
		mockRepo := new(repositories.MockETCMappingRepository)

		// Test empty result set
		params1 := repositories.ListMappingsParams{Page: 100, PageSize: 10}
		mockRepo.On("List", ctx, params1).Return([]*models.ETCMapping{}, int64(0), nil)

		result1, count1, err1 := mockRepo.List(ctx, params1)
		assert.Empty(t, result1)
		assert.Equal(t, int64(0), count1)
		assert.NoError(t, err1)

		// Test invalid page handling
		params2 := repositories.ListMappingsParams{Page: -1, PageSize: 10}
		mockRepo.On("List", ctx, params2).Return(nil, int64(0), errors.New("invalid page"))

		result2, count2, err2 := mockRepo.List(ctx, params2)
		assert.Nil(t, result2)
		assert.Equal(t, int64(0), count2)
		assert.Error(t, err2)

		mockRepo.AssertExpectations(t)
	})
}

// TestMockRepository_MethodCoverage ensures all mock methods are exercised
func TestMockRepository_MethodCoverage(t *testing.T) {
	t.Parallel()

	ctx := context.Background()

	t.Run("ETCMappingRepository full coverage", func(t *testing.T) {
		mockRepo := new(repositories.MockETCMappingRepository)

		// Test all methods with both success and error cases
		mapping := &models.ETCMapping{ID: 1}

		// Create
		mockRepo.On("Create", ctx, mapping).Return(nil).Once()
		err := mockRepo.Create(ctx, mapping)
		assert.NoError(t, err)

		// GetByID - success case
		mockRepo.On("GetByID", ctx, int64(1)).Return(mapping, nil).Once()
		result, err := mockRepo.GetByID(ctx, 1)
		assert.NotNil(t, result)
		assert.NoError(t, err)

		// Update
		mockRepo.On("Update", ctx, mapping).Return(nil).Once()
		err = mockRepo.Update(ctx, mapping)
		assert.NoError(t, err)

		// Delete
		mockRepo.On("Delete", ctx, int64(1)).Return(nil).Once()
		err = mockRepo.Delete(ctx, 1)
		assert.NoError(t, err)

		// GetByETCRecordID - success case
		mockRepo.On("GetByETCRecordID", ctx, int64(123)).Return([]*models.ETCMapping{mapping}, nil).Once()
		results, err := mockRepo.GetByETCRecordID(ctx, 123)
		assert.NotNil(t, results)
		assert.NoError(t, err)

		// GetByMappedEntity - success case
		mockRepo.On("GetByMappedEntity", ctx, "type", int64(456)).Return([]*models.ETCMapping{mapping}, nil).Once()
		results, err = mockRepo.GetByMappedEntity(ctx, "type", 456)
		assert.NotNil(t, results)
		assert.NoError(t, err)

		// GetActiveMapping - success case
		mockRepo.On("GetActiveMapping", ctx, int64(789)).Return(mapping, nil).Once()
		result, err = mockRepo.GetActiveMapping(ctx, 789)
		assert.NotNil(t, result)
		assert.NoError(t, err)

		// List - success case
		params := repositories.ListMappingsParams{Page: 1, PageSize: 10}
		mockRepo.On("List", ctx, params).Return([]*models.ETCMapping{mapping}, int64(1), nil).Once()
		results, count, err := mockRepo.List(ctx, params)
		assert.NotNil(t, results)
		assert.Equal(t, int64(1), count)
		assert.NoError(t, err)

		// BulkCreate
		mockRepo.On("BulkCreate", ctx, []*models.ETCMapping{mapping}).Return(nil).Once()
		err = mockRepo.BulkCreate(ctx, []*models.ETCMapping{mapping})
		assert.NoError(t, err)

		// UpdateStatus
		mockRepo.On("UpdateStatus", ctx, int64(1), "active").Return(nil).Once()
		err = mockRepo.UpdateStatus(ctx, 1, "active")
		assert.NoError(t, err)

		// BeginTx - success case
		txMock := new(repositories.MockETCMappingRepository)
		mockRepo.On("BeginTx", ctx).Return(txMock, nil).Once()
		tx, err := mockRepo.BeginTx(ctx)
		assert.NotNil(t, tx)
		assert.NoError(t, err)

		// CommitTx
		mockRepo.On("CommitTx").Return(nil).Once()
		err = mockRepo.CommitTx()
		assert.NoError(t, err)

		// RollbackTx
		mockRepo.On("RollbackTx").Return(nil).Once()
		err = mockRepo.RollbackTx()
		assert.NoError(t, err)

		// Ping
		mockRepo.On("Ping", ctx).Return(nil).Once()
		err = mockRepo.Ping(ctx)
		assert.NoError(t, err)

		mockRepo.AssertExpectations(t)
	})

	t.Run("ETCMeisaiRecordRepository full coverage", func(t *testing.T) {
		mockRepo := new(repositories.MockETCMeisaiRecordRepository)

		record := &models.ETCMeisaiRecord{ID: 1}

		// Create
		mockRepo.On("Create", ctx, record).Return(nil).Once()
		err := mockRepo.Create(ctx, record)
		assert.NoError(t, err)

		// GetByID
		mockRepo.On("GetByID", ctx, int64(1)).Return(record, nil).Once()
		result, err := mockRepo.GetByID(ctx, 1)
		assert.NotNil(t, result)
		assert.NoError(t, err)

		// Update
		mockRepo.On("Update", ctx, record).Return(nil).Once()
		err = mockRepo.Update(ctx, record)
		assert.NoError(t, err)

		// Delete
		mockRepo.On("Delete", ctx, int64(1)).Return(nil).Once()
		err = mockRepo.Delete(ctx, 1)
		assert.NoError(t, err)

		// GetByHash - success case
		mockRepo.On("GetByHash", ctx, "hash123").Return(record, nil).Once()
		result, err = mockRepo.GetByHash(ctx, "hash123")
		assert.NotNil(t, result)
		assert.NoError(t, err)

		// CheckDuplicateHash - without excludeID
		mockRepo.On("CheckDuplicateHash", ctx, "hash456").Return(false, nil).Once()
		exists, err := mockRepo.CheckDuplicateHash(ctx, "hash456")
		assert.False(t, exists)
		assert.NoError(t, err)

		// CheckDuplicateHash - with excludeID
		mockRepo.On("CheckDuplicateHash", ctx, "hash789", []int64{1}).Return(true, nil).Once()
		exists, err = mockRepo.CheckDuplicateHash(ctx, "hash789", 1)
		assert.True(t, exists)
		assert.NoError(t, err)

		// List - success case
		params := repositories.ListRecordsParams{Page: 1, PageSize: 20}
		mockRepo.On("List", ctx, params).Return([]*models.ETCMeisaiRecord{record}, int64(1), nil).Once()
		results, count, err := mockRepo.List(ctx, params)
		assert.NotNil(t, results)
		assert.Equal(t, int64(1), count)
		assert.NoError(t, err)

		// BeginTx - success case
		txMock := new(repositories.MockETCMeisaiRecordRepository)
		mockRepo.On("BeginTx", ctx).Return(txMock, nil).Once()
		tx, err := mockRepo.BeginTx(ctx)
		assert.NotNil(t, tx)
		assert.NoError(t, err)

		// CommitTx
		mockRepo.On("CommitTx").Return(nil).Once()
		err = mockRepo.CommitTx()
		assert.NoError(t, err)

		// RollbackTx
		mockRepo.On("RollbackTx").Return(nil).Once()
		err = mockRepo.RollbackTx()
		assert.NoError(t, err)

		// Ping
		mockRepo.On("Ping", ctx).Return(nil).Once()
		err = mockRepo.Ping(ctx)
		assert.NoError(t, err)

		mockRepo.AssertExpectations(t)
	})
}