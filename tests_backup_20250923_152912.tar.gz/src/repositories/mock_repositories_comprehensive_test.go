package repositories_test

import (
	"context"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/yhonda-ohishi/etc_meisai/src/models"
	"github.com/yhonda-ohishi/etc_meisai/src/repositories"
)

// Test coverage for mock_etc_meisai_record_repository.go
func TestMockETCMeisaiRecordRepository_AllMethods(t *testing.T) {
	t.Parallel()

	repo := &repositories.MockETCMeisaiRecordRepository{}
	ctx := context.Background()
	record := &models.ETCMeisaiRecord{ID: 1, Hash: "test_hash"}

	// Set up expectations for all methods
	repo.On("Create", ctx, record).Return(nil)
	repo.On("GetByID", ctx, int64(1)).Return(nil, nil)
	repo.On("Update", ctx, record).Return(nil)
	repo.On("Delete", ctx, int64(1)).Return(nil)
	repo.On("GetByHash", ctx, "test_hash").Return(nil, nil)
	repo.On("CheckDuplicateHash", ctx, "test_hash").Return(false, nil)
	repo.On("List", ctx, repositories.ListRecordsParams{}).Return(nil, int64(0), nil)
	repo.On("BeginTx", ctx).Return(nil, nil)
	repo.On("CommitTx").Return(nil)
	repo.On("RollbackTx").Return(nil)
	repo.On("Ping", ctx).Return(nil)

	// Test all methods
	err := repo.Create(ctx, record)
	assert.NoError(t, err)

	retrievedRecord, err := repo.GetByID(ctx, 1)
	assert.Nil(t, retrievedRecord)
	assert.NoError(t, err)

	err = repo.Update(ctx, record)
	assert.NoError(t, err)

	err = repo.Delete(ctx, 1)
	assert.NoError(t, err)

	hashRecord, err := repo.GetByHash(ctx, "test_hash")
	assert.Nil(t, hashRecord)
	assert.NoError(t, err)

	isDuplicate, err := repo.CheckDuplicateHash(ctx, "test_hash")
	assert.False(t, isDuplicate)
	assert.NoError(t, err)

	records, total, err := repo.List(ctx, repositories.ListRecordsParams{})
	assert.Nil(t, records)
	assert.Equal(t, int64(0), total)
	assert.NoError(t, err)

	txRepo, err := repo.BeginTx(ctx)
	assert.Nil(t, txRepo)
	assert.NoError(t, err)

	err = repo.CommitTx()
	assert.NoError(t, err)

	err = repo.RollbackTx()
	assert.NoError(t, err)

	err = repo.Ping(ctx)
	assert.NoError(t, err)

	repo.AssertExpectations(t)
}

// Test coverage for mock_etc_mapping_repository.go
func TestMockETCMappingRepository_AllMethods(t *testing.T) {
	t.Parallel()

	repo := &repositories.MockETCMappingRepository{}
	ctx := context.Background()
	mapping := &models.ETCMapping{ID: 1, ETCRecordID: 100}

	// Set up expectations for all methods
	repo.On("Create", ctx, mapping).Return(nil)
	repo.On("GetByID", ctx, int64(1)).Return(nil, nil)
	repo.On("Update", ctx, mapping).Return(nil)
	repo.On("Delete", ctx, int64(1)).Return(nil)
	repo.On("GetByETCRecordID", ctx, int64(100)).Return(nil, nil)
	repo.On("GetByMappedEntity", ctx, "dtako", int64(200)).Return(nil, nil)
	repo.On("GetActiveMapping", ctx, int64(100)).Return(nil, nil)
	repo.On("List", ctx, repositories.ListMappingsParams{}).Return(nil, int64(0), nil)
	repo.On("BulkCreate", ctx, []*models.ETCMapping{mapping}).Return(nil)
	repo.On("UpdateStatus", ctx, int64(1), "inactive").Return(nil)
	repo.On("BeginTx", ctx).Return(nil, nil)
	repo.On("CommitTx").Return(nil)
	repo.On("RollbackTx").Return(nil)
	repo.On("Ping", ctx).Return(nil)

	// Test all methods
	err := repo.Create(ctx, mapping)
	assert.NoError(t, err)

	retrievedMapping, err := repo.GetByID(ctx, 1)
	assert.Nil(t, retrievedMapping)
	assert.NoError(t, err)

	err = repo.Update(ctx, mapping)
	assert.NoError(t, err)

	err = repo.Delete(ctx, 1)
	assert.NoError(t, err)

	mappings, err := repo.GetByETCRecordID(ctx, 100)
	assert.Nil(t, mappings)
	assert.NoError(t, err)

	entityMappings, err := repo.GetByMappedEntity(ctx, "dtako", 200)
	assert.Nil(t, entityMappings)
	assert.NoError(t, err)

	activeMapping, err := repo.GetActiveMapping(ctx, 100)
	assert.Nil(t, activeMapping)
	assert.NoError(t, err)

	allMappings, total, err := repo.List(ctx, repositories.ListMappingsParams{})
	assert.Nil(t, allMappings)
	assert.Equal(t, int64(0), total)
	assert.NoError(t, err)

	err = repo.BulkCreate(ctx, []*models.ETCMapping{mapping})
	assert.NoError(t, err)

	err = repo.UpdateStatus(ctx, 1, "inactive")
	assert.NoError(t, err)

	txRepo, err := repo.BeginTx(ctx)
	assert.Nil(t, txRepo)
	assert.NoError(t, err)

	err = repo.CommitTx()
	assert.NoError(t, err)

	err = repo.RollbackTx()
	assert.NoError(t, err)

	err = repo.Ping(ctx)
	assert.NoError(t, err)

	repo.AssertExpectations(t)
}

// Test edge cases and error scenarios
func TestMockRepositories_EdgeCases(t *testing.T) {
	t.Parallel()

	t.Run("CheckDuplicateHash with excludeID", func(t *testing.T) {
		repo := &repositories.MockETCMeisaiRecordRepository{}
		ctx := context.Background()

		// Set expectation with excludeID parameter
		repo.On("CheckDuplicateHash", ctx, "hash", []int64{1, 2}).Return(true, nil)

		isDuplicate, err := repo.CheckDuplicateHash(ctx, "hash", 1, 2)
		assert.True(t, isDuplicate)
		assert.NoError(t, err)
		repo.AssertExpectations(t)
	})

	t.Run("Mock returns with actual data", func(t *testing.T) {
		repo := &repositories.MockETCMeisaiRecordRepository{}
		ctx := context.Background()

		testRecord := &models.ETCMeisaiRecord{ID: 1, Hash: "test"}
		repo.On("GetByID", ctx, int64(1)).Return(testRecord, nil)

		record, err := repo.GetByID(ctx, 1)
		assert.Equal(t, testRecord, record)
		assert.NoError(t, err)
		repo.AssertExpectations(t)
	})
}

// Benchmark tests for mock repositories
func BenchmarkMockETCMeisaiRecordRepository_Create(b *testing.B) {
	repo := &repositories.MockETCMeisaiRecordRepository{}
	ctx := context.Background()
	record := &models.ETCMeisaiRecord{ID: 1}

	repo.On("Create", ctx, record).Return(nil)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_ = repo.Create(ctx, record)
	}
}

func BenchmarkMockETCMappingRepository_Create(b *testing.B) {
	repo := &repositories.MockETCMappingRepository{}
	ctx := context.Background()
	mapping := &models.ETCMapping{ID: 1}

	repo.On("Create", ctx, mapping).Return(nil)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_ = repo.Create(ctx, mapping)
	}
}