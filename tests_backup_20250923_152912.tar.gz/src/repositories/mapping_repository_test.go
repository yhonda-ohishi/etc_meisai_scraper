package repositories_test

import (
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/yhonda-ohishi/etc_meisai/src/models"
	"github.com/yhonda-ohishi/etc_meisai/src/repositories"
)

// MockMappingClient is a mock implementation for testing
type MockMappingClient struct {
	CreateFunc               func(mapping *models.ETCMeisaiMapping) error
	GetByIDFunc              func(id int64) (*models.ETCMeisaiMapping, error)
	UpdateFunc               func(mapping *models.ETCMeisaiMapping) error
	DeleteFunc               func(id int64) error
	GetByETCMeisaiIDFunc     func(etcMeisaiID int64) ([]*models.ETCMeisaiMapping, error)
	GetByDTakoRowIDFunc      func(dtakoRowID string) (*models.ETCMeisaiMapping, error)
	ListFunc                 func(params *models.MappingListParams) ([]*models.ETCMeisaiMapping, int64, error)
	BulkCreateMappingsFunc   func(mappings []*models.ETCMeisaiMapping) error
	DeleteByETCMeisaiIDFunc  func(etcMeisaiID int64) error
	FindPotentialMatchesFunc func(etcMeisaiID int64, threshold float32) ([]*models.PotentialMatch, error)
	UpdateConfidenceScoreFunc func(id int64, confidence float32) error
}

func TestNewMappingGRPCRepository(t *testing.T) {
	t.Parallel()

	client := &MockMappingClient{}
	repo := repositories.NewMappingGRPCRepository(client)

	assert.NotNil(t, repo)
}

func TestMappingGRPCRepository_Create(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		mapping *models.ETCMeisaiMapping
		wantErr bool
		errMsg  string
	}{
		{
			name: "create new mapping",
			mapping: &models.ETCMeisaiMapping{
				ETCMeisaiID: 123,
				DTakoRowID:  "DTAKO-001",
				MappingType: "auto",
				Confidence:  0.95,
				Notes:     "Automatic matching",
				CreatedBy: "system",
			},
			wantErr: true,
			errMsg:  "CreateMapping not available",
		},
		{
			name: "create manual mapping",
			mapping: &models.ETCMeisaiMapping{
				ETCMeisaiID: 456,
				DTakoRowID:  "DTAKO-002",
				MappingType: "manual",
				Confidence:  1.0,
				Notes:     "Manual confirmation",
				CreatedBy: "user@example.com",
			},
			wantErr: true,
			errMsg:  "CreateMapping not available",
		},
		{
			name:    "create with nil mapping",
			mapping: nil,
			wantErr: true,
			errMsg:  "CreateMapping not available",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			client := &MockMappingClient{}
			repo := repositories.NewMappingGRPCRepository(client)

			err := repo.Create(tt.mapping)

			if tt.wantErr {
				assert.Error(t, err)
				if tt.errMsg != "" {
					assert.Contains(t, err.Error(), tt.errMsg)
				}
			} else {
				assert.NoError(t, err)
			}
		})
	}
}

func TestMappingGRPCRepository_GetByID(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		id      int64
		want    *models.ETCMeisaiMapping
		wantErr bool
		errMsg  string
	}{
		{
			name:    "get existing mapping",
			id:      1,
			wantErr: true,
			errMsg:  "GetMapping not available",
		},
		{
			name:    "get non-existing mapping",
			id:      999,
			wantErr: true,
			errMsg:  "GetMapping not available",
		},
		{
			name:    "get with zero ID",
			id:      0,
			wantErr: true,
			errMsg:  "GetMapping not available",
		},
		{
			name:    "get with negative ID",
			id:      -1,
			wantErr: true,
			errMsg:  "GetMapping not available",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			client := &MockMappingClient{}
			repo := repositories.NewMappingGRPCRepository(client)

			result, err := repo.GetByID(tt.id)

			if tt.wantErr {
				assert.Error(t, err)
				if tt.errMsg != "" {
					assert.Contains(t, err.Error(), tt.errMsg)
				}
			} else {
				assert.NoError(t, err)
				assert.Equal(t, tt.want, result)
			}
		})
	}
}

func TestMappingGRPCRepository_Update(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		mapping *models.ETCMeisaiMapping
		wantErr bool
		errMsg  string
	}{
		{
			name: "update existing mapping",
			mapping: &models.ETCMeisaiMapping{
				ID:          1,
				ETCMeisaiID: 123,
				DTakoRowID:  "DTAKO-001",
				MappingType: "manual",
				Confidence:  1.0,
				Notes:       "Updated by user",
			},
			wantErr: true,
			errMsg:  "UpdateMapping not available",
		},
		{
			name: "update confidence score",
			mapping: &models.ETCMeisaiMapping{
				ID:         2,
				Confidence: 0.85,
			},
			wantErr: true,
			errMsg:  "UpdateMapping not available",
		},
		{
			name:    "update with nil mapping",
			mapping: nil,
			wantErr: true,
			errMsg:  "UpdateMapping not available",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			client := &MockMappingClient{}
			repo := repositories.NewMappingGRPCRepository(client)

			err := repo.Update(tt.mapping)

			if tt.wantErr {
				assert.Error(t, err)
				if tt.errMsg != "" {
					assert.Contains(t, err.Error(), tt.errMsg)
				}
			} else {
				assert.NoError(t, err)
			}
		})
	}
}

func TestMappingGRPCRepository_Delete(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		id      int64
		wantErr bool
		errMsg  string
	}{
		{
			name:    "delete existing mapping",
			id:      1,
			wantErr: true,
			errMsg:  "DeleteMapping not available",
		},
		{
			name:    "delete non-existing mapping",
			id:      999,
			wantErr: true,
			errMsg:  "DeleteMapping not available",
		},
		{
			name:    "delete with zero ID",
			id:      0,
			wantErr: true,
			errMsg:  "DeleteMapping not available",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			client := &MockMappingClient{}
			repo := repositories.NewMappingGRPCRepository(client)

			err := repo.Delete(tt.id)

			if tt.wantErr {
				assert.Error(t, err)
				if tt.errMsg != "" {
					assert.Contains(t, err.Error(), tt.errMsg)
				}
			} else {
				assert.NoError(t, err)
			}
		})
	}
}

func TestMappingGRPCRepository_GetByETCMeisaiID(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name        string
		etcMeisaiID int64
		want        []*models.ETCMeisaiMapping
		wantErr     bool
		errMsg      string
	}{
		{
			name:        "get mappings for ETC Meisai",
			etcMeisaiID: 123,
			wantErr:     true,
			errMsg:      "ListMappings not available",
		},
		{
			name:        "get mappings for non-existing ETC Meisai",
			etcMeisaiID: 999,
			wantErr:     true,
			errMsg:      "ListMappings not available",
		},
		{
			name:        "get with zero ETC Meisai ID",
			etcMeisaiID: 0,
			wantErr:     true,
			errMsg:      "ListMappings not available",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			client := &MockMappingClient{}
			repo := repositories.NewMappingGRPCRepository(client)

			result, err := repo.GetByETCMeisaiID(tt.etcMeisaiID)

			if tt.wantErr {
				assert.Error(t, err)
				if tt.errMsg != "" {
					assert.Contains(t, err.Error(), tt.errMsg)
				}
			} else {
				assert.NoError(t, err)
				assert.Equal(t, tt.want, result)
			}
		})
	}
}

func TestMappingGRPCRepository_GetByDTakoRowID(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name       string
		dtakoRowID string
		want       *models.ETCMeisaiMapping
		wantErr    bool
		errMsg     string
	}{
		{
			name:       "get mapping for DTako row",
			dtakoRowID: "DTAKO-001",
			wantErr:    true,
			errMsg:     "GetByDTakoRowID not available",
		},
		{
			name:       "get mapping for non-existing DTako row",
			dtakoRowID: "DTAKO-999",
			wantErr:    true,
			errMsg:     "GetByDTakoRowID not available",
		},
		{
			name:       "get with empty DTako row ID",
			dtakoRowID: "",
			wantErr:    true,
			errMsg:     "GetByDTakoRowID not available",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			client := &MockMappingClient{}
			repo := repositories.NewMappingGRPCRepository(client)

			result, err := repo.GetByDTakoRowID(tt.dtakoRowID)

			if tt.wantErr {
				assert.Error(t, err)
				if tt.errMsg != "" {
					assert.Contains(t, err.Error(), tt.errMsg)
				}
			} else {
				assert.NoError(t, err)
				assert.Equal(t, tt.want, result)
			}
		})
	}
}

func TestMappingGRPCRepository_List(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name    string
		params  *models.MappingListParams
		wantErr bool
		errMsg  string
	}{
		{
			name: "list with pagination",
			params: &models.MappingListParams{
				Limit:  10,
				Offset: 0,
			},
			wantErr: true,
			errMsg:  "List mappings not available",
		},
		{
			name: "list with ETC Meisai filter",
			params: &models.MappingListParams{
				Limit:       10,
				Offset:      0,
				ETCMeisaiID: int64Ptr(123),
			},
			wantErr: true,
			errMsg:  "List mappings not available",
		},
		{
			name: "list with DTako row filter",
			params: &models.MappingListParams{
				Limit:      10,
				Offset:     0,
				DTakoRowID: "DTAKO-001",
			},
			wantErr: true,
			errMsg:  "List mappings not available",
		},
		{
			name: "list with mapping type filter",
			params: &models.MappingListParams{
				Limit:       10,
				Offset:      0,
				MappingType: "auto",
			},
			wantErr: true,
			errMsg:  "List mappings not available",
		},
		{
			name: "list with confidence threshold",
			params: &models.MappingListParams{
				Limit:         10,
				Offset:        0,
				MinConfidence: float32Ptr(0.8),
			},
			wantErr: true,
			errMsg:  "List mappings not available",
		},
		{
			name: "list with all filters",
			params: &models.MappingListParams{
				Limit:         10,
				Offset:        20,
				ETCMeisaiID:   int64Ptr(123),
				DTakoRowID:    "DTAKO-001",
				MappingType:   "auto",
				MinConfidence: float32Ptr(0.9),
			},
			wantErr: true,
			errMsg:  "List mappings not available",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			client := &MockMappingClient{}
			repo := repositories.NewMappingGRPCRepository(client)

			records, count, err := repo.List(tt.params)

			if tt.wantErr {
				assert.Error(t, err)
				if tt.errMsg != "" {
					assert.Contains(t, err.Error(), tt.errMsg)
				}
			} else {
				assert.NoError(t, err)
				assert.NotNil(t, records)
				assert.GreaterOrEqual(t, count, int64(0))
			}
		})
	}
}

func TestMappingGRPCRepository_BulkCreateMappings(t *testing.T) {
	t.Parallel()

	mappings := []*models.ETCMeisaiMapping{
		{
			ETCMeisaiID: 123,
			DTakoRowID:  "DTAKO-001",
			MappingType: "auto",
			Confidence:  0.95,
			Notes:     "Auto-matched",
			CreatedBy: "system",
		},
		{
			ETCMeisaiID: 124,
			DTakoRowID:  "DTAKO-002",
			MappingType: "fuzzy",
			Confidence:  0.75,
			Notes:     "Fuzzy match",
			CreatedBy: "system",
		},
		{
			ETCMeisaiID: 125,
			DTakoRowID:  "DTAKO-003",
			MappingType: "manual",
			Confidence:  1.0,
			Notes:     "Manual override",
			CreatedBy: "user@example.com",
		},
	}

	tests := []struct {
		name     string
		mappings []*models.ETCMeisaiMapping
		wantErr  bool
		errMsg   string
	}{
		{
			name:     "bulk create multiple mappings",
			mappings: mappings,
			wantErr:  true,
			errMsg:   "BulkCreateMappings not available",
		},
		{
			name:     "bulk create single mapping",
			mappings: mappings[:1],
			wantErr:  true,
			errMsg:   "BulkCreateMappings not available",
		},
		{
			name:     "bulk create empty slice",
			mappings: []*models.ETCMeisaiMapping{},
			wantErr:  true,
			errMsg:   "BulkCreateMappings not available",
		},
		{
			name:     "bulk create nil",
			mappings: nil,
			wantErr:  true,
			errMsg:   "BulkCreateMappings not available",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			client := &MockMappingClient{}
			repo := repositories.NewMappingGRPCRepository(client)

			err := repo.BulkCreateMappings(tt.mappings)

			if tt.wantErr {
				assert.Error(t, err)
				if tt.errMsg != "" {
					assert.Contains(t, err.Error(), tt.errMsg)
				}
			} else {
				assert.NoError(t, err)
			}
		})
	}
}

func TestMappingGRPCRepository_DeleteByETCMeisaiID(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name        string
		etcMeisaiID int64
		wantErr     bool
		errMsg      string
	}{
		{
			name:        "delete mappings for ETC Meisai",
			etcMeisaiID: 123,
			wantErr:     true,
			errMsg:      "DeleteMappingsByETCMeisai not available",
		},
		{
			name:        "delete mappings for non-existing ETC Meisai",
			etcMeisaiID: 999,
			wantErr:     true,
			errMsg:      "DeleteMappingsByETCMeisai not available",
		},
		{
			name:        "delete with zero ETC Meisai ID",
			etcMeisaiID: 0,
			wantErr:     true,
			errMsg:      "DeleteMappingsByETCMeisai not available",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			client := &MockMappingClient{}
			repo := repositories.NewMappingGRPCRepository(client)

			err := repo.DeleteByETCMeisaiID(tt.etcMeisaiID)

			if tt.wantErr {
				assert.Error(t, err)
				if tt.errMsg != "" {
					assert.Contains(t, err.Error(), tt.errMsg)
				}
			} else {
				assert.NoError(t, err)
			}
		})
	}
}

func TestMappingGRPCRepository_FindPotentialMatches(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name        string
		etcMeisaiID int64
		threshold   float32
		want        []*models.PotentialMatch
		wantErr     bool
		errMsg      string
	}{
		{
			name:        "find high confidence matches",
			etcMeisaiID: 123,
			threshold:   0.9,
			wantErr:     true,
			errMsg:      "FindPotentialMatches not available",
		},
		{
			name:        "find medium confidence matches",
			etcMeisaiID: 123,
			threshold:   0.7,
			wantErr:     true,
			errMsg:      "FindPotentialMatches not available",
		},
		{
			name:        "find all matches",
			etcMeisaiID: 123,
			threshold:   0.0,
			wantErr:     true,
			errMsg:      "FindPotentialMatches not available",
		},
		{
			name:        "find with invalid threshold",
			etcMeisaiID: 123,
			threshold:   -0.5,
			wantErr:     true,
			errMsg:      "FindPotentialMatches not available",
		},
		{
			name:        "find with threshold > 1",
			etcMeisaiID: 123,
			threshold:   1.5,
			wantErr:     true,
			errMsg:      "FindPotentialMatches not available",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			client := &MockMappingClient{}
			repo := repositories.NewMappingGRPCRepository(client)

			result, err := repo.FindPotentialMatches(tt.etcMeisaiID, tt.threshold)

			if tt.wantErr {
				assert.Error(t, err)
				if tt.errMsg != "" {
					assert.Contains(t, err.Error(), tt.errMsg)
				}
			} else {
				assert.NoError(t, err)
				assert.Equal(t, tt.want, result)
			}
		})
	}
}

func TestMappingGRPCRepository_UpdateConfidenceScore(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name       string
		id         int64
		confidence float32
		wantErr    bool
		errMsg     string
	}{
		{
			name:       "update to high confidence",
			id:         1,
			confidence: 0.95,
			wantErr:    true,
			errMsg:     "UpdateMappingConfidence not available",
		},
		{
			name:       "update to medium confidence",
			id:         2,
			confidence: 0.75,
			wantErr:    true,
			errMsg:     "UpdateMappingConfidence not available",
		},
		{
			name:       "update to low confidence",
			id:         3,
			confidence: 0.25,
			wantErr:    true,
			errMsg:     "UpdateMappingConfidence not available",
		},
		{
			name:       "update to zero confidence",
			id:         4,
			confidence: 0.0,
			wantErr:    true,
			errMsg:     "UpdateMappingConfidence not available",
		},
		{
			name:       "update to max confidence",
			id:         5,
			confidence: 1.0,
			wantErr:    true,
			errMsg:     "UpdateMappingConfidence not available",
		},
		{
			name:       "update with invalid confidence",
			id:         6,
			confidence: -0.5,
			wantErr:    true,
			errMsg:     "UpdateMappingConfidence not available",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			client := &MockMappingClient{}
			repo := repositories.NewMappingGRPCRepository(client)

			err := repo.UpdateConfidenceScore(tt.id, tt.confidence)

			if tt.wantErr {
				assert.Error(t, err)
				if tt.errMsg != "" {
					assert.Contains(t, err.Error(), tt.errMsg)
				}
			} else {
				assert.NoError(t, err)
			}
		})
	}
}

func TestMappingGRPCRepository_EdgeCases(t *testing.T) {
	t.Parallel()

	t.Run("handle nil client", func(t *testing.T) {
		repo := repositories.NewMappingGRPCRepository(nil)
		assert.NotNil(t, repo)

		// All operations should return errors
		err := repo.Create(&models.ETCMeisaiMapping{})
		assert.Error(t, err)

		_, err = repo.GetByID(1)
		assert.Error(t, err)

		err = repo.Update(&models.ETCMeisaiMapping{})
		assert.Error(t, err)

		err = repo.Delete(1)
		assert.Error(t, err)
	})

	t.Run("handle very large IDs", func(t *testing.T) {
		client := &MockMappingClient{}
		repo := repositories.NewMappingGRPCRepository(client)

		// Test with maximum int64
		_, err := repo.GetByID(9223372036854775807)
		assert.Error(t, err)

		// Test with large ETC Meisai ID
		_, err = repo.GetByETCMeisaiID(9223372036854775807)
		assert.Error(t, err)

		// Test delete with large ID
		err = repo.Delete(9223372036854775807)
		assert.Error(t, err)
	})

	t.Run("handle special characters in DTako row ID", func(t *testing.T) {
		client := &MockMappingClient{}
		repo := repositories.NewMappingGRPCRepository(client)

		specialIDs := []string{
			"DTAKO-001/002",
			"DTAKO_001#002",
			"DTAKO-001@002",
			"DTAKO-001 002",
			"DTAKO-001\t002",
			"",
		}

		for _, id := range specialIDs {
			_, err := repo.GetByDTakoRowID(id)
			assert.Error(t, err)
			assert.Contains(t, err.Error(), "GetByDTakoRowID not available")
		}
	})
}

func TestMappingGRPCRepository_MappingTypes(t *testing.T) {
	t.Parallel()

	mappingTypes := []string{"auto", "manual", "partial", "fuzzy", "override", ""}

	for _, mappingType := range mappingTypes {
		t.Run("mapping type: "+mappingType, func(t *testing.T) {
			client := &MockMappingClient{}
			repo := repositories.NewMappingGRPCRepository(client)

			mapping := &models.ETCMeisaiMapping{
				ETCMeisaiID: 123,
				DTakoRowID:  "DTAKO-001",
				MappingType: mappingType,
				Confidence:  0.85,
			}

			err := repo.Create(mapping)
			assert.Error(t, err)
			assert.Contains(t, err.Error(), "CreateMapping not available")
		})
	}
}

func TestMappingGRPCRepository_Timestamps(t *testing.T) {
	t.Parallel()

	now := time.Now()
	mapping := &models.ETCMeisaiMapping{
		ID:          1,
		ETCMeisaiID: 123,
		DTakoRowID:  "DTAKO-001",
		MappingType: "auto",
		Confidence:  0.95,
		CreatedAt:   now,
		UpdatedAt:   now,
		Notes:     "Test mapping",
		CreatedBy: "test",
	}

	client := &MockMappingClient{}
	repo := repositories.NewMappingGRPCRepository(client)

	// Test create with timestamps
	err := repo.Create(mapping)
	assert.Error(t, err)
	assert.Contains(t, err.Error(), "CreateMapping not available")

	// Test update with timestamps
	mapping.UpdatedAt = now.Add(1 * time.Hour)
	err = repo.Update(mapping)
	assert.Error(t, err)
	assert.Contains(t, err.Error(), "UpdateMapping not available")
}

// Helper functions
func int64Ptr(i int64) *int64 {
	return &i
}

func float32Ptr(f float32) *float32 {
	return &f
}