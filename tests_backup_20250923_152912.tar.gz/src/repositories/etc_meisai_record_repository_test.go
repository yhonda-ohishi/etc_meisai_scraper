package repositories_test

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"sync"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"
	"github.com/yhonda-ohishi/etc_meisai/src/models"
	"github.com/yhonda-ohishi/etc_meisai/src/repositories"
)

// MockETCMeisaiRecordRepository is a mock implementation for testing
type MockETCMeisaiRecordRepository struct {
	mock.Mock
}

func (m *MockETCMeisaiRecordRepository) Create(ctx context.Context, record *models.ETCMeisaiRecord) error {
	args := m.Called(ctx, record)
	return args.Error(0)
}

func (m *MockETCMeisaiRecordRepository) GetByID(ctx context.Context, id int64) (*models.ETCMeisaiRecord, error) {
	args := m.Called(ctx, id)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*models.ETCMeisaiRecord), args.Error(1)
}

func (m *MockETCMeisaiRecordRepository) Update(ctx context.Context, record *models.ETCMeisaiRecord) error {
	args := m.Called(ctx, record)
	return args.Error(0)
}

func (m *MockETCMeisaiRecordRepository) Delete(ctx context.Context, id int64) error {
	args := m.Called(ctx, id)
	return args.Error(0)
}

func (m *MockETCMeisaiRecordRepository) GetByHash(ctx context.Context, hash string) (*models.ETCMeisaiRecord, error) {
	args := m.Called(ctx, hash)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*models.ETCMeisaiRecord), args.Error(1)
}

func (m *MockETCMeisaiRecordRepository) CheckDuplicateHash(ctx context.Context, hash string, excludeID ...int64) (bool, error) {
	args := m.Called(ctx, hash, excludeID)
	return args.Bool(0), args.Error(1)
}

func (m *MockETCMeisaiRecordRepository) List(ctx context.Context, params repositories.ListRecordsParams) ([]*models.ETCMeisaiRecord, int64, error) {
	args := m.Called(ctx, params)
	if args.Get(0) == nil {
		return nil, args.Get(1).(int64), args.Error(2)
	}
	return args.Get(0).([]*models.ETCMeisaiRecord), args.Get(1).(int64), args.Error(2)
}

func (m *MockETCMeisaiRecordRepository) BeginTx(ctx context.Context) (repositories.ETCMeisaiRecordRepository, error) {
	args := m.Called(ctx)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(repositories.ETCMeisaiRecordRepository), args.Error(1)
}

func (m *MockETCMeisaiRecordRepository) CommitTx() error {
	args := m.Called()
	return args.Error(0)
}

func (m *MockETCMeisaiRecordRepository) RollbackTx() error {
	args := m.Called()
	return args.Error(0)
}

func (m *MockETCMeisaiRecordRepository) Ping(ctx context.Context) error {
	args := m.Called(ctx)
	return args.Error(0)
}

// Test data helper
func createTestETCMeisaiRecord() *models.ETCMeisaiRecord {
	return &models.ETCMeisaiRecord{
		ID:            1,
		Hash:          "abc123",
		Date:          time.Date(2024, 1, 15, 0, 0, 0, 0, time.UTC),
		Time:          "14:30:00",
		EntranceIC:    "入口IC",
		ExitIC:        "出口IC",
		TollAmount:    500,
		CarNumber:     "品川500あ1234",
		ETCCardNumber: "1234567890123456",
		CreatedAt:     time.Now(),
		UpdatedAt:     time.Now(),
	}
}

// T006-A: Error path testing for repository operations with database connection failures
func TestETCMeisaiRecordRepository_DatabaseConnectionFailures(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name           string
		setupMock      func(*MockETCMeisaiRecordRepository)
		operation      func(repositories.ETCMeisaiRecordRepository) error
		expectedErrMsg string
	}{
		{
			name: "Create fails with connection error",
			setupMock: func(m *MockETCMeisaiRecordRepository) {
				m.On("Create", mock.Anything, mock.Anything).Return(errors.New("connection refused"))
			},
			operation: func(repo repositories.ETCMeisaiRecordRepository) error {
				return repo.Create(context.Background(), createTestETCMeisaiRecord())
			},
			expectedErrMsg: "connection refused",
		},
		{
			name: "GetByID fails with timeout",
			setupMock: func(m *MockETCMeisaiRecordRepository) {
				m.On("GetByID", mock.Anything, mock.Anything).Return(nil, errors.New("context deadline exceeded"))
			},
			operation: func(repo repositories.ETCMeisaiRecordRepository) error {
				_, err := repo.GetByID(context.Background(), 1)
				return err
			},
			expectedErrMsg: "context deadline exceeded",
		},
		{
			name: "Update fails with database lock",
			setupMock: func(m *MockETCMeisaiRecordRepository) {
				m.On("Update", mock.Anything, mock.Anything).Return(errors.New("database is locked"))
			},
			operation: func(repo repositories.ETCMeisaiRecordRepository) error {
				return repo.Update(context.Background(), createTestETCMeisaiRecord())
			},
			expectedErrMsg: "database is locked",
		},
		{
			name: "List fails with SQL error",
			setupMock: func(m *MockETCMeisaiRecordRepository) {
				m.On("List", mock.Anything, mock.Anything).Return(nil, int64(0), errors.New("SQL syntax error"))
			},
			operation: func(repo repositories.ETCMeisaiRecordRepository) error {
				_, _, err := repo.List(context.Background(), repositories.ListRecordsParams{})
				return err
			},
			expectedErrMsg: "SQL syntax error",
		},
		{
			name: "Ping fails with connection lost",
			setupMock: func(m *MockETCMeisaiRecordRepository) {
				m.On("Ping", mock.Anything).Return(errors.New("connection lost"))
			},
			operation: func(repo repositories.ETCMeisaiRecordRepository) error {
				return repo.Ping(context.Background())
			},
			expectedErrMsg: "connection lost",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			mockRepo := new(MockETCMeisaiRecordRepository)
			tt.setupMock(mockRepo)

			err := tt.operation(mockRepo)

			assert.Error(t, err)
			assert.Contains(t, err.Error(), tt.expectedErrMsg)
			mockRepo.AssertExpectations(t)
		})
	}
}

// T006-B: Transaction testing with rollback scenarios
func TestETCMeisaiRecordRepository_TransactionRollback(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name      string
		setupMock func(*MockETCMeisaiRecordRepository, *MockETCMeisaiRecordRepository)
		scenario  string
	}{
		{
			name: "BeginTx fails",
			setupMock: func(mainRepo, txRepo *MockETCMeisaiRecordRepository) {
				mainRepo.On("BeginTx", mock.Anything).Return(nil, errors.New("failed to begin transaction"))
			},
			scenario: "transaction_begin_failure",
		},
		{
			name: "Create fails, rollback succeeds",
			setupMock: func(mainRepo, txRepo *MockETCMeisaiRecordRepository) {
				mainRepo.On("BeginTx", mock.Anything).Return(txRepo, nil)
				txRepo.On("Create", mock.Anything, mock.Anything).Return(errors.New("constraint violation"))
				txRepo.On("RollbackTx").Return(nil)
			},
			scenario: "create_failure_rollback_success",
		},
		{
			name: "Create fails, rollback also fails",
			setupMock: func(mainRepo, txRepo *MockETCMeisaiRecordRepository) {
				mainRepo.On("BeginTx", mock.Anything).Return(txRepo, nil)
				txRepo.On("Create", mock.Anything, mock.Anything).Return(errors.New("constraint violation"))
				txRepo.On("RollbackTx").Return(errors.New("rollback failed"))
			},
			scenario: "create_failure_rollback_failure",
		},
		{
			name: "Multiple operations, commit fails",
			setupMock: func(mainRepo, txRepo *MockETCMeisaiRecordRepository) {
				mainRepo.On("BeginTx", mock.Anything).Return(txRepo, nil)
				txRepo.On("Create", mock.Anything, mock.Anything).Return(nil).Twice()
				txRepo.On("CommitTx").Return(errors.New("commit failed"))
				txRepo.On("RollbackTx").Return(nil)
			},
			scenario: "commit_failure_rollback_success",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			mainRepo := new(MockETCMeisaiRecordRepository)
			txRepo := new(MockETCMeisaiRecordRepository)
			tt.setupMock(mainRepo, txRepo)

			ctx := context.Background()

			switch tt.scenario {
			case "transaction_begin_failure":
				_, err := mainRepo.BeginTx(ctx)
				assert.Error(t, err)
				assert.Contains(t, err.Error(), "failed to begin transaction")

			case "create_failure_rollback_success":
				tx, err := mainRepo.BeginTx(ctx)
				require.NoError(t, err)
				require.NotNil(t, tx)

				err = tx.Create(ctx, createTestETCMeisaiRecord())
				assert.Error(t, err)

				rollbackErr := tx.RollbackTx()
				assert.NoError(t, rollbackErr)

			case "create_failure_rollback_failure":
				tx, err := mainRepo.BeginTx(ctx)
				require.NoError(t, err)
				require.NotNil(t, tx)

				err = tx.Create(ctx, createTestETCMeisaiRecord())
				assert.Error(t, err)

				rollbackErr := tx.RollbackTx()
				assert.Error(t, rollbackErr)

			case "commit_failure_rollback_success":
				tx, err := mainRepo.BeginTx(ctx)
				require.NoError(t, err)
				require.NotNil(t, tx)

				// Multiple successful operations
				err = tx.Create(ctx, createTestETCMeisaiRecord())
				assert.NoError(t, err)

				record2 := createTestETCMeisaiRecord()
				record2.ID = 2
				record2.Hash = "def456"
				err = tx.Create(ctx, record2)
				assert.NoError(t, err)

				// Commit fails
				commitErr := tx.CommitTx()
				assert.Error(t, commitErr)

				// Rollback succeeds
				rollbackErr := tx.RollbackTx()
				assert.NoError(t, rollbackErr)
			}

			mainRepo.AssertExpectations(t)
			txRepo.AssertExpectations(t)
		})
	}
}

// T006-C: Concurrent access testing with race conditions
func TestETCMeisaiRecordRepository_ConcurrentAccess(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name        string
		concurrency int
		operation   string
	}{
		{
			name:        "Concurrent Create operations",
			concurrency: 10,
			operation:   "create",
		},
		{
			name:        "Concurrent Read operations",
			concurrency: 20,
			operation:   "read",
		},
		{
			name:        "Mixed Create and Read operations",
			concurrency: 15,
			operation:   "mixed",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			mockRepo := new(MockETCMeisaiRecordRepository)

			// Setup mock expectations for concurrent operations
			switch tt.operation {
			case "create":
				mockRepo.On("Create", mock.Anything, mock.Anything).Return(nil)
			case "read":
				testRecord := createTestETCMeisaiRecord()
				mockRepo.On("GetByID", mock.Anything, mock.Anything).Return(testRecord, nil)
			case "mixed":
				testRecord := createTestETCMeisaiRecord()
				mockRepo.On("Create", mock.Anything, mock.Anything).Return(nil).Maybe()
				mockRepo.On("GetByID", mock.Anything, mock.Anything).Return(testRecord, nil).Maybe()
			}

			var wg sync.WaitGroup
			errChan := make(chan error, tt.concurrency)
			ctx := context.Background()

			// Launch concurrent operations
			for i := 0; i < tt.concurrency; i++ {
				wg.Add(1)
				go func(id int) {
					defer wg.Done()

					switch tt.operation {
					case "create":
						record := createTestETCMeisaiRecord()
						record.ID = int64(id + 1)
						record.Hash = fmt.Sprintf("hash_%d", id)
						err := mockRepo.Create(ctx, record)
						if err != nil {
							errChan <- err
						}
					case "read":
						_, err := mockRepo.GetByID(ctx, int64(id+1))
						if err != nil {
							errChan <- err
						}
					case "mixed":
						if id%2 == 0 {
							record := createTestETCMeisaiRecord()
							record.ID = int64(id + 1)
							record.Hash = fmt.Sprintf("hash_%d", id)
							err := mockRepo.Create(ctx, record)
							if err != nil {
								errChan <- err
							}
						} else {
							_, err := mockRepo.GetByID(ctx, int64(id+1))
							if err != nil {
								errChan <- err
							}
						}
					}
				}(i)
			}

			// Wait for all operations to complete
			wg.Wait()
			close(errChan)

			// Check for errors
			var errors []error
			for err := range errChan {
				errors = append(errors, err)
			}

			assert.Empty(t, errors, "No errors should occur during concurrent operations")
			mockRepo.AssertExpectations(t)
		})
	}
}

// T006-D: Database constraint violation testing
func TestETCMeisaiRecordRepository_ConstraintViolations(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name           string
		setupMock      func(*MockETCMeisaiRecordRepository)
		operation      func(repositories.ETCMeisaiRecordRepository) error
		constraintType string
	}{
		{
			name: "Unique constraint violation on hash",
			setupMock: func(m *MockETCMeisaiRecordRepository) {
				m.On("Create", mock.Anything, mock.Anything).Return(errors.New("UNIQUE constraint failed: etc_meisai_records.hash"))
			},
			operation: func(repo repositories.ETCMeisaiRecordRepository) error {
				return repo.Create(context.Background(), createTestETCMeisaiRecord())
			},
			constraintType: "unique",
		},
		{
			name: "Foreign key constraint violation",
			setupMock: func(m *MockETCMeisaiRecordRepository) {
				m.On("Create", mock.Anything, mock.Anything).Return(errors.New("FOREIGN KEY constraint failed"))
			},
			operation: func(repo repositories.ETCMeisaiRecordRepository) error {
				record := createTestETCMeisaiRecord()
				// Simulate invalid foreign key reference
				return repo.Create(context.Background(), record)
			},
			constraintType: "foreign_key",
		},
		{
			name: "Not null constraint violation",
			setupMock: func(m *MockETCMeisaiRecordRepository) {
				m.On("Create", mock.Anything, mock.Anything).Return(errors.New("NOT NULL constraint failed: etc_meisai_records.hash"))
			},
			operation: func(repo repositories.ETCMeisaiRecordRepository) error {
				record := createTestETCMeisaiRecord()
				record.Hash = "" // Simulate missing required field
				return repo.Create(context.Background(), record)
			},
			constraintType: "not_null",
		},
		{
			name: "Check constraint violation on toll amount",
			setupMock: func(m *MockETCMeisaiRecordRepository) {
				m.On("Create", mock.Anything, mock.Anything).Return(errors.New("CHECK constraint failed: toll_amount >= 0"))
			},
			operation: func(repo repositories.ETCMeisaiRecordRepository) error {
				record := createTestETCMeisaiRecord()
				record.TollAmount = -100 // Simulate invalid toll amount
				return repo.Create(context.Background(), record)
			},
			constraintType: "check",
		},
		{
			name: "Duplicate hash detection",
			setupMock: func(m *MockETCMeisaiRecordRepository) {
				m.On("CheckDuplicateHash", mock.Anything, "existing_hash", mock.Anything).Return(true, nil)
			},
			operation: func(repo repositories.ETCMeisaiRecordRepository) error {
				isDuplicate, err := repo.CheckDuplicateHash(context.Background(), "existing_hash")
				if err != nil {
					return err
				}
				if isDuplicate {
					return errors.New("duplicate hash detected")
				}
				return nil
			},
			constraintType: "duplicate_check",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			mockRepo := new(MockETCMeisaiRecordRepository)
			tt.setupMock(mockRepo)

			err := tt.operation(mockRepo)

			assert.Error(t, err)

			switch tt.constraintType {
			case "unique":
				assert.Contains(t, err.Error(), "UNIQUE constraint")
			case "foreign_key":
				assert.Contains(t, err.Error(), "FOREIGN KEY constraint")
			case "not_null":
				assert.Contains(t, err.Error(), "NOT NULL constraint")
			case "check":
				assert.Contains(t, err.Error(), "CHECK constraint")
			case "duplicate_check":
				assert.Contains(t, err.Error(), "duplicate hash")
			}

			mockRepo.AssertExpectations(t)
		})
	}
}

// T006-E: Pagination edge case testing
func TestETCMeisaiRecordRepository_PaginationEdgeCases(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name           string
		params         repositories.ListRecordsParams
		mockResponse   []*models.ETCMeisaiRecord
		mockTotal      int64
		mockError      error
		expectedResult string
	}{
		{
			name: "Empty results - no records found",
			params: repositories.ListRecordsParams{
				Page:     1,
				PageSize: 10,
			},
			mockResponse:   []*models.ETCMeisaiRecord{},
			mockTotal:      0,
			mockError:      nil,
			expectedResult: "empty",
		},
		{
			name: "Single page with exact page size",
			params: repositories.ListRecordsParams{
				Page:     1,
				PageSize: 5,
			},
			mockResponse: []*models.ETCMeisaiRecord{
				createTestETCMeisaiRecord(),
				createTestETCMeisaiRecord(),
				createTestETCMeisaiRecord(),
				createTestETCMeisaiRecord(),
				createTestETCMeisaiRecord(),
			},
			mockTotal:      5,
			mockError:      nil,
			expectedResult: "exact_page",
		},
		{
			name: "Last page with partial results",
			params: repositories.ListRecordsParams{
				Page:     3,
				PageSize: 10,
			},
			mockResponse: []*models.ETCMeisaiRecord{
				createTestETCMeisaiRecord(),
				createTestETCMeisaiRecord(),
				createTestETCMeisaiRecord(),
			},
			mockTotal:      23, // Total 23, page 3 with size 10 = 3 remaining
			mockError:      nil,
			expectedResult: "partial_last_page",
		},
		{
			name: "Page beyond available data",
			params: repositories.ListRecordsParams{
				Page:     5,
				PageSize: 10,
			},
			mockResponse:   []*models.ETCMeisaiRecord{},
			mockTotal:      15, // Only 15 total records, page 5 is beyond available data
			mockError:      nil,
			expectedResult: "beyond_data",
		},
		{
			name: "Invalid page number (negative)",
			params: repositories.ListRecordsParams{
				Page:     -1,
				PageSize: 10,
			},
			mockResponse:   nil,
			mockTotal:      0,
			mockError:      errors.New("invalid page number: must be positive"),
			expectedResult: "invalid_page",
		},
		{
			name: "Invalid page size (zero)",
			params: repositories.ListRecordsParams{
				Page:     1,
				PageSize: 0,
			},
			mockResponse:   nil,
			mockTotal:      0,
			mockError:      errors.New("invalid page size: must be positive"),
			expectedResult: "invalid_page_size",
		},
		{
			name: "Very large page size",
			params: repositories.ListRecordsParams{
				Page:     1,
				PageSize: 10000,
			},
			mockResponse: func() []*models.ETCMeisaiRecord {
				// Create 100 test records
				records := make([]*models.ETCMeisaiRecord, 100)
				for i := 0; i < 100; i++ {
					record := createTestETCMeisaiRecord()
					record.ID = int64(i + 1)
					record.Hash = fmt.Sprintf("hash_%d", i)
					records[i] = record
				}
				return records
			}(),
			mockTotal:      100,
			mockError:      nil,
			expectedResult: "large_page_size",
		},
		{
			name: "Pagination with date filter - no results",
			params: repositories.ListRecordsParams{
				Page:     1,
				PageSize: 10,
				DateFrom: func() *time.Time { t := time.Date(2025, 1, 1, 0, 0, 0, 0, time.UTC); return &t }(),
				DateTo:   func() *time.Time { t := time.Date(2025, 1, 31, 23, 59, 59, 0, time.UTC); return &t }(),
			},
			mockResponse:   []*models.ETCMeisaiRecord{},
			mockTotal:      0,
			mockError:      nil,
			expectedResult: "filtered_empty",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			mockRepo := new(MockETCMeisaiRecordRepository)
			mockRepo.On("List", mock.Anything, tt.params).Return(tt.mockResponse, tt.mockTotal, tt.mockError)

			ctx := context.Background()
			result, total, err := mockRepo.List(ctx, tt.params)

			switch tt.expectedResult {
			case "empty":
				assert.NoError(t, err)
				assert.Empty(t, result)
				assert.Equal(t, int64(0), total)

			case "exact_page":
				assert.NoError(t, err)
				assert.Len(t, result, tt.params.PageSize)
				assert.Equal(t, int64(5), total)

			case "partial_last_page":
				assert.NoError(t, err)
				assert.Len(t, result, 3)
				assert.Equal(t, int64(23), total)

			case "beyond_data":
				assert.NoError(t, err)
				assert.Empty(t, result)
				assert.Equal(t, int64(15), total)

			case "invalid_page":
				assert.Error(t, err)
				assert.Contains(t, err.Error(), "invalid page number")

			case "invalid_page_size":
				assert.Error(t, err)
				assert.Contains(t, err.Error(), "invalid page size")

			case "large_page_size":
				assert.NoError(t, err)
				assert.Len(t, result, 100)
				assert.Equal(t, int64(100), total)

			case "filtered_empty":
				assert.NoError(t, err)
				assert.Empty(t, result)
				assert.Equal(t, int64(0), total)
			}

			mockRepo.AssertExpectations(t)
		})
	}
}

// Benchmark tests for repository operations
func BenchmarkETCMeisaiRecordRepository_Create(b *testing.B) {
	mockRepo := new(MockETCMeisaiRecordRepository)
	mockRepo.On("Create", mock.Anything, mock.Anything).Return(nil)

	ctx := context.Background()
	record := createTestETCMeisaiRecord()

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		record.ID = int64(i + 1)
		record.Hash = fmt.Sprintf("hash_%d", i)
		_ = mockRepo.Create(ctx, record)
	}
}

func BenchmarkETCMeisaiRecordRepository_GetByID(b *testing.B) {
	mockRepo := new(MockETCMeisaiRecordRepository)
	testRecord := createTestETCMeisaiRecord()
	mockRepo.On("GetByID", mock.Anything, mock.Anything).Return(testRecord, nil)

	ctx := context.Background()

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, _ = mockRepo.GetByID(ctx, int64(i+1))
	}
}

func BenchmarkETCMeisaiRecordRepository_List(b *testing.B) {
	mockRepo := new(MockETCMeisaiRecordRepository)
	testRecords := []*models.ETCMeisaiRecord{createTestETCMeisaiRecord()}
	mockRepo.On("List", mock.Anything, mock.Anything).Return(testRecords, int64(1), nil)

	ctx := context.Background()
	params := repositories.ListRecordsParams{
		Page:     1,
		PageSize: 10,
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, _, _ = mockRepo.List(ctx, params)
	}
}

// Integration-style test with realistic scenarios
func TestETCMeisaiRecordRepository_RealisticScenarios(t *testing.T) {
	t.Parallel()

	t.Run("Complete CRUD workflow", func(t *testing.T) {
		t.Parallel()

		mockRepo := new(MockETCMeisaiRecordRepository)
		ctx := context.Background()
		record := createTestETCMeisaiRecord()

		// Setup expectations for complete workflow
		mockRepo.On("Create", ctx, record).Return(nil).Once()
		mockRepo.On("GetByID", ctx, record.ID).Return(record, nil).Once()

		updatedRecord := *record
		updatedRecord.TollAmount = 600
		mockRepo.On("Update", ctx, &updatedRecord).Return(nil).Once()
		mockRepo.On("GetByID", ctx, record.ID).Return(&updatedRecord, nil).Once()
		mockRepo.On("Delete", ctx, record.ID).Return(nil).Once()
		mockRepo.On("GetByID", ctx, record.ID).Return(nil, sql.ErrNoRows).Once()

		// Execute workflow
		// 1. Create
		err := mockRepo.Create(ctx, record)
		assert.NoError(t, err)

		// 2. Read
		retrieved, err := mockRepo.GetByID(ctx, record.ID)
		assert.NoError(t, err)
		assert.Equal(t, record.ID, retrieved.ID)

		// 3. Update
		updatedRecord.TollAmount = 600
		err = mockRepo.Update(ctx, &updatedRecord)
		assert.NoError(t, err)

		// 4. Read updated
		retrieved, err = mockRepo.GetByID(ctx, record.ID)
		assert.NoError(t, err)
		assert.Equal(t, int(600), retrieved.TollAmount)

		// 5. Delete
		err = mockRepo.Delete(ctx, record.ID)
		assert.NoError(t, err)

		// 6. Verify deletion
		_, err = mockRepo.GetByID(ctx, record.ID)
		assert.Error(t, err)
		assert.Equal(t, sql.ErrNoRows, err)

		mockRepo.AssertExpectations(t)
	})

	t.Run("Transaction workflow with multiple operations", func(t *testing.T) {
		t.Parallel()

		mainRepo := new(MockETCMeisaiRecordRepository)
		txRepo := new(MockETCMeisaiRecordRepository)
		ctx := context.Background()

		// Setup transaction workflow
		mainRepo.On("BeginTx", ctx).Return(txRepo, nil).Once()

		// Multiple create operations in transaction
		record1 := createTestETCMeisaiRecord()
		record1.ID = 1
		record1.Hash = "hash1"
		txRepo.On("Create", ctx, record1).Return(nil).Once()

		record2 := createTestETCMeisaiRecord()
		record2.ID = 2
		record2.Hash = "hash2"
		txRepo.On("Create", ctx, record2).Return(nil).Once()

		txRepo.On("CommitTx").Return(nil).Once()

		// Execute transaction workflow
		tx, err := mainRepo.BeginTx(ctx)
		require.NoError(t, err)

		err = tx.Create(ctx, record1)
		assert.NoError(t, err)

		err = tx.Create(ctx, record2)
		assert.NoError(t, err)

		err = tx.CommitTx()
		assert.NoError(t, err)

		mainRepo.AssertExpectations(t)
		txRepo.AssertExpectations(t)
	})
}