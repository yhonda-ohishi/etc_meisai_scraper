package repositories_test

import (
	"context"
	"database/sql"
	"errors"
	"sync"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"
	"github.com/yhonda-ohishi/etc_meisai/src/models"
	"github.com/yhonda-ohishi/etc_meisai/src/repositories"
)

// MockETCMappingRepository is a mock implementation for testing
type MockETCMappingRepository struct {
	mock.Mock
}

func (m *MockETCMappingRepository) Create(ctx context.Context, mapping *models.ETCMapping) error {
	args := m.Called(ctx, mapping)
	return args.Error(0)
}

func (m *MockETCMappingRepository) GetByID(ctx context.Context, id int64) (*models.ETCMapping, error) {
	args := m.Called(ctx, id)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*models.ETCMapping), args.Error(1)
}

func (m *MockETCMappingRepository) Update(ctx context.Context, mapping *models.ETCMapping) error {
	args := m.Called(ctx, mapping)
	return args.Error(0)
}

func (m *MockETCMappingRepository) Delete(ctx context.Context, id int64) error {
	args := m.Called(ctx, id)
	return args.Error(0)
}

func (m *MockETCMappingRepository) GetByETCRecordID(ctx context.Context, etcRecordID int64) ([]*models.ETCMapping, error) {
	args := m.Called(ctx, etcRecordID)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).([]*models.ETCMapping), args.Error(1)
}

func (m *MockETCMappingRepository) GetByMappedEntity(ctx context.Context, entityType string, entityID int64) ([]*models.ETCMapping, error) {
	args := m.Called(ctx, entityType, entityID)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).([]*models.ETCMapping), args.Error(1)
}

func (m *MockETCMappingRepository) GetActiveMapping(ctx context.Context, etcRecordID int64) (*models.ETCMapping, error) {
	args := m.Called(ctx, etcRecordID)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*models.ETCMapping), args.Error(1)
}

func (m *MockETCMappingRepository) List(ctx context.Context, params repositories.ListMappingsParams) ([]*models.ETCMapping, int64, error) {
	args := m.Called(ctx, params)
	if args.Get(0) == nil {
		return nil, args.Get(1).(int64), args.Error(2)
	}
	return args.Get(0).([]*models.ETCMapping), args.Get(1).(int64), args.Error(2)
}

func (m *MockETCMappingRepository) BulkCreate(ctx context.Context, mappings []*models.ETCMapping) error {
	args := m.Called(ctx, mappings)
	return args.Error(0)
}

func (m *MockETCMappingRepository) UpdateStatus(ctx context.Context, id int64, status string) error {
	args := m.Called(ctx, id, status)
	return args.Error(0)
}

func (m *MockETCMappingRepository) BeginTx(ctx context.Context) (repositories.ETCMappingRepository, error) {
	args := m.Called(ctx)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(repositories.ETCMappingRepository), args.Error(1)
}

func (m *MockETCMappingRepository) CommitTx() error {
	args := m.Called()
	return args.Error(0)
}

func (m *MockETCMappingRepository) RollbackTx() error {
	args := m.Called()
	return args.Error(0)
}

func (m *MockETCMappingRepository) Ping(ctx context.Context) error {
	args := m.Called(ctx)
	return args.Error(0)
}

// Test data helper
func createTestETCMapping() *models.ETCMapping {
	return &models.ETCMapping{
		ID:               1,
		ETCRecordID:      100,
		MappingType:      "dtako",
		MappedEntityType: "dtako_record",
		MappedEntityID:   200,
		Confidence:       0.95,
		Status:           "active",
		CreatedAt:        time.Now(),
		UpdatedAt:        time.Now(),
	}
}

// T006-A: Error path testing for ETCMappingRepository operations with database connection failures
func TestETCMappingRepository_DatabaseConnectionFailures(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name           string
		setupMock      func(*MockETCMappingRepository)
		operation      func(repositories.ETCMappingRepository) error
		expectedErrMsg string
	}{
		{
			name: "Create fails with connection error",
			setupMock: func(m *MockETCMappingRepository) {
				m.On("Create", mock.Anything, mock.Anything).Return(errors.New("connection refused"))
			},
			operation: func(repo repositories.ETCMappingRepository) error {
				return repo.Create(context.Background(), createTestETCMapping())
			},
			expectedErrMsg: "connection refused",
		},
		{
			name: "GetByETCRecordID fails with timeout",
			setupMock: func(m *MockETCMappingRepository) {
				m.On("GetByETCRecordID", mock.Anything, mock.Anything).Return(nil, errors.New("context deadline exceeded"))
			},
			operation: func(repo repositories.ETCMappingRepository) error {
				_, err := repo.GetByETCRecordID(context.Background(), 100)
				return err
			},
			expectedErrMsg: "context deadline exceeded",
		},
		{
			name: "BulkCreate fails with database lock",
			setupMock: func(m *MockETCMappingRepository) {
				m.On("BulkCreate", mock.Anything, mock.Anything).Return(errors.New("database is locked"))
			},
			operation: func(repo repositories.ETCMappingRepository) error {
				mappings := []*models.ETCMapping{createTestETCMapping()}
				return repo.BulkCreate(context.Background(), mappings)
			},
			expectedErrMsg: "database is locked",
		},
		{
			name: "GetActiveMapping fails with SQL error",
			setupMock: func(m *MockETCMappingRepository) {
				m.On("GetActiveMapping", mock.Anything, mock.Anything).Return(nil, errors.New("SQL syntax error"))
			},
			operation: func(repo repositories.ETCMappingRepository) error {
				_, err := repo.GetActiveMapping(context.Background(), 100)
				return err
			},
			expectedErrMsg: "SQL syntax error",
		},
		{
			name: "List fails with connection lost",
			setupMock: func(m *MockETCMappingRepository) {
				m.On("List", mock.Anything, mock.Anything).Return(nil, int64(0), errors.New("connection lost"))
			},
			operation: func(repo repositories.ETCMappingRepository) error {
				_, _, err := repo.List(context.Background(), repositories.ListMappingsParams{})
				return err
			},
			expectedErrMsg: "connection lost",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			mockRepo := new(MockETCMappingRepository)
			tt.setupMock(mockRepo)

			err := tt.operation(mockRepo)

			assert.Error(t, err)
			assert.Contains(t, err.Error(), tt.expectedErrMsg)
			mockRepo.AssertExpectations(t)
		})
	}
}

// T006-B: Transaction testing for BulkCreate with rollback scenarios
func TestETCMappingRepository_BulkCreateTransactionRollback(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name      string
		setupMock func(*MockETCMappingRepository, *MockETCMappingRepository)
		scenario  string
	}{
		{
			name: "BeginTx fails",
			setupMock: func(mainRepo, txRepo *MockETCMappingRepository) {
				mainRepo.On("BeginTx", mock.Anything).Return(nil, errors.New("failed to begin transaction"))
			},
			scenario: "transaction_begin_failure",
		},
		{
			name: "BulkCreate fails, rollback succeeds",
			setupMock: func(mainRepo, txRepo *MockETCMappingRepository) {
				mainRepo.On("BeginTx", mock.Anything).Return(txRepo, nil)
				txRepo.On("BulkCreate", mock.Anything, mock.Anything).Return(errors.New("constraint violation"))
				txRepo.On("RollbackTx").Return(nil)
			},
			scenario: "bulk_create_failure_rollback_success",
		},
		{
			name: "BulkCreate fails, rollback also fails",
			setupMock: func(mainRepo, txRepo *MockETCMappingRepository) {
				mainRepo.On("BeginTx", mock.Anything).Return(txRepo, nil)
				txRepo.On("BulkCreate", mock.Anything, mock.Anything).Return(errors.New("constraint violation"))
				txRepo.On("RollbackTx").Return(errors.New("rollback failed"))
			},
			scenario: "bulk_create_failure_rollback_failure",
		},
		{
			name: "BulkCreate succeeds, commit fails",
			setupMock: func(mainRepo, txRepo *MockETCMappingRepository) {
				mainRepo.On("BeginTx", mock.Anything).Return(txRepo, nil)
				txRepo.On("BulkCreate", mock.Anything, mock.Anything).Return(nil)
				txRepo.On("CommitTx").Return(errors.New("commit failed"))
				txRepo.On("RollbackTx").Return(nil)
			},
			scenario: "commit_failure_rollback_success",
		},
		{
			name: "Mixed operations in transaction",
			setupMock: func(mainRepo, txRepo *MockETCMappingRepository) {
				mainRepo.On("BeginTx", mock.Anything).Return(txRepo, nil)
				txRepo.On("Create", mock.Anything, mock.Anything).Return(nil).Once()
				txRepo.On("BulkCreate", mock.Anything, mock.Anything).Return(nil).Once()
				txRepo.On("UpdateStatus", mock.Anything, mock.Anything, mock.Anything).Return(errors.New("update failed"))
				txRepo.On("RollbackTx").Return(nil)
			},
			scenario: "mixed_operations_rollback",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			mainRepo := new(MockETCMappingRepository)
			txRepo := new(MockETCMappingRepository)
			tt.setupMock(mainRepo, txRepo)

			ctx := context.Background()

			switch tt.scenario {
			case "transaction_begin_failure":
				_, err := mainRepo.BeginTx(ctx)
				assert.Error(t, err)
				assert.Contains(t, err.Error(), "failed to begin transaction")

			case "bulk_create_failure_rollback_success":
				tx, err := mainRepo.BeginTx(ctx)
				require.NoError(t, err)
				require.NotNil(t, tx)

				mappings := []*models.ETCMapping{createTestETCMapping()}
				err = tx.BulkCreate(ctx, mappings)
				assert.Error(t, err)

				rollbackErr := tx.RollbackTx()
				assert.NoError(t, rollbackErr)

			case "bulk_create_failure_rollback_failure":
				tx, err := mainRepo.BeginTx(ctx)
				require.NoError(t, err)
				require.NotNil(t, tx)

				mappings := []*models.ETCMapping{createTestETCMapping()}
				err = tx.BulkCreate(ctx, mappings)
				assert.Error(t, err)

				rollbackErr := tx.RollbackTx()
				assert.Error(t, rollbackErr)

			case "commit_failure_rollback_success":
				tx, err := mainRepo.BeginTx(ctx)
				require.NoError(t, err)
				require.NotNil(t, tx)

				mappings := []*models.ETCMapping{createTestETCMapping()}
				err = tx.BulkCreate(ctx, mappings)
				assert.NoError(t, err)

				commitErr := tx.CommitTx()
				assert.Error(t, commitErr)

				rollbackErr := tx.RollbackTx()
				assert.NoError(t, rollbackErr)

			case "mixed_operations_rollback":
				tx, err := mainRepo.BeginTx(ctx)
				require.NoError(t, err)
				require.NotNil(t, tx)

				// Single create succeeds
				mapping := createTestETCMapping()
				err = tx.Create(ctx, mapping)
				assert.NoError(t, err)

				// Bulk create succeeds
				mappings := []*models.ETCMapping{createTestETCMapping()}
				err = tx.BulkCreate(ctx, mappings)
				assert.NoError(t, err)

				// Update status fails
				err = tx.UpdateStatus(ctx, 1, "inactive")
				assert.Error(t, err)

				// Rollback
				rollbackErr := tx.RollbackTx()
				assert.NoError(t, rollbackErr)
			}

			mainRepo.AssertExpectations(t)
			txRepo.AssertExpectations(t)
		})
	}
}

// T006-C: Concurrent access testing for mapping operations with race conditions
func TestETCMappingRepository_ConcurrentAccess(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name        string
		concurrency int
		operation   string
	}{
		{
			name:        "Concurrent Create operations",
			concurrency: 10,
			operation:   "create",
		},
		{
			name:        "Concurrent GetByETCRecordID operations",
			concurrency: 15,
			operation:   "read_by_etc_record",
		},
		{
			name:        "Concurrent UpdateStatus operations",
			concurrency: 8,
			operation:   "update_status",
		},
		{
			name:        "Mixed concurrent operations",
			concurrency: 20,
			operation:   "mixed",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			mockRepo := new(MockETCMappingRepository)

			// Setup mock expectations for concurrent operations
			switch tt.operation {
			case "create":
				mockRepo.On("Create", mock.Anything, mock.Anything).Return(nil)
			case "read_by_etc_record":
				testMappings := []*models.ETCMapping{createTestETCMapping()}
				mockRepo.On("GetByETCRecordID", mock.Anything, mock.Anything).Return(testMappings, nil)
			case "update_status":
				mockRepo.On("UpdateStatus", mock.Anything, mock.Anything, mock.Anything).Return(nil)
			case "mixed":
				testMappings := []*models.ETCMapping{createTestETCMapping()}
				mockRepo.On("Create", mock.Anything, mock.Anything).Return(nil).Maybe()
				mockRepo.On("GetByETCRecordID", mock.Anything, mock.Anything).Return(testMappings, nil).Maybe()
				mockRepo.On("UpdateStatus", mock.Anything, mock.Anything, mock.Anything).Return(nil).Maybe()
			}

			var wg sync.WaitGroup
			errChan := make(chan error, tt.concurrency)
			ctx := context.Background()

			// Launch concurrent operations
			for i := 0; i < tt.concurrency; i++ {
				wg.Add(1)
				go func(id int) {
					defer wg.Done()

					switch tt.operation {
					case "create":
						mapping := createTestETCMapping()
						mapping.ID = int64(id + 1)
						mapping.ETCRecordID = int64(100 + id)
						err := mockRepo.Create(ctx, mapping)
						if err != nil {
							errChan <- err
						}
					case "read_by_etc_record":
						_, err := mockRepo.GetByETCRecordID(ctx, int64(100+id))
						if err != nil {
							errChan <- err
						}
					case "update_status":
						err := mockRepo.UpdateStatus(ctx, int64(id+1), "inactive")
						if err != nil {
							errChan <- err
						}
					case "mixed":
						operation := id % 3
						switch operation {
						case 0: // Create
							mapping := createTestETCMapping()
							mapping.ID = int64(id + 1)
							mapping.ETCRecordID = int64(100 + id)
							err := mockRepo.Create(ctx, mapping)
							if err != nil {
								errChan <- err
							}
						case 1: // Read
							_, err := mockRepo.GetByETCRecordID(ctx, int64(100+id))
							if err != nil {
								errChan <- err
							}
						case 2: // Update
							err := mockRepo.UpdateStatus(ctx, int64(id+1), "inactive")
							if err != nil {
								errChan <- err
							}
						}
					}
				}(i)
			}

			// Wait for all operations to complete
			wg.Wait()
			close(errChan)

			// Check for errors
			var errors []error
			for err := range errChan {
				errors = append(errors, err)
			}

			assert.Empty(t, errors, "No errors should occur during concurrent operations")
			mockRepo.AssertExpectations(t)
		})
	}
}

// T006-D: Database constraint violation testing
func TestETCMappingRepository_ConstraintViolations(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name           string
		setupMock      func(*MockETCMappingRepository)
		operation      func(repositories.ETCMappingRepository) error
		constraintType string
	}{
		{
			name: "Foreign key constraint violation - invalid ETC record ID",
			setupMock: func(m *MockETCMappingRepository) {
				m.On("Create", mock.Anything, mock.Anything).Return(errors.New("FOREIGN KEY constraint failed: etc_mappings.etc_record_id"))
			},
			operation: func(repo repositories.ETCMappingRepository) error {
				mapping := createTestETCMapping()
				mapping.ETCRecordID = 99999 // Non-existent ETC record
				return repo.Create(context.Background(), mapping)
			},
			constraintType: "foreign_key",
		},
		{
			name: "Unique constraint violation on ETC record and mapping type",
			setupMock: func(m *MockETCMappingRepository) {
				m.On("Create", mock.Anything, mock.Anything).Return(errors.New("UNIQUE constraint failed: etc_mappings.etc_record_id_mapping_type"))
			},
			operation: func(repo repositories.ETCMappingRepository) error {
				return repo.Create(context.Background(), createTestETCMapping())
			},
			constraintType: "unique",
		},
		{
			name: "Not null constraint violation on mapping type",
			setupMock: func(m *MockETCMappingRepository) {
				m.On("Create", mock.Anything, mock.Anything).Return(errors.New("NOT NULL constraint failed: etc_mappings.mapping_type"))
			},
			operation: func(repo repositories.ETCMappingRepository) error {
				mapping := createTestETCMapping()
				mapping.MappingType = "" // Empty mapping type
				return repo.Create(context.Background(), mapping)
			},
			constraintType: "not_null",
		},
		{
			name: "Check constraint violation on confidence",
			setupMock: func(m *MockETCMappingRepository) {
				m.On("Create", mock.Anything, mock.Anything).Return(errors.New("CHECK constraint failed: confidence >= 0 AND confidence <= 1"))
			},
			operation: func(repo repositories.ETCMappingRepository) error {
				mapping := createTestETCMapping()
				mapping.Confidence = 1.5 // Invalid confidence value
				return repo.Create(context.Background(), mapping)
			},
			constraintType: "check",
		},
		{
			name: "Invalid status constraint",
			setupMock: func(m *MockETCMappingRepository) {
				m.On("UpdateStatus", mock.Anything, mock.Anything, mock.Anything).Return(errors.New("CHECK constraint failed: status IN ('active', 'inactive', 'pending')"))
			},
			operation: func(repo repositories.ETCMappingRepository) error {
				return repo.UpdateStatus(context.Background(), 1, "invalid_status")
			},
			constraintType: "status_check",
		},
		{
			name: "Bulk create with constraint violations",
			setupMock: func(m *MockETCMappingRepository) {
				m.On("BulkCreate", mock.Anything, mock.Anything).Return(errors.New("FOREIGN KEY constraint failed during bulk insert"))
			},
			operation: func(repo repositories.ETCMappingRepository) error {
				mappings := []*models.ETCMapping{
					createTestETCMapping(),
					{
						ID:               2,
						ETCRecordID:      99999, // Invalid foreign key
						MappingType:      "dtako",
						MappedEntityType: "dtako_record",
						MappedEntityID:   201,
						Confidence:       0.8,
						Status:           "active",
					},
				}
				return repo.BulkCreate(context.Background(), mappings)
			},
			constraintType: "bulk_foreign_key",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			mockRepo := new(MockETCMappingRepository)
			tt.setupMock(mockRepo)

			err := tt.operation(mockRepo)

			assert.Error(t, err)

			switch tt.constraintType {
			case "foreign_key", "bulk_foreign_key":
				assert.Contains(t, err.Error(), "FOREIGN KEY constraint")
			case "unique":
				assert.Contains(t, err.Error(), "UNIQUE constraint")
			case "not_null":
				assert.Contains(t, err.Error(), "NOT NULL constraint")
			case "check":
				assert.Contains(t, err.Error(), "CHECK constraint")
			case "status_check":
				assert.Contains(t, err.Error(), "CHECK constraint")
			}

			mockRepo.AssertExpectations(t)
		})
	}
}

// T006-E: Pagination edge case testing
func TestETCMappingRepository_PaginationEdgeCases(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name           string
		params         repositories.ListMappingsParams
		mockResponse   []*models.ETCMapping
		mockTotal      int64
		mockError      error
		expectedResult string
	}{
		{
			name: "Empty results - no mappings found",
			params: repositories.ListMappingsParams{
				Page:     1,
				PageSize: 10,
			},
			mockResponse:   []*models.ETCMapping{},
			mockTotal:      0,
			mockError:      nil,
			expectedResult: "empty",
		},
		{
			name: "Single page with exact page size",
			params: repositories.ListMappingsParams{
				Page:     1,
				PageSize: 3,
			},
			mockResponse: []*models.ETCMapping{
				createTestETCMapping(),
				createTestETCMapping(),
				createTestETCMapping(),
			},
			mockTotal:      3,
			mockError:      nil,
			expectedResult: "exact_page",
		},
		{
			name: "Last page with partial results",
			params: repositories.ListMappingsParams{
				Page:     4,
				PageSize: 5,
			},
			mockResponse: []*models.ETCMapping{
				createTestETCMapping(),
				createTestETCMapping(),
			},
			mockTotal:      17, // Total 17, page 4 with size 5 = 2 remaining
			mockError:      nil,
			expectedResult: "partial_last_page",
		},
		{
			name: "Page beyond available data",
			params: repositories.ListMappingsParams{
				Page:     10,
				PageSize: 5,
			},
			mockResponse:   []*models.ETCMapping{},
			mockTotal:      20, // Only 20 total records, page 10 is beyond available data
			mockError:      nil,
			expectedResult: "beyond_data",
		},
		{
			name: "Filter by mapping type with results",
			params: repositories.ListMappingsParams{
				Page:        1,
				PageSize:    10,
				MappingType: func() *string { s := "dtako"; return &s }(),
			},
			mockResponse: []*models.ETCMapping{createTestETCMapping()},
			mockTotal:    1,
			mockError:    nil,
			expectedResult: "filtered_results",
		},
		{
			name: "Filter by status with no results",
			params: repositories.ListMappingsParams{
				Page:     1,
				PageSize: 10,
				Status:   func() *string { s := "deleted"; return &s }(),
			},
			mockResponse:   []*models.ETCMapping{},
			mockTotal:      0,
			mockError:      nil,
			expectedResult: "filtered_empty",
		},
		{
			name: "Filter by confidence range",
			params: repositories.ListMappingsParams{
				Page:          1,
				PageSize:      10,
				MinConfidence: func() *float32 { c := float32(0.9); return &c }(),
			},
			mockResponse: []*models.ETCMapping{createTestETCMapping()},
			mockTotal:    1,
			mockError:    nil,
			expectedResult: "confidence_filtered",
		},
		{
			name: "Date range filter with no results",
			params: repositories.ListMappingsParams{
				Page:     1,
				PageSize: 10,
				DateFrom: func() *time.Time { t := time.Date(2025, 1, 1, 0, 0, 0, 0, time.UTC); return &t }(),
				DateTo:   func() *time.Time { t := time.Date(2025, 1, 31, 23, 59, 59, 0, time.UTC); return &t }(),
			},
			mockResponse:   []*models.ETCMapping{},
			mockTotal:      0,
			mockError:      nil,
			expectedResult: "date_filtered_empty",
		},
		{
			name: "Invalid page number (negative)",
			params: repositories.ListMappingsParams{
				Page:     -1,
				PageSize: 10,
			},
			mockResponse:   nil,
			mockTotal:      0,
			mockError:      errors.New("invalid page number: must be positive"),
			expectedResult: "invalid_page",
		},
		{
			name: "Invalid page size (zero)",
			params: repositories.ListMappingsParams{
				Page:     1,
				PageSize: 0,
			},
			mockResponse:   nil,
			mockTotal:      0,
			mockError:      errors.New("invalid page size: must be positive"),
			expectedResult: "invalid_page_size",
		},
		{
			name: "Very large page size",
			params: repositories.ListMappingsParams{
				Page:     1,
				PageSize: 10000,
			},
			mockResponse: func() []*models.ETCMapping {
				// Create 50 test mappings
				mappings := make([]*models.ETCMapping, 50)
				for i := 0; i < 50; i++ {
					mapping := createTestETCMapping()
					mapping.ID = int64(i + 1)
					mapping.ETCRecordID = int64(100 + i)
					mappings[i] = mapping
				}
				return mappings
			}(),
			mockTotal:      50,
			mockError:      nil,
			expectedResult: "large_page_size",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			mockRepo := new(MockETCMappingRepository)
			mockRepo.On("List", mock.Anything, tt.params).Return(tt.mockResponse, tt.mockTotal, tt.mockError)

			ctx := context.Background()
			result, total, err := mockRepo.List(ctx, tt.params)

			switch tt.expectedResult {
			case "empty":
				assert.NoError(t, err)
				assert.Empty(t, result)
				assert.Equal(t, int64(0), total)

			case "exact_page":
				assert.NoError(t, err)
				assert.Len(t, result, tt.params.PageSize)
				assert.Equal(t, int64(3), total)

			case "partial_last_page":
				assert.NoError(t, err)
				assert.Len(t, result, 2)
				assert.Equal(t, int64(17), total)

			case "beyond_data":
				assert.NoError(t, err)
				assert.Empty(t, result)
				assert.Equal(t, int64(20), total)

			case "filtered_results":
				assert.NoError(t, err)
				assert.Len(t, result, 1)
				assert.Equal(t, int64(1), total)

			case "filtered_empty", "date_filtered_empty":
				assert.NoError(t, err)
				assert.Empty(t, result)
				assert.Equal(t, int64(0), total)

			case "confidence_filtered":
				assert.NoError(t, err)
				assert.Len(t, result, 1)
				assert.Equal(t, int64(1), total)

			case "invalid_page":
				assert.Error(t, err)
				assert.Contains(t, err.Error(), "invalid page number")

			case "invalid_page_size":
				assert.Error(t, err)
				assert.Contains(t, err.Error(), "invalid page size")

			case "large_page_size":
				assert.NoError(t, err)
				assert.Len(t, result, 50)
				assert.Equal(t, int64(50), total)
			}

			mockRepo.AssertExpectations(t)
		})
	}
}

// Benchmark tests for mapping repository operations
func BenchmarkETCMappingRepository_Create(b *testing.B) {
	mockRepo := new(MockETCMappingRepository)
	mockRepo.On("Create", mock.Anything, mock.Anything).Return(nil)

	ctx := context.Background()
	mapping := createTestETCMapping()

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		mapping.ID = int64(i + 1)
		mapping.ETCRecordID = int64(100 + i)
		_ = mockRepo.Create(ctx, mapping)
	}
}

func BenchmarkETCMappingRepository_GetByETCRecordID(b *testing.B) {
	mockRepo := new(MockETCMappingRepository)
	testMappings := []*models.ETCMapping{createTestETCMapping()}
	mockRepo.On("GetByETCRecordID", mock.Anything, mock.Anything).Return(testMappings, nil)

	ctx := context.Background()

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, _ = mockRepo.GetByETCRecordID(ctx, int64(100+i))
	}
}

func BenchmarkETCMappingRepository_BulkCreate(b *testing.B) {
	mockRepo := new(MockETCMappingRepository)
	mockRepo.On("BulkCreate", mock.Anything, mock.Anything).Return(nil)

	ctx := context.Background()

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		mappings := []*models.ETCMapping{
			createTestETCMapping(),
			createTestETCMapping(),
			createTestETCMapping(),
		}
		for j, mapping := range mappings {
			mapping.ID = int64(i*3 + j + 1)
			mapping.ETCRecordID = int64(100 + i*3 + j)
		}
		_ = mockRepo.BulkCreate(ctx, mappings)
	}
}

// Integration-style test with realistic scenarios
func TestETCMappingRepository_RealisticScenarios(t *testing.T) {
	t.Parallel()

	t.Run("Complete mapping lifecycle", func(t *testing.T) {
		t.Parallel()

		mockRepo := new(MockETCMappingRepository)
		ctx := context.Background()
		mapping := createTestETCMapping()

		// Setup expectations for complete lifecycle
		mockRepo.On("Create", ctx, mapping).Return(nil).Once()
		mockRepo.On("GetByID", ctx, mapping.ID).Return(mapping, nil).Once()
		mockRepo.On("GetByETCRecordID", ctx, mapping.ETCRecordID).Return([]*models.ETCMapping{mapping}, nil).Once()
		mockRepo.On("UpdateStatus", ctx, mapping.ID, "inactive").Return(nil).Once()

		updatedMapping := *mapping
		updatedMapping.Status = "inactive"
		mockRepo.On("GetByID", ctx, mapping.ID).Return(&updatedMapping, nil).Once()
		mockRepo.On("Delete", ctx, mapping.ID).Return(nil).Once()
		mockRepo.On("GetByID", ctx, mapping.ID).Return(nil, sql.ErrNoRows).Once()

		// Execute lifecycle
		// 1. Create
		err := mockRepo.Create(ctx, mapping)
		assert.NoError(t, err)

		// 2. Read by ID
		retrieved, err := mockRepo.GetByID(ctx, mapping.ID)
		assert.NoError(t, err)
		assert.Equal(t, mapping.ID, retrieved.ID)

		// 3. Read by ETC record ID
		mappings, err := mockRepo.GetByETCRecordID(ctx, mapping.ETCRecordID)
		assert.NoError(t, err)
		assert.Len(t, mappings, 1)

		// 4. Update status
		err = mockRepo.UpdateStatus(ctx, mapping.ID, "inactive")
		assert.NoError(t, err)

		// 5. Verify status update
		retrieved, err = mockRepo.GetByID(ctx, mapping.ID)
		assert.NoError(t, err)
		assert.Equal(t, "inactive", retrieved.Status)

		// 6. Delete
		err = mockRepo.Delete(ctx, mapping.ID)
		assert.NoError(t, err)

		// 7. Verify deletion
		_, err = mockRepo.GetByID(ctx, mapping.ID)
		assert.Error(t, err)
		assert.Equal(t, sql.ErrNoRows, err)

		mockRepo.AssertExpectations(t)
	})

	t.Run("Bulk mapping creation and management", func(t *testing.T) {
		t.Parallel()

		mainRepo := new(MockETCMappingRepository)
		txRepo := new(MockETCMappingRepository)
		ctx := context.Background()

		// Create multiple mappings for bulk operation
		mappings := make([]*models.ETCMapping, 5)
		for i := 0; i < 5; i++ {
			mapping := createTestETCMapping()
			mapping.ID = int64(i + 1)
			mapping.ETCRecordID = int64(100 + i)
			mappings[i] = mapping
		}

		// Setup expectations
		mainRepo.On("BeginTx", ctx).Return(txRepo, nil).Once()
		txRepo.On("BulkCreate", ctx, mappings).Return(nil).Once()

		// Verify each mapping was created
		for _, mapping := range mappings {
			txRepo.On("GetByETCRecordID", ctx, mapping.ETCRecordID).Return([]*models.ETCMapping{mapping}, nil).Once()
		}

		txRepo.On("CommitTx").Return(nil).Once()

		// Execute bulk creation
		tx, err := mainRepo.BeginTx(ctx)
		require.NoError(t, err)

		err = tx.BulkCreate(ctx, mappings)
		assert.NoError(t, err)

		// Verify all mappings were created
		for _, mapping := range mappings {
			retrieved, err := tx.GetByETCRecordID(ctx, mapping.ETCRecordID)
			assert.NoError(t, err)
			assert.Len(t, retrieved, 1)
			assert.Equal(t, mapping.ETCRecordID, retrieved[0].ETCRecordID)
		}

		err = tx.CommitTx()
		assert.NoError(t, err)

		mainRepo.AssertExpectations(t)
		txRepo.AssertExpectations(t)
	})
}