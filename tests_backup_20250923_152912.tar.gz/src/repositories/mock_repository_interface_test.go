package repositories_test

import (
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.com/yhonda-ohishi/etc_meisai/src/models"
	"github.com/yhonda-ohishi/etc_meisai/src/repositories"
)

// MockETCRepositoryInterface is a testify mock for ETCRepository interface
type MockETCRepositoryInterface struct {
	mock.Mock
}

// Create implements ETCRepository interface
func (m *MockETCRepositoryInterface) Create(etc *models.ETCMeisai) error {
	args := m.Called(etc)
	return args.Error(0)
}

// GetByID implements ETCRepository interface
func (m *MockETCRepositoryInterface) GetByID(id int64) (*models.ETCMeisai, error) {
	args := m.Called(id)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*models.ETCMeisai), args.Error(1)
}

// Update implements ETCRepository interface
func (m *MockETCRepositoryInterface) Update(etc *models.ETCMeisai) error {
	args := m.Called(etc)
	return args.Error(0)
}

// Delete implements ETCRepository interface
func (m *MockETCRepositoryInterface) Delete(id int64) error {
	args := m.Called(id)
	return args.Error(0)
}

// GetByDateRange implements ETCRepository interface
func (m *MockETCRepositoryInterface) GetByDateRange(from, to time.Time) ([]*models.ETCMeisai, error) {
	args := m.Called(from, to)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).([]*models.ETCMeisai), args.Error(1)
}

// GetByHash implements ETCRepository interface
func (m *MockETCRepositoryInterface) GetByHash(hash string) (*models.ETCMeisai, error) {
	args := m.Called(hash)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*models.ETCMeisai), args.Error(1)
}

// List implements ETCRepository interface
func (m *MockETCRepositoryInterface) List(params *models.ETCListParams) ([]*models.ETCMeisai, int64, error) {
	args := m.Called(params)
	if args.Get(0) == nil {
		return nil, args.Get(1).(int64), args.Error(2)
	}
	return args.Get(0).([]*models.ETCMeisai), args.Get(1).(int64), args.Error(2)
}

// BulkInsert implements ETCRepository interface
func (m *MockETCRepositoryInterface) BulkInsert(records []*models.ETCMeisai) error {
	args := m.Called(records)
	return args.Error(0)
}

// CheckDuplicatesByHash implements ETCRepository interface
func (m *MockETCRepositoryInterface) CheckDuplicatesByHash(hashes []string) (map[string]bool, error) {
	args := m.Called(hashes)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(map[string]bool), args.Error(1)
}

// CountByDateRange implements ETCRepository interface
func (m *MockETCRepositoryInterface) CountByDateRange(from, to time.Time) (int64, error) {
	args := m.Called(from, to)
	return args.Get(0).(int64), args.Error(1)
}

// GetByETCNumber implements ETCRepository interface
func (m *MockETCRepositoryInterface) GetByETCNumber(etcNumber string, limit int) ([]*models.ETCMeisai, error) {
	args := m.Called(etcNumber, limit)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).([]*models.ETCMeisai), args.Error(1)
}

// GetByCarNumber implements ETCRepository interface
func (m *MockETCRepositoryInterface) GetByCarNumber(carNumber string, limit int) ([]*models.ETCMeisai, error) {
	args := m.Called(carNumber, limit)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).([]*models.ETCMeisai), args.Error(1)
}

// GetSummaryByDateRange implements ETCRepository interface
func (m *MockETCRepositoryInterface) GetSummaryByDateRange(from, to time.Time) (*models.ETCSummary, error) {
	args := m.Called(from, to)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*models.ETCSummary), args.Error(1)
}

// Test to verify the mock implements the interface
func TestMockETCRepositoryInterface_InterfaceCompliance(t *testing.T) {
	t.Parallel()

	var repo repositories.ETCRepository = &MockETCRepositoryInterface{}
	assert.NotNil(t, repo)
}

func TestMockETCRepositoryInterface_Create(t *testing.T) {
	t.Parallel()

	mockRepo := &MockETCRepositoryInterface{}
	mockRepo.On("Create", mock.AnythingOfType("*models.ETCMeisai")).Return(nil)

	etc := &models.ETCMeisai{
		UseDate:   time.Date(2024, 1, 15, 0, 0, 0, 0, time.UTC),
		CarNumber: "品川500あ1234",
		Hash:      "test123",
	}

	err := mockRepo.Create(etc)
	assert.NoError(t, err)
	mockRepo.AssertCalled(t, "Create", etc)
}

func TestMockETCRepositoryInterface_GetByID(t *testing.T) {
	t.Parallel()

	mock := &MockETCRepositoryInterface{}
	expectedRecord := &models.ETCMeisai{
		ID:        1,
		UseDate:   time.Date(2024, 1, 15, 0, 0, 0, 0, time.UTC),
		CarNumber: "品川500あ1234",
		Hash:      "test123",
	}

	mock.On("GetByID", int64(1)).Return(expectedRecord, nil)
	mock.On("GetByID", int64(999)).Return(nil, assert.AnError)

	// Test successful get
	result, err := mock.GetByID(1)
	assert.NoError(t, err)
	assert.Equal(t, expectedRecord, result)

	// Test not found
	result, err = mock.GetByID(999)
	assert.Error(t, err)
	assert.Nil(t, result)

	mock.AssertExpectations(t)
}

func TestMockETCRepositoryInterface_List(t *testing.T) {
	t.Parallel()

	mock := &MockETCRepositoryInterface{}
	expectedRecords := []*models.ETCMeisai{
		{
			ID:        1,
			UseDate:   time.Date(2024, 1, 15, 0, 0, 0, 0, time.UTC),
			CarNumber: "品川500あ1234",
		},
		{
			ID:        2,
			UseDate:   time.Date(2024, 1, 16, 0, 0, 0, 0, time.UTC),
			CarNumber: "品川500い5678",
		},
	}

	params := &models.ETCListParams{
		Limit:  10,
		Offset: 0,
	}

	mock.On("List", params).Return(expectedRecords, int64(2), nil)

	records, count, err := mock.List(params)
	assert.NoError(t, err)
	assert.Equal(t, expectedRecords, records)
	assert.Equal(t, int64(2), count)

	mock.AssertExpectations(t)
}

func TestMockETCRepositoryInterface_BulkInsert(t *testing.T) {
	t.Parallel()

	mock := &MockETCRepositoryInterface{}
	records := []*models.ETCMeisai{
		{
			UseDate:   time.Date(2024, 1, 15, 0, 0, 0, 0, time.UTC),
			CarNumber: "品川500あ1234",
		},
		{
			UseDate:   time.Date(2024, 1, 16, 0, 0, 0, 0, time.UTC),
			CarNumber: "品川500い5678",
		},
	}

	mock.On("BulkInsert", records).Return(nil)

	err := mock.BulkInsert(records)
	assert.NoError(t, err)

	mock.AssertExpectations(t)
}

func TestMockETCRepositoryInterface_CheckDuplicatesByHash(t *testing.T) {
	t.Parallel()

	mock := &MockETCRepositoryInterface{}
	hashes := []string{"hash1", "hash2", "hash3"}
	expected := map[string]bool{
		"hash1": true,
		"hash2": false,
		"hash3": true,
	}

	mock.On("CheckDuplicatesByHash", hashes).Return(expected, nil)

	result, err := mock.CheckDuplicatesByHash(hashes)
	assert.NoError(t, err)
	assert.Equal(t, expected, result)

	mock.AssertExpectations(t)
}

func TestMockETCRepositoryInterface_CountByDateRange(t *testing.T) {
	t.Parallel()

	mock := &MockETCRepositoryInterface{}
	from := time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC)
	to := time.Date(2024, 1, 31, 23, 59, 59, 0, time.UTC)

	mock.On("CountByDateRange", from, to).Return(int64(150), nil)

	count, err := mock.CountByDateRange(from, to)
	assert.NoError(t, err)
	assert.Equal(t, int64(150), count)

	mock.AssertExpectations(t)
}

func TestMockETCRepositoryInterface_GetByETCNumber(t *testing.T) {
	t.Parallel()

	mock := &MockETCRepositoryInterface{}
	etcNumber := "1234567890123456"
	limit := 10

	expectedRecords := []*models.ETCMeisai{
		{
			ID:        1,
			ETCNumber: etcNumber,
			CarNumber: "品川500あ1234",
		},
		{
			ID:        2,
			ETCNumber: etcNumber,
			CarNumber: "品川500い5678",
		},
	}

	mock.On("GetByETCNumber", etcNumber, limit).Return(expectedRecords, nil)

	records, err := mock.GetByETCNumber(etcNumber, limit)
	assert.NoError(t, err)
	assert.Equal(t, expectedRecords, records)

	mock.AssertExpectations(t)
}

func TestMockETCRepositoryInterface_GetByCarNumber(t *testing.T) {
	t.Parallel()

	mock := &MockETCRepositoryInterface{}
	carNumber := "品川500あ1234"
	limit := 5

	expectedRecords := []*models.ETCMeisai{
		{
			ID:        1,
			CarNumber: carNumber,
			ETCNumber: "1111111111111111",
		},
		{
			ID:        3,
			CarNumber: carNumber,
			ETCNumber: "2222222222222222",
		},
	}

	mock.On("GetByCarNumber", carNumber, limit).Return(expectedRecords, nil)

	records, err := mock.GetByCarNumber(carNumber, limit)
	assert.NoError(t, err)
	assert.Equal(t, expectedRecords, records)

	mock.AssertExpectations(t)
}

func TestMockETCRepositoryInterface_GetSummaryByDateRange(t *testing.T) {
	t.Parallel()

	mock := &MockETCRepositoryInterface{}
	from := time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC)
	to := time.Date(2024, 1, 31, 23, 59, 59, 0, time.UTC)

	expectedSummary := &models.ETCSummary{
		TotalAmount: 50000,
		TotalCount:  25,
		StartDate:   from,
		EndDate:     to,
	}

	mock.On("GetSummaryByDateRange", from, to).Return(expectedSummary, nil)

	summary, err := mock.GetSummaryByDateRange(from, to)
	assert.NoError(t, err)
	assert.Equal(t, expectedSummary, summary)

	mock.AssertExpectations(t)
}

func TestMockETCRepositoryInterface_GetByDateRange(t *testing.T) {
	t.Parallel()

	mock := &MockETCRepositoryInterface{}
	from := time.Date(2024, 1, 15, 0, 0, 0, 0, time.UTC)
	to := time.Date(2024, 1, 20, 23, 59, 59, 0, time.UTC)

	expectedRecords := []*models.ETCMeisai{
		{
			ID:      1,
			UseDate: time.Date(2024, 1, 16, 0, 0, 0, 0, time.UTC),
		},
		{
			ID:      2,
			UseDate: time.Date(2024, 1, 18, 0, 0, 0, 0, time.UTC),
		},
	}

	mock.On("GetByDateRange", from, to).Return(expectedRecords, nil)

	records, err := mock.GetByDateRange(from, to)
	assert.NoError(t, err)
	assert.Equal(t, expectedRecords, records)

	mock.AssertExpectations(t)
}

func TestMockETCRepositoryInterface_GetByHash(t *testing.T) {
	t.Parallel()

	mock := &MockETCRepositoryInterface{}
	hash := "unique-hash-123"

	expectedRecord := &models.ETCMeisai{
		ID:   1,
		Hash: hash,
	}

	mock.On("GetByHash", hash).Return(expectedRecord, nil)
	mock.On("GetByHash", "non-existing").Return(nil, assert.AnError)

	// Test found
	record, err := mock.GetByHash(hash)
	assert.NoError(t, err)
	assert.Equal(t, expectedRecord, record)

	// Test not found
	record, err = mock.GetByHash("non-existing")
	assert.Error(t, err)
	assert.Nil(t, record)

	mock.AssertExpectations(t)
}

func TestMockETCRepositoryInterface_Update(t *testing.T) {
	t.Parallel()

	mock := &MockETCRepositoryInterface{}
	etc := &models.ETCMeisai{
		ID:        1,
		CarNumber: "品川500あ1234",
	}

	mock.On("Update", etc).Return(nil)

	err := mock.Update(etc)
	assert.NoError(t, err)

	mock.AssertExpectations(t)
}

func TestMockETCRepositoryInterface_Delete(t *testing.T) {
	t.Parallel()

	mock := &MockETCRepositoryInterface{}

	mock.On("Delete", int64(1)).Return(nil)
	mock.On("Delete", int64(999)).Return(assert.AnError)

	// Test successful delete
	err := mock.Delete(1)
	assert.NoError(t, err)

	// Test delete non-existing
	err = mock.Delete(999)
	assert.Error(t, err)

	mock.AssertExpectations(t)
}