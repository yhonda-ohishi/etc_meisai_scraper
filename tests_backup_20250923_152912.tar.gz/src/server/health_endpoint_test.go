package server_test

import (
	"context"
	"encoding/json"
	"errors"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/credentials/insecure"
	"google.golang.org/grpc/health"
	"google.golang.org/grpc/health/grpc_health_v1"
	"google.golang.org/grpc/status"
	"github.com/stretchr/testify/mock"
	"github.com/yhonda-ohishi/etc_meisai/src/server"
)

// TestHealthCheckHTTPEndpoint tests HTTP health check endpoints
func TestHealthCheckHTTPEndpoint(t *testing.T) {
	t.Parallel()

	config := server.HealthCheckConfig{
		CheckInterval:   100 * time.Millisecond,
		Timeout:         2 * time.Second,
		EnableReadiness: true,
		EnableLiveness:  true,
	}
	healthService := server.NewHealthCheckService(config)

	// Setup health check HTTP handler
	mux := http.NewServeMux()
	mux.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		ctx, cancel := context.WithTimeout(r.Context(), 5*time.Second)
		defer cancel()

		req := &server.HealthCheckRequest{Service: ""}
		resp, err := healthService.Check(ctx, req)

		if err != nil {
			w.WriteHeader(http.StatusServiceUnavailable)
			json.NewEncoder(w).Encode(map[string]string{
				"status": "unhealthy",
				"error":  err.Error(),
			})
			return
		}

		status := "healthy"
		if resp.Status != server.HealthCheckResponse_SERVING {
			status = "unhealthy"
		}

		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		json.NewEncoder(w).Encode(map[string]string{
			"status": status,
		})
	})

	mux.HandleFunc("/health/ready", func(w http.ResponseWriter, r *http.Request) {
		ctx, cancel := context.WithTimeout(r.Context(), 3*time.Second)
		defer cancel()

		ready, err := healthService.ReadinessCheck(ctx)
		statusCode := http.StatusOK
		if err != nil || !ready {
			statusCode = http.StatusServiceUnavailable
		}

		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(statusCode)
		json.NewEncoder(w).Encode(map[string]interface{}{
			"ready": ready,
			"error": errorString(err),
		})
	})

	mux.HandleFunc("/health/live", func(w http.ResponseWriter, r *http.Request) {
		ctx, cancel := context.WithTimeout(r.Context(), 3*time.Second)
		defer cancel()

		live, err := healthService.LivenessCheck(ctx)
		statusCode := http.StatusOK
		if err != nil || !live {
			statusCode = http.StatusServiceUnavailable
		}

		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(statusCode)
		json.NewEncoder(w).Encode(map[string]interface{}{
			"live":  live,
			"error": errorString(err),
		})
	})

	server := httptest.NewServer(mux)
	defer server.Close()

	// Test main health endpoint
	t.Run("main health endpoint", func(t *testing.T) {
		resp, err := http.Get(server.URL + "/health")
		require.NoError(t, err)
		defer resp.Body.Close()

		assert.Equal(t, http.StatusOK, resp.StatusCode)
		assert.Equal(t, "application/json", resp.Header.Get("Content-Type"))

		var result map[string]string
		err = json.NewDecoder(resp.Body).Decode(&result)
		require.NoError(t, err)
		assert.Equal(t, "healthy", result["status"])
	})

	// Test readiness endpoint
	t.Run("readiness endpoint", func(t *testing.T) {
		resp, err := http.Get(server.URL + "/health/ready")
		require.NoError(t, err)
		defer resp.Body.Close()

		assert.Equal(t, http.StatusOK, resp.StatusCode)

		var result map[string]interface{}
		err = json.NewDecoder(resp.Body).Decode(&result)
		require.NoError(t, err)
		assert.True(t, result["ready"].(bool))
	})

	// Test liveness endpoint
	t.Run("liveness endpoint", func(t *testing.T) {
		resp, err := http.Get(server.URL + "/health/live")
		require.NoError(t, err)
		defer resp.Body.Close()

		assert.Equal(t, http.StatusOK, resp.StatusCode)

		var result map[string]interface{}
		err = json.NewDecoder(resp.Body).Decode(&result)
		require.NoError(t, err)
		assert.True(t, result["live"].(bool))
	})
}

// TestHealthCheckWithDependencies tests health checks with various dependency states
func TestHealthCheckWithDependencies(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name           string
		setupMocks     func() (*server.HealthCheckService, []MockDependency)
		expectedStatus int
		expectedHealth bool
	}{
		{
			name: "all dependencies healthy",
			setupMocks: func() (*server.HealthCheckService, []MockDependency) {
				config := server.HealthCheckConfig{
					Timeout:         2 * time.Second,
					EnableReadiness: true,
				}
				service := server.NewHealthCheckService(config)

				dep1 := MockDependency{}
				dep1.On("GetName").Return("database")
				dep1.On("IsHealthy", context.Background()).Return(true, nil)

				dep2 := MockDependency{}
				dep2.On("GetName").Return("redis")
				dep2.On("IsHealthy", context.Background()).Return(true, nil)

				service.RegisterDependency(&dep1)
				service.RegisterDependency(&dep2)

				return service, []MockDependency{dep1, dep2}
			},
			expectedStatus: http.StatusOK,
			expectedHealth: true,
		},
		{
			name: "one dependency unhealthy",
			setupMocks: func() (*server.HealthCheckService, []MockDependency) {
				config := server.HealthCheckConfig{
					Timeout:         2 * time.Second,
					EnableReadiness: true,
				}
				service := server.NewHealthCheckService(config)

				dep1 := MockDependency{}
				dep1.On("GetName").Return("database")
				dep1.On("IsHealthy", context.Background()).Return(true, nil)

				dep2 := MockDependency{}
				dep2.On("GetName").Return("redis")
				dep2.On("IsHealthy", context.Background()).Return(false, nil)

				service.RegisterDependency(&dep1)
				service.RegisterDependency(&dep2)

				return service, []MockDependency{dep1, dep2}
			},
			expectedStatus: http.StatusServiceUnavailable,
			expectedHealth: false,
		},
		{
			name: "dependency check error",
			setupMocks: func() (*server.HealthCheckService, []MockDependency) {
				config := server.HealthCheckConfig{
					Timeout:         2 * time.Second,
					EnableReadiness: true,
				}
				service := server.NewHealthCheckService(config)

				dep1 := MockDependency{}
				dep1.On("GetName").Return("database")
				dep1.On("IsHealthy", context.Background()).Return(false, errors.New("connection failed"))

				service.RegisterDependency(&dep1)

				return service, []MockDependency{dep1}
			},
			expectedStatus: http.StatusServiceUnavailable,
			expectedHealth: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			healthService, mocks := tt.setupMocks()

			mux := http.NewServeMux()
			mux.HandleFunc("/health/ready", func(w http.ResponseWriter, r *http.Request) {
				ctx, cancel := context.WithTimeout(r.Context(), 3*time.Second)
				defer cancel()

				ready, err := healthService.ReadinessCheck(ctx)
				statusCode := http.StatusOK
				if err != nil || !ready {
					statusCode = http.StatusServiceUnavailable
				}

				w.Header().Set("Content-Type", "application/json")
				w.WriteHeader(statusCode)
				json.NewEncoder(w).Encode(map[string]interface{}{
					"ready": ready,
					"error": errorString(err),
				})
			})

			server := httptest.NewServer(mux)
			defer server.Close()

			resp, err := http.Get(server.URL + "/health/ready")
			require.NoError(t, err)
			defer resp.Body.Close()

			assert.Equal(t, tt.expectedStatus, resp.StatusCode)

			var result map[string]interface{}
			err = json.NewDecoder(resp.Body).Decode(&result)
			require.NoError(t, err)
			assert.Equal(t, tt.expectedHealth, result["ready"])

			// Verify mock expectations
			for _, mock := range mocks {
				mock.AssertExpectations(t)
			}
		})
	}
}

// TestHealthCheckGRPCService tests gRPC health check service
func TestHealthCheckGRPCService(t *testing.T) {
	t.Parallel()

	// Setup gRPC server with health service
	grpcServer := grpc.NewServer()
	healthServer := health.NewServer()

	// Register a test service
	healthServer.SetServingStatus("test-service", grpc_health_v1.HealthCheckResponse_SERVING)
	healthServer.SetServingStatus("", grpc_health_v1.HealthCheckResponse_SERVING) // Overall health

	grpc_health_v1.RegisterHealthServer(grpcServer, healthServer)

	listener, err := net.Listen("tcp", "localhost:0")
	require.NoError(t, err)
	defer listener.Close()

	go func() {
		grpcServer.Serve(listener)
	}()
	defer grpcServer.Stop()

	// Wait for server to start
	time.Sleep(100 * time.Millisecond)

	// Connect to gRPC server
	conn, err := grpc.Dial(listener.Addr().String(), grpc.WithTransportCredentials(insecure.NewCredentials()))
	require.NoError(t, err)
	defer conn.Close()

	client := grpc_health_v1.NewHealthClient(conn)

	// Test overall health check
	t.Run("overall health check", func(t *testing.T) {
		resp, err := client.Check(context.Background(), &grpc_health_v1.HealthCheckRequest{})
		require.NoError(t, err)
		assert.Equal(t, grpc_health_v1.HealthCheckResponse_SERVING, resp.Status)
	})

	// Test specific service health check
	t.Run("specific service health check", func(t *testing.T) {
		resp, err := client.Check(context.Background(), &grpc_health_v1.HealthCheckRequest{
			Service: "test-service",
		})
		require.NoError(t, err)
		assert.Equal(t, grpc_health_v1.HealthCheckResponse_SERVING, resp.Status)
	})

	// Test unknown service
	t.Run("unknown service", func(t *testing.T) {
		_, err := client.Check(context.Background(), &grpc_health_v1.HealthCheckRequest{
			Service: "unknown-service",
		})
		require.Error(t, err)
		st, ok := status.FromError(err)
		require.True(t, ok)
		assert.Equal(t, codes.NotFound, st.Code())
	})

	// Test health watch (streaming)
	t.Run("health watch", func(t *testing.T) {
		watchClient, err := client.Watch(context.Background(), &grpc_health_v1.HealthCheckRequest{
			Service: "test-service",
		})
		require.NoError(t, err)

		// Should get initial status
		resp, err := watchClient.Recv()
		require.NoError(t, err)
		assert.Equal(t, grpc_health_v1.HealthCheckResponse_SERVING, resp.Status)

		// Change service status
		healthServer.SetServingStatus("test-service", grpc_health_v1.HealthCheckResponse_NOT_SERVING)

		// Should get updated status
		resp, err = watchClient.Recv()
		require.NoError(t, err)
		assert.Equal(t, grpc_health_v1.HealthCheckResponse_NOT_SERVING, resp.Status)

		watchClient.CloseSend()
	})
}

// TestHealthCheckEndpointIntegration tests integration of HTTP and gRPC health checks
func TestHealthCheckEndpointIntegration(t *testing.T) {
	t.Parallel()

	// Setup health check service
	config := server.HealthCheckConfig{
		CheckInterval:   100 * time.Millisecond,
		Timeout:         2 * time.Second,
		EnableReadiness: true,
		EnableLiveness:  true,
	}
	healthService := server.NewHealthCheckService(config)

	// Add some mock checkers
	httpChecker := &MockHealthChecker{}
	httpChecker.On("GetServiceName").Return("http-server")
	httpChecker.On("CheckHealth", context.Background()).Return(nil)

	grpcChecker := &MockHealthChecker{}
	grpcChecker.On("GetServiceName").Return("grpc-server")
	grpcChecker.On("CheckHealth", context.Background()).Return(nil)

	healthService.RegisterChecker(httpChecker)
	healthService.RegisterChecker(grpcChecker)

	// Setup HTTP server with health endpoints
	httpMux := http.NewServeMux()
	setupHealthEndpoints(httpMux, healthService)

	httpServer := &http.Server{Handler: httpMux}
	httpListener, err := net.Listen("tcp", "localhost:0")
	require.NoError(t, err)
	defer httpListener.Close()

	go func() {
		httpServer.Serve(httpListener)
	}()
	defer httpServer.Close()

	// Setup gRPC server with health service
	grpcServer := grpc.NewServer()
	grpcHealthServer := health.NewServer()
	grpc_health_v1.RegisterHealthServer(grpcServer, grpcHealthServer)

	grpcListener, err := net.Listen("tcp", "localhost:0")
	require.NoError(t, err)
	defer grpcListener.Close()

	go func() {
		grpcServer.Serve(grpcListener)
	}()
	defer grpcServer.Stop()

	// Wait for servers to start
	time.Sleep(200 * time.Millisecond)

	// Test HTTP health endpoints
	httpBaseURL := "http://" + httpListener.Addr().String()

	t.Run("HTTP main health", func(t *testing.T) {
		resp, err := http.Get(httpBaseURL + "/health")
		require.NoError(t, err)
		defer resp.Body.Close()
		assert.Equal(t, http.StatusOK, resp.StatusCode)
	})

	t.Run("HTTP readiness", func(t *testing.T) {
		resp, err := http.Get(httpBaseURL + "/health/ready")
		require.NoError(t, err)
		defer resp.Body.Close()
		assert.Equal(t, http.StatusOK, resp.StatusCode)
	})

	t.Run("HTTP liveness", func(t *testing.T) {
		resp, err := http.Get(httpBaseURL + "/health/live")
		require.NoError(t, err)
		defer resp.Body.Close()
		assert.Equal(t, http.StatusOK, resp.StatusCode)
	})

	// Test gRPC health service
	grpcConn, err := grpc.Dial(grpcListener.Addr().String(), grpc.WithTransportCredentials(insecure.NewCredentials()))
	require.NoError(t, err)
	defer grpcConn.Close()

	grpcHealthClient := grpc_health_v1.NewHealthClient(grpcConn)

	t.Run("gRPC health check", func(t *testing.T) {
		resp, err := grpcHealthClient.Check(context.Background(), &grpc_health_v1.HealthCheckRequest{})
		require.NoError(t, err)
		assert.Equal(t, grpc_health_v1.HealthCheckResponse_SERVING, resp.Status)
	})

	httpChecker.AssertExpectations(t)
	grpcChecker.AssertExpectations(t)
}

// TestHealthCheckEndpointFailures tests health check endpoint failure scenarios
func TestHealthCheckEndpointFailures(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name           string
		setupService   func() *server.HealthCheckService
		endpoint       string
		expectedStatus int
	}{
		{
			name: "failing service checker",
			setupService: func() *server.HealthCheckService {
				config := server.HealthCheckConfig{Timeout: 1 * time.Second}
				service := server.NewHealthCheckService(config)

				checker := &MockHealthChecker{}
				checker.On("GetServiceName").Return("failing-service")
				checker.On("CheckHealth", context.Background()).Return(errors.New("service down"))

				service.RegisterChecker(checker)
				return service
			},
			endpoint:       "/health",
			expectedStatus: http.StatusServiceUnavailable,
		},
		{
			name: "timeout checker",
			setupService: func() *server.HealthCheckService {
				config := server.HealthCheckConfig{Timeout: 50 * time.Millisecond}
				service := server.NewHealthCheckService(config)

				checker := &MockHealthChecker{}
				checker.On("GetServiceName").Return("slow-service")
				checker.On("CheckHealth", context.Background()).Return(nil).Run(func(args mock.Arguments) {
					time.Sleep(100 * time.Millisecond) // Longer than timeout
				})

				service.RegisterChecker(checker)
				return service
			},
			endpoint:       "/health",
			expectedStatus: http.StatusServiceUnavailable,
		},
		{
			name: "readiness check with failing dependency",
			setupService: func() *server.HealthCheckService {
				config := server.HealthCheckConfig{
					Timeout:         1 * time.Second,
					EnableReadiness: true,
				}
				service := server.NewHealthCheckService(config)

				dep := &MockDependency{}
				dep.On("GetName").Return("database")
				dep.On("IsHealthy", context.Background()).Return(false, nil)

				service.RegisterDependency(dep)
				return service
			},
			endpoint:       "/health/ready",
			expectedStatus: http.StatusServiceUnavailable,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			healthService := tt.setupService()

			mux := http.NewServeMux()
			setupHealthEndpoints(mux, healthService)

			server := httptest.NewServer(mux)
			defer server.Close()

			resp, err := http.Get(server.URL + tt.endpoint)
			require.NoError(t, err)
			defer resp.Body.Close()

			assert.Equal(t, tt.expectedStatus, resp.StatusCode)
		})
	}
}

// TestHealthCheckEndpointMetrics tests health check endpoint metrics and status
func TestHealthCheckEndpointMetrics(t *testing.T) {
	t.Parallel()

	config := server.HealthCheckConfig{
		CheckInterval:   100 * time.Millisecond,
		Timeout:         2 * time.Second,
		EnableReadiness: true,
		EnableLiveness:  true,
	}
	healthService := server.NewHealthCheckService(config)

	// Add mock services
	for i := 0; i < 3; i++ {
		checker := &MockHealthChecker{}
		checker.On("GetServiceName").Return("service-" + string(rune('a'+i)))
		checker.On("CheckHealth", context.Background()).Return(nil)
		healthService.RegisterChecker(checker)
	}

	// Setup HTTP endpoint for metrics
	mux := http.NewServeMux()
	mux.HandleFunc("/health/status", func(w http.ResponseWriter, r *http.Request) {
		status := healthService.GetStatus()
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		json.NewEncoder(w).Encode(status)
	})

	server := httptest.NewServer(mux)
	defer server.Close()

	resp, err := http.Get(server.URL + "/health/status")
	require.NoError(t, err)
	defer resp.Body.Close()

	assert.Equal(t, http.StatusOK, resp.StatusCode)

	var status map[string]interface{}
	err = json.NewDecoder(resp.Body).Decode(&status)
	require.NoError(t, err)

	assert.True(t, status["healthy"].(bool))
	services := status["services"].(map[string]interface{})
	assert.Len(t, services, 3)

	for serviceName, serviceStatus := range services {
		assert.Contains(t, []string{"service-a", "service-b", "service-c"}, serviceName)
		assert.Equal(t, "healthy", serviceStatus)
	}
}

// Helper functions

func setupHealthEndpoints(mux *http.ServeMux, healthService *server.HealthCheckService) {
	mux.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		ctx, cancel := context.WithTimeout(r.Context(), 5*time.Second)
		defer cancel()

		req := &server.HealthCheckRequest{Service: ""}
		resp, err := healthService.Check(ctx, req)

		if err != nil {
			w.WriteHeader(http.StatusServiceUnavailable)
			json.NewEncoder(w).Encode(map[string]string{
				"status": "unhealthy",
				"error":  err.Error(),
			})
			return
		}

		status := "healthy"
		if resp.Status != server.HealthCheckResponse_SERVING {
			status = "unhealthy"
		}

		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		json.NewEncoder(w).Encode(map[string]string{
			"status": status,
		})
	})

	mux.HandleFunc("/health/ready", func(w http.ResponseWriter, r *http.Request) {
		ctx, cancel := context.WithTimeout(r.Context(), 3*time.Second)
		defer cancel()

		ready, err := healthService.ReadinessCheck(ctx)
		statusCode := http.StatusOK
		if err != nil || !ready {
			statusCode = http.StatusServiceUnavailable
		}

		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(statusCode)
		json.NewEncoder(w).Encode(map[string]interface{}{
			"ready": ready,
			"error": errorString(err),
		})
	})

	mux.HandleFunc("/health/live", func(w http.ResponseWriter, r *http.Request) {
		ctx, cancel := context.WithTimeout(r.Context(), 3*time.Second)
		defer cancel()

		live, err := healthService.LivenessCheck(ctx)
		statusCode := http.StatusOK
		if err != nil || !live {
			statusCode = http.StatusServiceUnavailable
		}

		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(statusCode)
		json.NewEncoder(w).Encode(map[string]interface{}{
			"live":  live,
			"error": errorString(err),
		})
	})
}

func errorString(err error) string {
	if err == nil {
		return ""
	}
	return err.Error()
}

// BenchmarkHealthCheckEndpoint benchmarks health check HTTP endpoint
func BenchmarkHealthCheckEndpoint(b *testing.B) {
	config := server.HealthCheckConfig{
		Timeout: 1 * time.Second,
	}
	healthService := server.NewHealthCheckService(config)

	mux := http.NewServeMux()
	mux.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		ctx, cancel := context.WithTimeout(r.Context(), 500*time.Millisecond)
		defer cancel()

		req := &server.HealthCheckRequest{Service: ""}
		resp, err := healthService.Check(ctx, req)

		if err != nil {
			w.WriteHeader(http.StatusServiceUnavailable)
			return
		}

		if resp.Status == server.HealthCheckResponse_SERVING {
			w.WriteHeader(http.StatusOK)
		} else {
			w.WriteHeader(http.StatusServiceUnavailable)
		}
	})

	server := httptest.NewServer(mux)
	defer server.Close()

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		resp, err := http.Get(server.URL + "/health")
		if err != nil {
			b.Fatal(err)
		}
		io.Copy(io.Discard, resp.Body)
		resp.Body.Close()
	}
}

// BenchmarkConcurrentHealthChecks benchmarks concurrent health check requests
func BenchmarkConcurrentHealthChecks(b *testing.B) {
	config := server.HealthCheckConfig{
		Timeout: 1 * time.Second,
	}
	healthService := server.NewHealthCheckService(config)

	// Add some mock checkers
	for i := 0; i < 5; i++ {
		checker := &MockHealthChecker{}
		checker.On("GetServiceName").Return("service-" + string(rune('a'+i)))
		checker.On("CheckHealth", context.Background()).Return(nil).Maybe()
		healthService.RegisterChecker(checker)
	}

	mux := http.NewServeMux()
	setupHealthEndpoints(mux, healthService)

	server := httptest.NewServer(mux)
	defer server.Close()

	b.ResetTimer()
	b.RunParallel(func(pb *testing.PB) {
		for pb.Next() {
			resp, err := http.Get(server.URL + "/health")
			if err != nil {
				b.Error(err)
				continue
			}
			io.Copy(io.Discard, resp.Body)
			resp.Body.Close()
		}
	})
}