package server_test

import (
	"context"
	"errors"
	"fmt"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
	"github.com/yhonda-ohishi/etc_meisai/src/server"
)

type MockHealthChecker struct {
	mock.Mock
}

func (m *MockHealthChecker) CheckHealth(ctx context.Context) error {
	args := m.Called(ctx)
	return args.Error(0)
}

func (m *MockHealthChecker) GetServiceName() string {
	args := m.Called()
	return args.String(0)
}

type MockDependency struct {
	mock.Mock
}

func (m *MockDependency) IsHealthy(ctx context.Context) (bool, error) {
	args := m.Called(ctx)
	return args.Bool(0), args.Error(1)
}

func (m *MockDependency) GetName() string {
	args := m.Called()
	return args.String(0)
}

func TestNewHealthCheckService(t *testing.T) {
	t.Parallel()

	config := server.HealthCheckConfig{
		CheckInterval:    5 * time.Second,
		Timeout:          30 * time.Second,
		EnableReadiness:  true,
		EnableLiveness:   true,
	}

	service := server.NewHealthCheckService(config)

	assert.NotNil(t, service)
}

func TestHealthCheckService_Check(t *testing.T) {
	t.Parallel()

	config := server.HealthCheckConfig{
		CheckInterval: 1 * time.Second,
		Timeout:       5 * time.Second,
	}

	tests := []struct {
		name          string
		serviceName   string
		setupMocks    func() []server.HealthChecker
		expectedCode  codes.Code
		expectedMsg   string
	}{
		{
			name:        "empty service name - overall health",
			serviceName: "",
			setupMocks: func() []server.HealthChecker {
				mockChecker := &MockHealthChecker{}
				mockChecker.On("GetServiceName").Return("test-service")
				mockChecker.On("CheckHealth", mock.Anything).Return(nil)
				return []server.HealthChecker{mockChecker}
			},
			expectedCode: codes.OK,
		},
		{
			name:        "specific service - healthy",
			serviceName: "test-service",
			setupMocks: func() []server.HealthChecker {
				mockChecker := &MockHealthChecker{}
				mockChecker.On("GetServiceName").Return("test-service")
				mockChecker.On("CheckHealth", mock.Anything).Return(nil)
				return []server.HealthChecker{mockChecker}
			},
			expectedCode: codes.OK,
		},
		{
			name:        "specific service - unhealthy",
			serviceName: "test-service",
			setupMocks: func() []server.HealthChecker {
				mockChecker := &MockHealthChecker{}
				mockChecker.On("GetServiceName").Return("test-service")
				mockChecker.On("CheckHealth", mock.Anything).Return(errors.New("service unavailable"))
				return []server.HealthChecker{mockChecker}
			},
			expectedCode: codes.Unavailable,
			expectedMsg:  "service unavailable",
		},
		{
			name:        "service not found",
			serviceName: "non-existent-service",
			setupMocks: func() []server.HealthChecker {
				mockChecker := &MockHealthChecker{}
				mockChecker.On("GetServiceName").Return("different-service")
				return []server.HealthChecker{mockChecker}
			},
			expectedCode: codes.NotFound,
			expectedMsg:  "service not found",
		},
		{
			name:        "no services registered",
			serviceName: "",
			setupMocks: func() []server.HealthChecker {
				return []server.HealthChecker{}
			},
			expectedCode: codes.OK, // Empty system is considered healthy
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			service := server.NewHealthCheckService(config)

			// Register mock checkers
			for _, checker := range tt.setupMocks() {
				service.RegisterChecker(checker)
			}

			ctx := context.Background()
			req := &server.HealthCheckRequest{
				Service: tt.serviceName,
			}

			resp, err := service.Check(ctx, req)

			if tt.expectedCode == codes.OK {
				assert.NoError(t, err)
				assert.NotNil(t, resp)
				assert.Equal(t, server.HealthCheckResponse_SERVING, resp.Status)
			} else {
				assert.Error(t, err)
				st, ok := status.FromError(err)
				assert.True(t, ok)
				assert.Equal(t, tt.expectedCode, st.Code())
				if tt.expectedMsg != "" {
					assert.Contains(t, st.Message(), tt.expectedMsg)
				}
			}

			// Verify mock expectations
			for _, checker := range tt.setupMocks() {
				if mockChecker, ok := checker.(*MockHealthChecker); ok {
					mockChecker.AssertExpectations(t)
				}
			}
		})
	}
}

func TestHealthCheckService_Watch(t *testing.T) {
	t.Parallel()

	config := server.HealthCheckConfig{
		CheckInterval: 100 * time.Millisecond, // Fast interval for testing
		Timeout:       1 * time.Second,
	}
	service := server.NewHealthCheckService(config)

	mockChecker := &MockHealthChecker{}
	mockChecker.On("GetServiceName").Return("test-service")
	// First call succeeds, second call fails, third call succeeds
	mockChecker.On("CheckHealth", mock.Anything).Return(nil).Once()
	mockChecker.On("CheckHealth", mock.Anything).Return(errors.New("temporary failure")).Once()
	mockChecker.On("CheckHealth", mock.Anything).Return(nil).Once()

	service.RegisterChecker(mockChecker)

	mockStream := &MockHealthCheckWatchServer{
		responses: make(chan *server.HealthCheckResponse, 10),
		ctx:       context.Background(),
	}

	req := &server.HealthCheckRequest{
		Service: "test-service",
	}

	// Start watching in a goroutine
	done := make(chan error, 1)
	go func() {
		done <- service.Watch(req, mockStream)
	}()

	// Collect responses
	var responses []*server.HealthCheckResponse
	timeout := time.After(1 * time.Second)

	for len(responses) < 3 {
		select {
		case resp := <-mockStream.responses:
			responses = append(responses, resp)
		case <-timeout:
			t.Fatal("Test timed out waiting for responses")
		}
	}

	// Stop the watch
	mockStream.Cancel()

	// Wait for watch to complete
	select {
	case err := <-done:
		assert.Error(t, err) // Should get context canceled error
	case <-time.After(2 * time.Second):
		t.Fatal("Watch did not complete in time")
	}

	// Verify response sequence
	assert.Len(t, responses, 3)
	assert.Equal(t, server.HealthCheckResponse_SERVING, responses[0].Status)
	assert.Equal(t, server.HealthCheckResponse_NOT_SERVING, responses[1].Status)
	assert.Equal(t, server.HealthCheckResponse_SERVING, responses[2].Status)

	mockChecker.AssertExpectations(t)
}

func TestHealthCheckService_RegisterChecker(t *testing.T) {
	t.Parallel()

	config := server.HealthCheckConfig{}
	service := server.NewHealthCheckService(config)

	mockChecker1 := &MockHealthChecker{}
	mockChecker1.On("GetServiceName").Return("service1")

	mockChecker2 := &MockHealthChecker{}
	mockChecker2.On("GetServiceName").Return("service2")

	service.RegisterChecker(mockChecker1)
	service.RegisterChecker(mockChecker2)

	checkers := service.GetRegisteredCheckers()
	assert.Len(t, checkers, 2)
	assert.Contains(t, checkers, "service1")
	assert.Contains(t, checkers, "service2")
}

func TestHealthCheckService_RegisterDependency(t *testing.T) {
	t.Parallel()

	config := server.HealthCheckConfig{}
	service := server.NewHealthCheckService(config)

	mockDep1 := &MockDependency{}
	mockDep1.On("GetName").Return("database")

	mockDep2 := &MockDependency{}
	mockDep2.On("GetName").Return("redis")

	service.RegisterDependency(mockDep1)
	service.RegisterDependency(mockDep2)

	deps := service.GetRegisteredDependencies()
	assert.Len(t, deps, 2)
	assert.Contains(t, deps, "database")
	assert.Contains(t, deps, "redis")
}

func TestHealthCheckService_CheckDependencies(t *testing.T) {
	t.Parallel()

	config := server.HealthCheckConfig{
		Timeout: 5 * time.Second,
	}

	tests := []struct {
		name           string
		dependencies   []server.Dependency
		expectedHealthy bool
		expectedError  bool
	}{
		{
			name: "all dependencies healthy",
			dependencies: func() []server.Dependency {
				mockDep1 := &MockDependency{}
				mockDep1.On("GetName").Return("database")
				mockDep1.On("IsHealthy", mock.Anything).Return(true, nil)

				mockDep2 := &MockDependency{}
				mockDep2.On("GetName").Return("redis")
				mockDep2.On("IsHealthy", mock.Anything).Return(true, nil)

				return []server.Dependency{mockDep1, mockDep2}
			}(),
			expectedHealthy: true,
		},
		{
			name: "one dependency unhealthy",
			dependencies: func() []server.Dependency {
				mockDep1 := &MockDependency{}
				mockDep1.On("GetName").Return("database")
				mockDep1.On("IsHealthy", mock.Anything).Return(true, nil)

				mockDep2 := &MockDependency{}
				mockDep2.On("GetName").Return("redis")
				mockDep2.On("IsHealthy", mock.Anything).Return(false, nil)

				return []server.Dependency{mockDep1, mockDep2}
			}(),
			expectedHealthy: false,
		},
		{
			name: "dependency check error",
			dependencies: func() []server.Dependency {
				mockDep := &MockDependency{}
				mockDep.On("GetName").Return("database")
				mockDep.On("IsHealthy", mock.Anything).Return(false, errors.New("connection failed"))

				return []server.Dependency{mockDep}
			}(),
			expectedError: true,
		},
		{
			name:            "no dependencies",
			dependencies:    []server.Dependency{},
			expectedHealthy: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			service := server.NewHealthCheckService(config)

			for _, dep := range tt.dependencies {
				service.RegisterDependency(dep)
			}

			ctx := context.Background()
			healthy, err := service.CheckDependencies(ctx)

			if tt.expectedError {
				assert.Error(t, err)
			} else {
				assert.NoError(t, err)
				assert.Equal(t, tt.expectedHealthy, healthy)
			}

			// Verify mock expectations
			for _, dep := range tt.dependencies {
				if mockDep, ok := dep.(*MockDependency); ok {
					mockDep.AssertExpectations(t)
				}
			}
		})
	}
}

func TestHealthCheckService_ReadinessCheck(t *testing.T) {
	t.Parallel()

	config := server.HealthCheckConfig{
		EnableReadiness: true,
		Timeout:         5 * time.Second,
	}

	tests := []struct {
		name          string
		setupMocks    func() ([]server.HealthChecker, []server.Dependency)
		expectedReady bool
		expectedError bool
	}{
		{
			name: "all services and dependencies ready",
			setupMocks: func() ([]server.HealthChecker, []server.Dependency) {
				checker := &MockHealthChecker{}
				checker.On("GetServiceName").Return("api")
				checker.On("CheckHealth", mock.Anything).Return(nil)

				dep := &MockDependency{}
				dep.On("GetName").Return("database")
				dep.On("IsHealthy", mock.Anything).Return(true, nil)

				return []server.HealthChecker{checker}, []server.Dependency{dep}
			},
			expectedReady: true,
		},
		{
			name: "service not ready",
			setupMocks: func() ([]server.HealthChecker, []server.Dependency) {
				checker := &MockHealthChecker{}
				checker.On("GetServiceName").Return("api")
				checker.On("CheckHealth", mock.Anything).Return(errors.New("not ready"))

				return []server.HealthChecker{checker}, []server.Dependency{}
			},
			expectedReady: false,
		},
		{
			name: "dependency not ready",
			setupMocks: func() ([]server.HealthChecker, []server.Dependency) {
				dep := &MockDependency{}
				dep.On("GetName").Return("database")
				dep.On("IsHealthy", mock.Anything).Return(false, nil)

				return []server.HealthChecker{}, []server.Dependency{dep}
			},
			expectedReady: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			service := server.NewHealthCheckService(config)

			checkers, deps := tt.setupMocks()
			for _, checker := range checkers {
				service.RegisterChecker(checker)
			}
			for _, dep := range deps {
				service.RegisterDependency(dep)
			}

			ctx := context.Background()
			ready, err := service.ReadinessCheck(ctx)

			if tt.expectedError {
				assert.Error(t, err)
			} else {
				assert.NoError(t, err)
				assert.Equal(t, tt.expectedReady, ready)
			}

			// Verify mock expectations
			for _, checker := range checkers {
				if mockChecker, ok := checker.(*MockHealthChecker); ok {
					mockChecker.AssertExpectations(t)
				}
			}
			for _, dep := range deps {
				if mockDep, ok := dep.(*MockDependency); ok {
					mockDep.AssertExpectations(t)
				}
			}
		})
	}
}

func TestHealthCheckService_LivenessCheck(t *testing.T) {
	t.Parallel()

	config := server.HealthCheckConfig{
		EnableLiveness: true,
		Timeout:        5 * time.Second,
	}

	tests := []struct {
		name         string
		setupMocks   func() []server.HealthChecker
		expectedLive bool
	}{
		{
			name: "service alive",
			setupMocks: func() []server.HealthChecker {
				checker := &MockHealthChecker{}
				checker.On("GetServiceName").Return("api")
				checker.On("CheckHealth", mock.Anything).Return(nil)
				return []server.HealthChecker{checker}
			},
			expectedLive: true,
		},
		{
			name: "service dead",
			setupMocks: func() []server.HealthChecker {
				checker := &MockHealthChecker{}
				checker.On("GetServiceName").Return("api")
				checker.On("CheckHealth", mock.Anything).Return(errors.New("service dead"))
				return []server.HealthChecker{checker}
			},
			expectedLive: false,
		},
		{
			name: "no services - considered alive",
			setupMocks: func() []server.HealthChecker {
				return []server.HealthChecker{}
			},
			expectedLive: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			service := server.NewHealthCheckService(config)

			for _, checker := range tt.setupMocks() {
				service.RegisterChecker(checker)
			}

			ctx := context.Background()
			live, err := service.LivenessCheck(ctx)

			assert.NoError(t, err)
			assert.Equal(t, tt.expectedLive, live)

			// Verify mock expectations
			for _, checker := range tt.setupMocks() {
				if mockChecker, ok := checker.(*MockHealthChecker); ok {
					mockChecker.AssertExpectations(t)
				}
			}
		})
	}
}

func TestHealthCheckService_ContextTimeout(t *testing.T) {
	t.Parallel()

	config := server.HealthCheckConfig{
		Timeout: 5 * time.Second,
	}
	service := server.NewHealthCheckService(config)

	mockChecker := &MockHealthChecker{}
	mockChecker.On("GetServiceName").Return("slow-service")
	mockChecker.On("CheckHealth", mock.Anything).Return(nil).Run(func(args mock.Arguments) {
		ctx := args.Get(0).(context.Context)
		select {
		case <-time.After(200 * time.Millisecond):
			// Simulate slow operation
		case <-ctx.Done():
			// Context was cancelled
		}
	})

	service.RegisterChecker(mockChecker)

	// Create context with very short timeout
	ctx, cancel := context.WithTimeout(context.Background(), 50*time.Millisecond)
	defer cancel()

	req := &server.HealthCheckRequest{
		Service: "slow-service",
	}

	_, err := service.Check(ctx, req)
	assert.Error(t, err)
	assert.Contains(t, err.Error(), "deadline exceeded")
}

func TestHealthCheckService_ConcurrentChecks(t *testing.T) {
	t.Parallel()

	config := server.HealthCheckConfig{
		CheckInterval: 100 * time.Millisecond,
		Timeout:       5 * time.Second,
	}
	service := server.NewHealthCheckService(config)

	mockChecker := &MockHealthChecker{}
	mockChecker.On("GetServiceName").Return("concurrent-service")
	mockChecker.On("CheckHealth", mock.Anything).Return(nil).Maybe() // Allow multiple calls

	service.RegisterChecker(mockChecker)

	numGoroutines := 10
	done := make(chan error, numGoroutines)

	// Perform concurrent health checks
	for i := 0; i < numGoroutines; i++ {
		go func() {
			ctx := context.Background()
			req := &server.HealthCheckRequest{
				Service: "concurrent-service",
			}
			_, err := service.Check(ctx, req)
			done <- err
		}()
	}

	// Collect results
	for i := 0; i < numGoroutines; i++ {
		err := <-done
		assert.NoError(t, err)
	}
}

func TestHealthCheckService_GetStatus(t *testing.T) {
	t.Parallel()

	config := server.HealthCheckConfig{}
	service := server.NewHealthCheckService(config)

	mockChecker := &MockHealthChecker{}
	mockChecker.On("GetServiceName").Return("status-service")
	mockChecker.On("CheckHealth", mock.Anything).Return(nil)

	service.RegisterChecker(mockChecker)

	status := service.GetStatus()
	assert.NotNil(t, status)
	assert.Contains(t, status.Services, "status-service")
	assert.True(t, status.Healthy)
}

// Mock stream for testing Watch functionality
type MockHealthCheckWatchServer struct {
	responses chan *server.HealthCheckResponse
	ctx       context.Context
	cancel    context.CancelFunc
}

func (m *MockHealthCheckWatchServer) Send(resp *server.HealthCheckResponse) error {
	select {
	case m.responses <- resp:
		return nil
	case <-m.ctx.Done():
		return m.ctx.Err()
	}
}

func (m *MockHealthCheckWatchServer) Context() context.Context {
	if m.ctx == nil {
		m.ctx, m.cancel = context.WithCancel(context.Background())
	}
	return m.ctx
}

func (m *MockHealthCheckWatchServer) Cancel() {
	if m.cancel != nil {
		m.cancel()
	}
}

// Benchmark tests
func BenchmarkHealthCheckService_Check(b *testing.B) {
	config := server.HealthCheckConfig{
		Timeout: 5 * time.Second,
	}
	service := server.NewHealthCheckService(config)

	mockChecker := &MockHealthChecker{}
	mockChecker.On("GetServiceName").Return("benchmark-service")
	mockChecker.On("CheckHealth", mock.Anything).Return(nil)

	service.RegisterChecker(mockChecker)

	ctx := context.Background()
	req := &server.HealthCheckRequest{
		Service: "benchmark-service",
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		service.Check(ctx, req)
	}
}

func BenchmarkHealthCheckService_CheckDependencies(b *testing.B) {
	config := server.HealthCheckConfig{
		Timeout: 5 * time.Second,
	}
	service := server.NewHealthCheckService(config)

	for i := 0; i < 5; i++ {
		mockDep := &MockDependency{}
		mockDep.On("GetName").Return(fmt.Sprintf("dep-%d", i))
		mockDep.On("IsHealthy", mock.Anything).Return(true, nil)
		service.RegisterDependency(mockDep)
	}

	ctx := context.Background()

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		service.CheckDependencies(ctx)
	}
}