package server_test

import (
	"context"
	"fmt"
	"net"
	"os"
	"sync"
	"syscall"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"google.golang.org/grpc"
	"github.com/yhonda-ohishi/etc_meisai/src/server"
)

type MockServer struct {
	mock.Mock
	stopped chan bool
}

func (m *MockServer) Serve(lis net.Listener) error {
	args := m.Called(lis)
	return args.Error(0)
}

func (m *MockServer) Stop() {
	m.Called()
	m.stopped <- true
}

func (m *MockServer) GracefulStop() {
	m.Called()
	m.stopped <- true
}

func TestNewGracefulShutdown(t *testing.T) {
	t.Parallel()

	config := server.GracefulShutdownConfig{
		ShutdownTimeout: 30 * time.Second,
		GracefulFirst:   true,
	}

	gs := server.NewGracefulShutdownV2(config)

	assert.NotNil(t, gs)
}

func TestGracefulShutdown_RegisterServer(t *testing.T) {
	t.Parallel()

	config := server.GracefulShutdownConfig{
		ShutdownTimeout: 5 * time.Second,
	}
	gs := server.NewGracefulShutdownV2(config)

	mockServer := &MockServer{stopped: make(chan bool, 1)}
	gs.RegisterServer("test-server", mockServer)

	// Verify server is registered
	servers := gs.GetRegisteredServers()
	assert.Contains(t, servers, "test-server")
}

func TestGracefulShutdown_RegisterMultipleServers(t *testing.T) {
	t.Parallel()

	config := server.GracefulShutdownConfig{
		ShutdownTimeout: 5 * time.Second,
	}
	gs := server.NewGracefulShutdownV2(config)

	mockServer1 := &MockServer{stopped: make(chan bool, 1)}
	mockServer2 := &MockServer{stopped: make(chan bool, 1)}

	gs.RegisterServer("grpc-server", mockServer1)
	gs.RegisterServer("http-server", mockServer2)

	servers := gs.GetRegisteredServers()
	assert.Contains(t, servers, "grpc-server")
	assert.Contains(t, servers, "http-server")
	assert.Len(t, servers, 2)
}

func TestGracefulShutdown_RegisterCleanupFunc(t *testing.T) {
	t.Parallel()

	config := server.GracefulShutdownConfig{
		ShutdownTimeout: 5 * time.Second,
	}
	gs := server.NewGracefulShutdownV2(config)

	cleanupCalled := false
	cleanupFunc := func() error {
		cleanupCalled = true
		return nil
	}

	gs.RegisterCleanupFunc("test-cleanup", cleanupFunc)

	// Trigger shutdown to test cleanup
	ctx, cancel := context.WithTimeout(context.Background(), 1*time.Second)
	defer cancel()

	err := gs.Shutdown(ctx)
	assert.NoError(t, err)
	assert.True(t, cleanupCalled)
}

func TestGracefulShutdown_RegisterMultipleCleanupFuncs(t *testing.T) {
	t.Parallel()

	config := server.GracefulShutdownConfig{
		ShutdownTimeout: 5 * time.Second,
	}
	gs := server.NewGracefulShutdownV2(config)

	cleanup1Called := false
	cleanup2Called := false

	gs.RegisterCleanupFunc("cleanup1", func() error {
		cleanup1Called = true
		return nil
	})

	gs.RegisterCleanupFunc("cleanup2", func() error {
		cleanup2Called = true
		return nil
	})

	ctx, cancel := context.WithTimeout(context.Background(), 1*time.Second)
	defer cancel()

	err := gs.Shutdown(ctx)
	assert.NoError(t, err)
	assert.True(t, cleanup1Called)
	assert.True(t, cleanup2Called)
}

func TestGracefulShutdown_Shutdown(t *testing.T) {
	t.Parallel()

	config := server.GracefulShutdownConfig{
		ShutdownTimeout: 5 * time.Second,
		GracefulFirst:   true,
	}
	gs := server.NewGracefulShutdownV2(config)

	mockServer := &MockServer{stopped: make(chan bool, 1)}
	mockServer.On("GracefulStop").Return()

	gs.RegisterServer("test-server", mockServer)

	ctx, cancel := context.WithTimeout(context.Background(), 1*time.Second)
	defer cancel()

	err := gs.Shutdown(ctx)
	assert.NoError(t, err)

	mockServer.AssertExpectations(t)
}

func TestGracefulShutdown_ShutdownWithForceStop(t *testing.T) {
	t.Parallel()

	config := server.GracefulShutdownConfig{
		ShutdownTimeout: 5 * time.Second,
		GracefulFirst:   false, // Force stop immediately
	}
	gs := server.NewGracefulShutdownV2(config)

	mockServer := &MockServer{stopped: make(chan bool, 1)}
	mockServer.On("Stop").Return()

	gs.RegisterServer("test-server", mockServer)

	ctx, cancel := context.WithTimeout(context.Background(), 1*time.Second)
	defer cancel()

	err := gs.Shutdown(ctx)
	assert.NoError(t, err)

	mockServer.AssertExpectations(t)
}

func TestGracefulShutdown_ShutdownTimeout(t *testing.T) {
	t.Parallel()

	config := server.GracefulShutdownConfig{
		ShutdownTimeout: 100 * time.Millisecond, // Very short timeout
		GracefulFirst:   true,
	}
	gs := server.NewGracefulShutdownV2(config)

	// Mock server that doesn't stop gracefully
	mockServer := &MockServer{stopped: make(chan bool, 1)}
	mockServer.On("GracefulStop").Return().Run(func(args mock.Arguments) {
		// Simulate a server that takes too long to stop gracefully
		time.Sleep(200 * time.Millisecond)
		mockServer.stopped <- true
	})
	mockServer.On("Stop").Return()

	gs.RegisterServer("slow-server", mockServer)

	ctx, cancel := context.WithTimeout(context.Background(), 1*time.Second)
	defer cancel()

	start := time.Now()
	err := gs.Shutdown(ctx)
	duration := time.Since(start)

	// Should fallback to force stop after timeout
	assert.NoError(t, err)
	assert.True(t, duration < 500*time.Millisecond) // Should not wait full timeout
	mockServer.AssertExpectations(t)
}

func TestGracefulShutdown_ContextCancellation(t *testing.T) {
	t.Parallel()

	config := server.GracefulShutdownConfig{
		ShutdownTimeout: 5 * time.Second,
	}
	gs := server.NewGracefulShutdownV2(config)

	mockServer := &MockServer{stopped: make(chan bool, 1)}
	mockServer.On("Stop").Return()

	gs.RegisterServer("test-server", mockServer)

	ctx, cancel := context.WithTimeout(context.Background(), 50*time.Millisecond)
	defer cancel()

	err := gs.Shutdown(ctx)
	assert.Equal(t, context.DeadlineExceeded, err)
}

func TestGracefulShutdown_CleanupError(t *testing.T) {
	t.Parallel()

	config := server.GracefulShutdownConfig{
		ShutdownTimeout: 5 * time.Second,
	}
	gs := server.NewGracefulShutdownV2(config)

	expectedError := assert.AnError
	gs.RegisterCleanupFunc("failing-cleanup", func() error {
		return expectedError
	})

	ctx, cancel := context.WithTimeout(context.Background(), 1*time.Second)
	defer cancel()

	err := gs.Shutdown(ctx)
	assert.Error(t, err)
	assert.Contains(t, err.Error(), expectedError.Error())
}

func TestGracefulShutdown_ConcurrentShutdown(t *testing.T) {
	t.Parallel()

	config := server.GracefulShutdownConfig{
		ShutdownTimeout: 5 * time.Second,
	}
	gs := server.NewGracefulShutdownV2(config)

	mockServer := &MockServer{stopped: make(chan bool, 1)}
	mockServer.On("GracefulStop").Return()

	gs.RegisterServer("test-server", mockServer)

	// Try to shutdown concurrently
	numGoroutines := 5
	errors := make(chan error, numGoroutines)

	for i := 0; i < numGoroutines; i++ {
		go func() {
			ctx, cancel := context.WithTimeout(context.Background(), 1*time.Second)
			defer cancel()
			errors <- gs.Shutdown(ctx)
		}()
	}

	// Collect all errors
	var shutdownErrors []error
	for i := 0; i < numGoroutines; i++ {
		err := <-errors
		shutdownErrors = append(shutdownErrors, err)
	}

	// At least one should succeed, others might fail due to already being shut down
	successCount := 0
	for _, err := range shutdownErrors {
		if err == nil {
			successCount++
		}
	}
	assert.True(t, successCount >= 1)
}

func TestGracefulShutdown_IsShutdown(t *testing.T) {
	t.Parallel()

	config := server.GracefulShutdownConfig{
		ShutdownTimeout: 5 * time.Second,
	}
	gs := server.NewGracefulShutdownV2(config)

	// Initially not shutdown
	assert.False(t, gs.IsShutdown())

	ctx, cancel := context.WithTimeout(context.Background(), 1*time.Second)
	defer cancel()

	err := gs.Shutdown(ctx)
	assert.NoError(t, err)

	// Should be shutdown now
	assert.True(t, gs.IsShutdown())
}

func TestGracefulShutdown_WaitForShutdown(t *testing.T) {
	t.Parallel()

	config := server.GracefulShutdownConfig{
		ShutdownTimeout: 5 * time.Second,
		Signals:         []os.Signal{syscall.SIGTERM},
	}
	gs := server.NewGracefulShutdownV2(config)

	shutdownComplete := make(chan bool)

	// Start waiting for shutdown in a goroutine
	go func() {
		gs.WaitForShutdown()
		shutdownComplete <- true
	}()

	// Trigger shutdown manually
	ctx, cancel := context.WithTimeout(context.Background(), 1*time.Second)
	defer cancel()

	err := gs.Shutdown(ctx)
	assert.NoError(t, err)

	// Verify shutdown completed
	select {
	case <-shutdownComplete:
		// Success
	case <-time.After(2 * time.Second):
		t.Fatal("Shutdown did not complete in time")
	}
}

func TestGracefulShutdown_ServerOrder(t *testing.T) {
	t.Parallel()

	config := server.GracefulShutdownConfig{
		ShutdownTimeout: 5 * time.Second,
		GracefulFirst:   true,
	}
	gs := server.NewGracefulShutdownV2(config)

	shutdownOrder := make([]string, 0)
	var shutdownMutex sync.Mutex

	mockServer1 := &MockServer{stopped: make(chan bool, 1)}
	mockServer1.On("GracefulStop").Return().Run(func(args mock.Arguments) {
		shutdownMutex.Lock()
		shutdownOrder = append(shutdownOrder, "server1")
		shutdownMutex.Unlock()
		mockServer1.stopped <- true
	})

	mockServer2 := &MockServer{stopped: make(chan bool, 1)}
	mockServer2.On("GracefulStop").Return().Run(func(args mock.Arguments) {
		shutdownMutex.Lock()
		shutdownOrder = append(shutdownOrder, "server2")
		shutdownMutex.Unlock()
		mockServer2.stopped <- true
	})

	// Register in specific order
	gs.RegisterServer("server1", mockServer1)
	gs.RegisterServer("server2", mockServer2)

	ctx, cancel := context.WithTimeout(context.Background(), 1*time.Second)
	defer cancel()

	err := gs.Shutdown(ctx)
	assert.NoError(t, err)

	// Servers should be shut down (order may vary due to concurrency)
	assert.Len(t, shutdownOrder, 2)
	assert.Contains(t, shutdownOrder, "server1")
	assert.Contains(t, shutdownOrder, "server2")
}

func TestGracefulShutdown_GetMetrics(t *testing.T) {
	t.Parallel()

	config := server.GracefulShutdownConfig{
		ShutdownTimeout: 5 * time.Second,
	}
	gs := server.NewGracefulShutdownV2(config)

	mockServer := &MockServer{stopped: make(chan bool, 1)}
	mockServer.On("GracefulStop").Return()

	gs.RegisterServer("test-server", mockServer)
	gs.RegisterCleanupFunc("test-cleanup", func() error { return nil })

	metrics := gs.GetMetrics()
	assert.Equal(t, 1, metrics.RegisteredServers)
	assert.Equal(t, 1, metrics.RegisteredCleanupFuncs)
	assert.False(t, metrics.IsShutdown)

	ctx, cancel := context.WithTimeout(context.Background(), 1*time.Second)
	defer cancel()

	start := time.Now()
	err := gs.Shutdown(ctx)
	duration := time.Since(start)

	assert.NoError(t, err)

	metrics = gs.GetMetrics()
	assert.True(t, metrics.IsShutdown)
	assert.True(t, metrics.ShutdownDuration > 0)
	assert.True(t, metrics.ShutdownDuration <= duration)
}

func TestGracefulShutdown_RealGRPCServer(t *testing.T) {
	t.Parallel()

	// Create a real gRPC server for integration test
	grpcServer := grpc.NewServer()

	config := server.GracefulShutdownConfig{
		ShutdownTimeout: 5 * time.Second,
		GracefulFirst:   true,
	}
	gs := server.NewGracefulShutdownV2(config)

	// Wrap the real gRPC server
	wrappedServer := server.NewGRPCServerWrapper(grpcServer)
	gs.RegisterServer("grpc-server", wrappedServer)

	ctx, cancel := context.WithTimeout(context.Background(), 1*time.Second)
	defer cancel()

	err := gs.Shutdown(ctx)
	assert.NoError(t, err)
}

// Helper function to create a test listener
func createTestListener(t *testing.T) net.Listener {
	lis, err := net.Listen("tcp", "localhost:0")
	assert.NoError(t, err)
	return lis
}

// Benchmark tests
func BenchmarkGracefulShutdown_SingleServer(b *testing.B) {
	config := server.GracefulShutdownConfig{
		ShutdownTimeout: 5 * time.Second,
		GracefulFirst:   true, // Set to true to use GracefulStop
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		gs := server.NewGracefulShutdownV2(config)
		mockServer := &MockServer{stopped: make(chan bool, 1)}
		mockServer.On("GracefulStop").Return()

		gs.RegisterServer("test-server", mockServer)

		ctx, cancel := context.WithTimeout(context.Background(), 100*time.Millisecond)
		gs.Shutdown(ctx)
		cancel()
	}
}

func BenchmarkGracefulShutdown_MultipleServers(b *testing.B) {
	config := server.GracefulShutdownConfig{
		ShutdownTimeout: 5 * time.Second,
		GracefulFirst:   true, // Set to true to use GracefulStop
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		gs := server.NewGracefulShutdownV2(config)

		for j := 0; j < 5; j++ {
			mockServer := &MockServer{stopped: make(chan bool, 1)}
			mockServer.On("GracefulStop").Return()
			gs.RegisterServer(fmt.Sprintf("server-%d", j), mockServer)
		}

		ctx, cancel := context.WithTimeout(context.Background(), 100*time.Millisecond)
		gs.Shutdown(ctx)
		cancel()
	}
}

