package server_test

import (
	"context"
	"fmt"
	"net"
	"net/http"
	"sync"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
	"google.golang.org/grpc/health"
	"google.golang.org/grpc/health/grpc_health_v1"
	"github.com/yhonda-ohishi/etc_meisai/src/server"
)

// TestHTTPAndGRPCSimultaneous tests running HTTP and gRPC servers simultaneously
func TestHTTPAndGRPCSimultaneous(t *testing.T) {
	t.Parallel()

	// Setup HTTP server
	httpMux := http.NewServeMux()
	httpMux.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("HTTP OK"))
	})

	httpServer := &http.Server{
		Handler:      httpMux,
		ReadTimeout:  5 * time.Second,
		WriteTimeout: 5 * time.Second,
	}

	httpListener, err := net.Listen("tcp", "localhost:0")
	require.NoError(t, err)
	defer httpListener.Close()

	// Setup gRPC server
	grpcServer := grpc.NewServer()
	healthServer := health.NewServer()
	grpc_health_v1.RegisterHealthServer(grpcServer, healthServer)

	grpcListener, err := net.Listen("tcp", "localhost:0")
	require.NoError(t, err)
	defer grpcListener.Close()

	// Setup graceful shutdown for both servers
	config := server.GracefulShutdownConfig{
		ShutdownTimeout: 5 * time.Second,
		GracefulFirst:   true,
	}
	gs := server.NewGracefulShutdownV2(config)

	httpWrapper := &HTTPServerWrapper{server: httpServer}
	grpcWrapper := server.NewGRPCServerWrapper(grpcServer)

	gs.RegisterServer("http", httpWrapper)
	gs.RegisterServer("grpc", grpcWrapper)

	// Start both servers
	httpErr := make(chan error, 1)
	grpcErr := make(chan error, 1)

	go func() {
		httpErr <- httpWrapper.Serve(httpListener)
	}()

	go func() {
		grpcErr <- grpcWrapper.Serve(grpcListener)
	}()

	// Wait for servers to be ready
	time.Sleep(200 * time.Millisecond)

	// Test HTTP server
	httpURL := fmt.Sprintf("http://%s/health", httpListener.Addr().String())
	resp, err := http.Get(httpURL)
	require.NoError(t, err)
	assert.Equal(t, http.StatusOK, resp.StatusCode)
	resp.Body.Close()

	// Test gRPC server
	grpcConn, err := grpc.Dial(grpcListener.Addr().String(), grpc.WithTransportCredentials(insecure.NewCredentials()))
	require.NoError(t, err)
	defer grpcConn.Close()

	grpcHealthClient := grpc_health_v1.NewHealthClient(grpcConn)
	healthResp, err := grpcHealthClient.Check(context.Background(), &grpc_health_v1.HealthCheckRequest{})
	require.NoError(t, err)
	assert.Equal(t, grpc_health_v1.HealthCheckResponse_SERVING, healthResp.Status)

	// Verify both servers are registered
	registeredServers := gs.GetRegisteredServers()
	assert.Contains(t, registeredServers, "http")
	assert.Contains(t, registeredServers, "grpc")
	assert.Len(t, registeredServers, 2)

	// Shutdown both servers gracefully
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	shutdownErr := gs.Shutdown(ctx)
	assert.NoError(t, shutdownErr)

	// Wait for both servers to stop
	select {
	case err := <-httpErr:
		assert.Equal(t, http.ErrServerClosed, err)
	case <-time.After(3 * time.Second):
		t.Fatal("HTTP server did not shut down in time")
	}

	select {
	case <-grpcErr:
		// gRPC server stopped (no specific error expected)
	case <-time.After(3 * time.Second):
		t.Fatal("gRPC server did not shut down in time")
	}
}

// TestMultiProtocolServerFailures tests handling of failures in multi-protocol setup
func TestMultiProtocolServerFailures(t *testing.T) {
	t.Parallel()

	t.Run("HTTP fails, gRPC continues", func(t *testing.T) {
		config := server.GracefulShutdownConfig{
			ShutdownTimeout: 2 * time.Second,
			GracefulFirst:   true,
		}
		gs := server.NewGracefulShutdownV2(config)

		// Setup failing HTTP server (invalid address)
		httpServer := &http.Server{}
		httpWrapper := &HTTPServerWrapper{server: httpServer}

		// Setup working gRPC server
		grpcServer := grpc.NewServer()
		grpcListener, err := net.Listen("tcp", "localhost:0")
		require.NoError(t, err)
		defer grpcListener.Close()

		grpcWrapper := server.NewGRPCServerWrapper(grpcServer)

		gs.RegisterServer("http", httpWrapper)
		gs.RegisterServer("grpc", grpcWrapper)

		// Start gRPC server (should succeed)
		grpcErr := make(chan error, 1)
		go func() {
			grpcErr <- grpcWrapper.Serve(grpcListener)
		}()

		time.Sleep(100 * time.Millisecond)

		// Try to create failing listener for HTTP
		invalidListener, err := net.Listen("tcp", "127.0.0.1:99999") // Invalid port
		if err == nil {
			defer invalidListener.Close()
			// If somehow we got a listener, just test normal shutdown
		}

		// Shutdown (should work even if HTTP never started properly)
		ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
		defer cancel()

		shutdownErr := gs.Shutdown(ctx)
		assert.NoError(t, shutdownErr)

		// gRPC should stop cleanly
		select {
		case <-grpcErr:
			// Expected
		case <-time.After(2 * time.Second):
			t.Fatal("gRPC server did not shut down")
		}
	})

	t.Run("gRPC fails, HTTP continues", func(t *testing.T) {
		config := server.GracefulShutdownConfig{
			ShutdownTimeout: 2 * time.Second,
			GracefulFirst:   true,
		}
		gs := server.NewGracefulShutdownV2(config)

		// Setup working HTTP server
		httpMux := http.NewServeMux()
		httpMux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
			w.WriteHeader(http.StatusOK)
		})

		httpServer := &http.Server{Handler: httpMux}
		httpListener, err := net.Listen("tcp", "localhost:0")
		require.NoError(t, err)
		defer httpListener.Close()

		httpWrapper := &HTTPServerWrapper{server: httpServer}

		// Setup gRPC server (will simulate failure)
		grpcServer := grpc.NewServer()
		grpcWrapper := server.NewGRPCServerWrapper(grpcServer)

		gs.RegisterServer("http", httpWrapper)
		gs.RegisterServer("grpc", grpcWrapper)

		// Start HTTP server
		httpErr := make(chan error, 1)
		go func() {
			httpErr <- httpWrapper.Serve(httpListener)
		}()

		time.Sleep(100 * time.Millisecond)

		// Test HTTP server is working
		url := fmt.Sprintf("http://%s/", httpListener.Addr().String())
		resp, err := http.Get(url)
		require.NoError(t, err)
		assert.Equal(t, http.StatusOK, resp.StatusCode)
		resp.Body.Close()

		// Shutdown both
		ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
		defer cancel()

		shutdownErr := gs.Shutdown(ctx)
		assert.NoError(t, shutdownErr)

		// HTTP should stop cleanly
		select {
		case err := <-httpErr:
			assert.Equal(t, http.ErrServerClosed, err)
		case <-time.After(2 * time.Second):
			t.Fatal("HTTP server did not shut down")
		}
	})
}

// TestMultiProtocolHealthChecks tests health checking across protocols
func TestMultiProtocolHealthChecks(t *testing.T) {
	t.Parallel()

	config := server.HealthCheckConfig{
		CheckInterval:   100 * time.Millisecond,
		Timeout:         2 * time.Second,
		EnableReadiness: true,
		EnableLiveness:  true,
	}
	healthService := server.NewHealthCheckService(config)

	// Setup HTTP health checker
	httpChecker := &MockHealthChecker{}
	httpChecker.On("GetServiceName").Return("http-service")
	httpChecker.On("CheckHealth", context.Background()).Return(nil)

	// Setup gRPC health checker
	grpcChecker := &MockHealthChecker{}
	grpcChecker.On("GetServiceName").Return("grpc-service")
	grpcChecker.On("CheckHealth", context.Background()).Return(nil)

	healthService.RegisterChecker(httpChecker)
	healthService.RegisterChecker(grpcChecker)

	// Test overall health
	ctx := context.Background()
	req := &server.HealthCheckRequest{Service: ""}
	resp, err := healthService.Check(ctx, req)
	assert.NoError(t, err)
	assert.Equal(t, server.HealthCheckResponse_SERVING, resp.Status)

	// Test specific service health
	httpReq := &server.HealthCheckRequest{Service: "http-service"}
	httpResp, err := healthService.Check(ctx, httpReq)
	assert.NoError(t, err)
	assert.Equal(t, server.HealthCheckResponse_SERVING, httpResp.Status)

	grpcReq := &server.HealthCheckRequest{Service: "grpc-service"}
	grpcResp, err := healthService.Check(ctx, grpcReq)
	assert.NoError(t, err)
	assert.Equal(t, server.HealthCheckResponse_SERVING, grpcResp.Status)

	// Test readiness (should check both)
	ready, err := healthService.ReadinessCheck(ctx)
	assert.NoError(t, err)
	assert.True(t, ready)

	// Test liveness (should check both)
	live, err := healthService.LivenessCheck(ctx)
	assert.NoError(t, err)
	assert.True(t, live)

	httpChecker.AssertExpectations(t)
	grpcChecker.AssertExpectations(t)
}

// TestMultiProtocolConcurrentOperations tests concurrent operations across protocols
func TestMultiProtocolConcurrentOperations(t *testing.T) {
	t.Parallel()

	numHTTPServers := 3
	numGRPCServers := 3

	config := server.GracefulShutdownConfig{
		ShutdownTimeout: 10 * time.Second,
		GracefulFirst:   true,
	}
	gs := server.NewGracefulShutdownV2(config)

	var httpServers []*HTTPServerWrapper
	var grpcServers []*server.GRPCServerWrapper
	var httpListeners []net.Listener
	var grpcListeners []net.Listener

	// Setup HTTP servers
	for i := 0; i < numHTTPServers; i++ {
		mux := http.NewServeMux()
		serverID := i
		mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
			fmt.Fprintf(w, "HTTP Server %d", serverID)
		})

		httpServer := &http.Server{Handler: mux}
		listener, err := net.Listen("tcp", "localhost:0")
		require.NoError(t, err)

		httpWrapper := &HTTPServerWrapper{server: httpServer}
		httpServers = append(httpServers, httpWrapper)
		httpListeners = append(httpListeners, listener)

		gs.RegisterServer(fmt.Sprintf("http-%d", i), httpWrapper)
	}

	// Setup gRPC servers
	for i := 0; i < numGRPCServers; i++ {
		grpcServer := grpc.NewServer()
		listener, err := net.Listen("tcp", "localhost:0")
		require.NoError(t, err)

		grpcWrapper := server.NewGRPCServerWrapper(grpcServer)
		grpcServers = append(grpcServers, grpcWrapper)
		grpcListeners = append(grpcListeners, listener)

		gs.RegisterServer(fmt.Sprintf("grpc-%d", i), grpcWrapper)
	}

	defer func() {
		for _, listener := range httpListeners {
			listener.Close()
		}
		for _, listener := range grpcListeners {
			listener.Close()
		}
	}()

	// Start all servers concurrently
	var wg sync.WaitGroup
	httpErrors := make([]chan error, numHTTPServers)
	grpcErrors := make([]chan error, numGRPCServers)

	for i := 0; i < numHTTPServers; i++ {
		httpErrors[i] = make(chan error, 1)
		wg.Add(1)
		go func(idx int) {
			defer wg.Done()
			httpErrors[idx] <- httpServers[idx].Serve(httpListeners[idx])
		}(i)
	}

	for i := 0; i < numGRPCServers; i++ {
		grpcErrors[i] = make(chan error, 1)
		wg.Add(1)
		go func(idx int) {
			defer wg.Done()
			grpcErrors[idx] <- grpcServers[idx].Serve(grpcListeners[idx])
		}(i)
	}

	// Wait for servers to be ready
	time.Sleep(300 * time.Millisecond)

	// Test HTTP servers concurrently
	var testWG sync.WaitGroup
	for i, listener := range httpListeners {
		testWG.Add(1)
		go func(idx int, lis net.Listener) {
			defer testWG.Done()
			url := fmt.Sprintf("http://%s/", lis.Addr().String())
			resp, err := http.Get(url)
			assert.NoError(t, err)
			if err == nil {
				assert.Equal(t, http.StatusOK, resp.StatusCode)
				resp.Body.Close()
			}
		}(i, listener)
	}

	// Test gRPC servers concurrently
	for i, listener := range grpcListeners {
		testWG.Add(1)
		go func(idx int, lis net.Listener) {
			defer testWG.Done()
			conn, err := grpc.Dial(lis.Addr().String(), grpc.WithTransportCredentials(insecure.NewCredentials()))
			if err == nil {
				defer conn.Close()
				// Just test that connection works
				assert.NotNil(t, conn)
			}
		}(i, listener)
	}

	testWG.Wait()

	// Verify all servers are registered
	registeredServers := gs.GetRegisteredServers()
	assert.Len(t, registeredServers, numHTTPServers+numGRPCServers)

	// Shutdown all servers
	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()

	shutdownErr := gs.Shutdown(ctx)
	assert.NoError(t, shutdownErr)

	// Wait for all HTTP servers to stop
	for i := 0; i < numHTTPServers; i++ {
		select {
		case err := <-httpErrors[i]:
			assert.Equal(t, http.ErrServerClosed, err)
		case <-time.After(5 * time.Second):
			t.Fatalf("HTTP server %d did not shut down in time", i)
		}
	}

	// Wait for all gRPC servers to stop
	for i := 0; i < numGRPCServers; i++ {
		select {
		case <-grpcErrors[i]:
			// gRPC server stopped
		case <-time.After(5 * time.Second):
			t.Fatalf("gRPC server %d did not shut down in time", i)
		}
	}
}

// TestProtocolSpecificShutdown tests shutting down only specific protocols
func TestProtocolSpecificShutdown(t *testing.T) {
	t.Parallel()

	// This test simulates a scenario where we might want to shutdown
	// servers individually rather than all at once
	config := server.GracefulShutdownConfig{
		ShutdownTimeout: 3 * time.Second,
		GracefulFirst:   true,
	}

	// Create separate shutdown managers for each protocol
	httpGS := server.NewGracefulShutdownV2(config)
	grpcGS := server.NewGracefulShutdownV2(config)

	// Setup HTTP server
	httpMux := http.NewServeMux()
	httpMux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
	})

	httpServer := &http.Server{Handler: httpMux}
	httpListener, err := net.Listen("tcp", "localhost:0")
	require.NoError(t, err)
	defer httpListener.Close()

	httpWrapper := &HTTPServerWrapper{server: httpServer}
	httpGS.RegisterServer("http", httpWrapper)

	// Setup gRPC server
	grpcServer := grpc.NewServer()
	grpcListener, err := net.Listen("tcp", "localhost:0")
	require.NoError(t, err)
	defer grpcListener.Close()

	grpcWrapper := server.NewGRPCServerWrapper(grpcServer)
	grpcGS.RegisterServer("grpc", grpcWrapper)

	// Start both servers
	httpErr := make(chan error, 1)
	grpcErr := make(chan error, 1)

	go func() {
		httpErr <- httpWrapper.Serve(httpListener)
	}()

	go func() {
		grpcErr <- grpcWrapper.Serve(grpcListener)
	}()

	time.Sleep(200 * time.Millisecond)

	// Test both servers are running
	httpURL := fmt.Sprintf("http://%s/", httpListener.Addr().String())
	resp, err := http.Get(httpURL)
	require.NoError(t, err)
	assert.Equal(t, http.StatusOK, resp.StatusCode)
	resp.Body.Close()

	grpcConn, err := grpc.Dial(grpcListener.Addr().String(), grpc.WithTransportCredentials(insecure.NewCredentials()))
	require.NoError(t, err)
	grpcConn.Close()

	// Shutdown HTTP first
	ctx1, cancel1 := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel1()

	httpShutdownErr := httpGS.Shutdown(ctx1)
	assert.NoError(t, httpShutdownErr)

	// Wait for HTTP to stop
	select {
	case err := <-httpErr:
		assert.Equal(t, http.ErrServerClosed, err)
	case <-time.After(3 * time.Second):
		t.Fatal("HTTP server did not shut down")
	}

	// gRPC should still be running
	grpcConn2, err := grpc.Dial(grpcListener.Addr().String(), grpc.WithTransportCredentials(insecure.NewCredentials()))
	require.NoError(t, err)
	grpcConn2.Close()

	// Now shutdown gRPC
	ctx2, cancel2 := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel2()

	grpcShutdownErr := grpcGS.Shutdown(ctx2)
	assert.NoError(t, grpcShutdownErr)

	// Wait for gRPC to stop
	select {
	case <-grpcErr:
		// gRPC stopped
	case <-time.After(3 * time.Second):
		t.Fatal("gRPC server did not shut down")
	}
}

// BenchmarkMultiProtocolStartup benchmarks starting multiple protocols
func BenchmarkMultiProtocolStartup(b *testing.B) {
	config := server.GracefulShutdownConfig{
		ShutdownTimeout: 1 * time.Second,
		GracefulFirst:   true,
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		gs := server.NewGracefulShutdownV2(config)

		// Setup HTTP
		httpServer := &http.Server{Handler: http.NewServeMux()}
		httpListener, err := net.Listen("tcp", "localhost:0")
		if err != nil {
			b.Fatal(err)
		}

		httpWrapper := &HTTPServerWrapper{server: httpServer}
		gs.RegisterServer("http", httpWrapper)

		// Setup gRPC
		grpcServer := grpc.NewServer()
		grpcListener, err := net.Listen("tcp", "localhost:0")
		if err != nil {
			b.Fatal(err)
		}

		grpcWrapper := server.NewGRPCServerWrapper(grpcServer)
		gs.RegisterServer("grpc", grpcWrapper)

		// Start servers
		httpErr := make(chan error, 1)
		grpcErr := make(chan error, 1)

		go func() {
			httpErr <- httpWrapper.Serve(httpListener)
		}()

		go func() {
			grpcErr <- grpcWrapper.Serve(grpcListener)
		}()

		time.Sleep(time.Millisecond) // Brief startup time

		// Shutdown
		ctx, cancel := context.WithTimeout(context.Background(), 200*time.Millisecond)
		gs.Shutdown(ctx)
		cancel()

		// Wait for shutdown
		<-httpErr
		<-grpcErr

		httpListener.Close()
		grpcListener.Close()
	}
}

// BenchmarkMultiProtocolShutdown benchmarks shutting down multiple protocols
func BenchmarkMultiProtocolShutdown(b *testing.B) {
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		config := server.GracefulShutdownConfig{
			ShutdownTimeout: 100 * time.Millisecond,
			GracefulFirst:   true,
		}
		gs := server.NewGracefulShutdownV2(config)

		numServers := 5
		var listeners []net.Listener
		var serverErrors []chan error

		// Create multiple HTTP and gRPC servers
		for j := 0; j < numServers; j++ {
			// HTTP
			httpServer := &http.Server{Handler: http.NewServeMux()}
			httpListener, err := net.Listen("tcp", "localhost:0")
			if err != nil {
				b.Fatal(err)
			}
			listeners = append(listeners, httpListener)

			httpWrapper := &HTTPServerWrapper{server: httpServer}
			gs.RegisterServer(fmt.Sprintf("http-%d", j), httpWrapper)

			httpErr := make(chan error, 1)
			serverErrors = append(serverErrors, httpErr)
			go func(se chan error) {
				se <- httpWrapper.Serve(httpListener)
			}(httpErr)

			// gRPC
			grpcServer := grpc.NewServer()
			grpcListener, err := net.Listen("tcp", "localhost:0")
			if err != nil {
				b.Fatal(err)
			}
			listeners = append(listeners, grpcListener)

			grpcWrapper := server.NewGRPCServerWrapper(grpcServer)
			gs.RegisterServer(fmt.Sprintf("grpc-%d", j), grpcWrapper)

			grpcErr := make(chan error, 1)
			serverErrors = append(serverErrors, grpcErr)
			go func(se chan error) {
				se <- grpcWrapper.Serve(grpcListener)
			}(grpcErr)
		}

		time.Sleep(5 * time.Millisecond) // Brief startup

		// Benchmark the shutdown
		b.StartTimer()
		ctx, cancel := context.WithTimeout(context.Background(), 500*time.Millisecond)
		gs.Shutdown(ctx)
		cancel()
		b.StopTimer()

		// Wait for all to stop
		for _, serverErr := range serverErrors {
			<-serverErr
		}

		// Cleanup
		for _, listener := range listeners {
			listener.Close()
		}
	}
}