package server_test

import (
	"context"
	"fmt"
	"net"
	"net/http"
	"sync"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"github.com/yhonda-ohishi/etc_meisai/src/server"
)

// TestHTTPServerLifecycle tests HTTP server start and graceful shutdown
func TestHTTPServerLifecycle(t *testing.T) {
	t.Parallel()

	// Create test HTTP server
	mux := http.NewServeMux()
	mux.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("OK"))
	})

	httpServer := &http.Server{
		Handler:      mux,
		ReadTimeout:  5 * time.Second,
		WriteTimeout: 5 * time.Second,
		IdleTimeout:  10 * time.Second,
	}

	// Create listener
	listener, err := net.Listen("tcp", "localhost:0")
	require.NoError(t, err)
	defer listener.Close()

	// Setup graceful shutdown
	config := server.GracefulShutdownConfig{
		ShutdownTimeout: 5 * time.Second,
		GracefulFirst:   true,
	}
	gs := server.NewGracefulShutdownV2(config)

	// Create HTTP server wrapper
	httpWrapper := &HTTPServerWrapper{server: httpServer}
	gs.RegisterServer("http", httpWrapper)

	// Start server in goroutine
	serverErr := make(chan error, 1)
	go func() {
		serverErr <- httpWrapper.Serve(listener)
	}()

	// Wait for server to be ready
	time.Sleep(100 * time.Millisecond)

	// Test that server is responding
	url := fmt.Sprintf("http://%s/health", listener.Addr().String())
	resp, err := http.Get(url)
	require.NoError(t, err)
	assert.Equal(t, http.StatusOK, resp.StatusCode)
	resp.Body.Close()

	// Test graceful shutdown
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()

	shutdownErr := gs.Shutdown(ctx)
	assert.NoError(t, shutdownErr)

	// Server should stop gracefully
	select {
	case err := <-serverErr:
		assert.Equal(t, http.ErrServerClosed, err)
	case <-time.After(2 * time.Second):
		t.Fatal("Server did not shut down in time")
	}

	// Verify server is no longer accessible
	_, err = http.Get(url)
	assert.Error(t, err)
}

// TestHTTPServerForceShutdown tests force shutdown when graceful fails
func TestHTTPServerForceShutdown(t *testing.T) {
	t.Parallel()

	// Create test HTTP server with blocking handler
	mux := http.NewServeMux()
	requestStarted := make(chan struct{})
	requestFinished := make(chan struct{})

	mux.HandleFunc("/slow", func(w http.ResponseWriter, r *http.Request) {
		close(requestStarted)
		<-requestFinished // Block until we tell it to finish
		w.WriteHeader(http.StatusOK)
	})

	httpServer := &http.Server{
		Handler:      mux,
		ReadTimeout:  10 * time.Second,
		WriteTimeout: 10 * time.Second,
	}

	listener, err := net.Listen("tcp", "localhost:0")
	require.NoError(t, err)
	defer listener.Close()

	// Setup graceful shutdown with very short timeout
	config := server.GracefulShutdownConfig{
		ShutdownTimeout: 100 * time.Millisecond, // Very short timeout
		GracefulFirst:   true,
	}
	gs := server.NewGracefulShutdownV2(config)

	httpWrapper := &HTTPServerWrapper{server: httpServer}
	gs.RegisterServer("http", httpWrapper)

	// Start server
	serverErr := make(chan error, 1)
	go func() {
		serverErr <- httpWrapper.Serve(listener)
	}()

	time.Sleep(50 * time.Millisecond)

	// Start a slow request that will block graceful shutdown
	go func() {
		url := fmt.Sprintf("http://%s/slow", listener.Addr().String())
		http.Get(url) // This will be interrupted
	}()

	// Wait for request to start
	<-requestStarted

	// Attempt graceful shutdown - should timeout and force stop
	ctx, cancel := context.WithTimeout(context.Background(), 1*time.Second)
	defer cancel()

	start := time.Now()
	shutdownErr := gs.Shutdown(ctx)
	duration := time.Since(start)

	// Should complete quickly due to force stop
	assert.True(t, duration < 500*time.Millisecond)
	assert.NoError(t, shutdownErr) // Force stop should not return error

	close(requestFinished) // Allow blocked request to finish

	// Server should stop
	select {
	case <-serverErr:
		// Server stopped (may be graceful or forced)
	case <-time.After(1 * time.Second):
		t.Fatal("Server did not shut down")
	}
}

// TestServerStartFailure tests handling of server start failures
func TestServerStartFailure(t *testing.T) {
	t.Parallel()

	// Create server that will fail to start (binding to unavailable port)
	httpServer := &http.Server{}

	// Create a listener and close it immediately to simulate port being taken
	tempListener, err := net.Listen("tcp", "localhost:0")
	require.NoError(t, err)
	addr := tempListener.Addr().String()
	tempListener.Close()

	// Try to create another listener on the same address (should fail)
	_, err = net.Listen("tcp", addr)
	assert.Error(t, err) // Verify the port is indeed unavailable

	config := server.GracefulShutdownConfig{
		ShutdownTimeout: 1 * time.Second,
	}
	gs := server.NewGracefulShutdownV2(config)

	httpWrapper := &HTTPServerWrapper{server: httpServer}
	gs.RegisterServer("http", httpWrapper)

	// Try to start server on unavailable address
	listener, err := net.Listen("tcp", addr)
	if err == nil {
		// If we somehow got the listener, test normal operation
		defer listener.Close()

		serverErr := make(chan error, 1)
		go func() {
			serverErr <- httpWrapper.Serve(listener)
		}()

		ctx, cancel := context.WithTimeout(context.Background(), 1*time.Second)
		defer cancel()

		gs.Shutdown(ctx)
		<-serverErr
	} else {
		// Expected: listener creation failed
		assert.Error(t, err)
	}
}

// TestConcurrentServerLifecycle tests multiple servers starting and stopping concurrently
func TestConcurrentServerLifecycle(t *testing.T) {
	t.Parallel()

	numServers := 5
	servers := make([]*HTTPServerWrapper, numServers)
	listeners := make([]net.Listener, numServers)

	config := server.GracefulShutdownConfig{
		ShutdownTimeout: 5 * time.Second,
		GracefulFirst:   true,
	}
	gs := server.NewGracefulShutdownV2(config)

	// Create multiple HTTP servers
	for i := 0; i < numServers; i++ {
		mux := http.NewServeMux()
		mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
			fmt.Fprintf(w, "Server %d", i)
		})

		httpServer := &http.Server{
			Handler: mux,
		}

		listener, err := net.Listen("tcp", "localhost:0")
		require.NoError(t, err)

		servers[i] = &HTTPServerWrapper{server: httpServer}
		listeners[i] = listener

		gs.RegisterServer(fmt.Sprintf("http-%d", i), servers[i])
	}

	defer func() {
		for _, listener := range listeners {
			listener.Close()
		}
	}()

	// Start all servers concurrently
	var wg sync.WaitGroup
	serverErrors := make([]chan error, numServers)

	for i := 0; i < numServers; i++ {
		serverErrors[i] = make(chan error, 1)
		wg.Add(1)
		go func(idx int) {
			defer wg.Done()
			serverErrors[idx] <- servers[idx].Serve(listeners[idx])
		}(i)
	}

	// Wait for servers to be ready
	time.Sleep(200 * time.Millisecond)

	// Test that all servers are responding
	for _, listener := range listeners {
		url := fmt.Sprintf("http://%s/", listener.Addr().String())
		resp, err := http.Get(url)
		require.NoError(t, err)
		assert.Equal(t, http.StatusOK, resp.StatusCode)
		resp.Body.Close()
	}

	// Shutdown all servers
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	shutdownErr := gs.Shutdown(ctx)
	assert.NoError(t, shutdownErr)

	// Wait for all servers to stop
	for i := 0; i < numServers; i++ {
		select {
		case err := <-serverErrors[i]:
			assert.Equal(t, http.ErrServerClosed, err)
		case <-time.After(3 * time.Second):
			t.Fatalf("Server %d did not shut down in time", i)
		}
	}
}

// TestServerRestartCycle tests restarting servers after shutdown
func TestServerRestartCycle(t *testing.T) {
	t.Parallel()

	mux := http.NewServeMux()
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("OK"))
	})

	// First lifecycle
	httpServer1 := &http.Server{Handler: mux}
	listener1, err := net.Listen("tcp", "localhost:0")
	require.NoError(t, err)
	defer listener1.Close()

	config := server.GracefulShutdownConfig{
		ShutdownTimeout: 2 * time.Second,
		GracefulFirst:   true,
	}
	gs1 := server.NewGracefulShutdownV2(config)

	httpWrapper1 := &HTTPServerWrapper{server: httpServer1}
	gs1.RegisterServer("http", httpWrapper1)

	// Start first server
	serverErr1 := make(chan error, 1)
	go func() {
		serverErr1 <- httpWrapper1.Serve(listener1)
	}()

	time.Sleep(100 * time.Millisecond)

	// Test first server
	url1 := fmt.Sprintf("http://%s/", listener1.Addr().String())
	resp, err := http.Get(url1)
	require.NoError(t, err)
	assert.Equal(t, http.StatusOK, resp.StatusCode)
	resp.Body.Close()

	// Shutdown first server
	ctx1, cancel1 := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel1()

	shutdownErr1 := gs1.Shutdown(ctx1)
	assert.NoError(t, shutdownErr1)

	<-serverErr1 // Wait for first server to stop

	// Start second server on different port (simulating restart)
	httpServer2 := &http.Server{Handler: mux}
	listener2, err := net.Listen("tcp", "localhost:0")
	require.NoError(t, err)
	defer listener2.Close()

	gs2 := server.NewGracefulShutdownV2(config)
	httpWrapper2 := &HTTPServerWrapper{server: httpServer2}
	gs2.RegisterServer("http", httpWrapper2)

	serverErr2 := make(chan error, 1)
	go func() {
		serverErr2 <- httpWrapper2.Serve(listener2)
	}()

	time.Sleep(100 * time.Millisecond)

	// Test second server
	url2 := fmt.Sprintf("http://%s/", listener2.Addr().String())
	resp, err = http.Get(url2)
	require.NoError(t, err)
	assert.Equal(t, http.StatusOK, resp.StatusCode)
	resp.Body.Close()

	// Shutdown second server
	ctx2, cancel2 := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel2()

	shutdownErr2 := gs2.Shutdown(ctx2)
	assert.NoError(t, shutdownErr2)

	<-serverErr2 // Wait for second server to stop
}

// HTTPServerWrapper implements the Server interface for http.Server
type HTTPServerWrapper struct {
	server *http.Server
}

func (w *HTTPServerWrapper) Serve(lis net.Listener) error {
	return w.server.Serve(lis)
}

func (w *HTTPServerWrapper) GracefulStop() {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	w.server.Shutdown(ctx)
}

func (w *HTTPServerWrapper) Stop() {
	w.server.Close()
}

// BenchmarkHTTPServerLifecycle benchmarks server start/stop cycle
func BenchmarkHTTPServerLifecycle(b *testing.B) {
	mux := http.NewServeMux()
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
	})

	config := server.GracefulShutdownConfig{
		ShutdownTimeout: 1 * time.Second,
		GracefulFirst:   true,
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		httpServer := &http.Server{Handler: mux}
		listener, err := net.Listen("tcp", "localhost:0")
		if err != nil {
			b.Fatal(err)
		}

		gs := server.NewGracefulShutdownV2(config)
		httpWrapper := &HTTPServerWrapper{server: httpServer}
		gs.RegisterServer("http", httpWrapper)

		serverErr := make(chan error, 1)
		go func() {
			serverErr <- httpWrapper.Serve(listener)
		}()

		time.Sleep(time.Millisecond) // Brief startup time

		ctx, cancel := context.WithTimeout(context.Background(), 500*time.Millisecond)
		gs.Shutdown(ctx)
		cancel()

		<-serverErr
		listener.Close()
	}
}

// BenchmarkConcurrentServerShutdown benchmarks concurrent server shutdown
func BenchmarkConcurrentServerShutdown(b *testing.B) {
	mux := http.NewServeMux()
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
	})

	config := server.GracefulShutdownConfig{
		ShutdownTimeout: 1 * time.Second,
		GracefulFirst:   true,
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		numServers := 10
		gs := server.NewGracefulShutdownV2(config)

		var listeners []net.Listener
		var serverErrors []chan error

		// Start multiple servers
		for j := 0; j < numServers; j++ {
			httpServer := &http.Server{Handler: mux}
			listener, err := net.Listen("tcp", "localhost:0")
			if err != nil {
				b.Fatal(err)
			}
			listeners = append(listeners, listener)

			httpWrapper := &HTTPServerWrapper{server: httpServer}
			gs.RegisterServer(fmt.Sprintf("http-%d", j), httpWrapper)

			serverErr := make(chan error, 1)
			serverErrors = append(serverErrors, serverErr)

			go func(se chan error) {
				se <- httpWrapper.Serve(listener)
			}(serverErr)
		}

		time.Sleep(10 * time.Millisecond) // Brief startup time

		// Shutdown all servers
		ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
		gs.Shutdown(ctx)
		cancel()

		// Wait for all to stop
		for _, serverErr := range serverErrors {
			<-serverErr
		}

		// Cleanup
		for _, listener := range listeners {
			listener.Close()
		}
	}
}