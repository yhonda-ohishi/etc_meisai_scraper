package server_test

import (
	"context"
	"os"
	"syscall"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"
	"github.com/yhonda-ohishi/etc_meisai/src/server"
)

// TestGracefulShutdownConfigValidation tests configuration validation
func TestGracefulShutdownConfigValidation(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name           string
		config         server.GracefulShutdownConfig
		expectedValid  bool
		expectedEffect func(*testing.T, *server.GracefulShutdownV2)
	}{
		{
			name: "default timeout applied when zero",
			config: server.GracefulShutdownConfig{
				ShutdownTimeout: 0, // Should get default 30s
				GracefulFirst:   true,
			},
			expectedValid: true,
			expectedEffect: func(t *testing.T, gs *server.GracefulShutdownV2) {
				metrics := gs.GetMetrics()
				assert.False(t, metrics.IsShutdown)
			},
		},
		{
			name: "custom timeout respected",
			config: server.GracefulShutdownConfig{
				ShutdownTimeout: 10 * time.Second,
				GracefulFirst:   true,
			},
			expectedValid: true,
			expectedEffect: func(t *testing.T, gs *server.GracefulShutdownV2) {
				// Test that custom timeout is used by doing quick shutdown
				ctx, cancel := context.WithTimeout(context.Background(), 1*time.Second)
				defer cancel()

				start := time.Now()
				err := gs.Shutdown(ctx)
				duration := time.Since(start)

				assert.NoError(t, err)
				assert.True(t, duration < 2*time.Second) // Should be much faster than 10s
			},
		},
		{
			name: "graceful first enabled",
			config: server.GracefulShutdownConfig{
				ShutdownTimeout: 1 * time.Second,
				GracefulFirst:   true,
			},
			expectedValid: true,
			expectedEffect: func(t *testing.T, gs *server.GracefulShutdownV2) {
				// Test graceful shutdown behavior
				mockServer := &MockServer{stopped: make(chan bool, 1)}
				mockServer.On("GracefulStop").Return()

				gs.RegisterServer("test", mockServer)

				ctx, cancel := context.WithTimeout(context.Background(), 500*time.Millisecond)
				defer cancel()

				err := gs.Shutdown(ctx)
				assert.NoError(t, err)
				mockServer.AssertExpectations(t)
			},
		},
		{
			name: "graceful first disabled (force stop)",
			config: server.GracefulShutdownConfig{
				ShutdownTimeout: 1 * time.Second,
				GracefulFirst:   false,
			},
			expectedValid: true,
			expectedEffect: func(t *testing.T, gs *server.GracefulShutdownV2) {
				// Test force stop behavior
				mockServer := &MockServer{stopped: make(chan bool, 1)}
				mockServer.On("Stop").Return() // Should call Stop, not GracefulStop

				gs.RegisterServer("test", mockServer)

				ctx, cancel := context.WithTimeout(context.Background(), 500*time.Millisecond)
				defer cancel()

				err := gs.Shutdown(ctx)
				assert.NoError(t, err)
				mockServer.AssertExpectations(t)
			},
		},
		{
			name: "custom signals configuration",
			config: server.GracefulShutdownConfig{
				ShutdownTimeout: 1 * time.Second,
				GracefulFirst:   true,
				Signals:         []os.Signal{syscall.SIGTERM, syscall.SIGINT},
			},
			expectedValid: true,
			expectedEffect: func(t *testing.T, gs *server.GracefulShutdownV2) {
				// Just verify it doesn't crash with custom signals
				assert.NotNil(t, gs)
			},
		},
		{
			name: "very short timeout",
			config: server.GracefulShutdownConfig{
				ShutdownTimeout: 1 * time.Millisecond,
				GracefulFirst:   true,
			},
			expectedValid: true,
			expectedEffect: func(t *testing.T, gs *server.GracefulShutdownV2) {
				// Should handle very short timeouts gracefully
				mockServer := &MockServer{stopped: make(chan bool, 1)}
				mockServer.On("GracefulStop").Return().Run(func(args mock.Arguments) {
					time.Sleep(10 * time.Millisecond) // Longer than timeout
				})
				mockServer.On("Stop").Return() // Should be called after timeout

				gs.RegisterServer("test", mockServer)

				ctx, cancel := context.WithTimeout(context.Background(), 100*time.Millisecond)
				defer cancel()

				start := time.Now()
				err := gs.Shutdown(ctx)
				duration := time.Since(start)

				assert.NoError(t, err)
				assert.True(t, duration < 50*time.Millisecond) // Should timeout quickly
			},
		},
		{
			name: "very long timeout",
			config: server.GracefulShutdownConfig{
				ShutdownTimeout: 1 * time.Hour,
				GracefulFirst:   true,
			},
			expectedValid: true,
			expectedEffect: func(t *testing.T, gs *server.GracefulShutdownV2) {
				// Should handle long timeouts without issues
				mockServer := &MockServer{stopped: make(chan bool, 1)}
				mockServer.On("GracefulStop").Return()

				gs.RegisterServer("test", mockServer)

				ctx, cancel := context.WithTimeout(context.Background(), 100*time.Millisecond)
				defer cancel()

				err := gs.Shutdown(ctx)
				assert.NoError(t, err) // Should complete quickly despite long internal timeout
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			gs := server.NewGracefulShutdownV2(tt.config)

			if tt.expectedValid {
				require.NotNil(t, gs)
				if tt.expectedEffect != nil {
					tt.expectedEffect(t, gs)
				}
			} else {
				assert.Nil(t, gs)
			}
		})
	}
}

// TestHealthCheckConfigValidation tests health check configuration validation
func TestHealthCheckConfigValidation(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name           string
		config         server.HealthCheckConfig
		expectedValid  bool
		expectedEffect func(*testing.T, *server.HealthCheckService)
	}{
		{
			name: "default config",
			config: server.HealthCheckConfig{},
			expectedValid: true,
			expectedEffect: func(t *testing.T, service *server.HealthCheckService) {
				assert.NotNil(t, service)

				// Test basic health check
				ctx := context.Background()
				req := &server.HealthCheckRequest{Service: ""}
				resp, err := service.Check(ctx, req)
				assert.NoError(t, err)
				assert.Equal(t, server.HealthCheckResponse_SERVING, resp.Status)
			},
		},
		{
			name: "custom intervals",
			config: server.HealthCheckConfig{
				CheckInterval: 100 * time.Millisecond,
				Timeout:       5 * time.Second,
			},
			expectedValid: true,
			expectedEffect: func(t *testing.T, service *server.HealthCheckService) {
				// Test with custom intervals
				mockChecker := &MockHealthChecker{}
				mockChecker.On("GetServiceName").Return("test-service")
				mockChecker.On("CheckHealth", context.Background()).Return(nil)

				service.RegisterChecker(mockChecker)

				ctx := context.Background()
				req := &server.HealthCheckRequest{Service: "test-service"}
				resp, err := service.Check(ctx, req)
				assert.NoError(t, err)
				assert.Equal(t, server.HealthCheckResponse_SERVING, resp.Status)
			},
		},
		{
			name: "readiness enabled",
			config: server.HealthCheckConfig{
				EnableReadiness: true,
				Timeout:         1 * time.Second,
			},
			expectedValid: true,
			expectedEffect: func(t *testing.T, service *server.HealthCheckService) {
				ctx := context.Background()
				ready, err := service.ReadinessCheck(ctx)
				assert.NoError(t, err)
				assert.True(t, ready) // Should be ready by default
			},
		},
		{
			name: "liveness enabled",
			config: server.HealthCheckConfig{
				EnableLiveness: true,
				Timeout:        1 * time.Second,
			},
			expectedValid: true,
			expectedEffect: func(t *testing.T, service *server.HealthCheckService) {
				ctx := context.Background()
				live, err := service.LivenessCheck(ctx)
				assert.NoError(t, err)
				assert.True(t, live) // Should be live by default
			},
		},
		{
			name: "both readiness and liveness enabled",
			config: server.HealthCheckConfig{
				CheckInterval:   200 * time.Millisecond,
				Timeout:         2 * time.Second,
				EnableReadiness: true,
				EnableLiveness:  true,
			},
			expectedValid: true,
			expectedEffect: func(t *testing.T, service *server.HealthCheckService) {
				ctx := context.Background()

				ready, err := service.ReadinessCheck(ctx)
				assert.NoError(t, err)
				assert.True(t, ready)

				live, err := service.LivenessCheck(ctx)
				assert.NoError(t, err)
				assert.True(t, live)
			},
		},
		{
			name: "very short timeout",
			config: server.HealthCheckConfig{
				Timeout: 1 * time.Millisecond,
			},
			expectedValid: true,
			expectedEffect: func(t *testing.T, service *server.HealthCheckService) {
				// Should handle very short timeouts
				mockChecker := &MockHealthChecker{}
				mockChecker.On("GetServiceName").Return("slow-service")
				mockChecker.On("CheckHealth", context.Background()).Return(nil).Run(func(args mock.Arguments) {
					time.Sleep(10 * time.Millisecond) // Longer than timeout
				})

				service.RegisterChecker(mockChecker)

				ctx, cancel := context.WithTimeout(context.Background(), 5*time.Millisecond)
				defer cancel()

				req := &server.HealthCheckRequest{Service: "slow-service"}
				_, err := service.Check(ctx, req)
				assert.Error(t, err) // Should timeout
			},
		},
		{
			name: "zero check interval (disabled watching)",
			config: server.HealthCheckConfig{
				CheckInterval: 0,
				Timeout:       1 * time.Second,
			},
			expectedValid: true,
			expectedEffect: func(t *testing.T, service *server.HealthCheckService) {
				// Should still work for direct checks
				ctx := context.Background()
				req := &server.HealthCheckRequest{Service: ""}
				resp, err := service.Check(ctx, req)
				assert.NoError(t, err)
				assert.Equal(t, server.HealthCheckResponse_SERVING, resp.Status)
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			service := server.NewHealthCheckService(tt.config)

			if tt.expectedValid {
				require.NotNil(t, service)
				if tt.expectedEffect != nil {
					tt.expectedEffect(t, service)
				}
			} else {
				assert.Nil(t, service)
			}
		})
	}
}

// TestConfigEdgeCases tests edge cases in configuration
func TestConfigEdgeCases(t *testing.T) {
	t.Parallel()

	t.Run("graceful shutdown with no servers", func(t *testing.T) {
		config := server.GracefulShutdownConfig{
			ShutdownTimeout: 1 * time.Second,
		}
		gs := server.NewGracefulShutdownV2(config)

		ctx, cancel := context.WithTimeout(context.Background(), 500*time.Millisecond)
		defer cancel()

		// Should succeed even with no servers
		err := gs.Shutdown(ctx)
		assert.NoError(t, err)
		assert.True(t, gs.IsShutdown())
	})

	t.Run("health check with no checkers", func(t *testing.T) {
		config := server.HealthCheckConfig{
			Timeout: 1 * time.Second,
		}
		service := server.NewHealthCheckService(config)

		ctx := context.Background()
		req := &server.HealthCheckRequest{Service: ""}
		resp, err := service.Check(ctx, req)

		// Should succeed even with no checkers (empty system is healthy)
		assert.NoError(t, err)
		assert.Equal(t, server.HealthCheckResponse_SERVING, resp.Status)
	})

	t.Run("graceful shutdown multiple calls", func(t *testing.T) {
		config := server.GracefulShutdownConfig{
			ShutdownTimeout: 1 * time.Second,
		}
		gs := server.NewGracefulShutdownV2(config)

		ctx, cancel := context.WithTimeout(context.Background(), 500*time.Millisecond)
		defer cancel()

		// First call should succeed
		err1 := gs.Shutdown(ctx)
		assert.NoError(t, err1)

		// Second call should also succeed (idempotent)
		err2 := gs.Shutdown(ctx)
		assert.NoError(t, err2)

		assert.True(t, gs.IsShutdown())
	})

	t.Run("register after shutdown", func(t *testing.T) {
		config := server.GracefulShutdownConfig{
			ShutdownTimeout: 1 * time.Second,
		}
		gs := server.NewGracefulShutdownV2(config)

		// Shutdown first
		ctx, cancel := context.WithTimeout(context.Background(), 500*time.Millisecond)
		defer cancel()
		err := gs.Shutdown(ctx)
		assert.NoError(t, err)

		// Try to register after shutdown (should be ignored)
		mockServer := &MockServer{stopped: make(chan bool, 1)}
		gs.RegisterServer("late-server", mockServer)

		servers := gs.GetRegisteredServers()
		assert.NotContains(t, servers, "late-server")
	})

	t.Run("health check with failing checker", func(t *testing.T) {
		config := server.HealthCheckConfig{
			Timeout: 1 * time.Second,
		}
		service := server.NewHealthCheckService(config)

		mockChecker := &MockHealthChecker{}
		mockChecker.On("GetServiceName").Return("failing-service")
		mockChecker.On("CheckHealth", context.Background()).Return(assert.AnError)

		service.RegisterChecker(mockChecker)

		ctx := context.Background()
		req := &server.HealthCheckRequest{Service: "failing-service"}
		_, err := service.Check(ctx, req)

		assert.Error(t, err)
		assert.Contains(t, err.Error(), "service unavailable")
	})
}

// TestConfigurationInheritance tests that configurations are properly inherited
func TestConfigurationInheritance(t *testing.T) {
	t.Parallel()

	t.Run("shutdown config inheritance", func(t *testing.T) {
		config := server.GracefulShutdownConfig{
			ShutdownTimeout: 2 * time.Second,
			GracefulFirst:   true,
			Signals:         []os.Signal{syscall.SIGTERM},
		}

		gs := server.NewGracefulShutdownV2(config)

		// Test that the configuration is properly stored and used
		mockServer := &MockServer{stopped: make(chan bool, 1)}
		mockServer.On("GracefulStop").Return() // Should use graceful because GracefulFirst=true

		gs.RegisterServer("test", mockServer)

		ctx, cancel := context.WithTimeout(context.Background(), 1*time.Second)
		defer cancel()

		err := gs.Shutdown(ctx)
		assert.NoError(t, err)
		mockServer.AssertExpectations(t)
	})

	t.Run("health check config inheritance", func(t *testing.T) {
		config := server.HealthCheckConfig{
			CheckInterval:   500 * time.Millisecond,
			Timeout:         3 * time.Second,
			EnableReadiness: true,
			EnableLiveness:  true,
		}

		service := server.NewHealthCheckService(config)

		// Test that all features are enabled
		ctx := context.Background()

		ready, err := service.ReadinessCheck(ctx)
		assert.NoError(t, err)
		assert.True(t, ready)

		live, err := service.LivenessCheck(ctx)
		assert.NoError(t, err)
		assert.True(t, live)
	})
}

// BenchmarkConfigValidation benchmarks configuration validation overhead
func BenchmarkConfigValidation(b *testing.B) {
	config := server.GracefulShutdownConfig{
		ShutdownTimeout: 5 * time.Second,
		GracefulFirst:   true,
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		gs := server.NewGracefulShutdownV2(config)
		_ = gs
	}
}

// BenchmarkHealthCheckConfigValidation benchmarks health check config validation
func BenchmarkHealthCheckConfigValidation(b *testing.B) {
	config := server.HealthCheckConfig{
		CheckInterval:   1 * time.Second,
		Timeout:         5 * time.Second,
		EnableReadiness: true,
		EnableLiveness:  true,
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		service := server.NewHealthCheckService(config)
		_ = service
	}
}