package handlers

import (
	"encoding/json"
	"log"
	"net/http"
	"net/http/httptest"
	"os"
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestNewAccountsHandler(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)
	baseHandler := BaseHandler{
		Logger: logger,
	}

	handler := NewAccountsHandler(baseHandler)

	assert.NotNil(t, handler)
	assert.Equal(t, baseHandler, handler.BaseHandler)
}

func TestAccountsHandler_GetAccounts(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)

	tests := []struct {
		name                   string
		corporateAccounts      string
		personalAccounts       string
		expectedAccountCount   int
		checkResponse          func(*testing.T, *httptest.ResponseRecorder)
	}{
		{
			name:                 "No accounts configured",
			corporateAccounts:    "",
			personalAccounts:     "",
			expectedAccountCount: 0,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response SuccessResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.True(t, response.Success)
				assert.Equal(t, "Accounts retrieved successfully", response.Message)

				data := response.Data.(map[string]interface{})
				assert.Equal(t, float64(0), data["count"])
				accounts := data["accounts"].([]interface{})
				assert.Len(t, accounts, 0)
			},
		},
		{
			name:                 "Only corporate accounts",
			corporateAccounts:    "corp1:password1:1234567890,corp2:password2:0987654321",
			personalAccounts:     "",
			expectedAccountCount: 2,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response SuccessResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.True(t, response.Success)

				data := response.Data.(map[string]interface{})
				assert.Equal(t, float64(2), data["count"])
				accounts := data["accounts"].([]interface{})
				assert.Len(t, accounts, 2)

				// Check first account
				account1 := accounts[0].(map[string]interface{})
				assert.Equal(t, "corp1", account1["id"])
				assert.Equal(t, "corp1", account1["name"])
				assert.Equal(t, "corporate", account1["type"])
				assert.Equal(t, "corp1", account1["username"])
				assert.Equal(t, "1234567890", account1["etc_num"])
				assert.Equal(t, true, account1["is_active"])

				// Check second account
				account2 := accounts[1].(map[string]interface{})
				assert.Equal(t, "corp2", account2["id"])
				assert.Equal(t, "0987654321", account2["etc_num"])
			},
		},
		{
			name:                 "Only personal accounts",
			corporateAccounts:    "",
			personalAccounts:     "personal1:password1:1111111111,personal2:password2",
			expectedAccountCount: 2,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response SuccessResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.True(t, response.Success)

				data := response.Data.(map[string]interface{})
				assert.Equal(t, float64(2), data["count"])
				accounts := data["accounts"].([]interface{})
				assert.Len(t, accounts, 2)

				// Check first account
				account1 := accounts[0].(map[string]interface{})
				assert.Equal(t, "personal1", account1["id"])
				assert.Equal(t, "personal", account1["type"])
				assert.Equal(t, "1111111111", account1["etc_num"])

				// Check second account (no ETC number)
				account2 := accounts[1].(map[string]interface{})
				assert.Equal(t, "personal2", account2["id"])
				assert.Equal(t, "personal", account2["type"])
				// etc_num should not be present when empty
				_, hasETCNum := account2["etc_num"]
				assert.False(t, hasETCNum)
			},
		},
		{
			name:                 "Mixed corporate and personal accounts",
			corporateAccounts:    "corp1:password1:1234567890",
			personalAccounts:     "personal1:password1:2222222222",
			expectedAccountCount: 2,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response SuccessResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.True(t, response.Success)

				data := response.Data.(map[string]interface{})
				assert.Equal(t, float64(2), data["count"])
				accounts := data["accounts"].([]interface{})
				assert.Len(t, accounts, 2)

				// Check that we have one of each type
				var corporateCount, personalCount int
				for _, acc := range accounts {
					account := acc.(map[string]interface{})
					accountType := account["type"].(string)
					if accountType == "corporate" {
						corporateCount++
						assert.Equal(t, "corp1", account["id"])
					} else if accountType == "personal" {
						personalCount++
						assert.Equal(t, "personal1", account["id"])
					}
				}
				assert.Equal(t, 1, corporateCount)
				assert.Equal(t, 1, personalCount)
			},
		},
		{
			name:                 "Accounts with missing parts",
			corporateAccounts:    "corp1:password1:1234567890,invalid_format,corp2:password2",
			personalAccounts:     "personal1,personal2:password2:3333333333",
			expectedAccountCount: 2, // Only corp1 and personal2 should be valid
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response SuccessResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.True(t, response.Success)

				data := response.Data.(map[string]interface{})
				assert.Equal(t, float64(2), data["count"])
				accounts := data["accounts"].([]interface{})
				assert.Len(t, accounts, 2)

				// Check that we have valid accounts only
				validIDs := []string{"corp1", "personal2"}
				for _, acc := range accounts {
					account := acc.(map[string]interface{})
					assert.Contains(t, validIDs, account["id"])
					if account["id"] == "corp1" {
						assert.Equal(t, "corporate", account["type"])
						assert.Equal(t, "1234567890", account["etc_num"])
					} else if account["id"] == "personal2" {
						assert.Equal(t, "personal", account["type"])
						assert.Equal(t, "3333333333", account["etc_num"])
					}
				}
			},
		},
		{
			name:                 "Empty account strings",
			corporateAccounts:    ",,,",
			personalAccounts:     ",",
			expectedAccountCount: 0,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response SuccessResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.True(t, response.Success)

				data := response.Data.(map[string]interface{})
				assert.Equal(t, float64(0), data["count"])
				accounts := data["accounts"].([]interface{})
				assert.Len(t, accounts, 0)
			},
		},
		{
			name:                 "Accounts with special characters",
			corporateAccounts:    "corp-1:pass@word:1234-5678-90,corp_2:pass_word:0987-6543-21",
			personalAccounts:     "",
			expectedAccountCount: 2,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response SuccessResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.True(t, response.Success)

				data := response.Data.(map[string]interface{})
				assert.Equal(t, float64(2), data["count"])
				accounts := data["accounts"].([]interface{})
				assert.Len(t, accounts, 2)

				// Check first account with special characters
				account1 := accounts[0].(map[string]interface{})
				assert.Equal(t, "corp-1", account1["id"])
				assert.Equal(t, "corp-1", account1["username"])
				assert.Equal(t, "1234-5678-90", account1["etc_num"])

				// Check second account with underscores
				account2 := accounts[1].(map[string]interface{})
				assert.Equal(t, "corp_2", account2["id"])
				assert.Equal(t, "0987-6543-21", account2["etc_num"])
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// Set environment variables
			if tt.corporateAccounts != "" {
				os.Setenv("ETC_CORPORATE_ACCOUNTS", tt.corporateAccounts)
			} else {
				os.Unsetenv("ETC_CORPORATE_ACCOUNTS")
			}

			if tt.personalAccounts != "" {
				os.Setenv("ETC_PERSONAL_ACCOUNTS", tt.personalAccounts)
			} else {
				os.Unsetenv("ETC_PERSONAL_ACCOUNTS")
			}

			// Clean up after test
			defer func() {
				os.Unsetenv("ETC_CORPORATE_ACCOUNTS")
				os.Unsetenv("ETC_PERSONAL_ACCOUNTS")
			}()

			handler := &AccountsHandler{
				BaseHandler: BaseHandler{
					Logger:       logger,
					ErrorHandler: NewGRPCErrorHandler(),
				},
			}

			req := httptest.NewRequest(http.MethodGet, "/api/accounts", nil)
			w := httptest.NewRecorder()

			handler.GetAccounts(w, req)

			assert.Equal(t, http.StatusOK, w.Code)
			assert.Equal(t, "application/json", w.Header().Get("Content-Type"))

			if tt.checkResponse != nil {
				tt.checkResponse(t, w)
			}
		})
	}
}

func TestAccount_Structure(t *testing.T) {
	tests := []struct {
		name     string
		account  Account
		expected string
	}{
		{
			name: "Complete account",
			account: Account{
				ID:       "test_account",
				Name:     "Test Account",
				Type:     "corporate",
				Username: "test_user",
				ETCNum:   "1234567890",
				IsActive: true,
			},
			expected: `{"id":"test_account","name":"Test Account","type":"corporate","username":"test_user","etc_num":"1234567890","is_active":true}`,
		},
		{
			name: "Account without ETC number",
			account: Account{
				ID:       "personal_account",
				Name:     "Personal Account",
				Type:     "personal",
				Username: "personal_user",
				ETCNum:   "",
				IsActive: true,
			},
			expected: `{"id":"personal_account","name":"Personal Account","type":"personal","username":"personal_user","is_active":true}`,
		},
		{
			name: "Inactive account",
			account: Account{
				ID:       "inactive_account",
				Name:     "Inactive Account",
				Type:     "corporate",
				Username: "inactive_user",
				ETCNum:   "0000000000",
				IsActive: false,
			},
			expected: `{"id":"inactive_account","name":"Inactive Account","type":"corporate","username":"inactive_user","etc_num":"0000000000","is_active":false}`,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			jsonData, err := json.Marshal(tt.account)
			assert.NoError(t, err)
			assert.JSONEq(t, tt.expected, string(jsonData))

			// Test unmarshaling
			var decoded Account
			err = json.Unmarshal(jsonData, &decoded)
			assert.NoError(t, err)
			assert.Equal(t, tt.account.ID, decoded.ID)
			assert.Equal(t, tt.account.Name, decoded.Name)
			assert.Equal(t, tt.account.Type, decoded.Type)
			assert.Equal(t, tt.account.Username, decoded.Username)
			assert.Equal(t, tt.account.IsActive, decoded.IsActive)
			// ETCNum should match only if not empty
			if tt.account.ETCNum != "" {
				assert.Equal(t, tt.account.ETCNum, decoded.ETCNum)
			}
		})
	}
}

func TestAccountsHandler_EnvironmentVariableHandling(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)

	tests := []struct {
		name      string
		envVar    string
		envValue  string
		checkFunc func(*testing.T, []Account)
	}{
		{
			name:     "Single corporate account",
			envVar:   "ETC_CORPORATE_ACCOUNTS",
			envValue: "single:password:1234567890",
			checkFunc: func(t *testing.T, accounts []Account) {
				assert.Len(t, accounts, 1)
				assert.Equal(t, "single", accounts[0].ID)
				assert.Equal(t, "corporate", accounts[0].Type)
				assert.Equal(t, "1234567890", accounts[0].ETCNum)
			},
		},
		{
			name:     "Multiple personal accounts",
			envVar:   "ETC_PERSONAL_ACCOUNTS",
			envValue: "user1:pass1:1111111111,user2:pass2:2222222222,user3:pass3:3333333333",
			checkFunc: func(t *testing.T, accounts []Account) {
				assert.Len(t, accounts, 3)
				for i, expectedID := range []string{"user1", "user2", "user3"} {
					assert.Equal(t, expectedID, accounts[i].ID)
					assert.Equal(t, "personal", accounts[i].Type)
					assert.True(t, accounts[i].IsActive)
				}
			},
		},
		{
			name:     "Account format with only two parts",
			envVar:   "ETC_CORPORATE_ACCOUNTS",
			envValue: "minimal:password",
			checkFunc: func(t *testing.T, accounts []Account) {
				assert.Len(t, accounts, 1)
				assert.Equal(t, "minimal", accounts[0].ID)
				assert.Equal(t, "corporate", accounts[0].Type)
				assert.Empty(t, accounts[0].ETCNum)
			},
		},
		{
			name:     "Account format with extra parts",
			envVar:   "ETC_PERSONAL_ACCOUNTS",
			envValue: "extended:password:1234567890:extra:parts",
			checkFunc: func(t *testing.T, accounts []Account) {
				assert.Len(t, accounts, 1)
				assert.Equal(t, "extended", accounts[0].ID)
				assert.Equal(t, "personal", accounts[0].Type)
				assert.Equal(t, "1234567890", accounts[0].ETCNum)
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// Clean environment first
			os.Unsetenv("ETC_CORPORATE_ACCOUNTS")
			os.Unsetenv("ETC_PERSONAL_ACCOUNTS")

			// Set the specific environment variable
			os.Setenv(tt.envVar, tt.envValue)
			defer os.Unsetenv(tt.envVar)

			handler := &AccountsHandler{
				BaseHandler: BaseHandler{
					Logger:       logger,
					ErrorHandler: NewGRPCErrorHandler(),
				},
			}

			req := httptest.NewRequest(http.MethodGet, "/api/accounts", nil)
			w := httptest.NewRecorder()

			handler.GetAccounts(w, req)

			assert.Equal(t, http.StatusOK, w.Code)

			var response SuccessResponse
			err := json.NewDecoder(w.Body).Decode(&response)
			assert.NoError(t, err)
			assert.True(t, response.Success)

			data := response.Data.(map[string]interface{})
			accountsData := data["accounts"].([]interface{})

			// Convert to Account structs for easier testing
			var accounts []Account
			for _, accData := range accountsData {
				accMap := accData.(map[string]interface{})
				account := Account{
					ID:       accMap["id"].(string),
					Name:     accMap["name"].(string),
					Type:     accMap["type"].(string),
					Username: accMap["username"].(string),
					IsActive: accMap["is_active"].(bool),
				}
				if etcNum, exists := accMap["etc_num"]; exists && etcNum != nil {
					account.ETCNum = etcNum.(string)
				}
				accounts = append(accounts, account)
			}

			tt.checkFunc(t, accounts)
		})
	}
}

func TestAccountsHandler_ConcurrentAccess(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)

	// Set up environment variables
	os.Setenv("ETC_CORPORATE_ACCOUNTS", "corp1:pass1:1111111111,corp2:pass2:2222222222")
	os.Setenv("ETC_PERSONAL_ACCOUNTS", "pers1:pass1:3333333333")
	defer func() {
		os.Unsetenv("ETC_CORPORATE_ACCOUNTS")
		os.Unsetenv("ETC_PERSONAL_ACCOUNTS")
	}()

	handler := &AccountsHandler{
		BaseHandler: BaseHandler{
			Logger:       logger,
			ErrorHandler: NewGRPCErrorHandler(),
		},
	}

	// Test concurrent access to the handler
	numRequests := 10
	results := make(chan *httptest.ResponseRecorder, numRequests)

	for i := 0; i < numRequests; i++ {
		go func() {
			req := httptest.NewRequest(http.MethodGet, "/api/accounts", nil)
			w := httptest.NewRecorder()
			handler.GetAccounts(w, req)
			results <- w
		}()
	}

	// Collect all results
	for i := 0; i < numRequests; i++ {
		w := <-results
		assert.Equal(t, http.StatusOK, w.Code)

		var response SuccessResponse
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.True(t, response.Success)

		data := response.Data.(map[string]interface{})
		assert.Equal(t, float64(3), data["count"]) // 2 corporate + 1 personal
	}
}

func TestAccountsHandler_EdgeCases(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)

	tests := []struct {
		name               string
		corporateAccounts  string
		personalAccounts   string
		expectedCount      int
		description        string
	}{
		{
			name:              "Whitespace in account strings",
			corporateAccounts: " corp1 : password1 : 1234567890 , corp2 : password2 ",
			personalAccounts:  "",
			expectedCount:     2,
			description:       "Should handle whitespace around separators",
		},
		{
			name:              "Colon in password",
			corporateAccounts: "corp1:pass:word:1234567890",
			personalAccounts:  "",
			expectedCount:     1,
			description:       "Should handle colon in password (uses leftmost parts)",
		},
		{
			name:              "Japanese characters in account ID",
			corporateAccounts: "法人1:password1:1234567890",
			personalAccounts:  "",
			expectedCount:     1,
			description:       "Should handle Unicode characters",
		},
		{
			name:              "Very long account strings",
			corporateAccounts: "verylongaccountnamethatexceedstypicallengths:verylongpasswordthatisnotnormallyused:12345678901234567890",
			personalAccounts:  "",
			expectedCount:     1,
			description:       "Should handle long strings",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// Clean environment first
			os.Unsetenv("ETC_CORPORATE_ACCOUNTS")
			os.Unsetenv("ETC_PERSONAL_ACCOUNTS")

			if tt.corporateAccounts != "" {
				os.Setenv("ETC_CORPORATE_ACCOUNTS", tt.corporateAccounts)
			}
			if tt.personalAccounts != "" {
				os.Setenv("ETC_PERSONAL_ACCOUNTS", tt.personalAccounts)
			}

			defer func() {
				os.Unsetenv("ETC_CORPORATE_ACCOUNTS")
				os.Unsetenv("ETC_PERSONAL_ACCOUNTS")
			}()

			handler := &AccountsHandler{
				BaseHandler: BaseHandler{
					Logger:       logger,
					ErrorHandler: NewGRPCErrorHandler(),
				},
			}

			req := httptest.NewRequest(http.MethodGet, "/api/accounts", nil)
			w := httptest.NewRecorder()

			handler.GetAccounts(w, req)

			assert.Equal(t, http.StatusOK, w.Code)

			var response SuccessResponse
			err := json.NewDecoder(w.Body).Decode(&response)
			assert.NoError(t, err, tt.description)
			assert.True(t, response.Success)

			data := response.Data.(map[string]interface{})
			assert.Equal(t, float64(tt.expectedCount), data["count"], tt.description)
		})
	}
}