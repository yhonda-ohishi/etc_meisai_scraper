package handlers

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"net/http/httptest"
	"os"
	"runtime"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.com/yhonda-ohishi/etc_meisai/src/services"
)

// MockBaseService for health handler testing
type MockBaseService struct {
	mock.Mock
}

func (m *MockBaseService) HealthCheck(ctx context.Context) *services.HealthCheckResult {
	args := m.Called(ctx)
	return args.Get(0).(*services.HealthCheckResult)
}

func (m *MockBaseService) RegisterService(name string, service interface{}) {
	m.Called(name, service)
}

func (m *MockBaseService) GetService(name string) interface{} {
	args := m.Called(name)
	return args.Get(0)
}

// MockHealthETCService for health handler testing
type MockHealthETCService struct {
	mock.Mock
}

func (m *MockHealthETCService) HealthCheck(ctx context.Context) error {
	args := m.Called(ctx)
	return args.Error(0)
}

// MockHealthMappingService for health handler testing
type MockHealthMappingService struct {
	mock.Mock
}

func (m *MockHealthMappingService) HealthCheck(ctx context.Context) error {
	args := m.Called(ctx)
	return args.Error(0)
}

// MockHealthImportService for health handler testing
type MockHealthImportService struct {
	mock.Mock
}

func (m *MockHealthImportService) HealthCheck(ctx context.Context) error {
	args := m.Called(ctx)
	return args.Error(0)
}

// MockHealthServiceRegistry for health handler testing
type MockHealthServiceRegistry struct {
	mock.Mock
	baseService    services.BaseServiceInterface
	etcService     *MockHealthETCService
	mappingService *MockHealthMappingService
	importService  *MockHealthImportService
}

func (m *MockHealthServiceRegistry) GetBaseService() *services.BaseService {
	return nil // Health handler doesn't use concrete base service
}

func (m *MockHealthServiceRegistry) GetETCService() *services.ETCService {
	return nil // Health handler doesn't use concrete ETC service
}

func (m *MockHealthServiceRegistry) GetMappingService() *services.MappingService {
	return nil // Health handler doesn't use concrete mapping service
}

func (m *MockHealthServiceRegistry) GetImportService() *services.ImportServiceLegacy {
	return nil // Health handler doesn't use concrete import service
}

func (m *MockHealthServiceRegistry) GetDownloadService() services.DownloadServiceInterface {
	return nil
}

func (m *MockHealthServiceRegistry) HealthCheck(ctx context.Context) *services.HealthCheckResult {
	args := m.Called(ctx)
	return args.Get(0).(*services.HealthCheckResult)
}

func (m *MockHealthServiceRegistry) GetDatabaseServiceClient() interface{} {
	args := m.Called()
	return args.Get(0)
}

func TestNewHealthHandler(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)
	serviceRegistry := &services.ServiceRegistry{}

	handler := NewHealthHandler(serviceRegistry, logger)

	assert.NotNil(t, handler)
	assert.NotNil(t, handler.BaseHandler)
	assert.Equal(t, serviceRegistry, handler.ServiceRegistry)
	assert.Equal(t, logger, handler.Logger)
}

func TestHealthHandler_HealthCheck(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)

	tests := []struct {
		name           string
		setupMock      func() *MockHealthServiceRegistry
		expectedStatus int
		checkResponse  func(*testing.T, *httptest.ResponseRecorder)
	}{
		{
			name: "Base service unavailable",
			setupMock: func() *MockHealthServiceRegistry {
				return &MockHealthServiceRegistry{baseService: nil}
			},
			expectedStatus: http.StatusServiceUnavailable,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "service_unavailable", response.Error.Code)
			},
		},
		{
			name: "Healthy services",
			setupMock: func() *MockHealthServiceRegistry {
				mockBase := &MockBaseService{}
				healthResult := &services.HealthCheckResult{
					Status: "healthy",
					Services: map[string]*services.ServiceHealth{
						"database": {Status: "healthy"},
						"cache":    {Status: "healthy"},
					},
				}
				mockBase.On("HealthCheck", mock.AnythingOfType("*context.timerCtx")).Return(healthResult)
				return &MockHealthServiceRegistry{baseService: nil}
			},
			expectedStatus: http.StatusOK,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var status HealthStatus
				err := json.NewDecoder(w.Body).Decode(&status)
				assert.NoError(t, err)
				assert.Equal(t, "healthy", status.Status)
				assert.Equal(t, "1.0.0", status.Version)
				assert.NotEmpty(t, status.Uptime)
				assert.NotEmpty(t, status.Timestamp)
				assert.NotEmpty(t, status.System.GoVersion)
				assert.Equal(t, 2, len(status.Services))
			},
		},
		{
			name: "Degraded services",
			setupMock: func() *MockHealthServiceRegistry {
				mockBase := &MockBaseService{}
				healthResult := &services.HealthCheckResult{
					Status: "healthy",
					Services: map[string]*services.ServiceHealth{
						"database": {Status: "healthy"},
						"cache":    {Status: "degraded", Error: "Slow response"},
					},
				}
				mockBase.On("HealthCheck", mock.AnythingOfType("*context.timerCtx")).Return(healthResult)
				return &MockHealthServiceRegistry{baseService: nil}
			},
			expectedStatus: http.StatusOK,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var status HealthStatus
				err := json.NewDecoder(w.Body).Decode(&status)
				assert.NoError(t, err)
				assert.Equal(t, "degraded", status.Status)
				assert.Equal(t, "Slow response", status.Services["cache"].Message)
			},
		},
		{
			name: "Unhealthy services",
			setupMock: func() *MockHealthServiceRegistry {
				mockBase := &MockBaseService{}
				healthResult := &services.HealthCheckResult{
					Status: "unhealthy",
					Services: map[string]*services.ServiceHealth{
						"database": {Status: "unhealthy", Error: "Connection failed"},
					},
				}
				mockBase.On("HealthCheck", mock.AnythingOfType("*context.timerCtx")).Return(healthResult)
				return &MockHealthServiceRegistry{baseService: nil}
			},
			expectedStatus: http.StatusServiceUnavailable,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var status HealthStatus
				err := json.NewDecoder(w.Body).Decode(&status)
				assert.NoError(t, err)
				assert.Equal(t, "unhealthy", status.Status)
				assert.Equal(t, "Connection failed", status.Services["database"].Message)
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockRegistry := tt.setupMock()
			handler := &HealthHandler{
				BaseHandler: &BaseHandler{
					ServiceRegistry: mockRegistry,
					Logger:          logger,
					ErrorHandler:    NewGRPCErrorHandler(),
				},
			}

			req := httptest.NewRequest(http.MethodGet, "/api/health", nil)
			w := httptest.NewRecorder()

			handler.HealthCheck(w, req)

			assert.Equal(t, tt.expectedStatus, w.Code)
			assert.Equal(t, "application/json", w.Header().Get("Content-Type"))
			if tt.checkResponse != nil {
				tt.checkResponse(t, w)
			}
		})
	}
}

func TestHealthHandler_Liveness(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)
	handler := &HealthHandler{
		BaseHandler: &BaseHandler{
			Logger: logger,
		},
	}

	req := httptest.NewRequest(http.MethodGet, "/api/health/live", nil)
	w := httptest.NewRecorder()

	handler.Liveness(w, req)

	assert.Equal(t, http.StatusOK, w.Code)
	assert.Equal(t, "application/json", w.Header().Get("Content-Type"))

	var response map[string]interface{}
	err := json.NewDecoder(w.Body).Decode(&response)
	assert.NoError(t, err)
	assert.Equal(t, "alive", response["status"])
	assert.NotEmpty(t, response["timestamp"])
}

func TestHealthHandler_Readiness(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)

	tests := []struct {
		name           string
		setupMock      func() *MockHealthServiceRegistry
		expectedStatus int
		checkResponse  func(*testing.T, *httptest.ResponseRecorder)
	}{
		{
			name: "Base service unavailable",
			setupMock: func() *MockHealthServiceRegistry {
				return &MockHealthServiceRegistry{baseService: nil}
			},
			expectedStatus: http.StatusServiceUnavailable,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response map[string]interface{}
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "not_ready", response["status"])
				assert.Equal(t, "Services not initialized", response["message"])
			},
		},
		{
			name: "Services ready",
			setupMock: func() *MockHealthServiceRegistry {
				mockBase := &MockBaseService{}
				healthResult := &services.HealthCheckResult{
					Status: "healthy",
					Services: map[string]*services.ServiceHealth{
						"database": {Status: "healthy"},
					},
				}
				mockBase.On("HealthCheck", mock.AnythingOfType("*context.timerCtx")).Return(healthResult)
				return &MockHealthServiceRegistry{baseService: nil}
			},
			expectedStatus: http.StatusOK,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response map[string]interface{}
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "ready", response["status"])
				assert.NotEmpty(t, response["timestamp"])
			},
		},
		{
			name: "Services not ready",
			setupMock: func() *MockHealthServiceRegistry {
				mockBase := &MockBaseService{}
				healthResult := &services.HealthCheckResult{
					Status: "unhealthy",
					Services: map[string]*services.ServiceHealth{
						"database": {Status: "unhealthy", Error: "Connection failed"},
					},
				}
				mockBase.On("HealthCheck", mock.AnythingOfType("*context.timerCtx")).Return(healthResult)
				return &MockHealthServiceRegistry{baseService: nil}
			},
			expectedStatus: http.StatusServiceUnavailable,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response map[string]interface{}
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "not_ready", response["status"])
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockRegistry := tt.setupMock()
			handler := &HealthHandler{
				BaseHandler: &BaseHandler{
					ServiceRegistry: mockRegistry,
					Logger:          logger,
					ErrorHandler:    NewGRPCErrorHandler(),
				},
			}

			req := httptest.NewRequest(http.MethodGet, "/api/health/ready", nil)
			w := httptest.NewRecorder()

			handler.Readiness(w, req)

			assert.Equal(t, tt.expectedStatus, w.Code)
			assert.Equal(t, "application/json", w.Header().Get("Content-Type"))
			if tt.checkResponse != nil {
				tt.checkResponse(t, w)
			}
		})
	}
}

func TestHealthHandler_DeepHealthCheck(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)

	tests := []struct {
		name          string
		setupMock     func() *MockHealthServiceRegistry
		checkResponse func(*testing.T, *httptest.ResponseRecorder)
	}{
		{
			name: "All services healthy",
			setupMock: func() *MockHealthServiceRegistry {
				mockETC := &MockHealthETCService{}
				mockMapping := &MockHealthMappingService{}
				mockImport := &MockHealthImportService{}

				mockETC.On("HealthCheck", mock.AnythingOfType("*context.timerCtx")).Return(nil)
				mockMapping.On("HealthCheck", mock.AnythingOfType("*context.timerCtx")).Return(nil)
				mockImport.On("HealthCheck", mock.AnythingOfType("*context.timerCtx")).Return(nil)

				return &MockHealthServiceRegistry{
					etcService:     mockETC,
					mappingService: mockMapping,
					importService:  mockImport,
				}
			},
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response SuccessResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.True(t, response.Success)
				assert.Equal(t, "Deep health check completed", response.Message)

				data := response.Data.(map[string]interface{})
				assert.NotEmpty(t, data["timestamp"])
				assert.NotEmpty(t, data["uptime"])
				assert.NotEmpty(t, data["system"])

				etcService := data["etc_service"].(map[string]interface{})
				assert.Equal(t, "healthy", etcService["status"])
				assert.NotEmpty(t, etcService["latency"])
				assert.Equal(t, "", etcService["error"])
			},
		},
		{
			name: "Some services unhealthy",
			setupMock: func() *MockHealthServiceRegistry {
				mockETC := &MockHealthETCService{}
				mockMapping := &MockHealthMappingService{}

				mockETC.On("HealthCheck", mock.AnythingOfType("*context.timerCtx")).Return(fmt.Errorf("database connection failed"))
				mockMapping.On("HealthCheck", mock.AnythingOfType("*context.timerCtx")).Return(nil)

				return &MockHealthServiceRegistry{
					etcService:     mockETC,
					mappingService: mockMapping,
					importService:  nil, // Not available
				}
			},
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response SuccessResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.True(t, response.Success)

				data := response.Data.(map[string]interface{})

				etcService := data["etc_service"].(map[string]interface{})
				assert.Equal(t, "unhealthy", etcService["status"])
				assert.Equal(t, "database connection failed", etcService["error"])

				mappingService := data["mapping_service"].(map[string]interface{})
				assert.Equal(t, "healthy", mappingService["status"])

				// Import service should not be present
				_, exists := data["import_service"]
				assert.False(t, exists)
			},
		},
		{
			name: "No services available",
			setupMock: func() *MockHealthServiceRegistry {
				return &MockHealthServiceRegistry{
					etcService:     nil,
					mappingService: nil,
					importService:  nil,
				}
			},
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response SuccessResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.True(t, response.Success)

				data := response.Data.(map[string]interface{})
				assert.NotEmpty(t, data["system"])
				assert.NotEmpty(t, data["timestamp"])
				assert.NotEmpty(t, data["uptime"])

				// No service checks should be present
				_, etcExists := data["etc_service"]
				assert.False(t, etcExists)
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockRegistry := tt.setupMock()
			handler := &HealthHandler{
				BaseHandler: &BaseHandler{
					ServiceRegistry: mockRegistry,
					Logger:          logger,
					ErrorHandler:    NewGRPCErrorHandler(),
				},
			}

			req := httptest.NewRequest(http.MethodGet, "/api/health/deep", nil)
			w := httptest.NewRecorder()

			handler.DeepHealthCheck(w, req)

			assert.Equal(t, http.StatusOK, w.Code)
			if tt.checkResponse != nil {
				tt.checkResponse(t, w)
			}
		})
	}
}

func TestHealthHandler_Timeout(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)

	mockBase := &MockBaseService{}
	mockBase.On("HealthCheck", mock.AnythingOfType("*context.timerCtx")).Return(func(ctx context.Context) *services.HealthCheckResult {
		select {
		case <-time.After(10 * time.Second):
			return &services.HealthCheckResult{Status: "timeout"}
		case <-ctx.Done():
			return &services.HealthCheckResult{Status: "cancelled", Services: map[string]*services.ServiceHealth{}}
		}
	})

	mockRegistry := &MockHealthServiceRegistry{baseService: nil}
	handler := &HealthHandler{
		BaseHandler: &BaseHandler{
			ServiceRegistry: mockRegistry,
			Logger:          logger,
			ErrorHandler:    NewGRPCErrorHandler(),
		},
	}

	req := httptest.NewRequest(http.MethodGet, "/api/health", nil)
	w := httptest.NewRecorder()

	start := time.Now()
	handler.HealthCheck(w, req)
	duration := time.Since(start)

	// Should timeout before 10 seconds (context timeout is 5s)
	assert.True(t, duration < 10*time.Second, "Health check should timeout before 10 seconds")
	assert.Equal(t, "application/json", w.Header().Get("Content-Type"))
}

func TestHealthStatus_Structure(t *testing.T) {
	tests := []struct {
		name   string
		status HealthStatus
	}{
		{
			name: "Complete health status",
			status: HealthStatus{
				Status:    "healthy",
				Timestamp: time.Date(2023, 1, 1, 0, 0, 0, 0, time.UTC),
				Version:   "1.0.0",
				Uptime:    "1h30m45s",
				Services: map[string]ServiceInfo{
					"database": {
						Status:  "healthy",
						Latency: "5ms",
					},
					"cache": {
						Status:  "degraded",
						Message: "Slow response",
						Latency: "100ms",
					},
				},
				System: SystemInfo{
					GoVersion:    runtime.Version(),
					NumCPU:       runtime.NumCPU(),
					NumGoroutine: runtime.NumGoroutine(),
					Memory: MemoryInfo{
						Alloc:      1024,
						TotalAlloc: 2048,
						Sys:        4096,
						NumGC:      10,
					},
				},
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			jsonData, err := json.Marshal(tt.status)
			assert.NoError(t, err)

			var decoded HealthStatus
			err = json.Unmarshal(jsonData, &decoded)
			assert.NoError(t, err)

			assert.Equal(t, tt.status.Status, decoded.Status)
			assert.Equal(t, tt.status.Version, decoded.Version)
			assert.Equal(t, tt.status.Uptime, decoded.Uptime)
			assert.Equal(t, len(tt.status.Services), len(decoded.Services))
			assert.Equal(t, tt.status.System.GoVersion, decoded.System.GoVersion)
		})
	}
}

func TestServiceInfo_Structure(t *testing.T) {
	tests := []struct {
		name     string
		info     ServiceInfo
		expected string
	}{
		{
			name: "Healthy service",
			info: ServiceInfo{
				Status:  "healthy",
				Latency: "5ms",
			},
			expected: `{"status":"healthy","latency":"5ms"}`,
		},
		{
			name: "Unhealthy service with message",
			info: ServiceInfo{
				Status:  "unhealthy",
				Message: "Connection failed",
				Latency: "timeout",
			},
			expected: `{"status":"unhealthy","message":"Connection failed","latency":"timeout"}`,
		},
		{
			name: "Service without optional fields",
			info: ServiceInfo{
				Status: "healthy",
			},
			expected: `{"status":"healthy"}`,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			jsonData, err := json.Marshal(tt.info)
			assert.NoError(t, err)
			assert.JSONEq(t, tt.expected, string(jsonData))
		})
	}
}

func TestSystemInfo_Structure(t *testing.T) {
	info := getSystemInfo()

	assert.NotEmpty(t, info.GoVersion)
	assert.Greater(t, info.NumCPU, 0)
	assert.GreaterOrEqual(t, info.NumGoroutine, 0)
	assert.GreaterOrEqual(t, info.Memory.Alloc, uint64(0))
	assert.GreaterOrEqual(t, info.Memory.TotalAlloc, uint64(0))
	assert.GreaterOrEqual(t, info.Memory.Sys, uint64(0))
	assert.GreaterOrEqual(t, info.Memory.NumGC, uint32(0))

	// Test JSON serialization
	jsonData, err := json.Marshal(info)
	assert.NoError(t, err)

	var decoded SystemInfo
	err = json.Unmarshal(jsonData, &decoded)
	assert.NoError(t, err)
	assert.Equal(t, info.GoVersion, decoded.GoVersion)
	assert.Equal(t, info.NumCPU, decoded.NumCPU)
}

func TestGetStatusFromError(t *testing.T) {
	tests := []struct {
		name     string
		err      error
		expected string
	}{
		{
			name:     "No error",
			err:      nil,
			expected: "healthy",
		},
		{
			name:     "With error",
			err:      fmt.Errorf("connection failed"),
			expected: "unhealthy",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			result := getStatusFromError(tt.err)
			assert.Equal(t, tt.expected, result)
		})
	}
}

func TestErrorString(t *testing.T) {
	tests := []struct {
		name     string
		err      error
		expected string
	}{
		{
			name:     "No error",
			err:      nil,
			expected: "",
		},
		{
			name:     "With error",
			err:      fmt.Errorf("connection failed"),
			expected: "connection failed",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			result := errorString(tt.err)
			assert.Equal(t, tt.expected, result)
		})
	}
}

func TestMemoryInfo_Structure(t *testing.T) {
	info := MemoryInfo{
		Alloc:      1024,
		TotalAlloc: 2048,
		Sys:        4096,
		NumGC:      10,
	}

	jsonData, err := json.Marshal(info)
	assert.NoError(t, err)

	expected := `{"alloc":1024,"total_alloc":2048,"sys":4096,"num_gc":10}`
	assert.JSONEq(t, expected, string(jsonData))

	var decoded MemoryInfo
	err = json.Unmarshal(jsonData, &decoded)
	assert.NoError(t, err)
	assert.Equal(t, info, decoded)
}