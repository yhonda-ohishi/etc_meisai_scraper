package handlers

import (
	"context"
	"encoding/json"
	"log"
	"net/http"
	"net/http/httptest"
	"os"
	"strings"
	"testing"
	"time"

	"github.com/go-chi/chi/v5"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.com/yhonda-ohishi/etc_meisai/src/models"
	"github.com/yhonda-ohishi/etc_meisai/src/services"
)

// MockMappingService for testing
type MockMappingService struct {
	mock.Mock
}

func (m *MockMappingService) CreateMapping(ctx context.Context, mapping *models.ETCMeisaiMapping) error {
	args := m.Called(ctx, mapping)
	return args.Error(0)
}

func (m *MockMappingService) UpdateMapping(ctx context.Context, mapping *models.ETCMeisaiMapping) error {
	args := m.Called(ctx, mapping)
	return args.Error(0)
}

func (m *MockMappingService) DeleteMapping(ctx context.Context, id int64) error {
	args := m.Called(ctx, id)
	return args.Error(0)
}

func (m *MockMappingService) GetMappingByID(ctx context.Context, id int64) (*models.ETCMeisaiMapping, error) {
	args := m.Called(ctx, id)
	return args.Get(0).(*models.ETCMeisaiMapping), args.Error(1)
}

func (m *MockMappingService) ListMappings(ctx context.Context, params *models.MappingListParams) ([]*models.ETCMeisaiMapping, int64, error) {
	args := m.Called(ctx, params)
	return args.Get(0).([]*models.ETCMeisaiMapping), args.Get(1).(int64), args.Error(2)
}

func (m *MockMappingService) AutoMatch(ctx context.Context, startDate, endDate time.Time, threshold float32) ([]*models.AutoMatchResult, error) {
	args := m.Called(ctx, startDate, endDate, threshold)
	return args.Get(0).([]*models.AutoMatchResult), args.Error(1)
}

func (m *MockMappingService) CreateBulkMappings(ctx context.Context, mappings []*models.ETCMeisaiMapping) (*models.BulkMappingResult, error) {
	args := m.Called(ctx, mappings)
	return args.Get(0).(*models.BulkMappingResult), args.Error(1)
}

func (m *MockMappingService) GetMappingsByETCMeisaiID(ctx context.Context, etcMeisaiID int64) ([]*models.ETCMeisaiMapping, error) {
	args := m.Called(ctx, etcMeisaiID)
	return args.Get(0).([]*models.ETCMeisaiMapping), args.Error(1)
}

func (m *MockMappingService) GetMappingsByDTakoRowID(ctx context.Context, dtakoRowID int64) ([]*models.ETCMeisaiMapping, error) {
	args := m.Called(ctx, dtakoRowID)
	return args.Get(0).([]*models.ETCMeisaiMapping), args.Error(1)
}

func (m *MockMappingService) UpdateBulkMappings(ctx context.Context, mappings []*models.ETCMeisaiMapping) (*models.BulkMappingResult, error) {
	args := m.Called(ctx, mappings)
	return args.Get(0).(*models.BulkMappingResult), args.Error(1)
}

func (m *MockMappingService) DeleteBulkMappings(ctx context.Context, ids []int64) (*models.BulkMappingResult, error) {
	args := m.Called(ctx, ids)
	return args.Get(0).(*models.BulkMappingResult), args.Error(1)
}

func (m *MockMappingService) GetUnmappedETCMeisai(ctx context.Context, limit, offset int) ([]*models.ETCMeisai, int64, error) {
	args := m.Called(ctx, limit, offset)
	return args.Get(0).([]*models.ETCMeisai), args.Get(1).(int64), args.Error(2)
}

func (m *MockMappingService) GetMappingStats(ctx context.Context, fromDate, toDate time.Time) (*models.MappingStats, error) {
	args := m.Called(ctx, fromDate, toDate)
	return args.Get(0).(*models.MappingStats), args.Error(1)
}

// MockMappingServiceRegistry for testing
type MockMappingServiceRegistry struct {
	mock.Mock
	mappingService services.MappingServiceInterface
}

func (m *MockMappingServiceRegistry) GetETCService() *services.ETCService {
	return nil
}

func (m *MockMappingServiceRegistry) GetMappingService() *services.MappingService {
	return nil // Mapping handler tests don't use concrete service
}

func (m *MockMappingServiceRegistry) GetBaseService() *services.BaseService {
	return nil
}

func (m *MockMappingServiceRegistry) GetImportService() *services.ImportServiceLegacy {
	return nil
}

func (m *MockMappingServiceRegistry) GetDownloadService() services.DownloadServiceInterface {
	return nil
}

func (m *MockMappingServiceRegistry) HealthCheck(ctx context.Context) *services.HealthCheckResult {
	args := m.Called(ctx)
	return args.Get(0).(*services.HealthCheckResult)
}

func (m *MockMappingServiceRegistry) GetDatabaseServiceClient() interface{} {
	args := m.Called()
	return args.Get(0)
}

func TestNewMappingHandler(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)
	serviceRegistry := &services.ServiceRegistry{}

	handler := NewMappingHandler(serviceRegistry, logger)

	assert.NotNil(t, handler)
	assert.Equal(t, serviceRegistry, handler.ServiceRegistry)
	assert.Equal(t, logger, handler.Logger)
}

func TestMappingHandler_CreateMapping(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)

	tests := []struct {
		name           string
		requestBody    string
		setupMock      func() *MockMappingServiceRegistry
		expectedStatus int
		checkResponse  func(*testing.T, *httptest.ResponseRecorder)
	}{
		{
			name:        "Invalid request body",
			requestBody: "invalid json",
			setupMock: func() *MockMappingServiceRegistry {
				return &MockMappingServiceRegistry{}
			},
			expectedStatus: http.StatusBadRequest,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "invalid_request", response.Error.Code)
			},
		},
		{
			name:        "Missing required fields",
			requestBody: `{"mapping_type": "manual"}`,
			setupMock: func() *MockMappingServiceRegistry {
				return &MockMappingServiceRegistry{}
			},
			expectedStatus: http.StatusBadRequest,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "missing_fields", response.Error.Code)
			},
		},
		{
			name:        "Service unavailable",
			requestBody: `{"etc_meisai_id": 123, "dtako_row_id": "row_456"}`,
			setupMock: func() *MockMappingServiceRegistry {
				return &MockMappingServiceRegistry{mappingService: nil}
			},
			expectedStatus: http.StatusServiceUnavailable,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "service_unavailable", response.Error.Code)
			},
		},
		{
			name:        "Successful creation with defaults",
			requestBody: `{"etc_meisai_id": 123, "dtako_row_id": "row_456"}`,
			setupMock: func() *MockMappingServiceRegistry {
				mockMapping := &MockMappingService{}
				mockMapping.On("CreateMapping", mock.AnythingOfType("*context.timerCtx"), mock.MatchedBy(func(mapping *models.ETCMeisaiMapping) bool {
					return mapping.ETCMeisaiID == 123 &&
						mapping.DTakoRowID == "row_456" &&
						mapping.MappingType == "manual" &&
						mapping.Confidence == 1.0 &&
						mapping.CreatedBy == "api_user"
				})).Return(nil)
				return &MockMappingServiceRegistry{mappingService: mockMapping}
			},
			expectedStatus: http.StatusCreated,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var mapping models.ETCMeisaiMapping
				err := json.NewDecoder(w.Body).Decode(&mapping)
				assert.NoError(t, err)
				assert.Equal(t, int64(123), mapping.ETCMeisaiID)
				assert.Equal(t, "row_456", mapping.DTakoRowID)
				assert.Equal(t, "manual", mapping.MappingType)
				assert.Equal(t, float32(1.0), mapping.Confidence)
			},
		},
		{
			name:        "Successful creation with custom values",
			requestBody: `{"etc_meisai_id": 123, "dtako_row_id": "row_456", "mapping_type": "auto", "confidence": 0.95, "notes": "Test mapping"}`,
			setupMock: func() *MockMappingServiceRegistry {
				mockMapping := &MockMappingService{}
				mockMapping.On("CreateMapping", mock.AnythingOfType("*context.timerCtx"), mock.MatchedBy(func(mapping *models.ETCMeisaiMapping) bool {
					return mapping.ETCMeisaiID == 123 &&
						mapping.DTakoRowID == "row_456" &&
						mapping.MappingType == "auto" &&
						mapping.Confidence == 0.95 &&
						mapping.Notes == "Test mapping"
				})).Return(nil)
				return &MockMappingServiceRegistry{mappingService: mockMapping}
			},
			expectedStatus: http.StatusCreated,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var mapping models.ETCMeisaiMapping
				err := json.NewDecoder(w.Body).Decode(&mapping)
				assert.NoError(t, err)
				assert.Equal(t, int64(123), mapping.ETCMeisaiID)
				assert.Equal(t, "auto", mapping.MappingType)
				assert.Equal(t, float32(0.95), mapping.Confidence)
				assert.Equal(t, "Test mapping", mapping.Notes)
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockRegistry := tt.setupMock()
			handler := &MappingHandler{
				BaseHandler: BaseHandler{
					ServiceRegistry: mockRegistry,
					Logger:          logger,
					ErrorHandler:    NewGRPCErrorHandler(),
				},
			}

			req := httptest.NewRequest(http.MethodPost, "/api/mapping", strings.NewReader(tt.requestBody))
			w := httptest.NewRecorder()

			handler.CreateMapping(w, req)

			assert.Equal(t, tt.expectedStatus, w.Code)
			if tt.checkResponse != nil {
				tt.checkResponse(t, w)
			}
		})
	}
}

func TestMappingHandler_GetMappings(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)

	tests := []struct {
		name           string
		queryParams    string
		setupMock      func() *MockMappingServiceRegistry
		expectedStatus int
		checkResponse  func(*testing.T, *httptest.ResponseRecorder)
	}{
		{
			name:        "Default parameters",
			queryParams: "",
			setupMock: func() *MockMappingServiceRegistry {
				mockMapping := &MockMappingService{}
				mappings := []*models.ETCMeisaiMapping{
					{ID: 1, ETCMeisaiID: 123, DTakoRowID: "row_456"},
					{ID: 2, ETCMeisaiID: 124, DTakoRowID: "row_457"},
				}
				mockMapping.On("ListMappings", mock.AnythingOfType("*context.timerCtx"), mock.MatchedBy(func(params *models.MappingListParams) bool {
					return params.Limit == 100 && params.Offset == 0
				})).Return(mappings, int64(2), nil)
				return &MockMappingServiceRegistry{mappingService: mockMapping}
			},
			expectedStatus: http.StatusOK,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response SuccessResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.True(t, response.Success)

				data := response.Data.(map[string]interface{})
				assert.Equal(t, float64(2), data["total"])
				assert.Equal(t, float64(100), data["limit"])
				assert.Equal(t, float64(0), data["offset"])
			},
		},
		{
			name:        "Custom parameters",
			queryParams: "limit=50&offset=10&etc_meisai_id=123&dtako_row_id=row_456&mapping_type=manual",
			setupMock: func() *MockMappingServiceRegistry {
				mockMapping := &MockMappingService{}
				mappings := []*models.ETCMeisaiMapping{}
				mockMapping.On("ListMappings", mock.AnythingOfType("*context.timerCtx"), mock.MatchedBy(func(params *models.MappingListParams) bool {
					return params.Limit == 50 &&
						params.Offset == 10 &&
						*params.ETCMeisaiID == 123 &&
						params.DTakoRowID == "row_456" &&
						params.MappingType == "manual"
				})).Return(mappings, int64(0), nil)
				return &MockMappingServiceRegistry{mappingService: mockMapping}
			},
			expectedStatus: http.StatusOK,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response SuccessResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.True(t, response.Success)
			},
		},
		{
			name:        "Service unavailable",
			queryParams: "",
			setupMock: func() *MockMappingServiceRegistry {
				return &MockMappingServiceRegistry{mappingService: nil}
			},
			expectedStatus: http.StatusServiceUnavailable,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "service_unavailable", response.Error.Code)
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockRegistry := tt.setupMock()
			handler := &MappingHandler{
				BaseHandler: BaseHandler{
					ServiceRegistry: mockRegistry,
					Logger:          logger,
					ErrorHandler:    NewGRPCErrorHandler(),
				},
			}

			req := httptest.NewRequest(http.MethodGet, "/api/mapping?"+tt.queryParams, nil)
			w := httptest.NewRecorder()

			handler.GetMappings(w, req)

			assert.Equal(t, tt.expectedStatus, w.Code)
			if tt.checkResponse != nil {
				tt.checkResponse(t, w)
			}
		})
	}
}

func TestMappingHandler_DeleteMapping(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)

	tests := []struct {
		name           string
		urlID          string
		setupMock      func() *MockMappingServiceRegistry
		expectedStatus int
		checkResponse  func(*testing.T, *httptest.ResponseRecorder)
	}{
		{
			name:  "Missing ID",
			urlID: "",
			setupMock: func() *MockMappingServiceRegistry {
				return &MockMappingServiceRegistry{}
			},
			expectedStatus: http.StatusBadRequest,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "missing_id", response.Error.Code)
			},
		},
		{
			name:  "Invalid ID",
			urlID: "invalid",
			setupMock: func() *MockMappingServiceRegistry {
				return &MockMappingServiceRegistry{}
			},
			expectedStatus: http.StatusBadRequest,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "invalid_id", response.Error.Code)
			},
		},
		{
			name:  "Service unavailable",
			urlID: "123",
			setupMock: func() *MockMappingServiceRegistry {
				return &MockMappingServiceRegistry{mappingService: nil}
			},
			expectedStatus: http.StatusServiceUnavailable,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "service_unavailable", response.Error.Code)
			},
		},
		{
			name:  "Successful deletion",
			urlID: "123",
			setupMock: func() *MockMappingServiceRegistry {
				mockMapping := &MockMappingService{}
				mockMapping.On("DeleteMapping", mock.AnythingOfType("*context.timerCtx"), int64(123)).Return(nil)
				return &MockMappingServiceRegistry{mappingService: mockMapping}
			},
			expectedStatus: http.StatusOK,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response SuccessResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.True(t, response.Success)
				assert.Equal(t, "Mapping deleted successfully", response.Message)

				data := response.Data.(map[string]interface{})
				assert.Equal(t, float64(123), data["id"])
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockRegistry := tt.setupMock()
			handler := &MappingHandler{
				BaseHandler: BaseHandler{
					ServiceRegistry: mockRegistry,
					Logger:          logger,
					ErrorHandler:    NewGRPCErrorHandler(),
				},
			}

			// Create chi router for URL parameter handling
			r := chi.NewRouter()
			r.Delete("/api/mapping/{id}", handler.DeleteMapping)

			req := httptest.NewRequest(http.MethodDelete, "/api/mapping/"+tt.urlID, nil)
			w := httptest.NewRecorder()

			r.ServeHTTP(w, req)

			assert.Equal(t, tt.expectedStatus, w.Code)
			if tt.checkResponse != nil {
				tt.checkResponse(t, w)
			}
		})
	}
}

func TestMappingHandler_UpdateMapping(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)

	tests := []struct {
		name           string
		urlID          string
		requestBody    string
		setupMock      func() *MockMappingServiceRegistry
		expectedStatus int
		checkResponse  func(*testing.T, *httptest.ResponseRecorder)
	}{
		{
			name:        "Missing ID",
			urlID:       "",
			requestBody: `{"dtako_row_id": "new_row"}`,
			setupMock: func() *MockMappingServiceRegistry {
				return &MockMappingServiceRegistry{}
			},
			expectedStatus: http.StatusBadRequest,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "missing_id", response.Error.Code)
			},
		},
		{
			name:        "Invalid ID",
			urlID:       "invalid",
			requestBody: `{"dtako_row_id": "new_row"}`,
			setupMock: func() *MockMappingServiceRegistry {
				return &MockMappingServiceRegistry{}
			},
			expectedStatus: http.StatusBadRequest,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "invalid_id", response.Error.Code)
			},
		},
		{
			name:        "Invalid request body",
			urlID:       "123",
			requestBody: "invalid json",
			setupMock: func() *MockMappingServiceRegistry {
				return &MockMappingServiceRegistry{}
			},
			expectedStatus: http.StatusBadRequest,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "invalid_request", response.Error.Code)
			},
		},
		{
			name:        "Service unavailable",
			urlID:       "123",
			requestBody: `{"dtako_row_id": "new_row"}`,
			setupMock: func() *MockMappingServiceRegistry {
				return &MockMappingServiceRegistry{mappingService: nil}
			},
			expectedStatus: http.StatusServiceUnavailable,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "service_unavailable", response.Error.Code)
			},
		},
		{
			name:        "Successful update",
			urlID:       "123",
			requestBody: `{"dtako_row_id": "new_row", "notes": "Updated mapping"}`,
			setupMock: func() *MockMappingServiceRegistry {
				mockMapping := &MockMappingService{}
				mockMapping.On("UpdateMapping", mock.AnythingOfType("*context.timerCtx"), int64(123), mock.MatchedBy(func(updates map[string]interface{}) bool {
					return updates["dtako_row_id"] == "new_row" && updates["notes"] == "Updated mapping"
				})).Return(nil)

				updatedMapping := &models.ETCMeisaiMapping{
					ID:          123,
					ETCMeisaiID: 456,
					DTakoRowID:  "new_row",
					Notes:       "Updated mapping",
				}
				mockMapping.On("GetMappingByID", mock.AnythingOfType("*context.timerCtx"), int64(123)).Return(updatedMapping, nil)
				return &MockMappingServiceRegistry{mappingService: mockMapping}
			},
			expectedStatus: http.StatusOK,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response SuccessResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.True(t, response.Success)
				assert.Equal(t, "Mapping updated successfully", response.Message)
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockRegistry := tt.setupMock()
			handler := &MappingHandler{
				BaseHandler: BaseHandler{
					ServiceRegistry: mockRegistry,
					Logger:          logger,
					ErrorHandler:    NewGRPCErrorHandler(),
				},
			}

			// Create chi router for URL parameter handling
			r := chi.NewRouter()
			r.Put("/api/mapping/{id}", handler.UpdateMapping)

			req := httptest.NewRequest(http.MethodPut, "/api/mapping/"+tt.urlID, strings.NewReader(tt.requestBody))
			w := httptest.NewRecorder()

			r.ServeHTTP(w, req)

			assert.Equal(t, tt.expectedStatus, w.Code)
			if tt.checkResponse != nil {
				tt.checkResponse(t, w)
			}
		})
	}
}

func TestMappingHandler_AutoMatch(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)

	tests := []struct {
		name           string
		requestBody    string
		setupMock      func() *MockMappingServiceRegistry
		expectedStatus int
		checkResponse  func(*testing.T, *httptest.ResponseRecorder)
	}{
		{
			name:        "Invalid request body",
			requestBody: "invalid json",
			setupMock: func() *MockMappingServiceRegistry {
				return &MockMappingServiceRegistry{}
			},
			expectedStatus: http.StatusBadRequest,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "invalid_request", response.Error.Code)
			},
		},
		{
			name:        "Invalid from_date",
			requestBody: `{"from_date": "invalid-date", "threshold": 0.8}`,
			setupMock: func() *MockMappingServiceRegistry {
				return &MockMappingServiceRegistry{}
			},
			expectedStatus: http.StatusBadRequest,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "invalid_date", response.Error.Code)
			},
		},
		{
			name:        "Invalid to_date",
			requestBody: `{"from_date": "2023-01-01", "to_date": "invalid-date", "threshold": 0.8}`,
			setupMock: func() *MockMappingServiceRegistry {
				return &MockMappingServiceRegistry{}
			},
			expectedStatus: http.StatusBadRequest,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "invalid_date", response.Error.Code)
			},
		},
		{
			name:        "Service unavailable",
			requestBody: `{"threshold": 0.8}`,
			setupMock: func() *MockMappingServiceRegistry {
				return &MockMappingServiceRegistry{mappingService: nil}
			},
			expectedStatus: http.StatusServiceUnavailable,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "service_unavailable", response.Error.Code)
			},
		},
		{
			name:        "Successful auto-match with defaults",
			requestBody: `{}`,
			setupMock: func() *MockMappingServiceRegistry {
				mockMapping := &MockMappingService{}
				results := []*models.AutoMatchResult{
					{
						ETCMeisaiID: 123,
						BestMatch: &models.PotentialMatch{
							DTakoRowID:   "row_456",
							Confidence:   0.9,
							MatchReasons: []string{"time_match", "amount_match"},
						},
					},
					{
						ETCMeisaiID: 124,
						Error:       "No suitable matches found",
					},
					{
						ETCMeisaiID: 125,
						BestMatch: &models.PotentialMatch{
							DTakoRowID:   "row_789",
							Confidence:   0.7, // Below threshold
							MatchReasons: []string{"time_match"},
						},
					},
				}
				mockMapping.On("AutoMatch", mock.AnythingOfType("*context.timerCtx"), mock.AnythingOfType("time.Time"), mock.AnythingOfType("time.Time"), float32(0.8)).Return(results, nil)
				return &MockMappingServiceRegistry{mappingService: mockMapping}
			},
			expectedStatus: http.StatusOK,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response SuccessResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.True(t, response.Success)
				assert.Equal(t, "Auto-matching completed", response.Message)

				data := response.Data.(map[string]interface{})
				assert.Equal(t, float64(1), data["matched_count"])   // Only one above threshold
				assert.Equal(t, float64(1), data["unmatched_count"]) // One below threshold
				assert.Equal(t, float64(1), data["error_count"])     // One with error
				assert.Equal(t, 0.8, data["threshold"])
			},
		},
		{
			name:        "Successful auto-match with custom dates and threshold",
			requestBody: `{"from_date": "2023-01-01", "to_date": "2023-01-31", "threshold": 0.9, "etc_num": "1234567890"}`,
			setupMock: func() *MockMappingServiceRegistry {
				mockMapping := &MockMappingService{}
				results := []*models.AutoMatchResult{
					{
						ETCMeisaiID: 123,
						BestMatch: &models.PotentialMatch{
							DTakoRowID:   "row_456",
							Confidence:   0.95,
							MatchReasons: []string{"exact_match"},
						},
					},
				}

				expectedStartDate := time.Date(2023, 1, 1, 0, 0, 0, 0, time.UTC)
				expectedEndDate := time.Date(2023, 1, 31, 0, 0, 0, 0, time.UTC)
				mockMapping.On("AutoMatch", mock.AnythingOfType("*context.timerCtx"), expectedStartDate, expectedEndDate, float32(0.9)).Return(results, nil)
				return &MockMappingServiceRegistry{mappingService: mockMapping}
			},
			expectedStatus: http.StatusOK,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response SuccessResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.True(t, response.Success)

				data := response.Data.(map[string]interface{})
				assert.Equal(t, float64(1), data["matched_count"])
				assert.Equal(t, float64(0), data["unmatched_count"])
				assert.Equal(t, float64(0), data["error_count"])
				assert.Equal(t, 0.9, data["threshold"])

				dateRange := data["date_range"].(map[string]interface{})
				assert.Equal(t, "2023-01-01", dateRange["from"])
				assert.Equal(t, "2023-01-31", dateRange["to"])
			},
		},
		{
			name:        "Auto-match with partial dates",
			requestBody: `{"from_date": "2023-01-01", "threshold": 0.8}`,
			setupMock: func() *MockMappingServiceRegistry {
				mockMapping := &MockMappingService{}
				results := []*models.AutoMatchResult{}

				expectedStartDate := time.Date(2023, 1, 1, 0, 0, 0, 0, time.UTC)
				mockMapping.On("AutoMatch", mock.AnythingOfType("*context.timerCtx"), expectedStartDate, mock.AnythingOfType("time.Time"), float32(0.8)).Return(results, nil)
				return &MockMappingServiceRegistry{mappingService: mockMapping}
			},
			expectedStatus: http.StatusOK,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response SuccessResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.True(t, response.Success)

				data := response.Data.(map[string]interface{})
				dateRange := data["date_range"].(map[string]interface{})
				assert.Equal(t, "2023-01-01", dateRange["from"])
				// to_date should be today's date
				assert.NotEmpty(t, dateRange["to"])
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockRegistry := tt.setupMock()
			handler := &MappingHandler{
				BaseHandler: BaseHandler{
					ServiceRegistry: mockRegistry,
					Logger:          logger,
					ErrorHandler:    NewGRPCErrorHandler(),
				},
			}

			req := httptest.NewRequest(http.MethodPost, "/api/mapping/auto-match", strings.NewReader(tt.requestBody))
			w := httptest.NewRecorder()

			handler.AutoMatch(w, req)

			assert.Equal(t, tt.expectedStatus, w.Code)
			if tt.checkResponse != nil {
				tt.checkResponse(t, w)
			}
		})
	}
}

func TestCreateMappingRequest_Structure(t *testing.T) {
	tests := []struct {
		name     string
		jsonData string
		expected CreateMappingRequest
	}{
		{
			name:     "Complete request",
			jsonData: `{"etc_meisai_id": 123, "dtako_row_id": 456, "match_type": "manual"}`,
			expected: CreateMappingRequest{
				ETCMeisaiID: 123,
				DtakoRowID:  456,
				MatchType:   "manual",
			},
		},
		{
			name:     "Minimal request",
			jsonData: `{"etc_meisai_id": 123, "dtako_row_id": 456}`,
			expected: CreateMappingRequest{
				ETCMeisaiID: 123,
				DtakoRowID:  456,
				MatchType:   "",
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			var req CreateMappingRequest
			err := json.Unmarshal([]byte(tt.jsonData), &req)
			assert.NoError(t, err)
			assert.Equal(t, tt.expected, req)
		})
	}
}

func TestUpdateMappingRequest_Structure(t *testing.T) {
	tests := []struct {
		name     string
		jsonData string
		expected UpdateMappingRequest
	}{
		{
			name:     "Complete request",
			jsonData: `{"dtako_row_id": 789, "is_active": true}`,
			expected: UpdateMappingRequest{
				DtakoRowID: mappingInt64Ptr(789),
				IsActive:   mappingBoolPtr(true),
			},
		},
		{
			name:     "Partial request",
			jsonData: `{"is_active": false}`,
			expected: UpdateMappingRequest{
				DtakoRowID: nil,
				IsActive:   mappingBoolPtr(false),
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			var req UpdateMappingRequest
			err := json.Unmarshal([]byte(tt.jsonData), &req)
			assert.NoError(t, err)
			assert.Equal(t, tt.expected, req)
		})
	}
}

func TestAutoMatchRequest_Structure(t *testing.T) {
	tests := []struct {
		name     string
		jsonData string
		expected AutoMatchRequest
	}{
		{
			name:     "Complete request",
			jsonData: `{"etc_num": "1234567890", "from_date": "2023-01-01", "to_date": "2023-01-31", "threshold": 0.8}`,
			expected: AutoMatchRequest{
				ETCNum:    "1234567890",
				FromDate:  "2023-01-01",
				ToDate:    "2023-01-31",
				Threshold: 0.8,
			},
		},
		{
			name:     "Minimal request",
			jsonData: `{"etc_num": "1234567890", "threshold": 0.9}`,
			expected: AutoMatchRequest{
				ETCNum:    "1234567890",
				FromDate:  "",
				ToDate:    "",
				Threshold: 0.9,
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			var req AutoMatchRequest
			err := json.Unmarshal([]byte(tt.jsonData), &req)
			assert.NoError(t, err)
			assert.Equal(t, tt.expected, req)
		})
	}
}

func TestETCDtakoMapping_Structure(t *testing.T) {
	tests := []struct {
		name     string
		mapping  ETCDtakoMapping
		expected string
	}{
		{
			name: "Complete mapping",
			mapping: ETCDtakoMapping{
				ID:          1,
				ETCMeisaiID: 123,
				DtakoRowID:  456,
				MatchType:   "auto",
				Confidence:  0.95,
				IsManual:    false,
				CreatedBy:   "system",
				CreatedAt:   "2023-01-01T00:00:00Z",
			},
			expected: `{"id":1,"etc_meisai_id":123,"dtako_row_id":456,"match_type":"auto","confidence":0.95,"is_manual":false,"created_by":"system","created_at":"2023-01-01T00:00:00Z"}`,
		},
		{
			name: "Manual mapping",
			mapping: ETCDtakoMapping{
				ID:          2,
				ETCMeisaiID: 124,
				DtakoRowID:  457,
				MatchType:   "manual",
				Confidence:  1.0,
				IsManual:    true,
				CreatedBy:   "user",
				CreatedAt:   "2023-01-02T00:00:00Z",
			},
			expected: `{"id":2,"etc_meisai_id":124,"dtako_row_id":457,"match_type":"manual","confidence":1,"is_manual":true,"created_by":"user","created_at":"2023-01-02T00:00:00Z"}`,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			jsonData, err := json.Marshal(tt.mapping)
			assert.NoError(t, err)
			assert.JSONEq(t, tt.expected, string(jsonData))
		})
	}
}

// Helper functions for pointer types
func mappingInt64Ptr(i int64) *int64 {
	return &i
}

func mappingBoolPtr(b bool) *bool {
	return &b
}