package handlers

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"net/http/httptest"
	"os"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.com/yhonda-ohishi/etc_meisai/src/services"
)

// MockServiceRegistry for testing
type MockServiceRegistry struct {
	mock.Mock
}

func (m *MockServiceRegistry) HealthCheck(ctx context.Context) *services.HealthCheckResult {
	args := m.Called(ctx)
	return args.Get(0).(*services.HealthCheckResult)
}

func (m *MockServiceRegistry) GetETCService() *services.ETCService {
	args := m.Called()
	return args.Get(0).(*services.ETCService)
}

func (m *MockServiceRegistry) GetMappingService() *services.MappingService {
	args := m.Called()
	return args.Get(0).(*services.MappingService)
}

func (m *MockServiceRegistry) GetBaseService() *services.BaseService {
	args := m.Called()
	return args.Get(0).(*services.BaseService)
}

func (m *MockServiceRegistry) GetImportService() *services.ImportServiceLegacy {
	args := m.Called()
	return args.Get(0).(*services.ImportServiceLegacy)
}

func (m *MockServiceRegistry) GetDownloadService() services.DownloadServiceInterface {
	args := m.Called()
	return args.Get(0).(services.DownloadServiceInterface)
}

func (m *MockServiceRegistry) GetDatabaseServiceClient() interface{} {
	args := m.Called()
	return args.Get(0)
}

func TestNewBaseHandler(t *testing.T) {
	tests := []struct {
		name            string
		serviceRegistry services.ServiceRegistryInterface
		logger          *log.Logger
		wantNil         bool
	}{
		{
			name:            "Valid inputs",
			serviceRegistry: &MockServiceRegistry{},
			logger:          log.New(os.Stdout, "", log.LstdFlags),
			wantNil:         false,
		},
		{
			name:            "Nil service registry",
			serviceRegistry: nil,
			logger:          log.New(os.Stdout, "", log.LstdFlags),
			wantNil:         false,
		},
		{
			name:            "Nil logger",
			serviceRegistry: &services.ServiceRegistry{},
			logger:          nil,
			wantNil:         false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			handler := NewBaseHandler(tt.serviceRegistry, tt.logger)

			if tt.wantNil {
				assert.Nil(t, handler)
			} else {
				assert.NotNil(t, handler)
				assert.Equal(t, tt.serviceRegistry, handler.ServiceRegistry)
				assert.Equal(t, tt.logger, handler.Logger)
				assert.NotNil(t, handler.ErrorHandler)
			}
		})
	}
}

func TestBaseHandler_RespondJSON(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)
	handler := NewBaseHandler(nil, logger)

	tests := []struct {
		name           string
		status         int
		data           interface{}
		expectedStatus int
		expectedBody   string
	}{
		{
			name:           "Success response",
			status:         http.StatusOK,
			data:           map[string]string{"message": "success"},
			expectedStatus: http.StatusOK,
			expectedBody:   `{"message":"success"}`,
		},
		{
			name:           "Error response",
			status:         http.StatusBadRequest,
			data:           map[string]string{"error": "bad request"},
			expectedStatus: http.StatusBadRequest,
			expectedBody:   `{"error":"bad request"}`,
		},
		{
			name:           "Nil data",
			status:         http.StatusNoContent,
			data:           nil,
			expectedStatus: http.StatusNoContent,
			expectedBody:   "null",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			w := httptest.NewRecorder()

			handler.RespondJSON(w, tt.status, tt.data)

			assert.Equal(t, tt.expectedStatus, w.Code)
			assert.Equal(t, "application/json", w.Header().Get("Content-Type"))
			assert.JSONEq(t, tt.expectedBody, w.Body.String())
		})
	}
}

func TestBaseHandler_RespondError(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)
	handler := NewBaseHandler(nil, logger)

	tests := []struct {
		name           string
		status         int
		code           string
		message        string
		details        interface{}
		expectedStatus int
	}{
		{
			name:           "Basic error",
			status:         http.StatusBadRequest,
			code:           "invalid_input",
			message:        "Invalid input provided",
			details:        nil,
			expectedStatus: http.StatusBadRequest,
		},
		{
			name:           "Error with details",
			status:         http.StatusUnprocessableEntity,
			code:           "validation_failed",
			message:        "Validation failed",
			details:        map[string]string{"field": "username", "issue": "required"},
			expectedStatus: http.StatusUnprocessableEntity,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			w := httptest.NewRecorder()

			handler.RespondError(w, tt.status, tt.code, tt.message, tt.details)

			assert.Equal(t, tt.expectedStatus, w.Code)
			assert.Equal(t, "application/json", w.Header().Get("Content-Type"))

			var response ErrorResponse
			err := json.NewDecoder(w.Body).Decode(&response)
			assert.NoError(t, err)
			assert.Equal(t, tt.code, response.Error.Code)
			assert.Equal(t, tt.message, response.Error.Message)
			assert.Equal(t, tt.details, response.Error.Details)
		})
	}
}

func TestBaseHandler_RespondSuccess(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)
	handler := NewBaseHandler(nil, logger)

	tests := []struct {
		name     string
		data     interface{}
		message  string
		expected SuccessResponse
	}{
		{
			name:    "Success with data and message",
			data:    map[string]string{"id": "123"},
			message: "Operation completed",
			expected: SuccessResponse{
				Success: true,
				Data:    map[string]interface{}{"id": "123"},
				Message: "Operation completed",
			},
		},
		{
			name:    "Success without message",
			data:    "simple data",
			message: "",
			expected: SuccessResponse{
				Success: true,
				Data:    "simple data",
				Message: "",
			},
		},
		{
			name:    "Success without data",
			data:    nil,
			message: "No data to return",
			expected: SuccessResponse{
				Success: true,
				Data:    nil,
				Message: "No data to return",
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			w := httptest.NewRecorder()

			handler.RespondSuccess(w, tt.data, tt.message)

			assert.Equal(t, http.StatusOK, w.Code)
			assert.Equal(t, "application/json", w.Header().Get("Content-Type"))

			var response SuccessResponse
			err := json.NewDecoder(w.Body).Decode(&response)
			assert.NoError(t, err)
			assert.Equal(t, tt.expected.Success, response.Success)
			assert.Equal(t, tt.expected.Message, response.Message)
		})
	}
}

func TestBaseHandler_RespondGRPCError(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)
	handler := NewBaseHandler(nil, logger)

	tests := []struct {
		name      string
		err       error
		requestID string
	}{
		{
			name:      "Standard error",
			err:       fmt.Errorf("standard error"),
			requestID: "req-123",
		},
		{
			name:      "Nil error",
			err:       nil,
			requestID: "req-456",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			w := httptest.NewRecorder()

			handler.RespondGRPCError(w, tt.err, tt.requestID)

			assert.Equal(t, "application/json", w.Header().Get("Content-Type"))

			var response ErrorResponse
			err := json.NewDecoder(w.Body).Decode(&response)
			assert.NoError(t, err)
			assert.NotEmpty(t, response.Error.Code)
			assert.NotEmpty(t, response.Error.Message)
		})
	}
}

func TestBaseHandler_HealthCheck(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)

	tests := []struct {
		name           string
		serviceRegistry *services.ServiceRegistry
		mockSetup      func() *MockServiceRegistry
		expectedStatus int
		checkResponse  func(*testing.T, *httptest.ResponseRecorder)
	}{
		{
			name:            "Nil service registry",
			serviceRegistry: nil,
			mockSetup:       nil,
			expectedStatus:  http.StatusServiceUnavailable,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "service_unavailable", response.Error.Code)
			},
		},
		{
			name: "Healthy service",
			mockSetup: func() *MockServiceRegistry {
				mockRegistry := &MockServiceRegistry{}
				healthResult := &services.HealthCheckResult{
					Status: "healthy",
					Services: map[string]*services.ServiceHealth{
						"test": {Status: "healthy"},
					},
				}
				mockRegistry.On("HealthCheck", mock.AnythingOfType("*context.timerCtx")).Return(healthResult)
				return mockRegistry
			},
			expectedStatus: http.StatusOK,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response services.HealthCheckResult
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "healthy", response.Status)
			},
		},
		{
			name: "Unhealthy service",
			mockSetup: func() *MockServiceRegistry {
				mockRegistry := &MockServiceRegistry{}
				healthResult := &services.HealthCheckResult{
					Status: "unhealthy",
					Services: map[string]*services.ServiceHealth{
						"test": {Status: "unhealthy", Error: "connection failed"},
					},
				}
				mockRegistry.On("HealthCheck", mock.AnythingOfType("*context.timerCtx")).Return(healthResult)
				return mockRegistry
			},
			expectedStatus: http.StatusServiceUnavailable,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response services.HealthCheckResult
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "unhealthy", response.Status)
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			handler := NewBaseHandler(tt.serviceRegistry, logger)

			if tt.mockSetup != nil {
				mockRegistry := tt.mockSetup()
				handler.ServiceRegistry = mockRegistry
			}

			req := httptest.NewRequest(http.MethodGet, "/health", nil)
			w := httptest.NewRecorder()

			handler.HealthCheck(w, req)

			assert.Equal(t, tt.expectedStatus, w.Code)
			assert.Equal(t, "application/json", w.Header().Get("Content-Type"))

			if tt.checkResponse != nil {
				tt.checkResponse(t, w)
			}
		})
	}
}

func TestBaseHandler_HealthCheck_Timeout(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)
	handler := NewBaseHandler(&MockServiceRegistry{}, logger)

	mockRegistry := &MockServiceRegistry{}

	mockRegistry.On("HealthCheck", mock.AnythingOfType("*context.timerCtx")).Return(func(ctx context.Context) *services.HealthCheckResult {
		select {
		case <-time.After(15 * time.Second):
			return &services.HealthCheckResult{Status: "timeout"}
		case <-ctx.Done():
			return &services.HealthCheckResult{Status: "cancelled"}
		}
	})

	handler.ServiceRegistry = mockRegistry

	req := httptest.NewRequest(http.MethodGet, "/health", nil)
	w := httptest.NewRecorder()

	start := time.Now()
	handler.HealthCheck(w, req)
	duration := time.Since(start)

	assert.True(t, duration < 15*time.Second, "Health check should timeout before 15 seconds")
	assert.Equal(t, "application/json", w.Header().Get("Content-Type"))
}

func TestErrorResponse_Structure(t *testing.T) {
	tests := []struct {
		name     string
		response ErrorResponse
	}{
		{
			name: "Complete error response",
			response: ErrorResponse{
				Error: struct {
					Code    string      `json:"code"`
					Message string      `json:"message"`
					Details interface{} `json:"details,omitempty"`
				}{
					Code:    "test_error",
					Message: "Test error message",
					Details: map[string]string{"field": "value"},
				},
			},
		},
		{
			name: "Error response without details",
			response: ErrorResponse{
				Error: struct {
					Code    string      `json:"code"`
					Message string      `json:"message"`
					Details interface{} `json:"details,omitempty"`
				}{
					Code:    "simple_error",
					Message: "Simple error message",
					Details: nil,
				},
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			jsonData, err := json.Marshal(tt.response)
			assert.NoError(t, err)

			var decoded ErrorResponse
			err = json.Unmarshal(jsonData, &decoded)
			assert.NoError(t, err)

			assert.Equal(t, tt.response.Error.Code, decoded.Error.Code)
			assert.Equal(t, tt.response.Error.Message, decoded.Error.Message)
		})
	}
}

func TestSuccessResponse_Structure(t *testing.T) {
	tests := []struct {
		name     string
		response SuccessResponse
	}{
		{
			name: "Complete success response",
			response: SuccessResponse{
				Success: true,
				Data:    map[string]string{"id": "123"},
				Message: "Operation successful",
			},
		},
		{
			name: "Success response without message",
			response: SuccessResponse{
				Success: true,
				Data:    "simple data",
				Message: "",
			},
		},
		{
			name: "Success response without data",
			response: SuccessResponse{
				Success: true,
				Data:    nil,
				Message: "No data to return",
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			jsonData, err := json.Marshal(tt.response)
			assert.NoError(t, err)

			var decoded SuccessResponse
			err = json.Unmarshal(jsonData, &decoded)
			assert.NoError(t, err)

			assert.Equal(t, tt.response.Success, decoded.Success)
			assert.Equal(t, tt.response.Message, decoded.Message)
		})
	}
}

func TestBaseHandler_RespondJSON_EncodingError(t *testing.T) {
	var logBuffer bytes.Buffer
	logger := log.New(&logBuffer, "", log.LstdFlags)
	handler := NewBaseHandler(nil, logger)

	w := httptest.NewRecorder()

	invalidData := func() {}
	handler.RespondJSON(w, http.StatusOK, invalidData)

	assert.Contains(t, logBuffer.String(), "Failed to encode response")
	assert.Equal(t, "application/json", w.Header().Get("Content-Type"))
	assert.Equal(t, http.StatusOK, w.Code)
}