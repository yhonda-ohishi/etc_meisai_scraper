package handlers_test

import (
	"context"
	"errors"
	"net/http"
	"testing"

	"github.com/stretchr/testify/assert"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
	"github.com/yhonda-ohishi/etc_meisai/src/handlers"
)

func TestNewGRPCErrorHandler(t *testing.T) {
	t.Parallel()

	handler := handlers.NewGRPCErrorHandler()

	assert.NotNil(t, handler)
}

func TestGRPCErrorHandler_HandleGRPCError(t *testing.T) {
	t.Parallel()

	handler := handlers.NewGRPCErrorHandler()

	tests := []struct {
		name           string
		err            error
		expectedStatus int
		expectedCode   string
		expectedMsg    string
	}{
		{
			name:           "nil error",
			err:            nil,
			expectedStatus: http.StatusOK,
			expectedCode:   "success",
			expectedMsg:    "Operation completed successfully",
		},
		{
			name:           "context deadline exceeded",
			err:            context.DeadlineExceeded,
			expectedStatus: http.StatusRequestTimeout,
			expectedCode:   "timeout",
			expectedMsg:    "Request timeout exceeded",
		},
		{
			name:           "context canceled",
			err:            context.Canceled,
			expectedStatus: http.StatusRequestTimeout,
			expectedCode:   "canceled",
			expectedMsg:    "Request was canceled",
		},
		{
			name:           "generic error",
			err:            errors.New("generic error"),
			expectedStatus: http.StatusInternalServerError,
			expectedCode:   "internal_error",
			expectedMsg:    "generic error",
		},
		{
			name:           "gRPC OK status",
			err:            status.Error(codes.OK, "success"),
			expectedStatus: http.StatusOK,
			expectedCode:   "success",
			expectedMsg:    "Operation completed successfully",
		},
		{
			name:           "gRPC InvalidArgument status",
			err:            status.Error(codes.InvalidArgument, "invalid input"),
			expectedStatus: http.StatusBadRequest,
			expectedCode:   "invalid_argument",
			expectedMsg:    "invalid input",
		},
		{
			name:           "gRPC NotFound status",
			err:            status.Error(codes.NotFound, "resource not found"),
			expectedStatus: http.StatusNotFound,
			expectedCode:   "not_found",
			expectedMsg:    "resource not found",
		},
		{
			name:           "gRPC AlreadyExists status",
			err:            status.Error(codes.AlreadyExists, "resource exists"),
			expectedStatus: http.StatusConflict,
			expectedCode:   "already_exists",
			expectedMsg:    "resource exists",
		},
		{
			name:           "gRPC PermissionDenied status",
			err:            status.Error(codes.PermissionDenied, "access denied"),
			expectedStatus: http.StatusForbidden,
			expectedCode:   "permission_denied",
			expectedMsg:    "access denied",
		},
		{
			name:           "gRPC Unauthenticated status",
			err:            status.Error(codes.Unauthenticated, "not authenticated"),
			expectedStatus: http.StatusUnauthorized,
			expectedCode:   "unauthenticated",
			expectedMsg:    "not authenticated",
		},
		{
			name:           "gRPC ResourceExhausted status",
			err:            status.Error(codes.ResourceExhausted, "rate limited"),
			expectedStatus: http.StatusTooManyRequests,
			expectedCode:   "resource_exhausted",
			expectedMsg:    "rate limited",
		},
		{
			name:           "gRPC FailedPrecondition status",
			err:            status.Error(codes.FailedPrecondition, "precondition failed"),
			expectedStatus: http.StatusPreconditionFailed,
			expectedCode:   "failed_precondition",
			expectedMsg:    "precondition failed",
		},
		{
			name:           "gRPC Aborted status",
			err:            status.Error(codes.Aborted, "operation aborted"),
			expectedStatus: http.StatusConflict,
			expectedCode:   "aborted",
			expectedMsg:    "operation aborted",
		},
		{
			name:           "gRPC OutOfRange status",
			err:            status.Error(codes.OutOfRange, "out of range"),
			expectedStatus: http.StatusBadRequest,
			expectedCode:   "out_of_range",
			expectedMsg:    "out of range",
		},
		{
			name:           "gRPC Unimplemented status",
			err:            status.Error(codes.Unimplemented, "not implemented"),
			expectedStatus: http.StatusNotImplemented,
			expectedCode:   "unimplemented",
			expectedMsg:    "not implemented",
		},
		{
			name:           "gRPC Internal status",
			err:            status.Error(codes.Internal, "internal error"),
			expectedStatus: http.StatusInternalServerError,
			expectedCode:   "internal_error",
			expectedMsg:    "internal error",
		},
		{
			name:           "gRPC Unavailable status",
			err:            status.Error(codes.Unavailable, "service unavailable"),
			expectedStatus: http.StatusServiceUnavailable,
			expectedCode:   "unavailable",
			expectedMsg:    "service unavailable",
		},
		{
			name:           "gRPC DataLoss status",
			err:            status.Error(codes.DataLoss, "data loss"),
			expectedStatus: http.StatusInternalServerError,
			expectedCode:   "data_loss",
			expectedMsg:    "data loss",
		},
		{
			name:           "gRPC DeadlineExceeded status",
			err:            status.Error(codes.DeadlineExceeded, "deadline exceeded"),
			expectedStatus: http.StatusRequestTimeout,
			expectedCode:   "deadline_exceeded",
			expectedMsg:    "deadline exceeded",
		},
		{
			name:           "gRPC Canceled status",
			err:            status.Error(codes.Canceled, "canceled"),
			expectedStatus: http.StatusRequestTimeout,
			expectedCode:   "canceled",
			expectedMsg:    "canceled",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			status, code, message := handler.HandleGRPCError(tt.err)

			assert.Equal(t, tt.expectedStatus, status)
			assert.Equal(t, tt.expectedCode, code)
			assert.Equal(t, tt.expectedMsg, message)
		})
	}
}

func TestGRPCErrorHandler_CreateErrorDetail(t *testing.T) {
	t.Parallel()

	handler := handlers.NewGRPCErrorHandler()

	tests := []struct {
		name        string
		err         error
		requestID   string
		expectedDetails bool
	}{
		{
			name:      "nil error",
			err:       nil,
			requestID: "req-123",
			expectedDetails: false,
		},
		{
			name:      "gRPC error with details",
			err:       status.Error(codes.InvalidArgument, "invalid input"),
			requestID: "req-456",
			expectedDetails: false, // No details in this case
		},
		{
			name:      "generic error",
			err:       errors.New("test error"),
			requestID: "req-789",
			expectedDetails: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			detail := handler.CreateErrorDetail(tt.err, tt.requestID)

			assert.NotNil(t, detail)
			assert.Equal(t, tt.requestID, detail.RequestID)
			assert.NotEmpty(t, detail.Code)
			assert.NotEmpty(t, detail.Message)
			assert.NotEmpty(t, detail.Timestamp)

			if tt.expectedDetails {
				assert.NotNil(t, detail.Details)
			}

			// Check if gRPC code is set for gRPC errors
			if st, ok := status.FromError(tt.err); ok {
				assert.Equal(t, st.Code().String(), detail.GRPCCode)
			}
		})
	}
}

func TestGRPCErrorHandler_HandleValidationErrors(t *testing.T) {
	t.Parallel()

	handler := handlers.NewGRPCErrorHandler()

	tests := []struct {
		name           string
		errors         []handlers.ValidationError
		expectedStatus int
		expectedCode   string
	}{
		{
			name:           "single validation error",
			errors:         []handlers.ValidationError{{Field: "email", Message: "invalid format"}},
			expectedStatus: http.StatusBadRequest,
			expectedCode:   "validation_failed",
		},
		{
			name: "multiple validation errors",
			errors: []handlers.ValidationError{
				{Field: "email", Message: "invalid format"},
				{Field: "password", Message: "too short"},
			},
			expectedStatus: http.StatusBadRequest,
			expectedCode:   "validation_failed",
		},
		{
			name:           "empty validation errors",
			errors:         []handlers.ValidationError{},
			expectedStatus: http.StatusBadRequest,
			expectedCode:   "validation_failed",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			status, code, details := handler.HandleValidationErrors(tt.errors)

			assert.Equal(t, tt.expectedStatus, status)
			assert.Equal(t, tt.expectedCode, code)
			assert.NotNil(t, details)

			detailMap, ok := details.(map[string]interface{})
			assert.True(t, ok)
			assert.Contains(t, detailMap, "validation_errors")
			assert.Contains(t, detailMap, "message")
		})
	}
}

func TestGRPCErrorHandler_HandleBusinessLogicError(t *testing.T) {
	t.Parallel()

	handler := handlers.NewGRPCErrorHandler()

	tests := []struct {
		name           string
		err            handlers.BusinessLogicError
		expectedStatus int
	}{
		{
			name: "basic business logic error",
			err: handlers.BusinessLogicError{
				Code:    "INSUFFICIENT_FUNDS",
				Message: "Account balance too low",
				Context: "payment processing",
			},
			expectedStatus: http.StatusUnprocessableEntity,
		},
		{
			name: "business logic error without context",
			err: handlers.BusinessLogicError{
				Code:    "INVALID_OPERATION",
				Message: "Operation not allowed",
			},
			expectedStatus: http.StatusUnprocessableEntity,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			status, code, details := handler.HandleBusinessLogicError(tt.err)

			assert.Equal(t, tt.expectedStatus, status)
			assert.Equal(t, tt.err.Code, code)
			assert.NotNil(t, details)

			detailMap, ok := details.(map[string]interface{})
			assert.True(t, ok)
			assert.Contains(t, detailMap, "business_error")
			assert.Contains(t, detailMap, "message")
			assert.Equal(t, tt.err.Message, detailMap["message"])
		})
	}
}

func TestErrorDetail_Structure(t *testing.T) {
	t.Parallel()

	detail := &handlers.ErrorDetail{
		Code:      "test_code",
		Message:   "test message",
		Details:   map[string]string{"key": "value"},
		GRPCCode:  "INVALID_ARGUMENT",
		Timestamp: "123456789",
		RequestID: "req-test",
	}

	assert.Equal(t, "test_code", detail.Code)
	assert.Equal(t, "test message", detail.Message)
	assert.NotNil(t, detail.Details)
	assert.Equal(t, "INVALID_ARGUMENT", detail.GRPCCode)
	assert.Equal(t, "123456789", detail.Timestamp)
	assert.Equal(t, "req-test", detail.RequestID)
}

func TestValidationError_Structure(t *testing.T) {
	t.Parallel()

	validationError := handlers.ValidationError{
		Field:   "username",
		Message: "required field",
		Value:   "test",
	}

	assert.Equal(t, "username", validationError.Field)
	assert.Equal(t, "required field", validationError.Message)
	assert.Equal(t, "test", validationError.Value)
}

func TestBusinessLogicError_Structure(t *testing.T) {
	t.Parallel()

	businessError := handlers.BusinessLogicError{
		Code:    "BUSINESS_RULE_VIOLATION",
		Message: "Business rule violated",
		Context: "user registration",
	}

	assert.Equal(t, "BUSINESS_RULE_VIOLATION", businessError.Code)
	assert.Equal(t, "Business rule violated", businessError.Message)
	assert.Equal(t, "user registration", businessError.Context)
}

// Edge case tests
func TestGRPCErrorHandler_UnknownGRPCCode(t *testing.T) {
	t.Parallel()

	handler := handlers.NewGRPCErrorHandler()

	// Create a status with an undefined code (this is theoretical since all codes are defined)
	// We'll test with the highest known code + 1 to simulate unknown
	unknownCode := codes.Code(99) // Assuming 99 is not defined
	err := status.Error(unknownCode, "unknown error")

	httpStatus, code, message := handler.HandleGRPCError(err)

	assert.Equal(t, http.StatusInternalServerError, httpStatus)
	assert.Equal(t, "unknown_error", code)
	assert.Contains(t, message, "Unknown gRPC error")
}

func TestGRPCErrorHandler_CreateErrorDetail_EmptyRequestID(t *testing.T) {
	t.Parallel()

	handler := handlers.NewGRPCErrorHandler()
	err := errors.New("test error")

	detail := handler.CreateErrorDetail(err, "")

	assert.NotNil(t, detail)
	assert.Empty(t, detail.RequestID)
	assert.NotEmpty(t, detail.Code)
	assert.NotEmpty(t, detail.Message)
}

// Benchmark tests
func BenchmarkGRPCErrorHandler_HandleGRPCError(b *testing.B) {
	handler := handlers.NewGRPCErrorHandler()
	err := status.Error(codes.InvalidArgument, "test error")

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, _, _ = handler.HandleGRPCError(err)
	}
}

func BenchmarkGRPCErrorHandler_CreateErrorDetail(b *testing.B) {
	handler := handlers.NewGRPCErrorHandler()
	err := status.Error(codes.Internal, "test error")

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_ = handler.CreateErrorDetail(err, "req-123")
	}
}