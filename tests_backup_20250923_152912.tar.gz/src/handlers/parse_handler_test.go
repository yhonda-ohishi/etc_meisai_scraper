package handlers

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"log"
	"mime/multipart"
	"net/http"
	"net/http/httptest"
	"os"
	"strings"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.com/yhonda-ohishi/etc_meisai/src/models"
	"github.com/yhonda-ohishi/etc_meisai/src/services"
)

// MockImportService for parse handler testing
type MockParseImportService struct {
	mock.Mock
}

func (m *MockParseImportService) ProcessCSVFile(ctx context.Context, filePath, accountID, accountType string) (*models.ETCImportBatch, error) {
	args := m.Called(ctx, filePath, accountID, accountType)
	return args.Get(0).(*models.ETCImportBatch), args.Error(1)
}

func (m *MockParseImportService) ValidateImportFile(filePath string) error {
	args := m.Called(filePath)
	return args.Error(0)
}

func (m *MockParseImportService) HealthCheck(ctx context.Context) error {
	args := m.Called(ctx)
	return args.Error(0)
}

// MockParseServiceRegistry for parse handler testing
type MockParseServiceRegistry struct {
	mock.Mock
	importService *MockParseImportService
}

func (m *MockParseServiceRegistry) GetETCService() *services.ETCService {
	return nil
}

func (m *MockParseServiceRegistry) GetMappingService() *services.MappingService {
	return nil
}

func (m *MockParseServiceRegistry) GetBaseService() *services.BaseService {
	return nil
}

func (m *MockParseServiceRegistry) GetImportService() *services.ImportServiceLegacy {
	return nil // Parse handler tests don't use concrete import service
}

func (m *MockParseServiceRegistry) GetDownloadService() services.DownloadServiceInterface {
	return nil
}

func (m *MockParseServiceRegistry) HealthCheck(ctx context.Context) *services.HealthCheckResult {
	args := m.Called(ctx)
	return args.Get(0).(*services.HealthCheckResult)
}

func (m *MockParseServiceRegistry) GetDatabaseServiceClient() interface{} {
	args := m.Called()
	return args.Get(0)
}

func TestNewParseHandler(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)
	serviceRegistry := &services.ServiceRegistry{}

	handler := NewParseHandler(serviceRegistry, logger)

	assert.NotNil(t, handler)
	assert.NotNil(t, handler.BaseHandler)
	assert.NotNil(t, handler.Parser)
	assert.NotNil(t, handler.CompatAdapter)
	assert.Equal(t, serviceRegistry, handler.ServiceRegistry)
	assert.Equal(t, logger, handler.Logger)
}

func TestParseHandler_ParseCSV(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)

	// Create a test CSV content
	csvContent := `利用日,利用時刻,IC,車種,入口,出口,距離(km),利用料金(円)
2023/01/15,06:30,1234567890,普通車,東京IC,新宿IC,25,630
2023/01/15,07:45,1234567890,普通車,新宿IC,渋谷IC,8,250`

	tests := []struct {
		name           string
		setupForm      func() (*bytes.Buffer, string)
		setupMock      func() *MockParseServiceRegistry
		expectedStatus int
		checkResponse  func(*testing.T, *httptest.ResponseRecorder)
	}{
		{
			name: "Invalid multipart form",
			setupForm: func() (*bytes.Buffer, string) {
				return bytes.NewBuffer([]byte("invalid")), "application/json"
			},
			setupMock: func() *MockParseServiceRegistry {
				return &MockParseServiceRegistry{}
			},
			expectedStatus: http.StatusBadRequest,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "parse_error", response.Error.Code)
			},
		},
		{
			name: "Missing file in form",
			setupForm: func() (*bytes.Buffer, string) {
				body := &bytes.Buffer{}
				writer := multipart.NewWriter(body)
				writer.WriteField("account_type", "corporate")
				writer.Close()
				return body, writer.FormDataContentType()
			},
			setupMock: func() *MockParseServiceRegistry {
				return &MockParseServiceRegistry{}
			},
			expectedStatus: http.StatusBadRequest,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "file_error", response.Error.Code)
			},
		},
		{
			name: "Successful CSV parse without auto-save",
			setupForm: func() (*bytes.Buffer, string) {
				body := &bytes.Buffer{}
				writer := multipart.NewWriter(body)

				part, err := writer.CreateFormFile("file", "test.csv")
				if err != nil {
					t.Fatal(err)
				}
				part.Write([]byte(csvContent))

				writer.WriteField("account_type", "corporate")
				writer.WriteField("auto_save", "false")
				writer.Close()
				return body, writer.FormDataContentType()
			},
			setupMock: func() *MockParseServiceRegistry {
				return &MockParseServiceRegistry{}
			},
			expectedStatus: http.StatusOK,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response SuccessResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.True(t, response.Success)
				assert.Contains(t, response.Message, "parsed")

				data := response.Data.(map[string]interface{})
				parseResponse := data
				assert.True(t, parseResponse["success"].(bool))
				assert.Equal(t, float64(2), parseResponse["record_count"].(float64))
				assert.NotNil(t, parseResponse["records"])
			},
		},
		{
			name: "Successful CSV parse with auto-save",
			setupForm: func() (*bytes.Buffer, string) {
				body := &bytes.Buffer{}
				writer := multipart.NewWriter(body)

				part, err := writer.CreateFormFile("file", "test.csv")
				if err != nil {
					t.Fatal(err)
				}
				part.Write([]byte(csvContent))

				writer.WriteField("account_type", "corporate")
				writer.WriteField("auto_save", "true")
				writer.WriteField("account_id", "test_account")
				writer.Close()
				return body, writer.FormDataContentType()
			},
			setupMock: func() *MockParseServiceRegistry {
				mockImport := &MockParseImportService{}
				batch := &models.ETCImportBatch{
					ID:            1,
					Status:        "completed",
					TotalRows:     2,
					ProcessedRows: 2,
					SuccessCount:  2,
					ErrorCount:    0,
					CreatedAt:     time.Now(),
				}
				mockImport.On("ProcessCSVFile", mock.AnythingOfType("*context.timerCtx"), mock.AnythingOfType("string"), "test_account", "corporate").Return(batch, nil)
				return &MockParseServiceRegistry{importService: mockImport}
			},
			expectedStatus: http.StatusOK,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response SuccessResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.True(t, response.Success)

				data := response.Data.(map[string]interface{})
				parseResponse := data
				assert.True(t, parseResponse["success"].(bool))
				assert.NotNil(t, parseResponse["import_result"])
			},
		},
		{
			name: "Parse with auto-save but import service unavailable",
			setupForm: func() (*bytes.Buffer, string) {
				body := &bytes.Buffer{}
				writer := multipart.NewWriter(body)

				part, err := writer.CreateFormFile("file", "test.csv")
				if err != nil {
					t.Fatal(err)
				}
				part.Write([]byte(csvContent))

				writer.WriteField("account_type", "personal")
				writer.WriteField("auto_save", "true")
				writer.Close()
				return body, writer.FormDataContentType()
			},
			setupMock: func() *MockParseServiceRegistry {
				return &MockParseServiceRegistry{importService: nil}
			},
			expectedStatus: http.StatusOK,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response SuccessResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.True(t, response.Success)

				data := response.Data.(map[string]interface{})
				parseResponse := data
				assert.True(t, parseResponse["success"].(bool))
				// import_result should be nil since import service is unavailable
				assert.Nil(t, parseResponse["import_result"])
			},
		},
		{
			name: "Parse with invalid CSV content",
			setupForm: func() (*bytes.Buffer, string) {
				body := &bytes.Buffer{}
				writer := multipart.NewWriter(body)

				part, err := writer.CreateFormFile("file", "invalid.csv")
				if err != nil {
					t.Fatal(err)
				}
				part.Write([]byte("invalid,csv,content\nwithout,proper,headers"))

				writer.WriteField("account_type", "corporate")
				writer.Close()
				return body, writer.FormDataContentType()
			},
			setupMock: func() *MockParseServiceRegistry {
				return &MockParseServiceRegistry{}
			},
			expectedStatus: http.StatusBadRequest,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "csv_parse_error", response.Error.Code)
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockRegistry := tt.setupMock()
			handler := &ParseHandler{
				BaseHandler: &BaseHandler{
					ServiceRegistry: mockRegistry,
					Logger:          logger,
					ErrorHandler:    NewGRPCErrorHandler(),
				},
				Parser:        nil, // Parser is not used when import service is mocked
				CompatAdapter: nil,
			}

			body, contentType := tt.setupForm()
			req := httptest.NewRequest(http.MethodPost, "/api/parse/csv", body)
			req.Header.Set("Content-Type", contentType)
			w := httptest.NewRecorder()

			handler.ParseCSV(w, req)

			assert.Equal(t, tt.expectedStatus, w.Code)
			if tt.checkResponse != nil {
				tt.checkResponse(t, w)
			}
		})
	}
}

func TestParseHandler_ParseAndImport(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)

	// Create a test CSV content
	csvContent := `利用日,利用時刻,IC,車種,入口,出口,距離(km),利用料金(円)
2023/01/15,06:30,1234567890,普通車,東京IC,新宿IC,25,630
2023/01/15,07:45,1234567890,普通車,新宿IC,渋谷IC,8,250`

	tests := []struct {
		name           string
		setupForm      func() (*bytes.Buffer, string)
		setupMock      func() *MockParseServiceRegistry
		expectedStatus int
		checkResponse  func(*testing.T, *httptest.ResponseRecorder)
	}{
		{
			name: "Invalid multipart form",
			setupForm: func() (*bytes.Buffer, string) {
				return bytes.NewBuffer([]byte("invalid")), "application/json"
			},
			setupMock: func() *MockParseServiceRegistry {
				return &MockParseServiceRegistry{}
			},
			expectedStatus: http.StatusBadRequest,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "parse_error", response.Error.Code)
			},
		},
		{
			name: "Missing file in form",
			setupForm: func() (*bytes.Buffer, string) {
				body := &bytes.Buffer{}
				writer := multipart.NewWriter(body)
				writer.WriteField("account_type", "corporate")
				writer.Close()
				return body, writer.FormDataContentType()
			},
			setupMock: func() *MockParseServiceRegistry {
				return &MockParseServiceRegistry{}
			},
			expectedStatus: http.StatusBadRequest,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "file_error", response.Error.Code)
			},
		},
		{
			name: "Import service unavailable",
			setupForm: func() (*bytes.Buffer, string) {
				body := &bytes.Buffer{}
				writer := multipart.NewWriter(body)

				part, err := writer.CreateFormFile("file", "test.csv")
				if err != nil {
					t.Fatal(err)
				}
				part.Write([]byte(csvContent))

				writer.WriteField("account_type", "corporate")
				writer.Close()
				return body, writer.FormDataContentType()
			},
			setupMock: func() *MockParseServiceRegistry {
				return &MockParseServiceRegistry{importService: nil}
			},
			expectedStatus: http.StatusServiceUnavailable,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "service_unavailable", response.Error.Code)
			},
		},
		{
			name: "Invalid file validation",
			setupForm: func() (*bytes.Buffer, string) {
				body := &bytes.Buffer{}
				writer := multipart.NewWriter(body)

				part, err := writer.CreateFormFile("file", "test.csv")
				if err != nil {
					t.Fatal(err)
				}
				part.Write([]byte(csvContent))

				writer.WriteField("account_type", "corporate")
				writer.Close()
				return body, writer.FormDataContentType()
			},
			setupMock: func() *MockParseServiceRegistry {
				mockImport := &MockParseImportService{}
				mockImport.On("ValidateImportFile", mock.AnythingOfType("string")).Return(fmt.Errorf("invalid file format"))
				return &MockParseServiceRegistry{importService: mockImport}
			},
			expectedStatus: http.StatusBadRequest,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "invalid_file", response.Error.Code)
			},
		},
		{
			name: "Successful parse and import",
			setupForm: func() (*bytes.Buffer, string) {
				body := &bytes.Buffer{}
				writer := multipart.NewWriter(body)

				part, err := writer.CreateFormFile("file", "test.csv")
				if err != nil {
					t.Fatal(err)
				}
				part.Write([]byte(csvContent))

				writer.WriteField("account_type", "corporate")
				writer.WriteField("account_id", "test_account")
				writer.Close()
				return body, writer.FormDataContentType()
			},
			setupMock: func() *MockParseServiceRegistry {
				mockImport := &MockParseImportService{}
				mockImport.On("ValidateImportFile", mock.AnythingOfType("string")).Return(nil)

				batch := &models.ETCImportBatch{
					ID:            1,
					Status:        "completed",
					TotalRows:     2,
					ProcessedRows: 2,
					SuccessCount:  2,
					ErrorCount:    0,
				}
				mockImport.On("ProcessCSVFile", mock.AnythingOfType("*context.timerCtx"), mock.AnythingOfType("string"), "test_account", "corporate").Return(batch, nil)
				return &MockParseServiceRegistry{importService: mockImport}
			},
			expectedStatus: http.StatusOK,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response SuccessResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.True(t, response.Success)
				assert.Contains(t, response.Message, "imported")

				data := response.Data.(map[string]interface{})
				assert.True(t, data["success"].(bool))
				assert.Equal(t, float64(1), data["batch_id"].(float64))
				assert.Equal(t, float64(2), data["total_rows"].(float64))
				assert.Equal(t, "completed", data["status"].(string))
			},
		},
		{
			name: "Partial import success",
			setupForm: func() (*bytes.Buffer, string) {
				body := &bytes.Buffer{}
				writer := multipart.NewWriter(body)

				part, err := writer.CreateFormFile("file", "test.csv")
				if err != nil {
					t.Fatal(err)
				}
				part.Write([]byte(csvContent))

				writer.WriteField("account_type", "personal")
				writer.Close()
				return body, writer.FormDataContentType()
			},
			setupMock: func() *MockParseServiceRegistry {
				mockImport := &MockParseImportService{}
				mockImport.On("ValidateImportFile", mock.AnythingOfType("string")).Return(nil)

				batch := &models.ETCImportBatch{
					ID:            1,
					Status:        "partial",
					TotalRows:     2,
					ProcessedRows: 2,
					SuccessCount:  1,
					ErrorCount:    1,
				}
				mockImport.On("ProcessCSVFile", mock.AnythingOfType("*context.timerCtx"), mock.AnythingOfType("string"), "default", "personal").Return(batch, nil)
				return &MockParseServiceRegistry{importService: mockImport}
			},
			expectedStatus: http.StatusPartialContent,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response map[string]interface{}
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.False(t, response["success"].(bool))
				assert.Equal(t, "partial", response["status"].(string))
				assert.Equal(t, float64(1), response["success_count"].(float64))
				assert.Equal(t, float64(1), response["error_count"].(float64))
			},
		},
		{
			name: "Import processing error",
			setupForm: func() (*bytes.Buffer, string) {
				body := &bytes.Buffer{}
				writer := multipart.NewWriter(body)

				part, err := writer.CreateFormFile("file", "test.csv")
				if err != nil {
					t.Fatal(err)
				}
				part.Write([]byte(csvContent))

				writer.WriteField("account_type", "corporate")
				writer.Close()
				return body, writer.FormDataContentType()
			},
			setupMock: func() *MockParseServiceRegistry {
				mockImport := &MockParseImportService{}
				mockImport.On("ValidateImportFile", mock.AnythingOfType("string")).Return(nil)
				mockImport.On("ProcessCSVFile", mock.AnythingOfType("*context.timerCtx"), mock.AnythingOfType("string"), "default", "corporate").Return((*models.ETCImportBatch)(nil), fmt.Errorf("processing failed"))
				return &MockParseServiceRegistry{importService: mockImport}
			},
			expectedStatus: http.StatusInternalServerError,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.NotEmpty(t, response.Error.Code)
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockRegistry := tt.setupMock()
			handler := &ParseHandler{
				BaseHandler: &BaseHandler{
					ServiceRegistry: mockRegistry,
					Logger:          logger,
					ErrorHandler:    NewGRPCErrorHandler(),
				},
				Parser:        nil, // Parser is not used when import service is mocked
				CompatAdapter: nil,
			}

			body, contentType := tt.setupForm()
			req := httptest.NewRequest(http.MethodPost, "/api/parse/import", body)
			req.Header.Set("Content-Type", contentType)
			w := httptest.NewRecorder()

			handler.ParseAndImport(w, req)

			assert.Equal(t, tt.expectedStatus, w.Code)
			if tt.checkResponse != nil {
				tt.checkResponse(t, w)
			}
		})
	}
}

func TestParseResponse_Structure(t *testing.T) {
	tests := []struct {
		name     string
		response ParseResponse
		expected string
	}{
		{
			name: "Successful parse response",
			response: ParseResponse{
				Success:     true,
				RecordCount: 2,
				Records:     []string{"record1", "record2"},
				Errors:      nil,
				ImportResult: &models.ETCImportResult{
					Success:      true,
					Message:      "Import completed",
					RecordCount:  2,
					ImportedRows: 2,
				},
			},
			expected: `{"success":true,"record_count":2,"records":["record1","record2"],"import_result":{"success":true,"message":"Import completed","record_count":2,"imported_rows":2,"imported_at":"0001-01-01T00:00:00Z"}}`,
		},
		{
			name: "Parse response with errors",
			response: ParseResponse{
				Success:     false,
				RecordCount: 1,
				Records:     []string{"record1"},
				Errors:      []string{"parsing error", "validation error"},
				ImportResult: nil,
			},
			expected: `{"success":false,"record_count":1,"records":["record1"],"errors":["parsing error","validation error"]}`,
		},
		{
			name: "Empty parse response",
			response: ParseResponse{
				Success:     true,
				RecordCount: 0,
				Records:     []interface{}{},
				Errors:      nil,
				ImportResult: nil,
			},
			expected: `{"success":true,"record_count":0,"records":[]}`,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			jsonData, err := json.Marshal(tt.response)
			assert.NoError(t, err)
			assert.JSONEq(t, tt.expected, string(jsonData))
		})
	}
}

func TestParseHandler_FileHandling(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)

	tests := []struct {
		name     string
		fileSize int64
		filename string
		content  string
		wantErr  bool
	}{
		{
			name:     "Normal file",
			fileSize: 1024,
			filename: "test.csv",
			content:  strings.Repeat("a,b,c\n", 100),
			wantErr:  false,
		},
		{
			name:     "Large file name",
			fileSize: 100,
			filename: strings.Repeat("a", 100) + ".csv",
			content:  "header1,header2\nvalue1,value2",
			wantErr:  false,
		},
		{
			name:     "Empty file",
			fileSize: 0,
			filename: "empty.csv",
			content:  "",
			wantErr:  true, // CSV parser should fail on empty file
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockRegistry := &MockParseServiceRegistry{}
			handler := &ParseHandler{
				BaseHandler: &BaseHandler{
					ServiceRegistry: mockRegistry,
					Logger:          logger,
					ErrorHandler:    NewGRPCErrorHandler(),
				},
				Parser:        nil, // Parser is not used when import service is mocked
				CompatAdapter: nil,
			}

			body := &bytes.Buffer{}
			writer := multipart.NewWriter(body)

			part, err := writer.CreateFormFile("file", tt.filename)
			assert.NoError(t, err)

			part.Write([]byte(tt.content))
			writer.WriteField("account_type", "corporate")
			writer.Close()

			req := httptest.NewRequest(http.MethodPost, "/api/parse/csv", body)
			req.Header.Set("Content-Type", writer.FormDataContentType())
			w := httptest.NewRecorder()

			handler.ParseCSV(w, req)

			if tt.wantErr {
				assert.NotEqual(t, http.StatusOK, w.Code)
			} else {
				assert.Equal(t, http.StatusOK, w.Code)
			}
		})
	}
}

func TestParseHandler_ErrorHandling(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)

	tests := []struct {
		name          string
		setupRequest  func() *http.Request
		expectedError string
	}{
		{
			name: "Request with no content type",
			setupRequest: func() *http.Request {
				req := httptest.NewRequest(http.MethodPost, "/api/parse/csv", strings.NewReader("test"))
				return req
			},
			expectedError: "parse_error",
		},
		{
			name: "Request with wrong content type",
			setupRequest: func() *http.Request {
				req := httptest.NewRequest(http.MethodPost, "/api/parse/csv", strings.NewReader("test"))
				req.Header.Set("Content-Type", "application/json")
				return req
			},
			expectedError: "parse_error",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockRegistry := &MockParseServiceRegistry{}
			handler := &ParseHandler{
				BaseHandler: &BaseHandler{
					ServiceRegistry: mockRegistry,
					Logger:          logger,
					ErrorHandler:    NewGRPCErrorHandler(),
				},
				Parser:        nil, // Parser is not used when import service is mocked
				CompatAdapter: nil,
			}

			req := tt.setupRequest()
			w := httptest.NewRecorder()

			handler.ParseCSV(w, req)

			assert.NotEqual(t, http.StatusOK, w.Code)

			var response ErrorResponse
			err := json.NewDecoder(w.Body).Decode(&response)
			assert.NoError(t, err)
			assert.Equal(t, tt.expectedError, response.Error.Code)
		})
	}
}

// Mock CSV parser for testing
type mockCSVParser struct{}

func (m mockCSVParser) ParseCSVFile(filePath string, isCorporate bool) ([]models.ETCMeisai, error) {
	// Read the file to check if it's empty or has invalid content
	content, err := os.ReadFile(filePath)
	if err != nil {
		return nil, err
	}

	if len(content) == 0 {
		return nil, fmt.Errorf("empty file")
	}

	contentStr := string(content)
	if !strings.Contains(contentStr, "利用日") && !strings.Contains(contentStr, "header") {
		return nil, fmt.Errorf("invalid CSV format")
	}

	// Return mock records for valid content
	return []models.ETCMeisai{
		{
			ID:       1,
			UseDate:  time.Date(2023, 1, 15, 6, 30, 0, 0, time.UTC),
			ETCNumber: "1234567890",
			Amount:   630,
		},
		{
			ID:       2,
			UseDate:  time.Date(2023, 1, 15, 7, 45, 0, 0, time.UTC),
			ETCNumber: "1234567890",
			Amount:   250,
		},
	}, nil
}

func TestParseHandler_DefaultValues(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)

	csvContent := `利用日,利用時刻,IC,車種,入口,出口,距離(km),利用料金(円)
2023/01/15,06:30,1234567890,普通車,東京IC,新宿IC,25,630`

	tests := []struct {
		name           string
		formFields     map[string]string
		expectedValues map[string]string
	}{
		{
			name:       "No account_type specified",
			formFields: map[string]string{},
			expectedValues: map[string]string{
				"account_type": "corporate",
				"account_id":   "default",
				"auto_save":    "false",
			},
		},
		{
			name: "Custom values specified",
			formFields: map[string]string{
				"account_type": "personal",
				"account_id":   "custom_account",
				"auto_save":    "true",
			},
			expectedValues: map[string]string{
				"account_type": "personal",
				"account_id":   "custom_account",
				"auto_save":    "true",
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			body := &bytes.Buffer{}
			writer := multipart.NewWriter(body)

			part, err := writer.CreateFormFile("file", "test.csv")
			assert.NoError(t, err)
			part.Write([]byte(csvContent))

			for key, value := range tt.formFields {
				writer.WriteField(key, value)
			}
			writer.Close()

			mockRegistry := &MockParseServiceRegistry{}
			handler := &ParseHandler{
				BaseHandler: &BaseHandler{
					ServiceRegistry: mockRegistry,
					Logger:          logger,
					ErrorHandler:    NewGRPCErrorHandler(),
				},
				Parser:        nil, // Parser is not used when import service is mocked
				CompatAdapter: nil,
			}

			req := httptest.NewRequest(http.MethodPost, "/api/parse/csv", body)
			req.Header.Set("Content-Type", writer.FormDataContentType())
			w := httptest.NewRecorder()

			handler.ParseCSV(w, req)

			assert.Equal(t, http.StatusOK, w.Code)

			var response SuccessResponse
			err = json.NewDecoder(w.Body).Decode(&response)
			assert.NoError(t, err)
			assert.True(t, response.Success)
		})
	}
}