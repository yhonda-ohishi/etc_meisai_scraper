package handlers

import (
	"encoding/json"
	"log"
	"net/http"
	"net/http/httptest"
	"os"
	"strings"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.com/yhonda-ohishi/etc_meisai/src/services"
)

// MockDownloadService for testing
type MockDownloadService struct {
	mock.Mock
}

func (m *MockDownloadService) GetAllAccountIDs() []string {
	args := m.Called()
	return args.Get(0).([]string)
}

func (m *MockDownloadService) ProcessAsync(jobID string, accounts []string, fromDate, toDate string) {
	m.Called(jobID, accounts, fromDate, toDate)
}

func (m *MockDownloadService) GetJobStatus(jobID string) (*services.DownloadJob, bool) {
	args := m.Called(jobID)
	return args.Get(0).(*services.DownloadJob), args.Bool(1)
}

func TestNewDownloadHandler(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)
	baseHandler := BaseHandler{
		Logger: logger,
	}
	downloadService := &services.DownloadService{}

	handler := NewDownloadHandler(baseHandler, downloadService)

	assert.NotNil(t, handler)
	assert.Equal(t, baseHandler, handler.BaseHandler)
	assert.Equal(t, downloadService, handler.DownloadService)
}

func TestDownloadHandler_DownloadSync(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)

	tests := []struct {
		name           string
		requestBody    string
		expectedStatus int
		checkResponse  func(*testing.T, *httptest.ResponseRecorder)
	}{
		{
			name:           "Invalid request body",
			requestBody:    "invalid json",
			expectedStatus: http.StatusBadRequest,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "INVALID_REQUEST", response.Error.Code)
			},
		},
		{
			name:           "Missing accounts",
			requestBody:    `{"from_date": "2023-01-01", "to_date": "2023-01-31"}`,
			expectedStatus: http.StatusBadRequest,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "MISSING_ACCOUNTS", response.Error.Code)
			},
		},
		{
			name:           "Valid request with accounts",
			requestBody:    `{"accounts": ["account1", "account2"], "from_date": "2023-01-01", "to_date": "2023-01-31"}`,
			expectedStatus: http.StatusOK,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response SuccessResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.True(t, response.Success)
				assert.Equal(t, "Download completed successfully", response.Message)
			},
		},
		{
			name:           "Request with defaults (no dates)",
			requestBody:    `{"accounts": ["account1"]}`,
			expectedStatus: http.StatusOK,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response SuccessResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.True(t, response.Success)
			},
		},
		{
			name:           "Request with partial dates",
			requestBody:    `{"accounts": ["account1"], "from_date": "2023-01-01"}`,
			expectedStatus: http.StatusOK,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response SuccessResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.True(t, response.Success)
			},
		},
		{
			name:           "Request with mode parameter",
			requestBody:    `{"accounts": ["account1"], "from_date": "2023-01-01", "to_date": "2023-01-31", "mode": "full"}`,
			expectedStatus: http.StatusOK,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response SuccessResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.True(t, response.Success)
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			handler := &DownloadHandler{
				BaseHandler: BaseHandler{
					Logger:       logger,
					ErrorHandler: NewGRPCErrorHandler(),
				},
				DownloadService: &services.DownloadService{},
			}

			req := httptest.NewRequest(http.MethodPost, "/api/download/sync", strings.NewReader(tt.requestBody))
			w := httptest.NewRecorder()

			handler.DownloadSync(w, req)

			assert.Equal(t, tt.expectedStatus, w.Code)
			if tt.checkResponse != nil {
				tt.checkResponse(t, w)
			}
		})
	}
}

func TestDownloadHandler_DownloadAsync(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)

	tests := []struct {
		name           string
		requestBody    string
		setupMock      func() *MockDownloadService
		expectedStatus int
		checkResponse  func(*testing.T, *httptest.ResponseRecorder)
	}{
		{
			name:           "Invalid request body",
			requestBody:    "invalid json",
			setupMock:      func() *MockDownloadService { return &MockDownloadService{} },
			expectedStatus: http.StatusBadRequest,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "INVALID_REQUEST", response.Error.Code)
			},
		},
		{
			name:        "No accounts and no defaults",
			requestBody: `{"from_date": "2023-01-01", "to_date": "2023-01-31"}`,
			setupMock: func() *MockDownloadService {
				mockService := &MockDownloadService{}
				mockService.On("GetAllAccountIDs").Return([]string{})
				return mockService
			},
			expectedStatus: http.StatusBadRequest,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "NO_ACCOUNTS", response.Error.Code)
			},
		},
		{
			name:        "No accounts but defaults available",
			requestBody: `{"from_date": "2023-01-01", "to_date": "2023-01-31"}`,
			setupMock: func() *MockDownloadService {
				mockService := &MockDownloadService{}
				mockService.On("GetAllAccountIDs").Return([]string{"default1", "default2"})
				mockService.On("ProcessAsync", mock.AnythingOfType("string"), []string{"default1", "default2"}, "2023-01-01", "2023-01-31").Return()
				return mockService
			},
			expectedStatus: http.StatusAccepted,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response map[string]interface{}
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "pending", response["status"])
				assert.NotEmpty(t, response["job_id"])
				assert.Equal(t, "Download job started", response["message"])
			},
		},
		{
			name:        "Valid request with accounts",
			requestBody: `{"accounts": ["account1", "account2"], "from_date": "2023-01-01", "to_date": "2023-01-31"}`,
			setupMock: func() *MockDownloadService {
				mockService := &MockDownloadService{}
				mockService.On("ProcessAsync", mock.AnythingOfType("string"), []string{"account1", "account2"}, "2023-01-01", "2023-01-31").Return()
				return mockService
			},
			expectedStatus: http.StatusAccepted,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response map[string]interface{}
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "pending", response["status"])
				assert.NotEmpty(t, response["job_id"])
			},
		},
		{
			name:        "Request with default dates",
			requestBody: `{"accounts": ["account1"]}`,
			setupMock: func() *MockDownloadService {
				mockService := &MockDownloadService{}
				mockService.On("ProcessAsync", mock.AnythingOfType("string"), []string{"account1"}, mock.AnythingOfType("string"), mock.AnythingOfType("string")).Return()
				return mockService
			},
			expectedStatus: http.StatusAccepted,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response map[string]interface{}
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "pending", response["status"])
				assert.NotEmpty(t, response["job_id"])
			},
		},
		{
			name:        "Request with partial dates (only to_date)",
			requestBody: `{"accounts": ["account1"], "to_date": "2023-01-31"}`,
			setupMock: func() *MockDownloadService {
				mockService := &MockDownloadService{}
				mockService.On("ProcessAsync", mock.AnythingOfType("string"), []string{"account1"}, mock.AnythingOfType("string"), "2023-01-31").Return()
				return mockService
			},
			expectedStatus: http.StatusAccepted,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response map[string]interface{}
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "pending", response["status"])
			},
		},
		{
			name:        "Request with partial dates (only from_date)",
			requestBody: `{"accounts": ["account1"], "from_date": "2023-01-01"}`,
			setupMock: func() *MockDownloadService {
				mockService := &MockDownloadService{}
				mockService.On("ProcessAsync", mock.AnythingOfType("string"), []string{"account1"}, "2023-01-01", mock.AnythingOfType("string")).Return()
				return mockService
			},
			expectedStatus: http.StatusAccepted,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response map[string]interface{}
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "pending", response["status"])
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockService := tt.setupMock()
			handler := &DownloadHandler{
				BaseHandler: BaseHandler{
					Logger:       logger,
					ErrorHandler: NewGRPCErrorHandler(),
				},
				DownloadService: mockService,
			}

			req := httptest.NewRequest(http.MethodPost, "/api/download/async", strings.NewReader(tt.requestBody))
			w := httptest.NewRecorder()

			handler.DownloadAsync(w, req)

			assert.Equal(t, tt.expectedStatus, w.Code)
			if tt.checkResponse != nil {
				tt.checkResponse(t, w)
			}

			mockService.AssertExpectations(t)
		})
	}
}

func TestDownloadHandler_GetDownloadStatus(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)

	tests := []struct {
		name           string
		url            string
		queryParam     string
		expectedStatus int
		checkResponse  func(*testing.T, *httptest.ResponseRecorder)
	}{
		{
			name:           "Missing job ID",
			url:            "/api/download/status",
			queryParam:     "",
			expectedStatus: http.StatusBadRequest,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "MISSING_JOB_ID", response.Error.Code)
			},
		},
		{
			name:           "Job ID in query parameter",
			url:            "/api/download/status",
			queryParam:     "job_id=test-job-123",
			expectedStatus: http.StatusOK,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response SuccessResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.True(t, response.Success)
				assert.Contains(t, response.Message, "test-job-123")

				// Check the status data
				statusData := response.Data.(map[string]interface{})
				assert.Equal(t, "test-job-123", statusData["job_id"])
				assert.Equal(t, "processing", statusData["status"])
				assert.Equal(t, float64(50), statusData["progress"])
				assert.Equal(t, float64(100), statusData["total_records"])
			},
		},
		{
			name:           "Job ID in URL path",
			url:            "/api/download/status/test-job-456",
			queryParam:     "",
			expectedStatus: http.StatusOK,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response SuccessResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.True(t, response.Success)
				assert.Contains(t, response.Message, "test-job-456")

				// Check the status data
				statusData := response.Data.(map[string]interface{})
				assert.Equal(t, "test-job-456", statusData["job_id"])
			},
		},
		{
			name:           "Query parameter takes precedence over path",
			url:            "/api/download/status/path-job",
			queryParam:     "job_id=query-job-123",
			expectedStatus: http.StatusOK,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response SuccessResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.True(t, response.Success)
				assert.Contains(t, response.Message, "query-job-123")

				// Check the status data
				statusData := response.Data.(map[string]interface{})
				assert.Equal(t, "query-job-123", statusData["job_id"])
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			handler := &DownloadHandler{
				BaseHandler: BaseHandler{
					Logger:       logger,
					ErrorHandler: NewGRPCErrorHandler(),
				},
				DownloadService: &services.DownloadService{},
			}

			url := tt.url
			if tt.queryParam != "" {
				url += "?" + tt.queryParam
			}

			req := httptest.NewRequest(http.MethodGet, url, nil)
			w := httptest.NewRecorder()

			handler.GetDownloadStatus(w, req)

			assert.Equal(t, tt.expectedStatus, w.Code)
			if tt.checkResponse != nil {
				tt.checkResponse(t, w)
			}
		})
	}
}

func TestDownloadRequest_Structure(t *testing.T) {
	tests := []struct {
		name     string
		jsonData string
		expected DownloadRequest
	}{
		{
			name:     "Complete request",
			jsonData: `{"accounts": ["acc1", "acc2"], "from_date": "2023-01-01", "to_date": "2023-01-31", "mode": "full"}`,
			expected: DownloadRequest{
				Accounts: []string{"acc1", "acc2"},
				FromDate: "2023-01-01",
				ToDate:   "2023-01-31",
				Mode:     "full",
			},
		},
		{
			name:     "Minimal request",
			jsonData: `{"accounts": ["acc1"]}`,
			expected: DownloadRequest{
				Accounts: []string{"acc1"},
				FromDate: "",
				ToDate:   "",
				Mode:     "",
			},
		},
		{
			name:     "Empty accounts",
			jsonData: `{"accounts": [], "from_date": "2023-01-01", "to_date": "2023-01-31"}`,
			expected: DownloadRequest{
				Accounts: []string{},
				FromDate: "2023-01-01",
				ToDate:   "2023-01-31",
				Mode:     "",
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			var req DownloadRequest
			err := json.Unmarshal([]byte(tt.jsonData), &req)
			assert.NoError(t, err)
			assert.Equal(t, tt.expected, req)
		})
	}
}

func TestJobStatus_Structure(t *testing.T) {
	tests := []struct {
		name     string
		status   JobStatus
		expected string
	}{
		{
			name: "Complete status",
			status: JobStatus{
				JobID:        "job-123",
				Status:       "completed",
				Progress:     100,
				TotalRecords: 500,
				ErrorMessage: nil,
				CompletedAt:  &time.Time{},
			},
			expected: `{"job_id":"job-123","status":"completed","progress":100,"total_records":500,"completed_at":"0001-01-01T00:00:00Z"}`,
		},
		{
			name: "Status with error",
			status: JobStatus{
				JobID:        "job-456",
				Status:       "failed",
				Progress:     30,
				TotalRecords: 100,
				ErrorMessage: downloadStringPtr("Connection timeout"),
				CompletedAt:  nil,
			},
			expected: `{"job_id":"job-456","status":"failed","progress":30,"total_records":100,"error_message":"Connection timeout"}`,
		},
		{
			name: "Processing status",
			status: JobStatus{
				JobID:        "job-789",
				Status:       "processing",
				Progress:     50,
				TotalRecords: 200,
				ErrorMessage: nil,
				CompletedAt:  nil,
			},
			expected: `{"job_id":"job-789","status":"processing","progress":50,"total_records":200}`,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			jsonData, err := json.Marshal(tt.status)
			assert.NoError(t, err)
			assert.JSONEq(t, tt.expected, string(jsonData))
		})
	}
}

func TestDownloadHandler_DateDefaultLogic(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)

	// Test the date default logic by examining the actual dates set
	tests := []struct {
		name        string
		requestBody string
		checkDates  func(*testing.T, string, string)
	}{
		{
			name:        "Both dates missing",
			requestBody: `{"accounts": ["account1"]}`,
			checkDates: func(t *testing.T, fromDate, toDate string) {
				// Should set both dates to current and last month
				now := time.Now()
				expectedToDate := now.Format("2006-01-02")
				expectedFromDate := now.AddDate(0, -1, 0).Format("2006-01-02")

				assert.Equal(t, expectedFromDate, fromDate)
				assert.Equal(t, expectedToDate, toDate)
			},
		},
		{
			name:        "Only from_date missing",
			requestBody: `{"accounts": ["account1"], "to_date": "2023-01-31"}`,
			checkDates: func(t *testing.T, fromDate, toDate string) {
				// Should keep to_date and set from_date to last month from current date
				now := time.Now()
				expectedFromDate := now.AddDate(0, -1, 0).Format("2006-01-02")

				assert.Equal(t, expectedFromDate, fromDate)
				assert.Equal(t, "2023-01-31", toDate)
			},
		},
		{
			name:        "Only to_date missing",
			requestBody: `{"accounts": ["account1"], "from_date": "2023-01-01"}`,
			checkDates: func(t *testing.T, fromDate, toDate string) {
				// Should keep from_date and set to_date to current date
				now := time.Now()
				expectedToDate := now.Format("2006-01-02")

				assert.Equal(t, "2023-01-01", fromDate)
				assert.Equal(t, expectedToDate, toDate)
			},
		},
		{
			name:        "Both dates provided",
			requestBody: `{"accounts": ["account1"], "from_date": "2023-01-01", "to_date": "2023-01-31"}`,
			checkDates: func(t *testing.T, fromDate, toDate string) {
				// Should keep both dates as provided
				assert.Equal(t, "2023-01-01", fromDate)
				assert.Equal(t, "2023-01-31", toDate)
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// Create a mock service that captures the dates passed to ProcessAsync
			mockService := &MockDownloadService{}
			var capturedFromDate, capturedToDate string

			mockService.On("ProcessAsync", mock.AnythingOfType("string"), mock.AnythingOfType("[]string"), mock.AnythingOfType("string"), mock.AnythingOfType("string")).Run(func(args mock.Arguments) {
				capturedFromDate = args.String(2)
				capturedToDate = args.String(3)
			}).Return()

			handler := &DownloadHandler{
				BaseHandler: BaseHandler{
					Logger:       logger,
					ErrorHandler: NewGRPCErrorHandler(),
				},
				DownloadService: mockService,
			}

			req := httptest.NewRequest(http.MethodPost, "/api/download/async", strings.NewReader(tt.requestBody))
			w := httptest.NewRecorder()

			handler.DownloadAsync(w, req)

			assert.Equal(t, http.StatusAccepted, w.Code)
			tt.checkDates(t, capturedFromDate, capturedToDate)

			mockService.AssertExpectations(t)
		})
	}
}

func TestDownloadHandler_AccountHandling(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)

	tests := []struct {
		name           string
		requestBody    string
		defaultAccounts []string
		expectedAccounts []string
		expectedStatus int
	}{
		{
			name:            "Accounts provided",
			requestBody:     `{"accounts": ["acc1", "acc2"], "from_date": "2023-01-01", "to_date": "2023-01-31"}`,
			defaultAccounts: []string{"default1", "default2"},
			expectedAccounts: []string{"acc1", "acc2"},
			expectedStatus:  http.StatusAccepted,
		},
		{
			name:            "No accounts but defaults available",
			requestBody:     `{"from_date": "2023-01-01", "to_date": "2023-01-31"}`,
			defaultAccounts: []string{"default1", "default2"},
			expectedAccounts: []string{"default1", "default2"},
			expectedStatus:  http.StatusAccepted,
		},
		{
			name:            "No accounts and no defaults",
			requestBody:     `{"from_date": "2023-01-01", "to_date": "2023-01-31"}`,
			defaultAccounts: []string{},
			expectedAccounts: nil,
			expectedStatus:  http.StatusBadRequest,
		},
		{
			name:            "Empty accounts but defaults available",
			requestBody:     `{"accounts": [], "from_date": "2023-01-01", "to_date": "2023-01-31"}`,
			defaultAccounts: []string{"default1"},
			expectedAccounts: []string{"default1"},
			expectedStatus:  http.StatusAccepted,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockService := &MockDownloadService{}
			var capturedAccounts []string

			mockService.On("GetAllAccountIDs").Return(tt.defaultAccounts)

			if tt.expectedStatus == http.StatusAccepted {
				mockService.On("ProcessAsync", mock.AnythingOfType("string"), mock.AnythingOfType("[]string"), mock.AnythingOfType("string"), mock.AnythingOfType("string")).Run(func(args mock.Arguments) {
					capturedAccounts = args.Get(1).([]string)
				}).Return()
			}

			handler := &DownloadHandler{
				BaseHandler: BaseHandler{
					Logger:       logger,
					ErrorHandler: NewGRPCErrorHandler(),
				},
				DownloadService: mockService,
			}

			req := httptest.NewRequest(http.MethodPost, "/api/download/async", strings.NewReader(tt.requestBody))
			w := httptest.NewRecorder()

			handler.DownloadAsync(w, req)

			assert.Equal(t, tt.expectedStatus, w.Code)

			if tt.expectedStatus == http.StatusAccepted {
				assert.Equal(t, tt.expectedAccounts, capturedAccounts)
			}

			mockService.AssertExpectations(t)
		})
	}
}

// Helper function for string pointer
func downloadStringPtr(s string) *string {
	return &s
}