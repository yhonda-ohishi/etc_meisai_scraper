package handlers

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"net/http/httptest"
	"os"
	"strings"
	"testing"
	"time"

	"github.com/go-chi/chi/v5"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.com/yhonda-ohishi/etc_meisai/src/models"
	"github.com/yhonda-ohishi/etc_meisai/src/services"
)

// MockETCService for testing
type MockETCService struct {
	mock.Mock
}

func (m *MockETCService) ImportData(req models.ETCImportRequest) (*models.ETCImportResult, error) {
	args := m.Called(req)
	return args.Get(0).(*models.ETCImportResult), args.Error(1)
}

func (m *MockETCService) GetMeisaiByDateRange(fromDate, toDate string) ([]models.ETCMeisai, error) {
	args := m.Called(fromDate, toDate)
	return args.Get(0).([]models.ETCMeisai), args.Error(1)
}

func (m *MockETCService) GetByID(ctx context.Context, id int64) (*models.ETCMeisai, error) {
	args := m.Called(ctx, id)
	return args.Get(0).(*models.ETCMeisai), args.Error(1)
}

func (m *MockETCService) Create(ctx context.Context, meisai *models.ETCMeisai) (*models.ETCMeisai, error) {
	args := m.Called(ctx, meisai)
	return args.Get(0).(*models.ETCMeisai), args.Error(1)
}

func (m *MockETCService) List(ctx context.Context, params *models.ETCListParams) ([]*models.ETCMeisai, int64, error) {
	args := m.Called(ctx, params)
	return args.Get(0).([]*models.ETCMeisai), args.Get(1).(int64), args.Error(2)
}

func (m *MockETCService) ImportCSV(ctx context.Context, records []*models.ETCMeisai) (*models.ETCImportResult, error) {
	args := m.Called(ctx, records)
	return args.Get(0).(*models.ETCImportResult), args.Error(1)
}

func (m *MockETCService) GetSummary(ctx context.Context, fromDate, toDate string) (map[string]interface{}, error) {
	args := m.Called(ctx, fromDate, toDate)
	return args.Get(0).(map[string]interface{}), args.Error(1)
}

func (m *MockETCService) GetByDateRange(ctx context.Context, from, to time.Time) ([]*models.ETCMeisai, error) {
	args := m.Called(ctx, from, to)
	return args.Get(0).([]*models.ETCMeisai), args.Error(1)
}

// MockServiceRegistry for testing
type MockETCServiceRegistry struct {
	mock.Mock
	etcService services.ETCServiceInterface
}

func (m *MockETCServiceRegistry) GetETCService() *services.ETCService {
	return nil // MockETCServiceRegistry is specialized for ETC only
}

func (m *MockETCServiceRegistry) GetMappingService() *services.MappingService {
	return nil
}

func (m *MockETCServiceRegistry) GetBaseService() *services.BaseService {
	return nil
}

func (m *MockETCServiceRegistry) GetImportService() *services.ImportServiceLegacy {
	return nil
}

func (m *MockETCServiceRegistry) GetDownloadService() services.DownloadServiceInterface {
	return nil
}

func (m *MockETCServiceRegistry) HealthCheck(ctx context.Context) *services.HealthCheckResult {
	args := m.Called(ctx)
	return args.Get(0).(*services.HealthCheckResult)
}

func (m *MockETCServiceRegistry) GetDatabaseServiceClient() interface{} {
	args := m.Called()
	return args.Get(0)
}

func TestNewETCHandler(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)
	serviceRegistry := &services.ServiceRegistry{}

	handler := NewETCHandler(serviceRegistry, logger)

	assert.NotNil(t, handler)
	assert.NotNil(t, handler.BaseHandler)
	assert.Equal(t, serviceRegistry, handler.ServiceRegistry)
	assert.Equal(t, logger, handler.Logger)
}

func TestETCHandler_ImportData(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)

	tests := []struct {
		name           string
		requestBody    string
		setupMock      func() *MockETCServiceRegistry
		expectedStatus int
		checkResponse  func(*testing.T, *httptest.ResponseRecorder)
	}{
		{
			name:        "Invalid request body",
			requestBody: "invalid json",
			setupMock: func() *MockETCServiceRegistry {
				return &MockETCServiceRegistry{}
			},
			expectedStatus: http.StatusBadRequest,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "invalid_request", response.Error.Code)
			},
		},
		{
			name:        "Service unavailable",
			requestBody: `{"file_path": "test.csv"}`,
			setupMock: func() *MockETCServiceRegistry {
				return &MockETCServiceRegistry{etcService: nil}
			},
			expectedStatus: http.StatusServiceUnavailable,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "service_unavailable", response.Error.Code)
			},
		},
		{
			name:        "Successful import",
			requestBody: `{"file_path": "test.csv"}`,
			setupMock: func() *MockETCServiceRegistry {
				mockETC := &MockETCService{}
				importResult := &models.ETCImportResult{
					Success:     true,
					RecordsRead: 10,
					RecordsSaved: 10,
				}
				mockETC.On("ImportData", mock.AnythingOfType("models.ETCImportRequest")).Return(importResult, nil)
				return &MockETCServiceRegistry{etcService: mockETC}
			},
			expectedStatus: http.StatusOK,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response SuccessResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.True(t, response.Success)
			},
		},
		{
			name:        "Import error",
			requestBody: `{"file_path": "test.csv"}`,
			setupMock: func() *MockETCServiceRegistry {
				mockETC := &MockETCService{}
				mockETC.On("ImportData", mock.AnythingOfType("models.ETCImportRequest")).Return((*models.ETCImportResult)(nil), fmt.Errorf("import failed"))
				return &MockETCServiceRegistry{etcService: mockETC}
			},
			expectedStatus: http.StatusInternalServerError,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.NotEmpty(t, response.Error.Code)
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockRegistry := tt.setupMock()
			handler := &ETCHandler{
				BaseHandler: &BaseHandler{
					ServiceRegistry: mockRegistry,
					Logger:          logger,
					ErrorHandler:    NewGRPCErrorHandler(),
				},
			}

			req := httptest.NewRequest(http.MethodPost, "/api/etc/import", strings.NewReader(tt.requestBody))
			w := httptest.NewRecorder()

			handler.ImportData(w, req)

			assert.Equal(t, tt.expectedStatus, w.Code)
			if tt.checkResponse != nil {
				tt.checkResponse(t, w)
			}
		})
	}
}

func TestETCHandler_GetMeisai(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)

	tests := []struct {
		name           string
		queryParams    string
		setupMock      func() *MockETCServiceRegistry
		expectedStatus int
		checkResponse  func(*testing.T, *httptest.ResponseRecorder)
	}{
		{
			name:        "Missing parameters",
			queryParams: "",
			setupMock: func() *MockETCServiceRegistry {
				return &MockETCServiceRegistry{}
			},
			expectedStatus: http.StatusBadRequest,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "missing_parameters", response.Error.Code)
			},
		},
		{
			name:        "Service unavailable",
			queryParams: "from_date=2023-01-01&to_date=2023-01-31",
			setupMock: func() *MockETCServiceRegistry {
				return &MockETCServiceRegistry{etcService: nil}
			},
			expectedStatus: http.StatusServiceUnavailable,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "service_unavailable", response.Error.Code)
			},
		},
		{
			name:        "Successful retrieval",
			queryParams: "from_date=2023-01-01&to_date=2023-01-31",
			setupMock: func() *MockETCServiceRegistry {
				mockETC := &MockETCService{}
				meisai := []*models.ETCMeisai{
					{ID: 1, Amount: 1000},
					{ID: 2, Amount: 2000},
				}
				mockETC.On("GetMeisaiByDateRange", "2023-01-01", "2023-01-31").Return(meisai, nil)
				return &MockETCServiceRegistry{etcService: mockETC}
			},
			expectedStatus: http.StatusOK,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response SuccessResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.True(t, response.Success)
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockRegistry := tt.setupMock()
			handler := &ETCHandler{
				BaseHandler: &BaseHandler{
					ServiceRegistry: mockRegistry,
					Logger:          logger,
					ErrorHandler:    NewGRPCErrorHandler(),
				},
			}

			req := httptest.NewRequest(http.MethodGet, "/api/etc/meisai?"+tt.queryParams, nil)
			w := httptest.NewRecorder()

			handler.GetMeisai(w, req)

			assert.Equal(t, tt.expectedStatus, w.Code)
			if tt.checkResponse != nil {
				tt.checkResponse(t, w)
			}
		})
	}
}

func TestETCHandler_GetMeisaiByID(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)

	tests := []struct {
		name           string
		urlID          string
		setupMock      func() *MockETCServiceRegistry
		expectedStatus int
		checkResponse  func(*testing.T, *httptest.ResponseRecorder)
	}{
		{
			name:  "Missing ID",
			urlID: "",
			setupMock: func() *MockETCServiceRegistry {
				return &MockETCServiceRegistry{}
			},
			expectedStatus: http.StatusBadRequest,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "missing_id", response.Error.Code)
			},
		},
		{
			name:  "Invalid ID",
			urlID: "invalid",
			setupMock: func() *MockETCServiceRegistry {
				return &MockETCServiceRegistry{}
			},
			expectedStatus: http.StatusBadRequest,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "invalid_id", response.Error.Code)
			},
		},
		{
			name:  "Service unavailable",
			urlID: "123",
			setupMock: func() *MockETCServiceRegistry {
				return &MockETCServiceRegistry{etcService: nil}
			},
			expectedStatus: http.StatusServiceUnavailable,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "service_unavailable", response.Error.Code)
			},
		},
		{
			name:  "Successful retrieval",
			urlID: "123",
			setupMock: func() *MockETCServiceRegistry {
				mockETC := &MockETCService{}
				meisai := &models.ETCMeisai{ID: 123, Amount: 1000}
				mockETC.On("GetByID", mock.AnythingOfType("*context.timerCtx"), int64(123)).Return(meisai, nil)
				return &MockETCServiceRegistry{etcService: mockETC}
			},
			expectedStatus: http.StatusOK,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response SuccessResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.True(t, response.Success)
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockRegistry := tt.setupMock()
			handler := &ETCHandler{
				BaseHandler: &BaseHandler{
					ServiceRegistry: mockRegistry,
					Logger:          logger,
					ErrorHandler:    NewGRPCErrorHandler(),
				},
			}

			// Create chi router for URL parameter handling
			r := chi.NewRouter()
			r.Get("/api/etc/meisai/{id}", handler.GetMeisaiByID)

			req := httptest.NewRequest(http.MethodGet, "/api/etc/meisai/"+tt.urlID, nil)
			w := httptest.NewRecorder()

			r.ServeHTTP(w, req)

			assert.Equal(t, tt.expectedStatus, w.Code)
			if tt.checkResponse != nil {
				tt.checkResponse(t, w)
			}
		})
	}
}

func TestETCHandler_CreateMeisai(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)

	tests := []struct {
		name           string
		requestBody    string
		setupMock      func() *MockETCServiceRegistry
		expectedStatus int
		checkResponse  func(*testing.T, *httptest.ResponseRecorder)
	}{
		{
			name:        "Invalid request body",
			requestBody: "invalid json",
			setupMock: func() *MockETCServiceRegistry {
				return &MockETCServiceRegistry{}
			},
			expectedStatus: http.StatusBadRequest,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "invalid_request", response.Error.Code)
			},
		},
		{
			name:        "Service unavailable",
			requestBody: `{"amount": 1000}`,
			setupMock: func() *MockETCServiceRegistry {
				return &MockETCServiceRegistry{etcService: nil}
			},
			expectedStatus: http.StatusServiceUnavailable,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "service_unavailable", response.Error.Code)
			},
		},
		{
			name:        "Successful creation",
			requestBody: `{"amount": 1000}`,
			setupMock: func() *MockETCServiceRegistry {
				mockETC := &MockETCService{}
				created := &models.ETCMeisai{ID: 1, Amount: 1000}
				mockETC.On("Create", mock.AnythingOfType("*context.timerCtx"), mock.AnythingOfType("*models.ETCMeisai")).Return(created, nil)
				return &MockETCServiceRegistry{etcService: mockETC}
			},
			expectedStatus: http.StatusCreated,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var created models.ETCMeisai
				err := json.NewDecoder(w.Body).Decode(&created)
				assert.NoError(t, err)
				assert.Equal(t, int64(1), created.ID)
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockRegistry := tt.setupMock()
			handler := &ETCHandler{
				BaseHandler: &BaseHandler{
					ServiceRegistry: mockRegistry,
					Logger:          logger,
					ErrorHandler:    NewGRPCErrorHandler(),
				},
			}

			req := httptest.NewRequest(http.MethodPost, "/api/etc/meisai", strings.NewReader(tt.requestBody))
			w := httptest.NewRecorder()

			handler.CreateMeisai(w, req)

			assert.Equal(t, tt.expectedStatus, w.Code)
			if tt.checkResponse != nil {
				tt.checkResponse(t, w)
			}
		})
	}
}

func TestETCHandler_ListETCMeisai(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)

	tests := []struct {
		name           string
		queryParams    string
		setupMock      func() *MockETCServiceRegistry
		expectedStatus int
		checkResponse  func(*testing.T, *httptest.ResponseRecorder)
	}{
		{
			name:        "Default parameters",
			queryParams: "",
			setupMock: func() *MockETCServiceRegistry {
				mockETC := &MockETCService{}
				records := []*models.ETCMeisai{
					{ID: 1, Amount: 1000},
					{ID: 2, Amount: 2000},
				}
				mockETC.On("List", mock.AnythingOfType("*context.timerCtx"), mock.AnythingOfType("*models.ETCListParams")).Return(records, int64(2), nil)
				return &MockETCServiceRegistry{etcService: mockETC}
			},
			expectedStatus: http.StatusOK,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response SuccessResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.True(t, response.Success)
			},
		},
		{
			name:        "Custom parameters",
			queryParams: "limit=10&offset=20&etc_number=123456",
			setupMock: func() *MockETCServiceRegistry {
				mockETC := &MockETCService{}
				records := []*models.ETCMeisai{}
				mockETC.On("List", mock.AnythingOfType("*context.timerCtx"), mock.MatchedBy(func(params *models.ETCListParams) bool {
					return params.Limit == 10 && params.Offset == 20 && params.ETCNumber == "123456"
				})).Return(records, int64(0), nil)
				return &MockETCServiceRegistry{etcService: mockETC}
			},
			expectedStatus: http.StatusOK,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response SuccessResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.True(t, response.Success)
			},
		},
		{
			name:        "Service unavailable",
			queryParams: "",
			setupMock: func() *MockETCServiceRegistry {
				return &MockETCServiceRegistry{etcService: nil}
			},
			expectedStatus: http.StatusServiceUnavailable,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "service_unavailable", response.Error.Code)
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockRegistry := tt.setupMock()
			handler := &ETCHandler{
				BaseHandler: &BaseHandler{
					ServiceRegistry: mockRegistry,
					Logger:          logger,
					ErrorHandler:    NewGRPCErrorHandler(),
				},
			}

			req := httptest.NewRequest(http.MethodGet, "/api/etc?"+tt.queryParams, nil)
			w := httptest.NewRecorder()

			handler.ListETCMeisai(w, req)

			assert.Equal(t, tt.expectedStatus, w.Code)
			if tt.checkResponse != nil {
				tt.checkResponse(t, w)
			}
		})
	}
}

func TestETCHandler_BulkCreateETCMeisai(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)

	tests := []struct {
		name           string
		requestBody    string
		setupMock      func() *MockETCServiceRegistry
		expectedStatus int
		checkResponse  func(*testing.T, *httptest.ResponseRecorder)
	}{
		{
			name:        "Invalid request body",
			requestBody: "invalid json",
			setupMock: func() *MockETCServiceRegistry {
				return &MockETCServiceRegistry{}
			},
			expectedStatus: http.StatusBadRequest,
		},
		{
			name:        "Empty records",
			requestBody: `[]`,
			setupMock: func() *MockETCServiceRegistry {
				return &MockETCServiceRegistry{}
			},
			expectedStatus: http.StatusBadRequest,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "empty_request", response.Error.Code)
			},
		},
		{
			name:        "Service unavailable",
			requestBody: `[{"amount": 1000}]`,
			setupMock: func() *MockETCServiceRegistry {
				return &MockETCServiceRegistry{etcService: nil}
			},
			expectedStatus: http.StatusServiceUnavailable,
		},
		{
			name:        "Successful bulk create",
			requestBody: `[{"amount": 1000}, {"amount": 2000}]`,
			setupMock: func() *MockETCServiceRegistry {
				mockETC := &MockETCService{}
				result := &models.ETCImportResult{
					Success:      true,
					RecordsRead:  2,
					RecordsSaved: 2,
				}
				mockETC.On("ImportCSV", mock.AnythingOfType("*context.timerCtx"), mock.AnythingOfType("[]*models.ETCMeisai")).Return(result, nil)
				return &MockETCServiceRegistry{etcService: mockETC}
			},
			expectedStatus: http.StatusOK,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response SuccessResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.True(t, response.Success)
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockRegistry := tt.setupMock()
			handler := &ETCHandler{
				BaseHandler: &BaseHandler{
					ServiceRegistry: mockRegistry,
					Logger:          logger,
					ErrorHandler:    NewGRPCErrorHandler(),
				},
			}

			req := httptest.NewRequest(http.MethodPost, "/api/etc/bulk", strings.NewReader(tt.requestBody))
			w := httptest.NewRecorder()

			handler.BulkCreateETCMeisai(w, req)

			assert.Equal(t, tt.expectedStatus, w.Code)
			if tt.checkResponse != nil {
				tt.checkResponse(t, w)
			}
		})
	}
}

func TestETCHandler_GetETCSummary(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)

	tests := []struct {
		name           string
		queryParams    string
		setupMock      func() *MockETCServiceRegistry
		expectedStatus int
		checkResponse  func(*testing.T, *httptest.ResponseRecorder)
	}{
		{
			name:        "Missing parameters",
			queryParams: "",
			setupMock: func() *MockETCServiceRegistry {
				return &MockETCServiceRegistry{}
			},
			expectedStatus: http.StatusBadRequest,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "missing_parameters", response.Error.Code)
			},
		},
		{
			name:        "Service unavailable",
			queryParams: "from_date=2023-01-01&to_date=2023-01-31",
			setupMock: func() *MockETCServiceRegistry {
				return &MockETCServiceRegistry{etcService: nil}
			},
			expectedStatus: http.StatusServiceUnavailable,
		},
		{
			name:        "Successful summary",
			queryParams: "from_date=2023-01-01&to_date=2023-01-31",
			setupMock: func() *MockETCServiceRegistry {
				mockETC := &MockETCService{}
				summary := map[string]interface{}{
					"total_count":  10,
					"total_amount": 15000,
				}
				mockETC.On("GetSummary", mock.AnythingOfType("*context.timerCtx"), "2023-01-01", "2023-01-31").Return(summary, nil)
				return &MockETCServiceRegistry{etcService: mockETC}
			},
			expectedStatus: http.StatusOK,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response SuccessResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.True(t, response.Success)
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockRegistry := tt.setupMock()
			handler := &ETCHandler{
				BaseHandler: &BaseHandler{
					ServiceRegistry: mockRegistry,
					Logger:          logger,
					ErrorHandler:    NewGRPCErrorHandler(),
				},
			}

			req := httptest.NewRequest(http.MethodGet, "/api/etc/summary?"+tt.queryParams, nil)
			w := httptest.NewRecorder()

			handler.GetETCSummary(w, req)

			assert.Equal(t, tt.expectedStatus, w.Code)
			if tt.checkResponse != nil {
				tt.checkResponse(t, w)
			}
		})
	}
}

func TestETCHandler_UpdateETCMeisai(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)
	handler := &ETCHandler{
		BaseHandler: &BaseHandler{
			ServiceRegistry: &services.ServiceRegistry{},
			Logger:          logger,
			ErrorHandler:    NewGRPCErrorHandler(),
		},
	}

	tests := []struct {
		name           string
		urlID          string
		requestBody    string
		expectedStatus int
		checkResponse  func(*testing.T, *httptest.ResponseRecorder)
	}{
		{
			name:           "Missing ID",
			urlID:          "",
			requestBody:    `{"amount": 1500}`,
			expectedStatus: http.StatusBadRequest,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "missing_id", response.Error.Code)
			},
		},
		{
			name:           "Invalid ID",
			urlID:          "invalid",
			requestBody:    `{"amount": 1500}`,
			expectedStatus: http.StatusBadRequest,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "invalid_id", response.Error.Code)
			},
		},
		{
			name:           "Invalid request body",
			urlID:          "123",
			requestBody:    "invalid json",
			expectedStatus: http.StatusBadRequest,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "invalid_request", response.Error.Code)
			},
		},
		{
			name:           "Not implemented",
			urlID:          "123",
			requestBody:    `{"amount": 1500}`,
			expectedStatus: http.StatusNotImplemented,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "not_implemented", response.Error.Code)
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// Create chi router for URL parameter handling
			r := chi.NewRouter()
			r.Put("/api/etc/{id}", handler.UpdateETCMeisai)

			req := httptest.NewRequest(http.MethodPut, "/api/etc/"+tt.urlID, strings.NewReader(tt.requestBody))
			w := httptest.NewRecorder()

			r.ServeHTTP(w, req)

			assert.Equal(t, tt.expectedStatus, w.Code)
			if tt.checkResponse != nil {
				tt.checkResponse(t, w)
			}
		})
	}
}

func TestETCHandler_DeleteETCMeisai(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)
	handler := &ETCHandler{
		BaseHandler: &BaseHandler{
			ServiceRegistry: &services.ServiceRegistry{},
			Logger:          logger,
			ErrorHandler:    NewGRPCErrorHandler(),
		},
	}

	tests := []struct {
		name           string
		urlID          string
		expectedStatus int
		checkResponse  func(*testing.T, *httptest.ResponseRecorder)
	}{
		{
			name:           "Missing ID",
			urlID:          "",
			expectedStatus: http.StatusBadRequest,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "missing_id", response.Error.Code)
			},
		},
		{
			name:           "Invalid ID",
			urlID:          "invalid",
			expectedStatus: http.StatusBadRequest,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "invalid_id", response.Error.Code)
			},
		},
		{
			name:           "Not implemented",
			urlID:          "123",
			expectedStatus: http.StatusNotImplemented,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "not_implemented", response.Error.Code)
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// Create chi router for URL parameter handling
			r := chi.NewRouter()
			r.Delete("/api/etc/{id}", handler.DeleteETCMeisai)

			req := httptest.NewRequest(http.MethodDelete, "/api/etc/"+tt.urlID, nil)
			w := httptest.NewRecorder()

			r.ServeHTTP(w, req)

			assert.Equal(t, tt.expectedStatus, w.Code)
			if tt.checkResponse != nil {
				tt.checkResponse(t, w)
			}
		})
	}
}

func TestETCHandler_GetSummary(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)

	tests := []struct {
		name           string
		queryParams    string
		setupMock      func() *MockETCServiceRegistry
		expectedStatus int
		checkResponse  func(*testing.T, *httptest.ResponseRecorder)
	}{
		{
			name:        "Missing parameters",
			queryParams: "",
			setupMock: func() *MockETCServiceRegistry {
				return &MockETCServiceRegistry{}
			},
			expectedStatus: http.StatusBadRequest,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "missing_parameters", response.Error.Code)
			},
		},
		{
			name:        "Invalid from_date",
			queryParams: "from_date=invalid&to_date=2023-01-31",
			setupMock: func() *MockETCServiceRegistry {
				return &MockETCServiceRegistry{}
			},
			expectedStatus: http.StatusBadRequest,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "invalid_date", response.Error.Code)
			},
		},
		{
			name:        "Invalid to_date",
			queryParams: "from_date=2023-01-01&to_date=invalid",
			setupMock: func() *MockETCServiceRegistry {
				return &MockETCServiceRegistry{}
			},
			expectedStatus: http.StatusBadRequest,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response ErrorResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.Equal(t, "invalid_date", response.Error.Code)
			},
		},
		{
			name:        "Service unavailable",
			queryParams: "from_date=2023-01-01&to_date=2023-01-31",
			setupMock: func() *MockETCServiceRegistry {
				return &MockETCServiceRegistry{etcService: nil}
			},
			expectedStatus: http.StatusServiceUnavailable,
		},
		{
			name:        "Successful summary",
			queryParams: "from_date=2023-01-01&to_date=2023-01-31",
			setupMock: func() *MockETCServiceRegistry {
				mockETC := &MockETCService{}
				records := []*models.ETCMeisai{
					{ID: 1, Amount: 1000, UseDate: time.Date(2023, 1, 15, 0, 0, 0, 0, time.UTC)},
					{ID: 2, Amount: 2000, UseDate: time.Date(2023, 1, 20, 0, 0, 0, 0, time.UTC)},
				}
				mockETC.On("GetByDateRange", mock.AnythingOfType("*context.timerCtx"),
					time.Date(2023, 1, 1, 0, 0, 0, 0, time.UTC),
					time.Date(2023, 1, 31, 0, 0, 0, 0, time.UTC)).Return(records, nil)
				return &MockETCServiceRegistry{etcService: mockETC}
			},
			expectedStatus: http.StatusOK,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response SuccessResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.True(t, response.Success)
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockRegistry := tt.setupMock()
			handler := &ETCHandler{
				BaseHandler: &BaseHandler{
					ServiceRegistry: mockRegistry,
					Logger:          logger,
					ErrorHandler:    NewGRPCErrorHandler(),
				},
			}

			req := httptest.NewRequest(http.MethodGet, "/api/etc/summary?"+tt.queryParams, nil)
			w := httptest.NewRecorder()

			handler.GetSummary(w, req)

			assert.Equal(t, tt.expectedStatus, w.Code)
			if tt.checkResponse != nil {
				tt.checkResponse(t, w)
			}
		})
	}
}

func TestETCHandler_createSummary(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)
	handler := &ETCHandler{
		BaseHandler: &BaseHandler{
			Logger: logger,
		},
	}

	tests := []struct {
		name     string
		records  []*models.ETCMeisai
		expected map[string]interface{}
	}{
		{
			name:    "Nil records",
			records: nil,
			expected: map[string]interface{}{
				"total_count":  0,
				"total_amount": 0,
				"date_range":   map[string]string{},
			},
		},
		{
			name:    "Empty records",
			records: []*models.ETCMeisai{},
			expected: map[string]interface{}{
				"total_count":  0,
				"total_amount": int32(0),
			},
		},
		{
			name: "Single record",
			records: []*models.ETCMeisai{
				{ID: 1, Amount: 1000, UseDate: time.Date(2023, 1, 15, 0, 0, 0, 0, time.UTC)},
			},
			expected: map[string]interface{}{
				"total_count":  1,
				"total_amount": int32(1000),
				"date_range": map[string]string{
					"from": "2023-01-15",
					"to":   "2023-01-15",
				},
			},
		},
		{
			name: "Multiple records",
			records: []*models.ETCMeisai{
				{ID: 1, Amount: 1000, UseDate: time.Date(2023, 1, 15, 0, 0, 0, 0, time.UTC)},
				{ID: 2, Amount: 2000, UseDate: time.Date(2023, 1, 20, 0, 0, 0, 0, time.UTC)},
				{ID: 3, Amount: 500, UseDate: time.Date(2023, 1, 10, 0, 0, 0, 0, time.UTC)},
			},
			expected: map[string]interface{}{
				"total_count":  3,
				"total_amount": int32(3500),
				"date_range": map[string]string{
					"from": "2023-01-10",
					"to":   "2023-01-20",
				},
			},
		},
		{
			name: "Records with nil entries",
			records: []*models.ETCMeisai{
				{ID: 1, Amount: 1000, UseDate: time.Date(2023, 1, 15, 0, 0, 0, 0, time.UTC)},
				nil,
				{ID: 2, Amount: 2000, UseDate: time.Date(2023, 1, 20, 0, 0, 0, 0, time.UTC)},
			},
			expected: map[string]interface{}{
				"total_count":  3,
				"total_amount": int32(3000),
				"date_range": map[string]string{
					"from": "2023-01-15",
					"to":   "2023-01-20",
				},
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			result := handler.createSummary(tt.records)

			assert.Equal(t, tt.expected["total_count"], result["total_count"])
			assert.Equal(t, tt.expected["total_amount"], result["total_amount"])

			if expectedDateRange, ok := tt.expected["date_range"].(map[string]string); ok {
				if len(expectedDateRange) > 0 {
					resultDateRange := result["date_range"].(map[string]string)
					assert.Equal(t, expectedDateRange["from"], resultDateRange["from"])
					assert.Equal(t, expectedDateRange["to"], resultDateRange["to"])
				}
			}
		})
	}
}

func TestETCHandler_BulkImport(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)

	tests := []struct {
		name           string
		requestBody    string
		setupMock      func() *MockETCServiceRegistry
		expectedStatus int
		checkResponse  func(*testing.T, *httptest.ResponseRecorder)
	}{
		{
			name:        "Invalid request body",
			requestBody: "invalid json",
			setupMock: func() *MockETCServiceRegistry {
				return &MockETCServiceRegistry{}
			},
			expectedStatus: http.StatusBadRequest,
		},
		{
			name:        "Service unavailable",
			requestBody: `[{"amount": 1000}]`,
			setupMock: func() *MockETCServiceRegistry {
				return &MockETCServiceRegistry{etcService: nil}
			},
			expectedStatus: http.StatusServiceUnavailable,
		},
		{
			name:        "Successful bulk import",
			requestBody: `[{"amount": 1000}, {"amount": 2000}]`,
			setupMock: func() *MockETCServiceRegistry {
				mockETC := &MockETCService{}
				result := &models.ETCImportResult{
					Success:      true,
					RecordsRead:  2,
					RecordsSaved: 2,
				}
				mockETC.On("ImportCSV", mock.AnythingOfType("*context.timerCtx"), mock.AnythingOfType("[]*models.ETCMeisai")).Return(result, nil)
				return &MockETCServiceRegistry{etcService: mockETC}
			},
			expectedStatus: http.StatusOK,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var response SuccessResponse
				err := json.NewDecoder(w.Body).Decode(&response)
				assert.NoError(t, err)
				assert.True(t, response.Success)
			},
		},
		{
			name:        "Partial success",
			requestBody: `[{"amount": 1000}, {"amount": 2000}]`,
			setupMock: func() *MockETCServiceRegistry {
				mockETC := &MockETCService{}
				result := &models.ETCImportResult{
					Success:      true,
					RecordsRead:  2,
					RecordsSaved: 1,
				}
				mockETC.On("ImportCSV", mock.AnythingOfType("*context.timerCtx"), mock.AnythingOfType("[]*models.ETCMeisai")).Return(result, fmt.Errorf("partial failure"))
				return &MockETCServiceRegistry{etcService: mockETC}
			},
			expectedStatus: http.StatusPartialContent,
			checkResponse: func(t *testing.T, w *httptest.ResponseRecorder) {
				var result models.ETCImportResult
				err := json.NewDecoder(w.Body).Decode(&result)
				assert.NoError(t, err)
				assert.True(t, result.Success)
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockRegistry := tt.setupMock()
			handler := &ETCHandler{
				BaseHandler: &BaseHandler{
					ServiceRegistry: mockRegistry,
					Logger:          logger,
					ErrorHandler:    NewGRPCErrorHandler(),
				},
			}

			req := httptest.NewRequest(http.MethodPost, "/api/etc/bulk-import", strings.NewReader(tt.requestBody))
			w := httptest.NewRecorder()

			handler.BulkImport(w, req)

			assert.Equal(t, tt.expectedStatus, w.Code)
			if tt.checkResponse != nil {
				tt.checkResponse(t, w)
			}
		})
	}
}

func TestETCHandler_TimeoutHandling(t *testing.T) {
	logger := log.New(os.Stdout, "", log.LstdFlags)

	mockETC := &MockETCService{}
	mockETC.On("GetByID", mock.AnythingOfType("*context.timerCtx"), int64(123)).Return(func(ctx context.Context, id int64) (*models.ETCMeisai, error) {
		select {
		case <-time.After(45 * time.Second):
			return &models.ETCMeisai{ID: id}, nil
		case <-ctx.Done():
			return nil, ctx.Err()
		}
	})

	mockRegistry := &MockETCServiceRegistry{etcService: mockETC}
	handler := &ETCHandler{
		BaseHandler: &BaseHandler{
			ServiceRegistry: mockRegistry,
			Logger:          logger,
			ErrorHandler:    NewGRPCErrorHandler(),
		},
	}

	// Create chi router for URL parameter handling
	r := chi.NewRouter()
	r.Get("/api/etc/meisai/{id}", handler.GetMeisaiByID)

	req := httptest.NewRequest(http.MethodGet, "/api/etc/meisai/123", nil)
	w := httptest.NewRecorder()

	start := time.Now()
	r.ServeHTTP(w, req)
	duration := time.Since(start)

	// Should timeout before 45 seconds (context timeout is 30s)
	assert.True(t, duration < 45*time.Second, "Request should timeout before 45 seconds")
	assert.Equal(t, "application/json", w.Header().Get("Content-Type"))
}