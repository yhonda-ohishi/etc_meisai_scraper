package services_test

import (
	"context"
	"errors"
	"log"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"

	"github.com/yhonda-ohishi/etc_meisai/src/repositories"
	"github.com/yhonda-ohishi/etc_meisai/src/services"
)

// MockStatisticsRepository is a mock implementation of statistics repository
type MockStatisticsRepository struct {
	mock.Mock
}

func (m *MockStatisticsRepository) CountRecords(ctx context.Context, filter repositories.StatisticsFilter) (int64, error) {
	args := m.Called(ctx, filter)
	return args.Get(0).(int64), args.Error(1)
}

func (m *MockStatisticsRepository) SumTollAmount(ctx context.Context, filter repositories.StatisticsFilter) (int64, error) {
	args := m.Called(ctx, filter)
	return args.Get(0).(int64), args.Error(1)
}

func (m *MockStatisticsRepository) AverageTollAmount(ctx context.Context, filter repositories.StatisticsFilter) (float64, error) {
	args := m.Called(ctx, filter)
	return args.Get(0).(float64), args.Error(1)
}

func (m *MockStatisticsRepository) CountUniqueVehicles(ctx context.Context, filter repositories.StatisticsFilter) (int64, error) {
	args := m.Called(ctx, filter)
	return args.Get(0).(int64), args.Error(1)
}

func (m *MockStatisticsRepository) CountUniqueCards(ctx context.Context, filter repositories.StatisticsFilter) (int64, error) {
	args := m.Called(ctx, filter)
	return args.Get(0).(int64), args.Error(1)
}

func (m *MockStatisticsRepository) CountUniqueEntranceICs(ctx context.Context, filter repositories.StatisticsFilter) (int64, error) {
	args := m.Called(ctx, filter)
	return args.Get(0).(int64), args.Error(1)
}

func (m *MockStatisticsRepository) CountUniqueExitICs(ctx context.Context, filter repositories.StatisticsFilter) (int64, error) {
	args := m.Called(ctx, filter)
	return args.Get(0).(int64), args.Error(1)
}

func (m *MockStatisticsRepository) GetTopRoutes(ctx context.Context, filter repositories.StatisticsFilter, limit int) ([]repositories.RouteStatistic, error) {
	args := m.Called(ctx, filter, limit)
	if result := args.Get(0); result != nil {
		return result.([]repositories.RouteStatistic), args.Error(1)
	}
	return nil, args.Error(1)
}

func (m *MockStatisticsRepository) GetTopVehicles(ctx context.Context, filter repositories.StatisticsFilter, limit int) ([]repositories.VehicleStatistic, error) {
	args := m.Called(ctx, filter, limit)
	if result := args.Get(0); result != nil {
		return result.([]repositories.VehicleStatistic), args.Error(1)
	}
	return nil, args.Error(1)
}

func (m *MockStatisticsRepository) GetTopCards(ctx context.Context, filter repositories.StatisticsFilter, limit int) ([]repositories.CardStatistic, error) {
	args := m.Called(ctx, filter, limit)
	if result := args.Get(0); result != nil {
		return result.([]repositories.CardStatistic), args.Error(1)
	}
	return nil, args.Error(1)
}

func (m *MockStatisticsRepository) GetHourlyDistribution(ctx context.Context, filter repositories.StatisticsFilter) ([]repositories.HourlyStatistic, error) {
	args := m.Called(ctx, filter)
	if result := args.Get(0); result != nil {
		return result.([]repositories.HourlyStatistic), args.Error(1)
	}
	return nil, args.Error(1)
}

func (m *MockStatisticsRepository) GetDailyDistribution(ctx context.Context, filter repositories.StatisticsFilter) ([]repositories.DailyStatistic, error) {
	args := m.Called(ctx, filter)
	if result := args.Get(0); result != nil {
		return result.([]repositories.DailyStatistic), args.Error(1)
	}
	return nil, args.Error(1)
}

func (m *MockStatisticsRepository) GetMonthlyDistribution(ctx context.Context, filter repositories.StatisticsFilter) ([]repositories.MonthlyStatistic, error) {
	args := m.Called(ctx, filter)
	if result := args.Get(0); result != nil {
		return result.([]repositories.MonthlyStatistic), args.Error(1)
	}
	return nil, args.Error(1)
}

func (m *MockStatisticsRepository) CountMappedRecords(ctx context.Context, filter repositories.StatisticsFilter) (int64, error) {
	args := m.Called(ctx, filter)
	return args.Get(0).(int64), args.Error(1)
}

func (m *MockStatisticsRepository) CountUnmappedRecords(ctx context.Context, filter repositories.StatisticsFilter) (int64, error) {
	args := m.Called(ctx, filter)
	return args.Get(0).(int64), args.Error(1)
}

func (m *MockStatisticsRepository) GetMappingStatistics(ctx context.Context, filter repositories.StatisticsFilter) (*repositories.MappingStatistics, error) {
	args := m.Called(ctx, filter)
	if result := args.Get(0); result != nil {
		return result.(*repositories.MappingStatistics), args.Error(1)
	}
	return nil, args.Error(1)
}

func (m *MockStatisticsRepository) Ping(ctx context.Context) error {
	args := m.Called(ctx)
	return args.Error(0)
}

func TestNewStatisticsService(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name   string
		repo   repositories.StatisticsRepository
		logger *log.Logger
	}{
		{
			name:   "with logger",
			repo:   &MockStatisticsRepository{},
			logger: log.Default(),
		},
		{
			name:   "without logger",
			repo:   &MockStatisticsRepository{},
			logger: nil,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			service := services.NewStatisticsService(tt.repo, tt.logger)
			assert.NotNil(t, service)
		})
	}
}

func TestStatisticsService_GetGeneralStatistics(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name        string
		filter      *services.StatisticsFilter
		setupMock   func(*MockStatisticsRepository)
		expectError bool
		errorMsg    string
		validate    func(*testing.T, *services.GeneralStatistics)
	}{
		{
			name: "successful statistics retrieval",
			filter: &services.StatisticsFilter{
				DateFrom: timePtr(time.Now().AddDate(0, -1, 0)),
				DateTo:   timePtr(time.Now()),
			},
			setupMock: func(m *MockStatisticsRepository) {
				m.On("CountRecords", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter")).Return(int64(100), nil)
				m.On("SumTollAmount", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter")).Return(int64(50000), nil)
				m.On("AverageTollAmount", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter")).Return(float64(500), nil)
				m.On("CountUniqueVehicles", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter")).Return(int64(10), nil)
				m.On("CountUniqueCards", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter")).Return(int64(5), nil)
				m.On("CountUniqueEntranceICs", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter")).Return(int64(15), nil)
				m.On("CountUniqueExitICs", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter")).Return(int64(20), nil)

				m.On("GetTopRoutes", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter"), 10).Return([]repositories.RouteStatistic{
					{EntranceIC: "東京IC", ExitIC: "横浜IC", Count: 50, TotalAmount: 25000, AvgAmount: 500},
				}, nil)

				m.On("GetTopVehicles", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter"), 10).Return([]repositories.VehicleStatistic{
					{CarNumber: "品川300あ1234", Count: 30, TotalAmount: 15000, AvgAmount: 500},
				}, nil)

				m.On("GetTopCards", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter"), 10).Return([]repositories.CardStatistic{
					{ETCCardNumber: "1234567890", Count: 20, TotalAmount: 10000, AvgAmount: 500},
				}, nil)

				m.On("GetHourlyDistribution", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter")).Return([]repositories.HourlyStatistic{
					{Hour: 8, Count: 10, TotalAmount: 5000, AvgAmount: 500},
				}, nil)
			},
			expectError: false,
			validate: func(t *testing.T, stats *services.GeneralStatistics) {
				assert.NotNil(t, stats)
				assert.Equal(t, int64(100), stats.TotalRecords)
				assert.Equal(t, int64(50000), stats.TotalAmount)
				assert.Equal(t, float64(500), stats.AverageAmount)
				assert.Equal(t, int64(10), stats.UniqueVehicles)
				assert.Equal(t, int64(5), stats.UniqueCards)
				assert.Len(t, stats.TopRoutes, 1)
				assert.Len(t, stats.TopVehicles, 1)
				assert.Len(t, stats.TopCards, 1)
				assert.Len(t, stats.HourlyDistribution, 1)
			},
		},
		{
			name:   "empty filter",
			filter: &services.StatisticsFilter{},
			setupMock: func(m *MockStatisticsRepository) {
				m.On("CountRecords", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter")).Return(int64(0), nil)
				m.On("SumTollAmount", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter")).Return(int64(0), nil)
				m.On("AverageTollAmount", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter")).Return(float64(0), nil)
				m.On("CountUniqueVehicles", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter")).Return(int64(0), nil)
				m.On("CountUniqueCards", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter")).Return(int64(0), nil)
				m.On("CountUniqueEntranceICs", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter")).Return(int64(0), nil)
				m.On("CountUniqueExitICs", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter")).Return(int64(0), nil)
				m.On("GetTopRoutes", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter"), 10).Return([]repositories.RouteStatistic{}, nil)
				m.On("GetTopVehicles", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter"), 10).Return([]repositories.VehicleStatistic{}, nil)
				m.On("GetTopCards", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter"), 10).Return([]repositories.CardStatistic{}, nil)
				m.On("GetHourlyDistribution", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter")).Return([]repositories.HourlyStatistic{}, nil)
			},
			expectError: false,
			validate: func(t *testing.T, stats *services.GeneralStatistics) {
				assert.NotNil(t, stats)
				assert.Equal(t, int64(0), stats.TotalRecords)
			},
		},
		{
			name:   "repository error",
			filter: &services.StatisticsFilter{},
			setupMock: func(m *MockStatisticsRepository) {
				m.On("CountRecords", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter")).Return(int64(0), errors.New("database error"))
			},
			expectError: true,
			errorMsg:    "failed to count records",
		},
		{
			name:   "nil filter",
			filter: nil,
			setupMock: func(m *MockStatisticsRepository) {
				// Should handle nil filter gracefully
				m.On("CountRecords", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter")).Return(int64(10), nil)
				m.On("SumTollAmount", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter")).Return(int64(1000), nil)
				m.On("AverageTollAmount", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter")).Return(float64(100), nil)
				m.On("CountUniqueVehicles", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter")).Return(int64(1), nil)
				m.On("CountUniqueCards", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter")).Return(int64(1), nil)
				m.On("CountUniqueEntranceICs", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter")).Return(int64(1), nil)
				m.On("CountUniqueExitICs", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter")).Return(int64(1), nil)
				m.On("GetTopRoutes", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter"), 10).Return([]repositories.RouteStatistic{}, nil)
				m.On("GetTopVehicles", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter"), 10).Return([]repositories.VehicleStatistic{}, nil)
				m.On("GetTopCards", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter"), 10).Return([]repositories.CardStatistic{}, nil)
				m.On("GetHourlyDistribution", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter")).Return([]repositories.HourlyStatistic{}, nil)
			},
			expectError: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockRepo := &MockStatisticsRepository{}
			tt.setupMock(mockRepo)

			service := services.NewStatisticsService(mockRepo, nil)
			ctx := context.Background()

			result, err := service.GetGeneralStatistics(ctx, tt.filter)

			if tt.expectError {
				assert.Error(t, err)
				if tt.errorMsg != "" {
					assert.Contains(t, err.Error(), tt.errorMsg)
				}
			} else {
				assert.NoError(t, err)
				if tt.validate != nil {
					tt.validate(t, result)
				}
			}

			mockRepo.AssertExpectations(t)
		})
	}
}

func TestStatisticsService_GetDailyStatistics(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name        string
		filter      *services.StatisticsFilter
		setupMock   func(*MockStatisticsRepository)
		expectError bool
		errorMsg    string
		validate    func(*testing.T, *services.DailyStatisticsResponse)
	}{
		{
			name: "successful daily statistics",
			filter: &services.StatisticsFilter{
				DateFrom: timePtr(time.Now().AddDate(0, 0, -7)),
				DateTo:   timePtr(time.Now()),
			},
			setupMock: func(m *MockStatisticsRepository) {
				m.On("GetDailyDistribution", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter")).Return([]repositories.DailyStatistic{
					{Date: time.Now(), Count: 10, TotalAmount: 5000, AvgAmount: 500},
					{Date: time.Now().AddDate(0, 0, -1), Count: 15, TotalAmount: 7500, AvgAmount: 500},
				}, nil)
			},
			expectError: false,
			validate: func(t *testing.T, resp *services.DailyStatisticsResponse) {
				assert.NotNil(t, resp)
				assert.Len(t, resp.Statistics, 2)
				assert.Equal(t, 10, int(resp.Statistics[0].Count))
			},
		},
		{
			name:   "repository error",
			filter: &services.StatisticsFilter{},
			setupMock: func(m *MockStatisticsRepository) {
				m.On("GetDailyDistribution", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter")).Return(nil, errors.New("database error"))
			},
			expectError: true,
			errorMsg:    "failed to get daily statistics",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockRepo := &MockStatisticsRepository{}
			tt.setupMock(mockRepo)

			service := services.NewStatisticsService(mockRepo, nil)
			ctx := context.Background()

			result, err := service.GetDailyStatistics(ctx, tt.filter)

			if tt.expectError {
				assert.Error(t, err)
				if tt.errorMsg != "" {
					assert.Contains(t, err.Error(), tt.errorMsg)
				}
			} else {
				assert.NoError(t, err)
				if tt.validate != nil {
					tt.validate(t, result)
				}
			}

			mockRepo.AssertExpectations(t)
		})
	}
}

func TestStatisticsService_GetMonthlyStatistics(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name        string
		filter      *services.StatisticsFilter
		setupMock   func(*MockStatisticsRepository)
		expectError bool
		errorMsg    string
		validate    func(*testing.T, *services.MonthlyStatisticsResponse)
	}{
		{
			name: "successful monthly statistics",
			filter: &services.StatisticsFilter{
				DateFrom: timePtr(time.Now().AddDate(-1, 0, 0)),
				DateTo:   timePtr(time.Now()),
			},
			setupMock: func(m *MockStatisticsRepository) {
				m.On("GetMonthlyDistribution", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter")).Return([]repositories.MonthlyStatistic{
					{Year: 2025, Month: 1, Count: 100, TotalAmount: 50000, AvgAmount: 500},
					{Year: 2024, Month: 12, Count: 150, TotalAmount: 75000, AvgAmount: 500},
				}, nil)
			},
			expectError: false,
			validate: func(t *testing.T, resp *services.MonthlyStatisticsResponse) {
				assert.NotNil(t, resp)
				assert.Len(t, resp.Statistics, 2)
				assert.Equal(t, 100, int(resp.Statistics[0].Count))
				assert.Equal(t, "January", resp.Statistics[0].MonthName)
			},
		},
		{
			name:   "repository error",
			filter: &services.StatisticsFilter{},
			setupMock: func(m *MockStatisticsRepository) {
				m.On("GetMonthlyDistribution", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter")).Return(nil, errors.New("database error"))
			},
			expectError: true,
			errorMsg:    "failed to get monthly statistics",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockRepo := &MockStatisticsRepository{}
			tt.setupMock(mockRepo)

			service := services.NewStatisticsService(mockRepo, nil)
			ctx := context.Background()

			result, err := service.GetMonthlyStatistics(ctx, tt.filter)

			if tt.expectError {
				assert.Error(t, err)
				if tt.errorMsg != "" {
					assert.Contains(t, err.Error(), tt.errorMsg)
				}
			} else {
				assert.NoError(t, err)
				if tt.validate != nil {
					tt.validate(t, result)
				}
			}

			mockRepo.AssertExpectations(t)
		})
	}
}

func TestStatisticsService_GetVehicleStatistics(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name        string
		carNumbers  []string
		filter      *services.StatisticsFilter
		setupMock   func(*MockStatisticsRepository)
		expectError bool
		errorMsg    string
		validate    func(*testing.T, *services.VehicleStatisticsResponse)
	}{
		{
			name:       "successful vehicle statistics",
			carNumbers: []string{"品川300あ1234", "横浜400い5678"},
			filter:     &services.StatisticsFilter{},
			setupMock: func(m *MockStatisticsRepository) {
				m.On("GetTopVehicles", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter"), 2).Return([]repositories.VehicleStatistic{
					{CarNumber: "品川300あ1234", Count: 30, TotalAmount: 15000, AvgAmount: 500},
					{CarNumber: "横浜400い5678", Count: 20, TotalAmount: 10000, AvgAmount: 500},
				}, nil)
			},
			expectError: false,
			validate: func(t *testing.T, resp *services.VehicleStatisticsResponse) {
				assert.NotNil(t, resp)
				assert.Len(t, resp.Vehicles, 2)
				assert.Equal(t, "品川300あ1234", resp.Vehicles[0].CarNumber)
			},
		},
		{
			name:       "empty car numbers",
			carNumbers: []string{},
			filter:     &services.StatisticsFilter{},
			setupMock: func(m *MockStatisticsRepository) {
				// Service calls GetTopVehicles with len(carNumbers) = 0
				m.On("GetTopVehicles", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter"), 0).Return([]repositories.VehicleStatistic{}, nil)
			},
			expectError: false,
			validate: func(t *testing.T, resp *services.VehicleStatisticsResponse) {
				assert.NotNil(t, resp)
				assert.Len(t, resp.Vehicles, 0)
			},
		},
		{
			name:       "repository error",
			carNumbers: []string{"test"},
			filter:     &services.StatisticsFilter{},
			setupMock: func(m *MockStatisticsRepository) {
				m.On("GetTopVehicles", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter"), 1).Return(nil, errors.New("database error"))
			},
			expectError: true,
			errorMsg:    "failed to get vehicle statistics",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockRepo := &MockStatisticsRepository{}
			tt.setupMock(mockRepo)

			service := services.NewStatisticsService(mockRepo, nil)
			ctx := context.Background()

			result, err := service.GetVehicleStatistics(ctx, tt.carNumbers, tt.filter)

			if tt.expectError {
				assert.Error(t, err)
				if tt.errorMsg != "" {
					assert.Contains(t, err.Error(), tt.errorMsg)
				}
			} else {
				assert.NoError(t, err)
				if tt.validate != nil {
					tt.validate(t, result)
				}
			}

			mockRepo.AssertExpectations(t)
		})
	}
}

func TestStatisticsService_GetMappingStatistics(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name        string
		filter      *services.StatisticsFilter
		setupMock   func(*MockStatisticsRepository)
		expectError bool
		errorMsg    string
		validate    func(*testing.T, *services.MappingStatisticsResponse)
	}{
		{
			name:   "successful mapping statistics",
			filter: &services.StatisticsFilter{},
			setupMock: func(m *MockStatisticsRepository) {
				m.On("GetMappingStatistics", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter")).Return(&repositories.MappingStatistics{
					TotalRecords:     100,
					MappedRecords:    80,
					UnmappedRecords:  20,
					MappingRate:      0.8,
				}, nil)
			},
			expectError: false,
			validate: func(t *testing.T, resp *services.MappingStatisticsResponse) {
				assert.NotNil(t, resp)
				assert.Equal(t, int64(100), resp.TotalRecords)
				assert.Equal(t, int64(80), resp.MappedRecords)
				assert.Equal(t, int64(20), resp.UnmappedRecords)
				assert.Equal(t, 0.8, resp.MappingRate)
			},
		},
		{
			name:   "repository error",
			filter: &services.StatisticsFilter{},
			setupMock: func(m *MockStatisticsRepository) {
				m.On("GetMappingStatistics", mock.Anything, mock.AnythingOfType("repositories.StatisticsFilter")).Return(nil, errors.New("database error"))
			},
			expectError: true,
			errorMsg:    "failed to get mapping statistics",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockRepo := &MockStatisticsRepository{}
			tt.setupMock(mockRepo)

			service := services.NewStatisticsService(mockRepo, nil)
			ctx := context.Background()

			result, err := service.GetMappingStatistics(ctx, tt.filter)

			if tt.expectError {
				assert.Error(t, err)
				if tt.errorMsg != "" {
					assert.Contains(t, err.Error(), tt.errorMsg)
				}
			} else {
				assert.NoError(t, err)
				if tt.validate != nil {
					tt.validate(t, result)
				}
			}

			mockRepo.AssertExpectations(t)
		})
	}
}

func TestStatisticsService_HealthCheck(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name        string
		setupMock   func(*MockStatisticsRepository)
		expectError bool
		errorMsg    string
	}{
		{
			name: "healthy repository",
			setupMock: func(m *MockStatisticsRepository) {
				m.On("Ping", mock.Anything).Return(nil)
			},
			expectError: false,
		},
		{
			name: "unhealthy repository",
			setupMock: func(m *MockStatisticsRepository) {
				m.On("Ping", mock.Anything).Return(errors.New("connection failed"))
			},
			expectError: true,
			errorMsg:    "statistics repository ping failed",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockRepo := &MockStatisticsRepository{}
			tt.setupMock(mockRepo)

			service := services.NewStatisticsService(mockRepo, nil)
			ctx := context.Background()

			err := service.HealthCheck(ctx)

			if tt.expectError {
				assert.Error(t, err)
				if tt.errorMsg != "" {
					assert.Contains(t, err.Error(), tt.errorMsg)
				}
			} else {
				assert.NoError(t, err)
			}

			mockRepo.AssertExpectations(t)
		})
	}
}

// Helper function
func timePtr(t time.Time) *time.Time {
	return &t
}