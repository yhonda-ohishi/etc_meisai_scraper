package services

import (
	"context"
	"errors"
	"log"
	"os"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"

	"github.com/yhonda-ohishi/etc_meisai/src/models"
	"github.com/yhonda-ohishi/etc_meisai/src/repositories"
)

// MockETCMeisaiRecordRepository is a mock implementation of ETCMeisaiRecordRepository
type MockETCMeisaiRecordRepository struct {
	mock.Mock
}

func (m *MockETCMeisaiRecordRepository) Create(ctx context.Context, record *models.ETCMeisaiRecord) error {
	args := m.Called(ctx, record)
	return args.Error(0)
}

func (m *MockETCMeisaiRecordRepository) GetByID(ctx context.Context, id int64) (*models.ETCMeisaiRecord, error) {
	args := m.Called(ctx, id)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*models.ETCMeisaiRecord), args.Error(1)
}

func (m *MockETCMeisaiRecordRepository) Update(ctx context.Context, record *models.ETCMeisaiRecord) error {
	args := m.Called(ctx, record)
	return args.Error(0)
}

func (m *MockETCMeisaiRecordRepository) Delete(ctx context.Context, id int64) error {
	args := m.Called(ctx, id)
	return args.Error(0)
}

func (m *MockETCMeisaiRecordRepository) GetByHash(ctx context.Context, hash string) (*models.ETCMeisaiRecord, error) {
	args := m.Called(ctx, hash)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*models.ETCMeisaiRecord), args.Error(1)
}

func (m *MockETCMeisaiRecordRepository) CheckDuplicateHash(ctx context.Context, hash string, excludeID ...int64) (bool, error) {
	args := m.Called(ctx, hash, excludeID)
	return args.Bool(0), args.Error(1)
}

func (m *MockETCMeisaiRecordRepository) List(ctx context.Context, params repositories.ListRecordsParams) ([]*models.ETCMeisaiRecord, int64, error) {
	args := m.Called(ctx, params)
	if args.Get(0) == nil {
		return nil, args.Get(1).(int64), args.Error(2)
	}
	return args.Get(0).([]*models.ETCMeisaiRecord), args.Get(1).(int64), args.Error(2)
}

func (m *MockETCMeisaiRecordRepository) BeginTx(ctx context.Context) (repositories.ETCMeisaiRecordRepository, error) {
	args := m.Called(ctx)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(repositories.ETCMeisaiRecordRepository), args.Error(1)
}

func (m *MockETCMeisaiRecordRepository) CommitTx() error {
	args := m.Called()
	return args.Error(0)
}

func (m *MockETCMeisaiRecordRepository) RollbackTx() error {
	args := m.Called()
	return args.Error(0)
}

func (m *MockETCMeisaiRecordRepository) Ping(ctx context.Context) error {
	args := m.Called(ctx)
	return args.Error(0)
}

// Helper function to create a test service
func createTestService(repo repositories.ETCMeisaiRecordRepository, logger *log.Logger) *ETCMeisaiService {
	if logger == nil {
		logger = log.New(os.Stdout, "[TEST] ", log.LstdFlags)
	}
	return NewETCMeisaiService(repo, logger)
}

// Helper function to create valid test parameters
func createValidParams() *CreateRecordParams {
	return &CreateRecordParams{
		Date:          time.Date(2024, 1, 15, 0, 0, 0, 0, time.UTC),
		Time:          "10:30:00", // Fixed: Use HH:MM:SS format
		EntranceIC:    "東京IC",
		ExitIC:        "横浜IC",
		TollAmount:    1000,
		CarNumber:     "ABC-1234", // Fixed: Use valid format that matches regex patterns
		ETCCardNumber: "1234567890123456",
		ETCNum:        stringPtr("ETC001"),
		DtakoRowID:    int64Ptr(123),
	}
}

func stringPtr(s string) *string {
	return &s
}

func int64Ptr(i int64) *int64 {
	return &i
}

func TestNewETCMeisaiService(t *testing.T) {
	t.Parallel()

	t.Run("with provided logger", func(t *testing.T) {
		mockRepo := &MockETCMeisaiRecordRepository{}
		logger := log.New(os.Stdout, "[TEST] ", log.LstdFlags)

		service := NewETCMeisaiService(mockRepo, logger)

		assert.NotNil(t, service)
		assert.Equal(t, mockRepo, service.repo)
		assert.Equal(t, logger, service.logger)
	})

	t.Run("with nil logger creates default logger", func(t *testing.T) {
		mockRepo := &MockETCMeisaiRecordRepository{}

		service := NewETCMeisaiService(mockRepo, nil)

		assert.NotNil(t, service)
		assert.Equal(t, mockRepo, service.repo)
		assert.NotNil(t, service.logger)
	})
}

func TestETCMeisaiService_CreateRecord(t *testing.T) {
	t.Parallel()

	t.Run("successful creation", func(t *testing.T) {
		ctx := context.Background()
		mockRepo := &MockETCMeisaiRecordRepository{}
		mockTxRepo := &MockETCMeisaiRecordRepository{}
		service := createTestService(mockRepo, nil)
		params := createValidParams()

		// Setup expectations
		mockRepo.On("BeginTx", ctx).Return(mockTxRepo, nil)
		mockTxRepo.On("CheckDuplicateHash", ctx, mock.AnythingOfType("string"), mock.Anything).Return(false, nil)
		mockTxRepo.On("Create", ctx, mock.AnythingOfType("*models.ETCMeisaiRecord")).Return(nil).Run(func(args mock.Arguments) {
			record := args.Get(1).(*models.ETCMeisaiRecord)
			record.ID = 1 // Simulate ID assignment
		})
		mockTxRepo.On("CommitTx").Return(nil)

		record, err := service.CreateRecord(ctx, params)

		require.NoError(t, err)
		assert.NotNil(t, record)
		assert.Equal(t, int64(1), record.ID)
		assert.Equal(t, params.Date, record.Date)
		assert.Equal(t, params.Time, record.Time)
		assert.Equal(t, params.EntranceIC, record.EntranceIC)
		assert.Equal(t, params.ExitIC, record.ExitIC)
		assert.Equal(t, params.TollAmount, record.TollAmount)
		assert.NotEmpty(t, record.Hash)

		mockRepo.AssertExpectations(t)
		mockTxRepo.AssertExpectations(t)
	})

	t.Run("validation failure", func(t *testing.T) {
		ctx := context.Background()
		mockRepo := &MockETCMeisaiRecordRepository{}
		service := createTestService(mockRepo, nil)

		// Invalid params (negative toll amount)
		params := createValidParams()
		params.TollAmount = -100

		record, err := service.CreateRecord(ctx, params)

		assert.Error(t, err)
		assert.Nil(t, record)
		assert.Contains(t, err.Error(), "record validation failed")
		mockRepo.AssertExpectations(t)
	})

	t.Run("begin transaction failure", func(t *testing.T) {
		ctx := context.Background()
		mockRepo := &MockETCMeisaiRecordRepository{}
		service := createTestService(mockRepo, nil)
		params := createValidParams()

		mockRepo.On("BeginTx", ctx).Return(nil, errors.New("tx error"))

		record, err := service.CreateRecord(ctx, params)

		assert.Error(t, err)
		assert.Nil(t, record)
		assert.Contains(t, err.Error(), "failed to start transaction")
		mockRepo.AssertExpectations(t)
	})

	t.Run("duplicate hash detection", func(t *testing.T) {
		ctx := context.Background()
		mockRepo := &MockETCMeisaiRecordRepository{}
		mockTxRepo := &MockETCMeisaiRecordRepository{}
		service := createTestService(mockRepo, nil)
		params := createValidParams()

		mockRepo.On("BeginTx", ctx).Return(mockTxRepo, nil)
		mockTxRepo.On("CheckDuplicateHash", ctx, mock.AnythingOfType("string"), mock.Anything).Return(true, nil)
		mockTxRepo.On("RollbackTx").Return(nil)

		record, err := service.CreateRecord(ctx, params)

		assert.Error(t, err)
		assert.Nil(t, record)
		assert.Contains(t, err.Error(), "duplicate record with hash")
		mockRepo.AssertExpectations(t)
		mockTxRepo.AssertExpectations(t)
	})

	t.Run("check duplicate hash failure", func(t *testing.T) {
		ctx := context.Background()
		mockRepo := &MockETCMeisaiRecordRepository{}
		mockTxRepo := &MockETCMeisaiRecordRepository{}
		service := createTestService(mockRepo, nil)
		params := createValidParams()

		mockRepo.On("BeginTx", ctx).Return(mockTxRepo, nil)
		mockTxRepo.On("CheckDuplicateHash", ctx, mock.AnythingOfType("string"), mock.Anything).Return(false, errors.New("check error"))
		mockTxRepo.On("RollbackTx").Return(nil)

		record, err := service.CreateRecord(ctx, params)

		assert.Error(t, err)
		assert.Nil(t, record)
		assert.Contains(t, err.Error(), "failed to check for duplicates")
		mockRepo.AssertExpectations(t)
		mockTxRepo.AssertExpectations(t)
	})

	t.Run("create failure", func(t *testing.T) {
		ctx := context.Background()
		mockRepo := &MockETCMeisaiRecordRepository{}
		mockTxRepo := &MockETCMeisaiRecordRepository{}
		service := createTestService(mockRepo, nil)
		params := createValidParams()

		mockRepo.On("BeginTx", ctx).Return(mockTxRepo, nil)
		mockTxRepo.On("CheckDuplicateHash", ctx, mock.AnythingOfType("string"), mock.Anything).Return(false, nil)
		mockTxRepo.On("Create", ctx, mock.AnythingOfType("*models.ETCMeisaiRecord")).Return(errors.New("create error"))
		mockTxRepo.On("RollbackTx").Return(nil)

		record, err := service.CreateRecord(ctx, params)

		assert.Error(t, err)
		assert.Nil(t, record)
		assert.Contains(t, err.Error(), "failed to create record")
		mockRepo.AssertExpectations(t)
		mockTxRepo.AssertExpectations(t)
	})

	t.Run("commit failure", func(t *testing.T) {
		ctx := context.Background()
		mockRepo := &MockETCMeisaiRecordRepository{}
		mockTxRepo := &MockETCMeisaiRecordRepository{}
		service := createTestService(mockRepo, nil)
		params := createValidParams()

		mockRepo.On("BeginTx", ctx).Return(mockTxRepo, nil)
		mockTxRepo.On("CheckDuplicateHash", ctx, mock.AnythingOfType("string"), mock.Anything).Return(false, nil)
		mockTxRepo.On("Create", ctx, mock.AnythingOfType("*models.ETCMeisaiRecord")).Return(nil)
		mockTxRepo.On("CommitTx").Return(errors.New("commit error"))

		record, err := service.CreateRecord(ctx, params)

		assert.Error(t, err)
		assert.Nil(t, record)
		assert.Contains(t, err.Error(), "failed to commit transaction")
		mockRepo.AssertExpectations(t)
		mockTxRepo.AssertExpectations(t)
	})
}

func TestETCMeisaiService_GetRecord(t *testing.T) {
	t.Parallel()

	t.Run("successful retrieval", func(t *testing.T) {
		ctx := context.Background()
		mockRepo := &MockETCMeisaiRecordRepository{}
		service := createTestService(mockRepo, nil)

		expectedRecord := &models.ETCMeisaiRecord{
			ID:            1,
			Date:          time.Date(2024, 1, 15, 0, 0, 0, 0, time.UTC),
			Time:          "10:30:00", // Fixed format
			EntranceIC:    "東京IC",
			ExitIC:        "横浜IC",
			TollAmount:    1000,
			CarNumber:     "ABC-1234", // Fixed car number
			ETCCardNumber: "1234567890123456",
		}

		mockRepo.On("GetByID", ctx, int64(1)).Return(expectedRecord, nil)

		record, err := service.GetRecord(ctx, 1)

		require.NoError(t, err)
		assert.Equal(t, expectedRecord, record)
		mockRepo.AssertExpectations(t)
	})

	t.Run("invalid ID", func(t *testing.T) {
		ctx := context.Background()
		mockRepo := &MockETCMeisaiRecordRepository{}
		service := createTestService(mockRepo, nil)

		tests := []int64{0, -1, -100}
		for _, id := range tests {
			record, err := service.GetRecord(ctx, id)

			assert.Error(t, err)
			assert.Nil(t, record)
			assert.Contains(t, err.Error(), "invalid record ID")
		}

		mockRepo.AssertExpectations(t)
	})

	t.Run("repository error", func(t *testing.T) {
		ctx := context.Background()
		mockRepo := &MockETCMeisaiRecordRepository{}
		service := createTestService(mockRepo, nil)

		mockRepo.On("GetByID", ctx, int64(1)).Return(nil, errors.New("db error"))

		record, err := service.GetRecord(ctx, 1)

		assert.Error(t, err)
		assert.Nil(t, record)
		assert.Contains(t, err.Error(), "failed to retrieve record")
		mockRepo.AssertExpectations(t)
	})
}

func TestETCMeisaiService_ListRecords(t *testing.T) {
	t.Parallel()

	t.Run("successful listing with defaults", func(t *testing.T) {
		ctx := context.Background()
		mockRepo := &MockETCMeisaiRecordRepository{}
		service := createTestService(mockRepo, nil)

		params := &ListRecordsParams{}
		expectedRecords := []*models.ETCMeisaiRecord{
			{ID: 1, CarNumber: "ABC-1234"},
			{ID: 2, CarNumber: "XYZ-5678"},
		}

		mockRepo.On("List", ctx, mock.MatchedBy(func(p repositories.ListRecordsParams) bool {
			return p.Page == 1 && p.PageSize == 50 && p.SortBy == "date" && p.SortOrder == "desc"
		})).Return(expectedRecords, int64(2), nil)

		response, err := service.ListRecords(ctx, params)

		require.NoError(t, err)
		assert.NotNil(t, response)
		assert.Equal(t, expectedRecords, response.Records)
		assert.Equal(t, int64(2), response.TotalCount)
		assert.Equal(t, 1, response.Page)
		assert.Equal(t, 50, response.PageSize)
		assert.Equal(t, 1, response.TotalPages)
		mockRepo.AssertExpectations(t)
	})

	t.Run("custom parameters", func(t *testing.T) {
		ctx := context.Background()
		mockRepo := &MockETCMeisaiRecordRepository{}
		service := createTestService(mockRepo, nil)

		carNumber := "ABC-1234"
		params := &ListRecordsParams{
			Page:      2,
			PageSize:  25,
			CarNumber: &carNumber,
			SortBy:    "toll_amount",
			SortOrder: "asc",
		}

		expectedRecords := []*models.ETCMeisaiRecord{
			{ID: 3, CarNumber: "ABC-1234"},
		}

		mockRepo.On("List", ctx, mock.MatchedBy(func(p repositories.ListRecordsParams) bool {
			return p.Page == 2 && p.PageSize == 25 && p.SortBy == "toll_amount" && p.SortOrder == "asc" &&
				p.CarNumber != nil && *p.CarNumber == carNumber
		})).Return(expectedRecords, int64(100), nil)

		response, err := service.ListRecords(ctx, params)

		require.NoError(t, err)
		assert.NotNil(t, response)
		assert.Equal(t, expectedRecords, response.Records)
		assert.Equal(t, int64(100), response.TotalCount)
		assert.Equal(t, 2, response.Page)
		assert.Equal(t, 25, response.PageSize)
		assert.Equal(t, 4, response.TotalPages) // 100/25 = 4
		mockRepo.AssertExpectations(t)
	})

	t.Run("page size limit enforcement", func(t *testing.T) {
		ctx := context.Background()
		mockRepo := &MockETCMeisaiRecordRepository{}
		service := createTestService(mockRepo, nil)

		params := &ListRecordsParams{
			PageSize: 2000, // Above limit
		}

		mockRepo.On("List", ctx, mock.MatchedBy(func(p repositories.ListRecordsParams) bool {
			return p.PageSize == 1000 // Should be limited to 1000
		})).Return([]*models.ETCMeisaiRecord{}, int64(0), nil)

		response, err := service.ListRecords(ctx, params)

		require.NoError(t, err)
		assert.Equal(t, 1000, response.PageSize)
		mockRepo.AssertExpectations(t)
	})

	t.Run("repository error", func(t *testing.T) {
		ctx := context.Background()
		mockRepo := &MockETCMeisaiRecordRepository{}
		service := createTestService(mockRepo, nil)

		params := &ListRecordsParams{}

		mockRepo.On("List", ctx, mock.AnythingOfType("repositories.ListRecordsParams")).Return(nil, int64(0), errors.New("db error"))

		response, err := service.ListRecords(ctx, params)

		assert.Error(t, err)
		assert.Nil(t, response)
		assert.Contains(t, err.Error(), "failed to retrieve records")
		mockRepo.AssertExpectations(t)
	})
}

func TestETCMeisaiService_UpdateRecord(t *testing.T) {
	t.Parallel()

	t.Run("successful update", func(t *testing.T) {
		ctx := context.Background()
		mockRepo := &MockETCMeisaiRecordRepository{}
		mockTxRepo := &MockETCMeisaiRecordRepository{}
		service := createTestService(mockRepo, nil)
		params := createValidParams()

		existingRecord := &models.ETCMeisaiRecord{
			ID:            1,
			Date:          time.Date(2023, 12, 1, 0, 0, 0, 0, time.UTC),
			Time:          "09:00:00", // Fixed: Use HH:MM:SS format
			EntranceIC:    "大阪IC",
			ExitIC:        "京都IC",
			TollAmount:    800,
			CarNumber:     "DEF-9999",
			ETCCardNumber: "9876543210987654",
		}

		mockRepo.On("BeginTx", ctx).Return(mockTxRepo, nil)
		mockTxRepo.On("GetByID", ctx, int64(1)).Return(existingRecord, nil)
		mockTxRepo.On("CheckDuplicateHash", ctx, mock.AnythingOfType("string"), []int64{1}).Return(false, nil)
		mockTxRepo.On("Update", ctx, mock.AnythingOfType("*models.ETCMeisaiRecord")).Return(nil)
		mockTxRepo.On("CommitTx").Return(nil)

		record, err := service.UpdateRecord(ctx, 1, params)

		require.NoError(t, err)
		assert.NotNil(t, record)
		assert.Equal(t, int64(1), record.ID)
		assert.Equal(t, params.Date, record.Date)
		assert.Equal(t, params.Time, record.Time)
		assert.Equal(t, params.EntranceIC, record.EntranceIC)
		assert.Equal(t, params.ExitIC, record.ExitIC)
		assert.Equal(t, params.TollAmount, record.TollAmount)
		assert.NotEmpty(t, record.Hash)

		mockRepo.AssertExpectations(t)
		mockTxRepo.AssertExpectations(t)
	})

	t.Run("invalid ID", func(t *testing.T) {
		ctx := context.Background()
		mockRepo := &MockETCMeisaiRecordRepository{}
		service := createTestService(mockRepo, nil)
		params := createValidParams()

		tests := []int64{0, -1, -100}
		for _, id := range tests {
			record, err := service.UpdateRecord(ctx, id, params)

			assert.Error(t, err)
			assert.Nil(t, record)
			assert.Contains(t, err.Error(), "invalid record ID")
		}

		mockRepo.AssertExpectations(t)
	})

	t.Run("record not found", func(t *testing.T) {
		ctx := context.Background()
		mockRepo := &MockETCMeisaiRecordRepository{}
		mockTxRepo := &MockETCMeisaiRecordRepository{}
		service := createTestService(mockRepo, nil)
		params := createValidParams()

		mockRepo.On("BeginTx", ctx).Return(mockTxRepo, nil)
		mockTxRepo.On("GetByID", ctx, int64(1)).Return(nil, errors.New("record not found"))
		mockTxRepo.On("RollbackTx").Return(nil)

		record, err := service.UpdateRecord(ctx, 1, params)

		assert.Error(t, err)
		assert.Nil(t, record)
		assert.Contains(t, err.Error(), "failed to retrieve record")
		mockRepo.AssertExpectations(t)
		mockTxRepo.AssertExpectations(t)
	})

	t.Run("validation failure", func(t *testing.T) {
		ctx := context.Background()
		mockRepo := &MockETCMeisaiRecordRepository{}
		mockTxRepo := &MockETCMeisaiRecordRepository{}
		service := createTestService(mockRepo, nil)

		// Invalid params (negative toll amount)
		params := createValidParams()
		params.TollAmount = -100

		existingRecord := &models.ETCMeisaiRecord{
			ID:            1,
			Date:          time.Date(2023, 12, 1, 0, 0, 0, 0, time.UTC),
			Time:          "09:00:00",
			EntranceIC:    "大阪IC",
			ExitIC:        "京都IC",
			TollAmount:    800,
			CarNumber:     "DEF-9999",
			ETCCardNumber: "9876543210987654",
		}

		mockRepo.On("BeginTx", ctx).Return(mockTxRepo, nil)
		mockTxRepo.On("GetByID", ctx, int64(1)).Return(existingRecord, nil)
		mockTxRepo.On("RollbackTx").Return(nil)

		record, err := service.UpdateRecord(ctx, 1, params)

		assert.Error(t, err)
		assert.Nil(t, record)
		assert.Contains(t, err.Error(), "record validation failed")
		mockRepo.AssertExpectations(t)
		mockTxRepo.AssertExpectations(t)
	})

	t.Run("duplicate hash with different record", func(t *testing.T) {
		ctx := context.Background()
		mockRepo := &MockETCMeisaiRecordRepository{}
		mockTxRepo := &MockETCMeisaiRecordRepository{}
		service := createTestService(mockRepo, nil)
		params := createValidParams()

		existingRecord := &models.ETCMeisaiRecord{
			ID:            1,
			Date:          time.Date(2023, 12, 1, 0, 0, 0, 0, time.UTC),
			Time:          "09:00:00",
			EntranceIC:    "大阪IC",
			ExitIC:        "京都IC",
			TollAmount:    800,
			CarNumber:     "DEF-9999",
			ETCCardNumber: "9876543210987654",
		}

		mockRepo.On("BeginTx", ctx).Return(mockTxRepo, nil)
		mockTxRepo.On("GetByID", ctx, int64(1)).Return(existingRecord, nil)
		mockTxRepo.On("CheckDuplicateHash", ctx, mock.AnythingOfType("string"), []int64{1}).Return(true, nil)
		mockTxRepo.On("RollbackTx").Return(nil)

		record, err := service.UpdateRecord(ctx, 1, params)

		assert.Error(t, err)
		assert.Nil(t, record)
		assert.Contains(t, err.Error(), "duplicate record with hash")
		mockRepo.AssertExpectations(t)
		mockTxRepo.AssertExpectations(t)
	})
}

func TestETCMeisaiService_DeleteRecord(t *testing.T) {
	t.Parallel()

	t.Run("successful deletion", func(t *testing.T) {
		ctx := context.Background()
		mockRepo := &MockETCMeisaiRecordRepository{}
		mockTxRepo := &MockETCMeisaiRecordRepository{}
		service := createTestService(mockRepo, nil)

		existingRecord := &models.ETCMeisaiRecord{ID: 1}

		mockRepo.On("BeginTx", ctx).Return(mockTxRepo, nil)
		mockTxRepo.On("GetByID", ctx, int64(1)).Return(existingRecord, nil)
		mockTxRepo.On("Delete", ctx, int64(1)).Return(nil)
		mockTxRepo.On("CommitTx").Return(nil)

		err := service.DeleteRecord(ctx, 1)

		require.NoError(t, err)
		mockRepo.AssertExpectations(t)
		mockTxRepo.AssertExpectations(t)
	})

	t.Run("invalid ID", func(t *testing.T) {
		ctx := context.Background()
		mockRepo := &MockETCMeisaiRecordRepository{}
		service := createTestService(mockRepo, nil)

		tests := []int64{0, -1, -100}
		for _, id := range tests {
			err := service.DeleteRecord(ctx, id)

			assert.Error(t, err)
			assert.Contains(t, err.Error(), "invalid record ID")
		}

		mockRepo.AssertExpectations(t)
	})

	t.Run("record not found", func(t *testing.T) {
		ctx := context.Background()
		mockRepo := &MockETCMeisaiRecordRepository{}
		mockTxRepo := &MockETCMeisaiRecordRepository{}
		service := createTestService(mockRepo, nil)

		mockRepo.On("BeginTx", ctx).Return(mockTxRepo, nil)
		mockTxRepo.On("GetByID", ctx, int64(1)).Return(nil, errors.New("record not found"))
		mockTxRepo.On("RollbackTx").Return(nil)

		err := service.DeleteRecord(ctx, 1)

		assert.Error(t, err)
		assert.Contains(t, err.Error(), "failed to retrieve record")
		mockRepo.AssertExpectations(t)
		mockTxRepo.AssertExpectations(t)
	})

	t.Run("delete operation failure", func(t *testing.T) {
		ctx := context.Background()
		mockRepo := &MockETCMeisaiRecordRepository{}
		mockTxRepo := &MockETCMeisaiRecordRepository{}
		service := createTestService(mockRepo, nil)

		existingRecord := &models.ETCMeisaiRecord{ID: 1}

		mockRepo.On("BeginTx", ctx).Return(mockTxRepo, nil)
		mockTxRepo.On("GetByID", ctx, int64(1)).Return(existingRecord, nil)
		mockTxRepo.On("Delete", ctx, int64(1)).Return(errors.New("delete error"))
		mockTxRepo.On("RollbackTx").Return(nil)

		err := service.DeleteRecord(ctx, 1)

		assert.Error(t, err)
		assert.Contains(t, err.Error(), "failed to delete record")
		mockRepo.AssertExpectations(t)
		mockTxRepo.AssertExpectations(t)
	})
}

func TestETCMeisaiService_GetRecordByHash(t *testing.T) {
	t.Parallel()

	t.Run("successful retrieval", func(t *testing.T) {
		ctx := context.Background()
		mockRepo := &MockETCMeisaiRecordRepository{}
		service := createTestService(mockRepo, nil)

		hash := "test-hash-123"
		expectedRecord := &models.ETCMeisaiRecord{
			ID:   1,
			Hash: hash,
		}

		mockRepo.On("GetByHash", ctx, hash).Return(expectedRecord, nil)

		record, err := service.GetRecordByHash(ctx, hash)

		require.NoError(t, err)
		assert.Equal(t, expectedRecord, record)
		mockRepo.AssertExpectations(t)
	})

	t.Run("empty hash", func(t *testing.T) {
		ctx := context.Background()
		mockRepo := &MockETCMeisaiRecordRepository{}
		service := createTestService(mockRepo, nil)

		record, err := service.GetRecordByHash(ctx, "")

		assert.Error(t, err)
		assert.Nil(t, record)
		assert.Contains(t, err.Error(), "hash cannot be empty")
		mockRepo.AssertExpectations(t)
	})

	t.Run("repository error", func(t *testing.T) {
		ctx := context.Background()
		mockRepo := &MockETCMeisaiRecordRepository{}
		service := createTestService(mockRepo, nil)

		hash := "test-hash-123"
		mockRepo.On("GetByHash", ctx, hash).Return(nil, errors.New("db error"))

		record, err := service.GetRecordByHash(ctx, hash)

		assert.Error(t, err)
		assert.Nil(t, record)
		assert.Contains(t, err.Error(), "failed to retrieve record")
		mockRepo.AssertExpectations(t)
	})
}

func TestETCMeisaiService_ValidateRecord(t *testing.T) {
	t.Parallel()

	t.Run("valid record", func(t *testing.T) {
		ctx := context.Background()
		mockRepo := &MockETCMeisaiRecordRepository{}
		service := createTestService(mockRepo, nil)
		params := createValidParams()

		err := service.ValidateRecord(ctx, params)

		assert.NoError(t, err)
		mockRepo.AssertExpectations(t)
	})

	t.Run("invalid record", func(t *testing.T) {
		ctx := context.Background()
		mockRepo := &MockETCMeisaiRecordRepository{}
		service := createTestService(mockRepo, nil)

		params := createValidParams()
		params.TollAmount = -100 // Invalid

		err := service.ValidateRecord(ctx, params)

		assert.Error(t, err)
		mockRepo.AssertExpectations(t)
	})
}

func TestETCMeisaiService_HealthCheck(t *testing.T) {
	t.Parallel()

	t.Run("healthy service", func(t *testing.T) {
		ctx := context.Background()
		mockRepo := &MockETCMeisaiRecordRepository{}
		service := createTestService(mockRepo, nil)

		mockRepo.On("Ping", ctx).Return(nil)

		err := service.HealthCheck(ctx)

		assert.NoError(t, err)
		mockRepo.AssertExpectations(t)
	})

	t.Run("nil repository", func(t *testing.T) {
		ctx := context.Background()
		service := &ETCMeisaiService{
			repo:   nil,
			logger: log.New(os.Stdout, "[TEST] ", log.LstdFlags),
		}

		err := service.HealthCheck(ctx)

		assert.Error(t, err)
		assert.Contains(t, err.Error(), "repository not initialized")
	})

	t.Run("repository ping failure", func(t *testing.T) {
		ctx := context.Background()
		mockRepo := &MockETCMeisaiRecordRepository{}
		service := createTestService(mockRepo, nil)

		mockRepo.On("Ping", ctx).Return(errors.New("connection failed"))

		err := service.HealthCheck(ctx)

		assert.Error(t, err)
		assert.Contains(t, err.Error(), "repository ping failed")
		mockRepo.AssertExpectations(t)
	})
}

// Additional tests for missing coverage areas
func TestETCMeisaiService_UpdateRecord_AdditionalCoverage(t *testing.T) {
	t.Parallel()

	t.Run("check duplicate hash failure", func(t *testing.T) {
		ctx := context.Background()
		mockRepo := &MockETCMeisaiRecordRepository{}
		mockTxRepo := &MockETCMeisaiRecordRepository{}
		service := createTestService(mockRepo, nil)

		params := createValidParams()
		existingRecord := &models.ETCMeisaiRecord{
			ID:            1,
			Date:          time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
			Time:          "09:00:00",
			EntranceIC:    "大阪IC",
			ExitIC:        "神戸IC",
			TollAmount:    500,
			CarNumber:     "XYZ-9999",
			ETCCardNumber: "9876543210987654",
		}

		mockRepo.On("BeginTx", ctx).Return(mockTxRepo, nil)
		mockTxRepo.On("GetByID", ctx, int64(1)).Return(existingRecord, nil)
		mockTxRepo.On("CheckDuplicateHash", ctx, mock.AnythingOfType("string"), []int64{1}).Return(false, errors.New("check hash error"))
		mockTxRepo.On("RollbackTx").Return(nil)

		record, err := service.UpdateRecord(ctx, 1, params)

		assert.Error(t, err)
		assert.Nil(t, record)
		assert.Contains(t, err.Error(), "failed to check for duplicates")
		mockRepo.AssertExpectations(t)
		mockTxRepo.AssertExpectations(t)
	})

	t.Run("update repository failure", func(t *testing.T) {
		ctx := context.Background()
		mockRepo := &MockETCMeisaiRecordRepository{}
		mockTxRepo := &MockETCMeisaiRecordRepository{}
		service := createTestService(mockRepo, nil)

		params := createValidParams()
		existingRecord := &models.ETCMeisaiRecord{
			ID:            1,
			Date:          time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
			Time:          "09:00:00",
			EntranceIC:    "大阪IC",
			ExitIC:        "神戸IC",
			TollAmount:    500,
			CarNumber:     "XYZ-9999",
			ETCCardNumber: "9876543210987654",
		}

		mockRepo.On("BeginTx", ctx).Return(mockTxRepo, nil)
		mockTxRepo.On("GetByID", ctx, int64(1)).Return(existingRecord, nil)
		mockTxRepo.On("CheckDuplicateHash", ctx, mock.AnythingOfType("string"), []int64{1}).Return(false, nil)
		mockTxRepo.On("Update", ctx, mock.AnythingOfType("*models.ETCMeisaiRecord")).Return(errors.New("update error"))
		mockTxRepo.On("RollbackTx").Return(nil)

		record, err := service.UpdateRecord(ctx, 1, params)

		assert.Error(t, err)
		assert.Nil(t, record)
		assert.Contains(t, err.Error(), "failed to update record")
		mockRepo.AssertExpectations(t)
		mockTxRepo.AssertExpectations(t)
	})

	t.Run("commit transaction failure", func(t *testing.T) {
		ctx := context.Background()
		mockRepo := &MockETCMeisaiRecordRepository{}
		mockTxRepo := &MockETCMeisaiRecordRepository{}
		service := createTestService(mockRepo, nil)

		params := createValidParams()
		existingRecord := &models.ETCMeisaiRecord{
			ID:            1,
			Date:          time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC),
			Time:          "09:00:00",
			EntranceIC:    "大阪IC",
			ExitIC:        "神戸IC",
			TollAmount:    500,
			CarNumber:     "XYZ-9999",
			ETCCardNumber: "9876543210987654",
		}

		mockRepo.On("BeginTx", ctx).Return(mockTxRepo, nil)
		mockTxRepo.On("GetByID", ctx, int64(1)).Return(existingRecord, nil)
		mockTxRepo.On("CheckDuplicateHash", ctx, mock.AnythingOfType("string"), []int64{1}).Return(false, nil)
		mockTxRepo.On("Update", ctx, mock.AnythingOfType("*models.ETCMeisaiRecord")).Return(nil)
		mockTxRepo.On("CommitTx").Return(errors.New("commit error"))

		record, err := service.UpdateRecord(ctx, 1, params)

		assert.Error(t, err)
		assert.Nil(t, record)
		assert.Contains(t, err.Error(), "failed to commit transaction")
		mockRepo.AssertExpectations(t)
		mockTxRepo.AssertExpectations(t)
	})
}
// Additional tests for DeleteRecord missing coverage areas
func TestETCMeisaiService_DeleteRecord_AdditionalCoverage(t *testing.T) {
	t.Parallel()

	t.Run("begin transaction failure", func(t *testing.T) {
		ctx := context.Background()
		mockRepo := &MockETCMeisaiRecordRepository{}
		service := createTestService(mockRepo, nil)

		mockRepo.On("BeginTx", ctx).Return(nil, errors.New("transaction error"))

		err := service.DeleteRecord(ctx, 1)

		assert.Error(t, err)
		assert.Contains(t, err.Error(), "failed to start transaction")
		mockRepo.AssertExpectations(t)
	})

	t.Run("commit transaction failure", func(t *testing.T) {
		ctx := context.Background()
		mockRepo := &MockETCMeisaiRecordRepository{}
		mockTxRepo := &MockETCMeisaiRecordRepository{}
		service := createTestService(mockRepo, nil)

		existingRecord := &models.ETCMeisaiRecord{ID: 1}

		mockRepo.On("BeginTx", ctx).Return(mockTxRepo, nil)
		mockTxRepo.On("GetByID", ctx, int64(1)).Return(existingRecord, nil)
		mockTxRepo.On("Delete", ctx, int64(1)).Return(nil)
		mockTxRepo.On("CommitTx").Return(errors.New("commit error"))

		err := service.DeleteRecord(ctx, 1)

		assert.Error(t, err)
		assert.Contains(t, err.Error(), "failed to commit transaction")
		mockRepo.AssertExpectations(t)
		mockTxRepo.AssertExpectations(t)
	})
}
