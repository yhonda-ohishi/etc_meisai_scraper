package services

import (
	"context"
	"errors"
	"log"
	"os"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"

	"github.com/yhonda-ohishi/etc_meisai/src/models"
	"github.com/yhonda-ohishi/etc_meisai/src/repositories"
)

// MockETCMappingRepository is a mock implementation of ETCMappingRepository
type MockETCMappingRepository struct {
	mock.Mock
}

func (m *MockETCMappingRepository) Create(ctx context.Context, mapping *models.ETCMapping) error {
	args := m.Called(ctx, mapping)
	return args.Error(0)
}

func (m *MockETCMappingRepository) GetByID(ctx context.Context, id int64) (*models.ETCMapping, error) {
	args := m.Called(ctx, id)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*models.ETCMapping), args.Error(1)
}

func (m *MockETCMappingRepository) Update(ctx context.Context, mapping *models.ETCMapping) error {
	args := m.Called(ctx, mapping)
	return args.Error(0)
}

func (m *MockETCMappingRepository) Delete(ctx context.Context, id int64) error {
	args := m.Called(ctx, id)
	return args.Error(0)
}

func (m *MockETCMappingRepository) List(ctx context.Context, params repositories.ListMappingsParams) ([]*models.ETCMapping, int64, error) {
	args := m.Called(ctx, params)
	if args.Get(0) == nil {
		return nil, args.Get(1).(int64), args.Error(2)
	}
	return args.Get(0).([]*models.ETCMapping), args.Get(1).(int64), args.Error(2)
}

func (m *MockETCMappingRepository) GetActiveMapping(ctx context.Context, etcRecordID int64) (*models.ETCMapping, error) {
	args := m.Called(ctx, etcRecordID)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*models.ETCMapping), args.Error(1)
}

func (m *MockETCMappingRepository) GetByETCRecordID(ctx context.Context, etcRecordID int64) ([]*models.ETCMapping, error) {
	args := m.Called(ctx, etcRecordID)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).([]*models.ETCMapping), args.Error(1)
}

func (m *MockETCMappingRepository) GetByMappedEntity(ctx context.Context, entityType string, entityID int64) ([]*models.ETCMapping, error) {
	args := m.Called(ctx, entityType, entityID)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).([]*models.ETCMapping), args.Error(1)
}

func (m *MockETCMappingRepository) BulkCreate(ctx context.Context, mappings []*models.ETCMapping) error {
	args := m.Called(ctx, mappings)
	return args.Error(0)
}

func (m *MockETCMappingRepository) UpdateStatus(ctx context.Context, id int64, status string) error {
	args := m.Called(ctx, id, status)
	return args.Error(0)
}

func (m *MockETCMappingRepository) BeginTx(ctx context.Context) (repositories.ETCMappingRepository, error) {
	args := m.Called(ctx)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(repositories.ETCMappingRepository), args.Error(1)
}

func (m *MockETCMappingRepository) CommitTx() error {
	args := m.Called()
	return args.Error(0)
}

func (m *MockETCMappingRepository) RollbackTx() error {
	args := m.Called()
	return args.Error(0)
}

func (m *MockETCMappingRepository) Ping(ctx context.Context) error {
	args := m.Called(ctx)
	return args.Error(0)
}

// Helper function to create a test service
func createMappingTestService(mappingRepo repositories.ETCMappingRepository, recordRepo repositories.ETCMeisaiRecordRepository, logger *log.Logger) *ETCMappingService {
	if logger == nil {
		logger = log.New(os.Stdout, "[TEST] ", log.LstdFlags)
	}
	return NewETCMappingService(mappingRepo, recordRepo, logger)
}

// Helper function to create valid CreateMappingParams
func createValidMappingParams() *CreateMappingParams {
	return &CreateMappingParams{
		ETCRecordID:      1,
		MappingType:      "AUTOMATIC",
		MappedEntityID:   100,
		MappedEntityType: "DRIVER",
		Confidence:       0.95,
		Status:           string(models.MappingStatusActive),
		CreatedBy:        "test_user",
		Metadata:         map[string]interface{}{"source": "test"},
	}
}

func TestNewETCMappingService(t *testing.T) {
	t.Parallel()

	t.Run("with provided logger", func(t *testing.T) {
		mockMappingRepo := &MockETCMappingRepository{}
		mockRecordRepo := &MockETCMeisaiRecordRepository{}
		logger := log.New(os.Stdout, "[TEST] ", log.LstdFlags)

		service := NewETCMappingService(mockMappingRepo, mockRecordRepo, logger)

		assert.NotNil(t, service)
		assert.Equal(t, logger, service.logger)
	})

	t.Run("with nil logger creates default logger", func(t *testing.T) {
		mockMappingRepo := &MockETCMappingRepository{}
		mockRecordRepo := &MockETCMeisaiRecordRepository{}

		service := NewETCMappingService(mockMappingRepo, mockRecordRepo, nil)

		assert.NotNil(t, service)
		assert.NotNil(t, service.logger)
	})
}

func TestETCMappingService_CreateMapping(t *testing.T) {
	t.Parallel()

	t.Run("successful creation", func(t *testing.T) {
		ctx := context.Background()
		mockMappingRepo := &MockETCMappingRepository{}
		mockTxMappingRepo := &MockETCMappingRepository{}
		mockRecordRepo := &MockETCMeisaiRecordRepository{}
		service := createMappingTestService(mockMappingRepo, mockRecordRepo, nil)
		params := createValidMappingParams()

		existingRecord := &models.ETCMeisaiRecord{ID: 1}

		mockMappingRepo.On("BeginTx", ctx).Return(mockTxMappingRepo, nil)
		mockRecordRepo.On("GetByID", ctx, int64(1)).Return(existingRecord, nil)
		mockTxMappingRepo.On("GetActiveMapping", ctx, int64(1)).Return(nil, errors.New("no active mapping"))
		mockTxMappingRepo.On("Create", ctx, mock.AnythingOfType("*models.ETCMapping")).Return(nil).Run(func(args mock.Arguments) {
			mapping := args.Get(1).(*models.ETCMapping)
			mapping.ID = 1 // Simulate ID assignment
		})
		mockTxMappingRepo.On("CommitTx").Return(nil)

		mapping, err := service.CreateMapping(ctx, params)

		require.NoError(t, err)
		assert.NotNil(t, mapping)
		assert.Equal(t, int64(1), mapping.ID)
		assert.Equal(t, params.ETCRecordID, mapping.ETCRecordID)
		assert.Equal(t, params.MappingType, mapping.MappingType)
		assert.Equal(t, params.MappedEntityID, mapping.MappedEntityID)
		assert.Equal(t, params.MappedEntityType, mapping.MappedEntityType)
		assert.Equal(t, params.Confidence, mapping.Confidence)
		assert.Equal(t, params.Status, mapping.Status)
		assert.Equal(t, params.CreatedBy, mapping.CreatedBy)

		mockMappingRepo.AssertExpectations(t)
		mockTxMappingRepo.AssertExpectations(t)
		mockRecordRepo.AssertExpectations(t)
	})

	t.Run("default confidence and status", func(t *testing.T) {
		ctx := context.Background()
		mockMappingRepo := &MockETCMappingRepository{}
		mockTxMappingRepo := &MockETCMappingRepository{}
		mockRecordRepo := &MockETCMeisaiRecordRepository{}
		service := createMappingTestService(mockMappingRepo, mockRecordRepo, nil)

		params := createValidMappingParams()
		params.Confidence = 0   // Should default to 1.0
		params.Status = ""      // Should default to "active"

		existingRecord := &models.ETCMeisaiRecord{ID: 1}

		mockMappingRepo.On("BeginTx", ctx).Return(mockTxMappingRepo, nil)
		mockRecordRepo.On("GetByID", ctx, int64(1)).Return(existingRecord, nil)
		mockTxMappingRepo.On("GetActiveMapping", ctx, int64(1)).Return(nil, errors.New("no active mapping"))
		mockTxMappingRepo.On("Create", ctx, mock.AnythingOfType("*models.ETCMapping")).Return(nil).Run(func(args mock.Arguments) {
			mapping := args.Get(1).(*models.ETCMapping)
			mapping.ID = 1
			assert.Equal(t, float32(1.0), mapping.Confidence)
			assert.Equal(t, string(models.MappingStatusActive), mapping.Status)
		})
		mockTxMappingRepo.On("CommitTx").Return(nil)

		mapping, err := service.CreateMapping(ctx, params)

		require.NoError(t, err)
		assert.NotNil(t, mapping)
		mockMappingRepo.AssertExpectations(t)
		mockTxMappingRepo.AssertExpectations(t)
		mockRecordRepo.AssertExpectations(t)
	})

	t.Run("metadata set failure", func(t *testing.T) {
		ctx := context.Background()
		mockMappingRepo := &MockETCMappingRepository{}
		mockRecordRepo := &MockETCMeisaiRecordRepository{}
		service := createMappingTestService(mockMappingRepo, mockRecordRepo, nil)

		params := createValidMappingParams()
		params.Metadata = map[string]interface{}{
			"invalid": make(chan int), // Unsupported type that will cause JSON marshal error
		}

		mapping, err := service.CreateMapping(ctx, params)

		assert.Error(t, err)
		assert.Nil(t, mapping)
		assert.Contains(t, err.Error(), "failed to set metadata")
		mockMappingRepo.AssertExpectations(t)
		mockRecordRepo.AssertExpectations(t)
	})

	t.Run("begin transaction failure", func(t *testing.T) {
		ctx := context.Background()
		mockMappingRepo := &MockETCMappingRepository{}
		mockRecordRepo := &MockETCMeisaiRecordRepository{}
		service := createMappingTestService(mockMappingRepo, mockRecordRepo, nil)
		params := createValidMappingParams()

		mockMappingRepo.On("BeginTx", ctx).Return(nil, errors.New("transaction error"))

		mapping, err := service.CreateMapping(ctx, params)

		assert.Error(t, err)
		assert.Nil(t, mapping)
		assert.Contains(t, err.Error(), "failed to start transaction")
		mockMappingRepo.AssertExpectations(t)
		mockRecordRepo.AssertExpectations(t)
	})

	t.Run("ETC record not found", func(t *testing.T) {
		ctx := context.Background()
		mockMappingRepo := &MockETCMappingRepository{}
		mockTxMappingRepo := &MockETCMappingRepository{}
		mockRecordRepo := &MockETCMeisaiRecordRepository{}
		service := createMappingTestService(mockMappingRepo, mockRecordRepo, nil)
		params := createValidMappingParams()

		mockMappingRepo.On("BeginTx", ctx).Return(mockTxMappingRepo, nil)
		mockRecordRepo.On("GetByID", ctx, int64(1)).Return(nil, errors.New("record not found"))
		mockTxMappingRepo.On("RollbackTx").Return(nil)

		mapping, err := service.CreateMapping(ctx, params)

		assert.Error(t, err)
		assert.Nil(t, mapping)
		assert.Contains(t, err.Error(), "ETC record not found with ID 1")
		mockMappingRepo.AssertExpectations(t)
		mockTxMappingRepo.AssertExpectations(t)
		mockRecordRepo.AssertExpectations(t)
	})

	t.Run("active mapping already exists", func(t *testing.T) {
		ctx := context.Background()
		mockMappingRepo := &MockETCMappingRepository{}
		mockTxMappingRepo := &MockETCMappingRepository{}
		mockRecordRepo := &MockETCMeisaiRecordRepository{}
		service := createMappingTestService(mockMappingRepo, mockRecordRepo, nil)
		params := createValidMappingParams()

		existingRecord := &models.ETCMeisaiRecord{ID: 1}
		existingMapping := &models.ETCMapping{ID: 2, ETCRecordID: 1}

		mockMappingRepo.On("BeginTx", ctx).Return(mockTxMappingRepo, nil)
		mockRecordRepo.On("GetByID", ctx, int64(1)).Return(existingRecord, nil)
		mockTxMappingRepo.On("GetActiveMapping", ctx, int64(1)).Return(existingMapping, nil)
		mockTxMappingRepo.On("RollbackTx").Return(nil)

		mapping, err := service.CreateMapping(ctx, params)

		assert.Error(t, err)
		assert.Nil(t, mapping)
		assert.Contains(t, err.Error(), "active mapping already exists for ETC record 1")
		mockMappingRepo.AssertExpectations(t)
		mockTxMappingRepo.AssertExpectations(t)
		mockRecordRepo.AssertExpectations(t)
	})

	t.Run("create mapping failure", func(t *testing.T) {
		ctx := context.Background()
		mockMappingRepo := &MockETCMappingRepository{}
		mockTxMappingRepo := &MockETCMappingRepository{}
		mockRecordRepo := &MockETCMeisaiRecordRepository{}
		service := createMappingTestService(mockMappingRepo, mockRecordRepo, nil)
		params := createValidMappingParams()

		existingRecord := &models.ETCMeisaiRecord{ID: 1}

		mockMappingRepo.On("BeginTx", ctx).Return(mockTxMappingRepo, nil)
		mockRecordRepo.On("GetByID", ctx, int64(1)).Return(existingRecord, nil)
		mockTxMappingRepo.On("GetActiveMapping", ctx, int64(1)).Return(nil, errors.New("no active mapping"))
		mockTxMappingRepo.On("Create", ctx, mock.AnythingOfType("*models.ETCMapping")).Return(errors.New("create error"))
		mockTxMappingRepo.On("RollbackTx").Return(nil)

		mapping, err := service.CreateMapping(ctx, params)

		assert.Error(t, err)
		assert.Nil(t, mapping)
		assert.Contains(t, err.Error(), "failed to create mapping")
		mockMappingRepo.AssertExpectations(t)
		mockTxMappingRepo.AssertExpectations(t)
		mockRecordRepo.AssertExpectations(t)
	})

	t.Run("commit transaction failure", func(t *testing.T) {
		ctx := context.Background()
		mockMappingRepo := &MockETCMappingRepository{}
		mockTxMappingRepo := &MockETCMappingRepository{}
		mockRecordRepo := &MockETCMeisaiRecordRepository{}
		service := createMappingTestService(mockMappingRepo, mockRecordRepo, nil)
		params := createValidMappingParams()

		existingRecord := &models.ETCMeisaiRecord{ID: 1}

		mockMappingRepo.On("BeginTx", ctx).Return(mockTxMappingRepo, nil)
		mockRecordRepo.On("GetByID", ctx, int64(1)).Return(existingRecord, nil)
		mockTxMappingRepo.On("GetActiveMapping", ctx, int64(1)).Return(nil, errors.New("no active mapping"))
		mockTxMappingRepo.On("Create", ctx, mock.AnythingOfType("*models.ETCMapping")).Return(nil)
		mockTxMappingRepo.On("CommitTx").Return(errors.New("commit error"))

		mapping, err := service.CreateMapping(ctx, params)

		assert.Error(t, err)
		assert.Nil(t, mapping)
		assert.Contains(t, err.Error(), "failed to commit transaction")
		mockMappingRepo.AssertExpectations(t)
		mockTxMappingRepo.AssertExpectations(t)
		mockRecordRepo.AssertExpectations(t)
	})
}

func TestETCMappingService_GetMapping(t *testing.T) {
	t.Parallel()

	t.Run("successful retrieval", func(t *testing.T) {
		ctx := context.Background()
		mockMappingRepo := &MockETCMappingRepository{}
		mockRecordRepo := &MockETCMeisaiRecordRepository{}
		service := createMappingTestService(mockMappingRepo, mockRecordRepo, nil)

		expectedMapping := &models.ETCMapping{
			ID:               1,
			ETCRecordID:      1,
			MappingType:      "AUTOMATIC",
			MappedEntityID:   100,
			MappedEntityType: "DRIVER",
			Confidence:       0.95,
			Status:           string(models.MappingStatusActive),
		}

		mockMappingRepo.On("GetByID", ctx, int64(1)).Return(expectedMapping, nil)

		mapping, err := service.GetMapping(ctx, 1)

		require.NoError(t, err)
		assert.Equal(t, expectedMapping, mapping)
		mockMappingRepo.AssertExpectations(t)
		mockRecordRepo.AssertExpectations(t)
	})

	t.Run("invalid ID", func(t *testing.T) {
		ctx := context.Background()
		mockMappingRepo := &MockETCMappingRepository{}
		mockRecordRepo := &MockETCMeisaiRecordRepository{}
		service := createMappingTestService(mockMappingRepo, mockRecordRepo, nil)

		tests := []int64{0, -1, -100}
		for _, id := range tests {
			mapping, err := service.GetMapping(ctx, id)

			assert.Error(t, err)
			assert.Nil(t, mapping)
			assert.Contains(t, err.Error(), "invalid mapping ID")
		}

		mockMappingRepo.AssertExpectations(t)
		mockRecordRepo.AssertExpectations(t)
	})

	t.Run("repository error", func(t *testing.T) {
		ctx := context.Background()
		mockMappingRepo := &MockETCMappingRepository{}
		mockRecordRepo := &MockETCMeisaiRecordRepository{}
		service := createMappingTestService(mockMappingRepo, mockRecordRepo, nil)

		mockMappingRepo.On("GetByID", ctx, int64(1)).Return(nil, errors.New("db error"))

		mapping, err := service.GetMapping(ctx, 1)

		assert.Error(t, err)
		assert.Nil(t, mapping)
		assert.Contains(t, err.Error(), "failed to retrieve mapping")
		mockMappingRepo.AssertExpectations(t)
		mockRecordRepo.AssertExpectations(t)
	})
}

func TestETCMappingService_ListMappings(t *testing.T) {
	t.Parallel()

	t.Run("successful listing with defaults", func(t *testing.T) {
		ctx := context.Background()
		mockMappingRepo := &MockETCMappingRepository{}
		mockRecordRepo := &MockETCMeisaiRecordRepository{}
		service := createMappingTestService(mockMappingRepo, mockRecordRepo, nil)

		params := &ListMappingsParams{}
		expectedMappings := []*models.ETCMapping{
			{ID: 1, ETCRecordID: 1},
			{ID: 2, ETCRecordID: 2},
		}

		mockMappingRepo.On("List", ctx, mock.MatchedBy(func(p repositories.ListMappingsParams) bool {
			return p.Page == 1 && p.PageSize == 50 && p.SortBy == "created_at" && p.SortOrder == "desc"
		})).Return(expectedMappings, int64(2), nil)

		response, err := service.ListMappings(ctx, params)

		require.NoError(t, err)
		assert.NotNil(t, response)
		assert.Equal(t, expectedMappings, response.Mappings)
		assert.Equal(t, int64(2), response.TotalCount)
		assert.Equal(t, 1, response.Page)
		assert.Equal(t, 50, response.PageSize)
		assert.Equal(t, 1, response.TotalPages)
		mockMappingRepo.AssertExpectations(t)
		mockRecordRepo.AssertExpectations(t)
	})

	t.Run("custom parameters", func(t *testing.T) {
		ctx := context.Background()
		mockMappingRepo := &MockETCMappingRepository{}
		mockRecordRepo := &MockETCMeisaiRecordRepository{}
		service := createMappingTestService(mockMappingRepo, mockRecordRepo, nil)

		mappingType := "MANUAL"
		params := &ListMappingsParams{
			Page:        2,
			PageSize:    25,
			MappingType: &mappingType,
			SortBy:      "confidence",
			SortOrder:   "asc",
		}

		expectedMappings := []*models.ETCMapping{
			{ID: 3, MappingType: "MANUAL"},
		}

		mockMappingRepo.On("List", ctx, mock.MatchedBy(func(p repositories.ListMappingsParams) bool {
			return p.Page == 2 && p.PageSize == 25 && p.SortBy == "confidence" && p.SortOrder == "asc" &&
				p.MappingType != nil && *p.MappingType == mappingType
		})).Return(expectedMappings, int64(100), nil)

		response, err := service.ListMappings(ctx, params)

		require.NoError(t, err)
		assert.NotNil(t, response)
		assert.Equal(t, expectedMappings, response.Mappings)
		assert.Equal(t, int64(100), response.TotalCount)
		assert.Equal(t, 2, response.Page)
		assert.Equal(t, 25, response.PageSize)
		assert.Equal(t, 4, response.TotalPages) // 100/25 = 4
		mockMappingRepo.AssertExpectations(t)
		mockRecordRepo.AssertExpectations(t)
	})

	t.Run("page size limit enforcement", func(t *testing.T) {
		ctx := context.Background()
		mockMappingRepo := &MockETCMappingRepository{}
		mockRecordRepo := &MockETCMeisaiRecordRepository{}
		service := createMappingTestService(mockMappingRepo, mockRecordRepo, nil)

		params := &ListMappingsParams{
			PageSize: 2000, // Above limit
		}

		mockMappingRepo.On("List", ctx, mock.MatchedBy(func(p repositories.ListMappingsParams) bool {
			return p.PageSize == 1000 // Should be limited to 1000
		})).Return([]*models.ETCMapping{}, int64(0), nil)

		response, err := service.ListMappings(ctx, params)

		require.NoError(t, err)
		assert.Equal(t, 1000, response.PageSize)
		mockMappingRepo.AssertExpectations(t)
		mockRecordRepo.AssertExpectations(t)
	})

	t.Run("repository error", func(t *testing.T) {
		ctx := context.Background()
		mockMappingRepo := &MockETCMappingRepository{}
		mockRecordRepo := &MockETCMeisaiRecordRepository{}
		service := createMappingTestService(mockMappingRepo, mockRecordRepo, nil)

		params := &ListMappingsParams{}

		mockMappingRepo.On("List", ctx, mock.AnythingOfType("repositories.ListMappingsParams")).Return(nil, int64(0), errors.New("db error"))

		response, err := service.ListMappings(ctx, params)

		assert.Error(t, err)
		assert.Nil(t, response)
		assert.Contains(t, err.Error(), "failed to retrieve mappings")
		mockMappingRepo.AssertExpectations(t)
		mockRecordRepo.AssertExpectations(t)
	})
}
func TestETCMappingService_UpdateMapping(t *testing.T) {
	t.Parallel()

	t.Run("successful update", func(t *testing.T) {
		ctx := context.Background()
		mockMappingRepo := &MockETCMappingRepository{}
		mockTxMappingRepo := &MockETCMappingRepository{}
		mockRecordRepo := &MockETCMeisaiRecordRepository{}
		service := createMappingTestService(mockMappingRepo, mockRecordRepo, nil)

		existingMapping := &models.ETCMapping{
			ID:               1,
			ETCRecordID:      1,
			MappingType:      "AUTOMATIC",
			MappedEntityID:   100,
			MappedEntityType: "DRIVER",
			Confidence:       0.8,
			Status:           string(models.MappingStatusActive),
		}

		newMappingType := "MANUAL"
		newConfidence := float32(0.95)
		params := &UpdateMappingParams{
			MappingType: &newMappingType,
			Confidence:  &newConfidence,
		}

		mockMappingRepo.On("BeginTx", ctx).Return(mockTxMappingRepo, nil)
		mockTxMappingRepo.On("GetByID", ctx, int64(1)).Return(existingMapping, nil)
		mockTxMappingRepo.On("Update", ctx, mock.AnythingOfType("*models.ETCMapping")).Return(nil)
		mockTxMappingRepo.On("CommitTx").Return(nil)

		mapping, err := service.UpdateMapping(ctx, 1, params)

		require.NoError(t, err)
		assert.NotNil(t, mapping)
		assert.Equal(t, newMappingType, mapping.MappingType)
		assert.Equal(t, newConfidence, mapping.Confidence)
		mockMappingRepo.AssertExpectations(t)
		mockTxMappingRepo.AssertExpectations(t)
		mockRecordRepo.AssertExpectations(t)
	})

	t.Run("invalid ID", func(t *testing.T) {
		ctx := context.Background()
		mockMappingRepo := &MockETCMappingRepository{}
		mockRecordRepo := &MockETCMeisaiRecordRepository{}
		service := createMappingTestService(mockMappingRepo, mockRecordRepo, nil)

		params := &UpdateMappingParams{}
		tests := []int64{0, -1, -100}
		for _, id := range tests {
			mapping, err := service.UpdateMapping(ctx, id, params)

			assert.Error(t, err)
			assert.Nil(t, mapping)
			assert.Contains(t, err.Error(), "invalid mapping ID")
		}

		mockMappingRepo.AssertExpectations(t)
		mockRecordRepo.AssertExpectations(t)
	})

	t.Run("begin transaction failure", func(t *testing.T) {
		ctx := context.Background()
		mockMappingRepo := &MockETCMappingRepository{}
		mockRecordRepo := &MockETCMeisaiRecordRepository{}
		service := createMappingTestService(mockMappingRepo, mockRecordRepo, nil)

		params := &UpdateMappingParams{}
		mockMappingRepo.On("BeginTx", ctx).Return(nil, errors.New("transaction error"))

		mapping, err := service.UpdateMapping(ctx, 1, params)

		assert.Error(t, err)
		assert.Nil(t, mapping)
		assert.Contains(t, err.Error(), "failed to start transaction")
		mockMappingRepo.AssertExpectations(t)
		mockRecordRepo.AssertExpectations(t)
	})

	t.Run("mapping not found", func(t *testing.T) {
		ctx := context.Background()
		mockMappingRepo := &MockETCMappingRepository{}
		mockTxMappingRepo := &MockETCMappingRepository{}
		mockRecordRepo := &MockETCMeisaiRecordRepository{}
		service := createMappingTestService(mockMappingRepo, mockRecordRepo, nil)

		params := &UpdateMappingParams{}
		mockMappingRepo.On("BeginTx", ctx).Return(mockTxMappingRepo, nil)
		mockTxMappingRepo.On("GetByID", ctx, int64(1)).Return(nil, errors.New("mapping not found"))
		mockTxMappingRepo.On("RollbackTx").Return(nil)

		mapping, err := service.UpdateMapping(ctx, 1, params)

		assert.Error(t, err)
		assert.Nil(t, mapping)
		assert.Contains(t, err.Error(), "failed to retrieve mapping")
		mockMappingRepo.AssertExpectations(t)
		mockTxMappingRepo.AssertExpectations(t)
		mockRecordRepo.AssertExpectations(t)
	})

	t.Run("metadata set failure", func(t *testing.T) {
		ctx := context.Background()
		mockMappingRepo := &MockETCMappingRepository{}
		mockTxMappingRepo := &MockETCMappingRepository{}
		mockRecordRepo := &MockETCMeisaiRecordRepository{}
		service := createMappingTestService(mockMappingRepo, mockRecordRepo, nil)

		existingMapping := &models.ETCMapping{ID: 1}
		params := &UpdateMappingParams{
			Metadata: map[string]interface{}{
				"invalid": make(chan int),
			},
		}

		mockMappingRepo.On("BeginTx", ctx).Return(mockTxMappingRepo, nil)
		mockTxMappingRepo.On("GetByID", ctx, int64(1)).Return(existingMapping, nil)
		mockTxMappingRepo.On("RollbackTx").Return(nil)

		mapping, err := service.UpdateMapping(ctx, 1, params)

		assert.Error(t, err)
		assert.Nil(t, mapping)
		assert.Contains(t, err.Error(), "failed to set metadata")
		mockMappingRepo.AssertExpectations(t)
		mockTxMappingRepo.AssertExpectations(t)
		mockRecordRepo.AssertExpectations(t)
	})

	t.Run("update failure", func(t *testing.T) {
		ctx := context.Background()
		mockMappingRepo := &MockETCMappingRepository{}
		mockTxMappingRepo := &MockETCMappingRepository{}
		mockRecordRepo := &MockETCMeisaiRecordRepository{}
		service := createMappingTestService(mockMappingRepo, mockRecordRepo, nil)

		existingMapping := &models.ETCMapping{ID: 1}
		params := &UpdateMappingParams{}

		mockMappingRepo.On("BeginTx", ctx).Return(mockTxMappingRepo, nil)
		mockTxMappingRepo.On("GetByID", ctx, int64(1)).Return(existingMapping, nil)
		mockTxMappingRepo.On("Update", ctx, mock.AnythingOfType("*models.ETCMapping")).Return(errors.New("update error"))
		mockTxMappingRepo.On("RollbackTx").Return(nil)

		mapping, err := service.UpdateMapping(ctx, 1, params)

		assert.Error(t, err)
		assert.Nil(t, mapping)
		assert.Contains(t, err.Error(), "failed to update mapping")
		mockMappingRepo.AssertExpectations(t)
		mockTxMappingRepo.AssertExpectations(t)
		mockRecordRepo.AssertExpectations(t)
	})

	t.Run("commit failure", func(t *testing.T) {
		ctx := context.Background()
		mockMappingRepo := &MockETCMappingRepository{}
		mockTxMappingRepo := &MockETCMappingRepository{}
		mockRecordRepo := &MockETCMeisaiRecordRepository{}
		service := createMappingTestService(mockMappingRepo, mockRecordRepo, nil)

		existingMapping := &models.ETCMapping{ID: 1}
		params := &UpdateMappingParams{}

		mockMappingRepo.On("BeginTx", ctx).Return(mockTxMappingRepo, nil)
		mockTxMappingRepo.On("GetByID", ctx, int64(1)).Return(existingMapping, nil)
		mockTxMappingRepo.On("Update", ctx, mock.AnythingOfType("*models.ETCMapping")).Return(nil)
		mockTxMappingRepo.On("CommitTx").Return(errors.New("commit error"))

		mapping, err := service.UpdateMapping(ctx, 1, params)

		assert.Error(t, err)
		assert.Nil(t, mapping)
		assert.Contains(t, err.Error(), "failed to commit transaction")
		mockMappingRepo.AssertExpectations(t)
		mockTxMappingRepo.AssertExpectations(t)
		mockRecordRepo.AssertExpectations(t)
	})
}
